# Ücretsiz sürüm devir notu

Önce README.md, TEST_REPORT.md ve docs/HIZ_VE_BILDIRIM.md oku. Bu kaynak 1.1.3 yükleme/mesaj/bildirim güncellemesidir. Firebase Blaze kullanma. Firebase Authentication hesapları korunur; sosyal kayıtlar Supabase PostgreSQL, özel medya Storage, API Edge Function olur. Proje qinevhhhdtslnzrtcanq; yapılandırma supabase/ içinde, sunucu dağıtımı scripts/deploy-free.cjs üzerinden.

Paket com.birarada.app; versionName1.1.3/versionCode5. Mevcut EAS @ahmedberat/birarada / 9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b ve mevcut keystore korunmalı. Eski AAB yeni ücretsiz kodları içermez. Play'e bir dosya sonradan yüklendiyse en yüksek versionCode'u tekrar doğrula.

Kimlik Google imzalı Firebase JWT + güncel hesap lookup ile doğrulanır. Anonim DB/RPC ve Storage erişimi kapalı; yalnız Edge service role kullanır. verify_jwt=false özel Firebase doğrulaması içindir; anonim API erişimi değildir. Emulator kimlik doğrulaması sadece scripts/free-local-server.mts içindedir; üretim girişine taşıma. Tests/free-harness.ts yerel motoru kurduğu için kaynak paketinde gerekir.

Kaynakta özel anahtar, parola veya oturum tokenı yoktur; sağlayıcıların resmî girişini kullan. Supabase hesabı oluşturulmuştur, bu çalışma ortamında yetkili Supabase/Expo/Firebase oturumu yoktur. Canlı şema/Edge/politika dağıtımı, owner etkinleştirme, gerçek cihaz/push ve son imzalı AAB/16KB kontrolü tamamlanmadan yayıma hazır deme. Fotoğraflar JPEG'e çevrilir; videolar H264 MP4, sesler AAC M4A olmalı. Ücretsiz sunucuda FFmpeg dönüşümü yoktur. Önceki Firestore verileri otomatik taşınmaz veya silinmez.

Mevcut sunucu kuruludur; bu güncellemede `npm run backend:update` yalnız Edge Function revizyonunu `2026-10-27-instant1` yapar. `db push`/`link` ve yeni DB parolası gerekmez. Önceki kaynak adayı code4 kullanıyordu. Eski kaynak test raporlarını yeni başarı kanıtı olarak kullanma; güncel raporda yerel/üretim ayrımı vardır. Sesli/görüntülü arama, canlı yayın ve lisanslı müzik kataloğu uygulanmadı.

Android push yapılandırması npm run notifications:setup ile resmî Firebase CLI üzerinden alınır. EAS FCM v1 yetkisi BILDIRIM_KUR.bat ile kontrol edilir; gizli anahtarlar ZIP veya GitHub içine eklenmez. Push taşıma testleri gerçek telefon teslimi sayılmaz; operatör SMS yoktur.
