export type ReadResult<T> = {
  data?: T;
  error?: { code: string; message: string };
};
type Pending<T> = {
  scope: string;
  input: unknown;
  resolve: (value: T) => void;
  reject: (e: unknown) => void;
};
// Bound both request size and transport concurrency; keep errors isolated per read.
export function createReadBatcher<T>(
  send: (scope: string, inputs: unknown[]) => Promise<ReadResult<T>[]>,
  isCurrent: (scope: string) => boolean,
  { delay = 12, maximum = 8, concurrency = 2 } = {},
) {
  const queue: Pending<T>[] = [];
  let active = 0,
    timer: ReturnType<typeof setTimeout> | undefined;
  const sessionError = () =>
    Object.assign(Error("Oturum değişti."), { code: "unauthenticated" });
  const schedule = () => {
    if (!timer && queue.length && active < concurrency)
      timer = setTimeout(flush, delay);
  };
  const flush = () => {
    timer = undefined;
    while (active < concurrency && queue.length) {
      const scope = queue[0]!.scope,
        batch: Pending<T>[] = [];
      for (let i = 0; i < queue.length && batch.length < maximum; ) {
        if (queue[i]!.scope === scope) batch.push(queue.splice(i, 1)[0]!);
        else i++;
      }
      if (!isCurrent(scope)) {
        batch.forEach((item) => item.reject(sessionError()));
        continue;
      }
      active++;
      void Promise.resolve()
        .then(() =>
          send(
            scope,
            batch.map((item) => item.input),
          ),
        )
        .then((results) => {
          if (!Array.isArray(results) || results.length !== batch.length)
            throw Error("Sunucu yanıtı tamamlanamadı.");
          batch.forEach((item, i) => {
            if (!isCurrent(scope)) {
              item.reject(sessionError());
              return;
            }
            const result = results[i]!;
            if (result.error)
              item.reject(
                Object.assign(Error(result.error.message), {
                  code: result.error.code,
                }),
              );
            else item.resolve(result.data!);
          });
        })
        .catch((e) => batch.forEach((item) => item.reject(e)))
        .finally(() => {
          active--;
          schedule();
        });
    }
  };
  return (scope: string, input: unknown) =>
    new Promise<T>((resolve, reject) => {
      queue.push({ scope, input, resolve, reject });
      schedule();
    });
}
