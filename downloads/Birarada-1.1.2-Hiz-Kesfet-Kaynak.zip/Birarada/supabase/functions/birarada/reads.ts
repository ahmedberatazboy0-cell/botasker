import { type Actor, InputError } from "./domain.ts";
import { HttpsError } from "./context.ts";
import { Query, Records, type Snapshot } from "./records.ts";
import { canRead } from "./policy.ts";
import {
  cachedRecord,
  primeRecords,
  primeVisibility,
  seedReadRecords,
  withReadCache,
} from "./core.ts";
async function preparePermissions(actor: Actor, rows: Snapshot[]) {
  const parents = [
    ...new Set(
      rows
        .map((row) => {
          const p = row.raw.path.split("/");
          return p.length === 4 && ["posts", "chats"].includes(p[0]!)
            ? p.slice(0, 2).join("/")
            : "";
        })
        .filter(Boolean),
    ),
  ];
  await primeRecords([
    `users/${actor.uid}`,
    `accountStatus/${actor.uid}`,
    ...parents,
  ]);
  const posts = rows
    .filter(
      (row) =>
        row.raw.path.startsWith("posts/") &&
        row.raw.path.split("/").length === 2,
    )
    .map((row) => row.data())
    .filter(Boolean);
  for (const path of parents.filter((path) => path.startsWith("posts/"))) {
    const post = await cachedRecord(path);
    if (post) posts.push(post);
  }
  await primeVisibility(actor.uid, posts as any[]);
}
async function read(
  actor: Actor,
  input: any,
  records: Records,
): Promise<any[]> {
  if (input.operation === "get") {
    if (!Array.isArray(input.paths) || input.paths.length > 100) {
      throw new InputError("Geçersiz kayıt listesi.");
    }
    const rows = await records.getAll(
      ...input.paths.map((p: string) => records.doc(p)),
    );
    seedReadRecords(rows);
    await preparePermissions(actor, rows);
    for (const row of rows) {
      if (!(await canRead(actor, row.raw.path, row.data()))) {
        throw new HttpsError("permission-denied", "Bu kayıt görünür değil.");
      }
    }
    return rows.map((r: any) => r.raw);
  } else if (input.operation === "query") {
    const spec = input.spec;
    if (
      !spec ||
      typeof spec.path !== "string" ||
      !Array.isArray(spec.filters) ||
      spec.filters.length > 10 ||
      !Array.isArray(spec.orders) ||
      spec.orders.length > 3 ||
      spec.limit > 500 ||
      (spec.group && !["likes", "comments", "messages"].includes(spec.path))
    )
      throw new InputError("Geçersiz sorgu.");
    const roots = spec.path.split("/");
    if (
      ![
        "users",
        "usernames",
        "posts",
        "notes",
        "follows",
        "chats",
        "saved",
        "notifications",
        "reports",
      ].includes(roots[0]) &&
      !spec.group
    ) {
      throw new HttpsError("permission-denied", "Bu listeye erişilemez.");
    }
    let q = new Query(records, spec.path, spec.group === true);
    for (const [f, op, v] of spec.filters) {
      if (
        typeof f !== "string" ||
        !["==", "!=", ">", ">=", "<", "<=", "array-contains", "in"].includes(op)
      )
        throw new InputError("Geçersiz sorgu.");
      q = q.where(f, op, v);
    }
    for (const [f, d] of spec.orders) {
      if (typeof f !== "string" || !["asc", "desc"].includes(d)) {
        throw new InputError("Geçersiz sıralama.");
      }
      q = q.orderBy(f, d);
    }
    q = q.limit(Math.min(Number(spec.limit) || 50, 500));
    if (spec.bounds) q.bounds = spec.bounds;
    const rows = await q.get(),
      visible = [];
    seedReadRecords(rows.docs);
    await preparePermissions(actor, rows.docs);
    for (const row of rows.docs) {
      if (await canRead(actor, row.raw.path, row.data())) {
        visible.push(row.raw);
      }
    }
    return visible;
  }
  throw new InputError("Geçersiz okuma işlemi.");
}
export async function readDocuments(
  actor: Actor,
  input: any,
  records: Records,
) {
  return withReadCache(async () => {
    if (input.operation !== "batch") return read(actor, input, records);
    const items = input.items;
    if (
      !Array.isArray(items) ||
      !items.length ||
      items.length > 8 ||
      items.some((item) => !item || !["get", "query"].includes(item.operation))
    )
      throw new InputError("Toplu okuma en fazla 8 okuma işlemi içerebilir.");
    return Promise.all(
      items.map(async (item) => {
        try {
          return { data: await read(actor, item, records) };
        } catch (e) {
          return {
            error: {
              code:
                e instanceof HttpsError
                  ? e.code
                  : e instanceof InputError
                    ? "invalid-argument"
                    : "unavailable",
              message:
                e instanceof HttpsError || e instanceof InputError
                  ? e.message
                  : "Okuma tamamlanamadı. Yeniden dene.",
            },
          };
        }
      }),
    );
  });
}
