# Birarada 1.1.2 — hız ve keşfet

25 Ekim 2026. Paket `com.birarada.app`; sürüm **1.1.2 / versionCode4**. Mevcut EAS projesi ve upload keystore korunur. Yeni Edge revizyonu `2026-10-25-performance1`. DB şeması değişmez.

## Sorun ve düzeltme

Önceki sürümün sosyal API akışı toplu yetki okumaları yapıyordu; genel belge/listeler için kullanılan ayrı uç aynı tekrarları hâlâ yapıyordu. Bir beğeni/yorum listesindeki her satırda kullanıcı, hesap durumu, üst gönderi, takip ve engel kayıtları tekrar okunabiliyordu. Bu, küçük yerel DB'de gizlenen ama gerçek ağ gecikmesiyle büyüyen bir maliyetti.

Yeni ortak okuma yolu bu kayıtları **yalnız aynı HTTP isteği içinde** tekrar kullanır. Oturum, rol ve kısıtlama kayıtları tek DB çağrısında, yollarıyla eşleştirilerek alınır; sıralamaya güvenilmez. Google JWT ve geçerli Firebase hesabı doğrulaması kaldırılmadı. Yeni istekte rol, engel ve kısıtlama yeniden okunur; istekler arası yetki önbelleği yoktur.

İstemci aynı hesabın eşzamanlı okumalarını en fazla **8 okuma / 2 eşzamanlı HTTP isteği** ile birleştirir. Tekil işlemler eski `get/query` yoluyla da çalışır. Toplu istek yazma kabul etmez; her okumanın izin kontrolü ayrıdır ve bir öğenin reddi diğerlerini bozmaz. Hız sınırı işlem sayısı kadar sayılır; toplu istekle kota aşılmaz. Eski oturumdan geciken sonuçlar kabul edilmez. Liste/sayfa okumaları 20 saniyede hata ve yeniden deneme durumuna geçer; gönderme/yükleme süreleri ayrı korunur. Üretim DB taşımasında da istek süresi sınırı vardır.

Kendi profilin `App.tsx` içinde zaten izlenen güncel profilden hemen gösterilir. Aynı profil ikinci kez soğuk yüklenmez; kendine takip ilişkisi sorgulanmaz. Sunucunun erişim kontrolünden geçmiş akış kartları, ikincil engel listesinin yüklenmesini bekleyerek gizlenmez. Bilinen engeller istemcide ayrıca filtrelenir; sunucu görünürlük/medya kontrolü korunur.

## Keşfet ve görünürlük

- Keşfet ilk sayfası açık ve öndeyken 15 saniyede yenilenir; başka hesaptan gelen herkese açık paylaşım için sekmeden çıkmak gerekmez. Bu anlık teslim veya tüm gönderilerin ilk 20 sırada bulunacağı garantisi değildir; sıralama tarih ve sayfalamayladır.
- Bir sayfanın aday taraması 40'tan 100'e çıkarıldı. Hesabı sonradan gizlenen kişilerin eski `audience:public` kayıtları, daha aşağıdaki uygun gönderiyi kolayca boş ilk sayfanın arkasında bırakmaz. Kalan sayfa varsa devam düğmesi/sayfalama korunur.
- **Gizli hesap gönderileri genel Keşfet'e eklenmez.** Yeni paylaşım ekranında kimlerin görebileceği yazılır.
- **Hesabı açmak eski gizli gönderileri otomatik açmaz.** Gönderi sahibi hesabını herkese açık yaptıktan sonra, gönderi detayındaki **Gönderi seçenekleri → Herkese açık paylaş → Evet, herkese açık paylaş** yoluyla tek gönderiyi açık onayla yayımlayabilir. İptal edildiğinde değişiklik olmaz. Sunucu sahiplik ve hesabın açık olmasını atomik olarak kontrol eder. Engellenen/kısıtlı hesaplara açılmaz. Orijinal gönderi tarihi değişmez.

## Kontrollü performans karşılaştırması

Aynı yerel PostgreSQL + gateway, aynı iki kullanıcı ve 25 beğeni. Kimlik önhazırlığı yapıldı, ilgisiz bildirim işleri boşaltıldı, her DB RPC'sine yapay 10 ms gecikme eklendi. Önceki kod 1.1.1 kaynak ZIP'inden alındı.

| Ölçüm | 1.1.1 | 1.1.2 |
|---|---:|---:|
| Başarılı dönen beğeni | 25 | 25 |
| DB kayıt okuma çağrısı | 255 | 5 |
| Toplam DB işlemi | 259 | 9 |
| Ölçülen yanıt süresi | 2027 ms | 103 ms |

Bu kontrollü ölçüm gerçek cihaz, Supabase soğuk başlangıcı veya mobil ağ için hız garantisi değildir. Gizli/profil/kısıtlama kontrolleri ölçümden çıkarılmadı. Kaynakta `tests/free-read-performance.test.ts`, izinlerin korunmasını ve okuma sayısının satır sayısıyla büyümemesini sınar.

## Güncelleme

ZIP'in tamamını **yeni klasöre** çıkar. İçteki `Birarada` klasöründe **GUNCELLE_VE_AAB.bat** çalıştır. Yardımcı mevcut Supabase Edge işlevini günceller, kontrollerden sonra mevcut EAS projesi/imzasıyla code4 üretim AAB başlatır. DB migration'ı, yeni hesap/proje veya yeni keystore gerekmez. Eski normal okuma uçları korunduğundan sunucu optimizasyonu 1.1.1 istemcisiyle uyumludur; yeni toplu okuma ve görünürlük arayüzü için yeni AAB gerekir.

Bu bulut çalışmasında yetkili canlı sağlayıcı oturumu yok; yeni backend dağıtımı ve imzalı AAB üretimi yapılmadı. Kaynak paketini AAB olarak yüklemeyin. Fiziksel telefonda son paket, kamera/video/ses, gerçek push teslimi ve Play kontrolleri ayrıca doğrulanmalıdır. Özel içerikler rıza olmadan keşfete açılmadı.
