import { test } from "node:test";
import assert from "node:assert/strict";
import { harness } from "./free-harness";
import { Timestamp } from "../supabase/functions/birarada/records";
const profile = (uid: string) => ({
  uid,
  username: uid + "_user",
  isPrivate: false,
  deletionPending: false,
  createdAt: Timestamp.now(),
});
test("reading a populated like list does not repeat authorization database round trips for each row", async () => {
  const h = await harness();
  try {
    for (const uid of ["alice", "bob", "eve"])
      await h.db.doc("users/" + uid).set(profile(uid));
    await h.db
      .doc("posts/public-post")
      .set({
        uid: "alice",
        kind: "post",
        audience: "public",
        createdAt: Timestamp.now(),
      });
    for (let i = 0; i < 25; i++)
      await h.db
        .doc(`posts/public-post/likes/person-${i}`)
        .set({ uid: "person-" + i, createdAt: Timestamp.now() });
    await h.pg.exec("truncate public.birarada_jobs");
    await h.db.doc("system/maintenance").set({ after: Date.now() + 60000 });
    const rpc = h.driver.rpc.bind(h.driver);
    let gets = 0;
    h.driver.rpc = async (name, input) => {
      if (name === "birarada_get") gets++;
      return rpc(name, input);
    };
    const r = await h.request("bob", "documents", {
      operation: "query",
      spec: {
        path: "posts/public-post/likes",
        group: false,
        filters: [],
        orders: [],
        limit: 500,
      },
    });
    assert.equal(r.status, 200, await r.clone().text());
    assert.equal((await r.json()).data.length, 25);
    assert.ok(
      gets <= 12,
      `25 likes must reuse request-scoped permissions, got ${gets} database reads`,
    );
  } finally {
    await h.pg.close();
  }
});
test("one read batch isolates forbidden items and never accepts writes", async () => {
  const h = await harness();
  try {
    for (const uid of ["alice", "bob", "eve"])
      await h.db.doc("users/" + uid).set(profile(uid));
    await h.db.doc("roles/alice").set({ role: "owner" });
    const r = await h.request("bob", "documents", {
      operation: "batch",
      items: [
        { operation: "get", paths: ["users/alice"] },
        { operation: "get", paths: ["roles/alice"] },
        {
          operation: "query",
          spec: {
            path: "users/bob/blocks",
            group: false,
            filters: [],
            orders: [],
            limit: 100,
          },
        },
      ],
    });
    assert.equal(r.status, 200, await r.clone().text());
    const result = (await r.json()).data;
    assert.equal(result[0].data[0].data.uid, "alice");
    assert.equal(result[1].error.code, "permission-denied");
    assert.deepEqual(result[2].data, []);
    const write = await h.request("bob", "documents", {
      operation: "batch",
      items: [
        {
          operation: "commit",
          reads: [],
          writes: [{ kind: "set", path: "roles/bob", data: { role: "owner" } }],
        },
      ],
    });
    assert.equal(write.status, 400);
    assert.equal((await h.db.doc("roles/bob").get()).exists, false);
  } finally {
    await h.pg.close();
  }
});
test("discover scans past public snapshots whose owners later became private", async () => {
  const h = await harness();
  try {
    for (const uid of ["alice", "bob", "eve"])
      await h.db.doc("users/" + uid).set(profile(uid));
    const now = Date.now();
    for (let i = 0; i < 50; i++)
      await h.db
        .doc("posts/hidden-" + i)
        .set({
          uid: "alice",
          kind: "post",
          audience: "public",
          createdAt: Timestamp.fromMillis(now - i * 1000),
        });
    await h.db
      .doc("posts/eligible")
      .set({
        uid: "eve",
        kind: "post",
        audience: "public",
        createdAt: Timestamp.fromMillis(now - 100000),
      });
    await h.db.doc("users/alice").update({ isPrivate: true });
    const page = await h.call("bob", "listContent", { kind: "post" });
    assert.equal(page.status, 200);
    assert.deepEqual(
      page.data.rows.map((p: any) => p.id),
      ["eligible"],
    );
  } finally {
    await h.pg.close();
  }
});
test("historical private posts require owner consent before discover publication and remain hidden from blocked users", async () => {
  const h = await harness();
  try {
    for (const uid of ["alice", "bob", "eve"])
      await h.db.doc("users/" + uid).set(profile(uid));
    await h.db
      .doc("posts/old-private")
      .set({
        uid: "alice",
        username: "alice_user",
        kind: "post",
        caption: "private",
        audience: "private",
        createdAt: Timestamp.now(),
      });
    assert.equal((await h.call("bob", "listContent", {})).data.rows.length, 0);
    assert.equal(
      (await h.call("alice", "publishToExplore", { id: "old-private" })).status,
      400,
    );
    assert.equal(
      (
        await h.call("bob", "publishToExplore", {
          id: "old-private",
          confirmPublic: true,
        })
      ).status,
      403,
    );
    await h.db.doc("users/alice").update({ isPrivate: true });
    assert.equal(
      (
        await h.call("alice", "publishToExplore", {
          id: "old-private",
          confirmPublic: true,
        })
      ).status,
      412,
    );
    await h.db.doc("users/alice").update({ isPrivate: false });
    assert.equal(
      (
        await h.call("alice", "publishToExplore", {
          id: "old-private",
          confirmPublic: true,
        })
      ).status,
      200,
    );
    for (const uid of ["bob", "eve"])
      assert.equal(
        (await h.call(uid, "listContent", {})).data.rows[0].id,
        "old-private",
      );
    await h.db
      .doc("users/alice/blocks/bob")
      .set({ uid: "bob", createdAt: Timestamp.now() });
    assert.equal((await h.call("bob", "listContent", {})).data.rows.length, 0);
  } finally {
    await h.pg.close();
  }
});
