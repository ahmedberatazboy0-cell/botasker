import { test } from "node:test";
import assert from "node:assert/strict";
import { createReadBatcher } from "../src/utils/readBatcher";
test("concurrent reads share transport but an individual denial cannot poison other results", async () => {
  let calls = 0;
  const read = createReadBatcher<number>(
    async (_scope, items) => {
      calls++;
      return items.map((x) =>
        x === 2
          ? { error: { code: "permission-denied", message: "denied" } }
          : { data: Number(x) },
      );
    },
    () => true,
    { delay: 1 },
  );
  const result = await Promise.allSettled([
    read("alice", 1),
    read("alice", 2),
    read("alice", 3),
  ]);
  assert.equal(calls, 1);
  assert.deepEqual(
    result.map((r) => r.status),
    ["fulfilled", "rejected", "fulfilled"],
  );
  assert.equal((result[2] as PromiseFulfilledResult<number>).value, 3);
});
test("batch size and network concurrency stay bounded", async () => {
  let running = 0,
    maximum = 0;
  const sizes: number[] = [];
  const read = createReadBatcher<number>(
    async (_scope, items) => {
      sizes.push(items.length);
      running++;
      maximum = Math.max(maximum, running);
      await new Promise((r) => setTimeout(r, 5));
      running--;
      return items.map((x) => ({ data: Number(x) }));
    },
    () => true,
    { delay: 1, maximum: 3, concurrency: 2 },
  );
  assert.deepEqual(
    await Promise.all(Array.from({ length: 11 }, (_, i) => read("alice", i))),
    Array.from({ length: 11 }, (_, i) => i),
  );
  assert.ok(sizes.every((n) => n <= 3));
  assert.ok(maximum <= 2);
});
test("queued and late results from a previous session are rejected", async () => {
  let current = "alice",
    calls = 0;
  const read = createReadBatcher<number>(
    async () => {
      calls++;
      await new Promise((r) => setTimeout(r, 5));
      current = "bob";
      return [{ data: 1 }];
    },
    (scope) => scope === current,
    { delay: 1 },
  );
  await assert.rejects(
    read("alice", 1),
    (e: any) => e.code === "unauthenticated",
  );
  await assert.rejects(
    read("alice", 2),
    (e: any) => e.code === "unauthenticated",
  );
  assert.equal(calls, 1);
});
