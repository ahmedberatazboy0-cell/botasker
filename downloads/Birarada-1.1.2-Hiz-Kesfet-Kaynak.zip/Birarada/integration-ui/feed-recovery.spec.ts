import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
const password = "Local-feed-recovery-984!";
let user: { uid: string; email: string; token: string; username: string };
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  expect(r.status, await r.clone().text()).toBe(200);
  return r.json();
}
async function request(route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + user.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  expect(r.status, await r.clone().text()).toBe(200);
  return (await r.json()).data;
}
const api = (action: string, input: any = {}) =>
  request("socialApi", { action, input });
async function publish(caption: string) {
  return api("publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption,
    mediaIds: [],
    commentsEnabled: true,
  });
}
async function login(page: Page) {
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page.getByLabel("E-posta", { exact: true }).fill(user.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
test.beforeEach(async () => {
  const suffix = randomUUID().slice(0, 8),
    email = "feed-" + suffix + "@example.test";
  const created = await auth("accounts:signUp", {
    email,
    password,
    returnSecureToken: true,
  });
  await auth(
    "projects/demo-birarada/accounts:update",
    { localId: created.localId, emailVerified: true },
    true,
  );
  const signed = await auth("accounts:signInWithPassword", {
    email,
    password,
    returnSecureToken: true,
  });
  user = {
    uid: created.localId,
    email,
    token: signed.idToken,
    username: "feed_" + suffix,
  };
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      profiles: [
        {
          uid: user.uid,
          email,
          username: user.username,
          displayName: "Feed Tester",
        },
      ],
    }),
  });
  expect(r.status).toBe(200);
});
test("private author sees a newly published post immediately on returning home", async ({
  page,
}) => {
  const path = "users/" + user.uid,
    old = (await request("documents", { operation: "get", paths: [path] }))[0];
  await request("documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ path, kind: "set", data: { ...old.data, isPrivate: true } }],
  });
  await login(page);
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  const caption = "Gizli hesabimin yeni gonderisi " + randomUUID();
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(page.getByText(caption, { exact: false })).toBeVisible();
});
test("returning to a loaded feed preserves cards while the refresh is slow", async ({
  page,
}) => {
  const post = await publish(
    "Yukleme sirasinda kaybolmayan gonderi " + randomUUID(),
  );
  await login(page);
  const card = page.getByTestId("post-" + post.id);
  await expect(card).toBeVisible();
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  await page.route("**/socialApi", async (route) => {
    if (route.request().postDataJSON()?.action === "listContent") {
      await gate;
    }
    await route.continue().catch(() => {});
  });
  await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
  try {
    await expect(card).toBeVisible({ timeout: 2500 });
  } finally {
    release();
  }
});
test("a previously visited profile refreshes its grid after publishing", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await expect(page.getByText(user.username, { exact: true })).toBeVisible();
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  const caption = "Profilde yeni gonderi " + randomUUID();
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await expect(
    page.getByRole("button", {
      name: "@" + user.username + ": " + caption,
      exact: true,
    }),
  ).toBeVisible();
});
test("an open feed receives a new server post without a reload or tab change", async ({
  page,
}) => {
  const first = await publish("Already loaded " + randomUUID());
  await login(page);
  await expect(page.getByTestId("post-" + first.id)).toBeVisible();
  const post = await publish("Acik akis kendini yeniler " + randomUUID());
  await expect(page.getByTestId("post-" + post.id)).toBeVisible({
    timeout: 22000,
  });
});
test("a temporary blocks read failure clears after the next successful subscription read", async ({
  page,
}) => {
  let failed = false;
  await page.route("**/documents", async (route) => {
    const i = route.request().postDataJSON();
    if (
      !failed &&
      (i?.operation === "batch" ? i.items : [i]).some(
        (read: any) =>
          read?.operation === "query" &&
          read.spec?.path === `users/${user.uid}/blocks`,
      )
    ) {
      failed = true;
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: { code: "unavailable", message: "temporary" },
        }),
      });
      return;
    }
    await route.continue();
  });
  const post = await publish(
    "Baglanti duzelince geri gelen gonderi " + randomUUID(),
  );
  await login(page);
  await expect(
    page.getByRole("button", { name: "Tekrar dene", exact: true }),
  ).toBeVisible();
  await expect(page.getByTestId("post-" + post.id)).toBeVisible({
    timeout: 20000,
  });
  await expect(
    page.getByRole("button", { name: "Tekrar dene", exact: true }),
  ).toHaveCount(0);
});
test("a failed feed request stops loading and retry restores the list", async ({
  page,
}) => {
  let failing = true;
  await page.route("**/socialApi", async (route) => {
    if (failing && route.request().postDataJSON()?.action === "listContent") {
      await route.abort("failed");
      return;
    }
    await route.continue();
  });
  const post = await publish("Yeniden denemeyle gelen gonderi " + randomUUID());
  await login(page);
  const retry = page.getByRole("button", { name: "Tekrar dene", exact: true });
  await expect(retry).toBeVisible();
  failing = false;
  await retry.click();
  await expect(page.getByTestId("post-" + post.id)).toBeVisible();
});
test("post details recover from a failed load without retaining the old error", async ({
  page,
}) => {
  const caption = "Tekrar acilan detay " + randomUUID(),
    post = await publish(caption);
  let failing = true;
  await page.route("**/socialApi", async (route) => {
    if (failing && route.request().postDataJSON()?.action === "getContent") {
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: { code: "unavailable", message: "temporary" },
        }),
      });
      return;
    }
    await route.continue();
  });
  await login(page);
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await page
    .getByRole("button", {
      name: "@" + user.username + ": " + caption,
      exact: true,
    })
    .click();
  const retry = page.getByRole("button", { name: "Tekrar dene", exact: true });
  await expect(retry).toBeVisible();
  failing = false;
  await retry.click();
  await expect(
    page.getByTestId("post-details").getByTestId("post-" + post.id),
  ).toBeVisible();
  await expect(retry).toHaveCount(0);
});

test("own profile content appears without waiting for secondary document reads", async ({
  page,
}) => {
  await login(page);
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route("**/documents", async (route) => {
    await gate;
    await route.continue().catch(() => {});
  });
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  try {
    await expect(page.getByText("Feed Tester", { exact: true })).toBeVisible({
      timeout: 2000,
    });
  } finally {
    release();
  }
});

test("a server-authorized feed card is not held behind the secondary block-list load", async ({
  page,
}) => {
  const post = await publish("Akis ek sorguyu beklemiyor " + randomUUID());
  let release!: () => void;
  const gate = new Promise<void>((resolve) => {
    release = resolve;
  });
  await page.route("**/documents", async (route) => {
    const body = route.request().postDataJSON(),
      reads = body?.operation === "batch" ? body.items : [body];
    if (
      reads.some(
        (read: any) =>
          read?.operation === "query" &&
          read.spec?.path === `users/${user.uid}/blocks`,
      )
    )
      await gate;
    await route.continue().catch(() => {});
  });
  try {
    await login(page);
    await expect(page.getByTestId("post-" + post.id)).toBeVisible({
      timeout: 4000,
    });
  } finally {
    release();
  }
});

test("an already open Explore receives a public post from another account without following", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  const suffix = randomUUID().slice(0, 8),
    email = `explore-${suffix}@example.test`,
    username = "explore_" + suffix;
  const created = await auth("accounts:signUp", {
    email,
    password,
    returnSecureToken: true,
  });
  await auth(
    "projects/demo-birarada/accounts:update",
    { localId: created.localId, emailVerified: true },
    true,
  );
  const other = await auth("accounts:signInWithPassword", {
    email,
    password,
    returnSecureToken: true,
  });
  const fixture = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      profiles: [
        {
          uid: created.localId,
          email,
          username,
          displayName: "Public Publisher",
        },
      ],
    }),
  });
  expect(fixture.status).toBe(200);
  const caption = "Baska hesaptan acik kesfete " + randomUUID();
  const result = await fetch("http://127.0.0.1:5002/socialApi", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + other.idToken,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      action: "publishContent",
      input: { requestId: randomUUID(), kind: "post", caption, mediaIds: [] },
    }),
  });
  expect(result.status, await result.clone().text()).toBe(200);
  await expect(
    page.getByRole("button", {
      name: "@" + username + ": " + caption,
      exact: true,
    }),
  ).toBeVisible({ timeout: 22000 });
});

test("a historical private post requires explicit confirmation to become public", async ({
  page,
}) => {
  const path = "users/" + user.uid;
  async function privacy(value: boolean) {
    const old = (
      await request("documents", { operation: "get", paths: [path] })
    )[0];
    await request("documents", {
      operation: "commit",
      reads: [{ path, rev: old.rev }],
      writes: [{ path, kind: "set", data: { ...old.data, isPrivate: value } }],
    });
  }
  await privacy(true);
  const caption = "Gizli arsivden onayli paylasim " + randomUUID(),
    post = await publish(caption);
  await privacy(false);
  await login(page);
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await page
    .getByRole("button", {
      name: "@" + user.username + ": " + caption,
      exact: true,
    })
    .click();
  await page
    .getByRole("button", { name: "Gönderi seçenekleri", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Herkese açık paylaş", exact: true })
    .click();
  await expect(
    page.getByRole("button", {
      name: "Evet, herkese açık paylaş",
      exact: true,
    }),
  ).toBeVisible();
  expect(
    (await api("listContent", {})).rows.some((p: any) => p.id === post.id),
  ).toBe(false);
  await page.getByRole("button", { name: "Vazgeç", exact: true }).click();
  expect(
    (await api("listContent", {})).rows.some((p: any) => p.id === post.id),
  ).toBe(false);
  await page
    .getByRole("button", { name: "Herkese açık paylaş", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Evet, herkese açık paylaş", exact: true })
    .click();
  await expect
    .poll(async () =>
      (await api("listContent", {})).rows.some((p: any) => p.id === post.id),
    )
    .toBe(true);
});
