# Birarada — ücretsiz altyapı paketi

Firebase Authentication giriş hesapları korunur; sosyal veriler Supabase PostgreSQL'de, medya özel Supabase Storage bucket'ında, API Supabase Edge Function'da çalışır. Bu kaynak Firebase Blaze, Firebase Functions veya Firebase Storage kurulumu istemez. Supabase projesi **qinevhhhdtslnzrtcanq**; mevcut EAS projesi **@ahmedberat/birarada / 9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b**. Paket **com.birarada.app**, sürüm1.0.0/code1. Mevcut EAS imzası korunur.

**Kaynak paketi yeni imzalı AAB değildir. Canlı dağıtım, gerçek telefon ve son AAB denetimleri tamamlanmadan yayıma hazır sayılmaz.** Kullanıcının Supabase projesi oluşturuldu; bu ortamda yetkili Supabase oturumu bulunmuyor. Kullanıcı kendi bilgisayarında resmî CLI girişini tamamlayarak dağıtır.

## Windows'ta kurulum

Node.js22/24 ve Chrome/Edge kurulu olsun. ZIP'in tamamını yeni bir klasöre çıkar; eski Firebase paketinin üstüne karıştırma.

1. **UCRETSIZ_KUR.bat** veya CMD'de `npm run backend:deploy`. Bağımlılıklar/tip/güvenlik testleri çalışır. Resmî Supabase CLI, yayıncının SHA-256 listesiyle doğrulanarak indirilir. Tarayıcıda Supabase hesabına giriş yap; link aşamasında gerekirse veritabanı parolasını yalnız resmî CLI istemine gir. Parola/token/service_role anahtarını sohbete veya proje dosyasına yazma. Araç yalnız verilen proje kimliğini bağlar, SQL şemasını, özel bucket'ı ve Edge sunucusunu dağıtır. Ücretli plan açmaz.
2. **WEB_TEST.bat** yerel web denemesi açar. Öncesinde bir kez `npm ci` çalışmış olmalı. Adres `http://localhost:8081`. Auth emulator + yerel PostgreSQL motoru ve yerel medya kullanır; Supabase/Firebase canlı verilerini değiştirmez. Java/Docker gerektirmez. Pencere açık kalmalı; Ctrl+C ile kapatılır. Yerel hesaplar canlı hesap değildir.
3. Güncel yasal sayfaları mevcut web sitesinin tam çıktısıyla birleştirip yayımla: `docs/HOSTING.md`. Ücretsiz Firebase Hosting kullanılabilir; yalnız yasal sayfa klasörü mevcut sitenin üzerine tek başına dağıtılmaz.
4. **AAB_OLUSTUR.bat** veya `npm run build:no-github`. Uygulama, ücretsiz sunucu, tarayıcı ve canlı sürüm/yasal sayfa kontrolleri geçince mevcut EAS projesi ve mevcut keystore ile üretim derlemesi başlar. Başarısız kontroller atlanmaz. Yeni `.aab` bağlantısını EAS verir; Play Console'a otomatik gönderilmez.

İki kurulum/derlemeyi aynı klasörde aynı anda çalıştırma; ikisi de node_modules kurulumunu yönetir. Chrome/Edge özel konumu `CHROMIUM_PATH` ile seçilebilir.

## Özellikler ve sınırlar

Fotoğraf/video gönderileri, çoklu paylaşım, taslak, hikâye/öne çıkanlar, Reels, şarkı bağlantılı notlar, profil/arama/takip, yorum/beğeni/kaydetme, bireysel/grup/medya mesajları, yanıt/tepki/görüldü ve role bağlı yönetim paneli bulunur. Aynı Firebase hesabıyla giriş yapılır; eski Firestore gönderileri/profilleri otomatik kopyalanmaz veya silinmez. Supabase profilini kurmak veya doğrulanmış resmî hesabı etkinleştirmek gerekir.

Ücretsiz sunucu FFmpeg dönüştürmesi yapmaz. Fotoğraflar istemcide JPEG'e dönüştürülür ve sunucuda EXIF kaldırılır. Videolar H.264 MP4, sesler AAC M4A olmalı; diğer biçimler açık hatayla reddedilir. iOS seçicisinde H.264 export seçilir; Android galerideki uyumsuz video için önceden dönüştürme gerekir. Native ses kaydı desteklenir. AAC/MP4 kaydı desteklemeyen tarayıcıda ses kaydı açıklayıcı hatayla durur. Web'de her tarayıcıda ses kaydı desteği yoktur. Özel video/ses, oturumla indirilen geçici tarayıcı nesne adresi üzerinden oynatılır; adres ekran/oturum değişiminde kaldırılır. Video ve ses indirme/oynatma gerçek tarayıcıda sınandı.

Tüm medya istekleri Firebase imzası, güncel hesap ve uygulama yetkisiyle denetlenir. Doğrudan PostgreSQL tabloları/RPC'ler ve bucket genel istemci erişimine kapalıdır; signed/public download URL üretilmez. Yönetim yetkisi yalnız sunucudaki role kaydından gelir; e-posta veya profil alanı tek başına yetki vermez. Resmî hesap e-postası doğrulanır ve owner UID bir kez sabitlenir.

Uygulamada medya rezervasyonları için512MiB, JSON kayıtları için128MiB, aylık medya gönderimi için2GiB koruyucu sınırlar vardır. Bunlar sağlayıcının gerçek kota/ücret hesabının yerine geçmez. Proje Free planında tutulmalı; araç ücretli plana yükseltmez. Supabase'in ücretsiz depolama, trafik, Edge ve bekleme/askıya alma koşulları geçerlidir; sınırsız veya kesintisiz hizmet vaadi yoktur.

Liste/değişiklik takibi10 saniyelik sorgulama ve yerel yazım sonrası yenilemeyle çalışır. Cihaz push kayıt/gönderim altyapısı korunur; gerçek FCM/EAS bağlantısı ve telefon teslimi ayrıca gerekir. Kuyruk işleri istekler sırasında yeniden denenir; sürekli çalışan ücretli zamanlayıcı yoktur.

Destek/resmî hesap: **ahmedberatazboy0@gmail.com**. Verilen parola kaynaklara eklenmedi. Doğrulanmış oturumla Profil kurulumu/Ayarlar → **Resmî hesabı etkinleştir**, ardından Ayarlar → **Yönetim paneli**.

Güncel doğrulama ve kalan işler: **TEST_REPORT.md**.
