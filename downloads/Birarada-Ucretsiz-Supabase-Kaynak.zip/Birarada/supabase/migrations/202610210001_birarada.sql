-- Private application records. The public client cannot access tables/RPCs directly.
create table if not exists public.birarada_records (
 path text primary key check(length(path) between 3 and 1500),
 data jsonb not null check(jsonb_typeof(data)='object'),
 rev bigint not null,
 parent text generated always as (regexp_replace(path,'/[^/]+$','')) stored,
 collection text generated always as (split_part(regexp_replace(path,'/[^/]+$',''), '/', array_length(string_to_array(regexp_replace(path,'/[^/]+$',''),'/'),1))) stored
);
create sequence if not exists public.birarada_revision;
create index if not exists birarada_parent on public.birarada_records(parent);
create index if not exists birarada_collection on public.birarada_records(collection);
create index if not exists birarada_uid on public.birarada_records ((data->>'uid'));
alter table public.birarada_records enable row level security;
revoke all on public.birarada_records from public, anon, authenticated;
revoke all on sequence public.birarada_revision from public, anon, authenticated;
grant all on public.birarada_records to service_role;
grant usage,select on sequence public.birarada_revision to service_role;

create or replace function public.birarada_value(d jsonb, p text, key text) returns jsonb language sql immutable set search_path='' as $$
 select case when key='__name__' then to_jsonb(regexp_replace(p,'^.*/',''))
 when jsonb_typeof(d #> string_to_array(key,'.'))='object' and (d #> string_to_array(key,'.')) ? '__ts'
 then to_jsonb(((d #> string_to_array(key,'.'))->'__ts'->>0)::numeric*1000000000 + ((d #> string_to_array(key,'.'))->'__ts'->>1)::numeric)
 else d #> string_to_array(key,'.') end
$$;
create or replace function public.birarada_literal(v jsonb) returns jsonb language sql immutable set search_path='' as $$
 select case when jsonb_typeof(v)='object' and v ? '__ts' then to_jsonb((v->'__ts'->>0)::numeric*1000000000+(v->'__ts'->>1)::numeric) else v end
$$;
create or replace function public.birarada_matches(d jsonb,p text,filters jsonb) returns boolean language plpgsql immutable set search_path='' as $$
declare f jsonb; a jsonb; b jsonb; op text;
begin
 for f in select value from jsonb_array_elements(coalesce(filters,'[]')) loop
 a:=public.birarada_value(d,p,f->>0);b:=public.birarada_literal(f->2);op:=f->>1;
 if a is null then return false;end if;
 if not coalesce(case op when '==' then a=b when '!=' then a<>b when '>' then a>b when '>=' then a>=b when '<' then a<b when '<=' then a<=b when 'array-contains' then a @> jsonb_build_array(b) when 'in' then b @> jsonb_build_array(a) else false end,false) then return false;end if;
 end loop;return true;
end $$;
create or replace function public.birarada_query(spec jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare sql text; ord text:='';f jsonb;expr text; lim integer; off integer;
begin
 lim:=least(greatest(coalesce((spec->>'limit')::integer,1000),1),1000); off:=greatest(coalesce((spec->>'offset')::integer,0),0);
 if spec->>'group'='true' then sql:=format('select path,data,rev from public.birarada_records where collection=%L',spec->>'path');
 else sql:=format('select path,data,rev from public.birarada_records where parent=%L',spec->>'path');end if;
 sql:=sql||format(' and public.birarada_matches(data,path,%L::jsonb)',coalesce(spec->'filters','[]'::jsonb));
 for f in select value from jsonb_array_elements(coalesce(spec->'orders','[]')) loop
 expr:=format('public.birarada_value(data,path,%L)',f->>0);
 ord:=ord||case when ord='' then '' else ',' end||expr||case when f->>1='desc' then ' desc nulls last' else ' asc nulls first' end;
 end loop;
 if ord='' then ord:='path';else ord:=ord||',path';end if;
 if spec->>'count'='true' then execute 'select jsonb_build_object(''count'',count(*)) from ('||sql||') q' into f;return f;end if;
 execute 'select coalesce(jsonb_agg(to_jsonb(q)),''[]''::jsonb) from ('||sql||' order by '||ord||' limit '||lim||' offset '||off||') q' into f;return f;
end $$;
create or replace function public.birarada_get(paths jsonb) returns jsonb language sql security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('path',v.value,'data',r.data,'rev',r.rev)),'[]'::jsonb) from jsonb_array_elements_text(paths) v left join public.birarada_records r on r.path=v.value
$$;
create or replace function public.birarada_commit(reads jsonb,writes jsonb) returns boolean language plpgsql security definer set search_path='' as $$
declare r jsonb;w jsonb;actual bigint;existing jsonb;total_bytes bigint;media_bytes bigint;
begin
 perform pg_advisory_xact_lock(7248721);
 if jsonb_array_length(writes)>400 or jsonb_array_length(reads)>1500 then raise exception 'BATCH_LIMIT';end if;
 for r in select value from jsonb_array_elements(reads) loop
 select rev into actual from public.birarada_records where path=r->>'path';
 if actual is distinct from (r->>'rev')::bigint then return false;end if;
 end loop;
 for w in select value from jsonb_array_elements(writes) loop
 if w->>'kind'='delete' then delete from public.birarada_records where path=w->>'path';
 elsif w->>'kind'='create' then insert into public.birarada_records(path,data,rev) values(w->>'path',w->'data',nextval('public.birarada_revision'));
 elsif w->>'kind'='set' then insert into public.birarada_records(path,data,rev) values(w->>'path',w->'data',nextval('public.birarada_revision')) on conflict(path) do update set data=excluded.data,rev=excluded.rev;
 else raise exception 'INVALID_WRITE';end if;
 end loop;
 select coalesce(sum(octet_length(data::text)),0),coalesce(sum(case when parent='media' then (data->>'declaredBytes')::bigint else 0 end),0) into total_bytes,media_bytes from public.birarada_records;
 if total_bytes>134217728 then raise exception 'FREE_DATABASE_LIMIT';end if;
 if media_bytes>536870912 then raise exception 'FREE_STORAGE_LIMIT';end if;
 return true;
end $$;

-- Outbox for retryable media removal and notification delivery.
create table if not exists public.birarada_jobs(id bigint generated always as identity primary key,kind text not null,payload jsonb not null,available_at timestamptz not null default now(),attempts integer not null default 0);
alter table public.birarada_jobs enable row level security;
revoke all on public.birarada_jobs from public,anon,authenticated;
grant all on public.birarada_jobs to service_role;
grant usage,select on sequence public.birarada_jobs_id_seq to service_role;
create or replace function public.birarada_events() returns trigger language plpgsql security definer set search_path='' as $$
declare uid text;pid text;f record;n jsonb;target text;source text;key text;ts jsonb;
begin
 if TG_OP='DELETE' then
  if OLD.parent in ('posts','stories') or OLD.collection='messages' then insert into public.birarada_jobs(kind,payload) values('remove-media',coalesce(OLD.data->'mediaIds','[]'));end if;return OLD;
 end if;
 pid:=regexp_replace(NEW.path,'^.*/','');ts:=jsonb_build_object('__ts',jsonb_build_array(floor(extract(epoch from now())),0));
 if NEW.parent='posts' and TG_OP='INSERT' then
  for uid in select NEW.data->>'uid' union select data->>'followerUid' from public.birarada_records where parent='follows' and data->>'followingUid'=NEW.data->>'uid' and data->>'status'='accepted' loop
   insert into public.birarada_records(path,data,rev) values('timelines/'||uid||'/posts/'||pid,jsonb_build_object('createdAt',NEW.data->'createdAt'),nextval('public.birarada_revision')) on conflict(path) do nothing;
  end loop;
 end if;
 if NEW.parent='follows' and NEW.data->>'status'='accepted' and (TG_OP='INSERT' or OLD.data->>'status' is distinct from 'accepted') then
  for f in select path,data from public.birarada_records where parent='posts' and data->>'uid'=NEW.data->>'followingUid' order by public.birarada_value(data,path,'createdAt') desc limit 30 loop
   insert into public.birarada_records(path,data,rev) values('timelines/'||(NEW.data->>'followerUid')||'/posts/'||regexp_replace(f.path,'^.*/',''),jsonb_build_object('createdAt',f.data->'createdAt'),nextval('public.birarada_revision')) on conflict(path) do nothing;
  end loop;
 end if;
 if NEW.parent='notifications' and TG_OP='INSERT' then insert into public.birarada_jobs(kind,payload) values('push',jsonb_build_object('path',NEW.path));end if;
 if TG_OP<>'INSERT' then return NEW;end if;
 if NEW.collection in ('likes','comments') then
  select data->>'uid' into target from public.birarada_records where path=regexp_replace(NEW.parent,'/(likes|comments)$','');source:=NEW.data->>'uid';
  if target is not null and target<>source then
   n:=jsonb_build_object('sourceUid',source,'targetUid',target,'type',case when NEW.collection='likes' then 'like' else 'comment' end,'text','Yeni bir etkilesim var.','read',false,'createdAt',ts,'target',jsonb_build_object('postId',split_part(NEW.path,'/',2)));
   insert into public.birarada_records(path,data,rev) values('notifications/'||md5(NEW.path||NEW.rev::text),n,nextval('public.birarada_revision')) on conflict(path) do nothing;
  end if;
 elsif NEW.collection='messages' then
  select data into n from public.birarada_records where path=regexp_replace(NEW.parent,'/messages$','');
  for uid in select jsonb_array_elements_text(n->'memberIds') loop
   if uid<>NEW.data->>'senderUid' then insert into public.birarada_records(path,data,rev) values('notifications/'||md5(NEW.path||uid||NEW.rev::text),jsonb_build_object('sourceUid',NEW.data->>'senderUid','targetUid',uid,'type','message','text','Yeni bir mesajin var.','read',false,'createdAt',ts,'target',jsonb_build_object('chatId',split_part(NEW.path,'/',2))),nextval('public.birarada_revision')) on conflict(path) do nothing;end if;
  end loop;
 end if;
 return NEW;
end $$;
drop trigger if exists birarada_record_events on public.birarada_records;
create trigger birarada_record_events after insert or update or delete on public.birarada_records for each row execute function public.birarada_events();
create or replace function public.birarada_claim_jobs() returns setof public.birarada_jobs language sql security definer set search_path='' as $$
 update public.birarada_jobs set available_at=now()+interval '90 seconds',attempts=attempts+1 where id in (select id from public.birarada_jobs where available_at<=now() and attempts<20 order by id limit 10 for update skip locked) returning *
$$;
create or replace function public.birarada_finish_job(job_id bigint,success boolean) returns void language plpgsql security definer set search_path='' as $$
begin if success then delete from public.birarada_jobs where id=job_id;else update public.birarada_jobs set available_at=now()+interval '5 minutes' where id=job_id;end if;end $$;

revoke all on function public.birarada_value(jsonb,text,text),public.birarada_literal(jsonb),public.birarada_matches(jsonb,text,jsonb),public.birarada_query(jsonb),public.birarada_get(jsonb),public.birarada_commit(jsonb,jsonb),public.birarada_events(),public.birarada_claim_jobs(),public.birarada_finish_job(bigint,boolean) from public,anon,authenticated;
grant execute on function public.birarada_query(jsonb),public.birarada_get(jsonb),public.birarada_commit(jsonb,jsonb),public.birarada_claim_jobs(),public.birarada_finish_job(bigint,boolean) to service_role;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('birarada-media','birarada-media',false,20971520,array['image/jpeg','video/mp4','audio/mp4','audio/webm']) on conflict(id) do nothing;
-- No anonymous/authenticated Storage policy: only the authenticated Edge gateway serves objects.
create or replace function public.birarada_subtree(prefix text,maximum integer) returns jsonb language sql security definer set search_path='' as $$
 select coalesce(jsonb_agg(to_jsonb(t)),'[]') from (select path,data,rev from public.birarada_records where path=prefix or starts_with(path,prefix||'/') order by path desc limit least(greatest(maximum,1),200)) t
$$;
revoke all on function public.birarada_subtree(text,integer) from public,anon,authenticated;
grant execute on function public.birarada_subtree(text,integer) to service_role;
