import { type Actor, id, text } from "./domain.ts";
import { db, HttpsError } from "./context.ts";
import {
  type DocumentData,
  Snapshot,
  Timestamp,
  Transaction,
  type Write,
} from "./records.ts";
import { active, blocked, follows, rate, visible } from "./core.ts";
const deny = () => {
  throw new HttpsError("permission-denied", "Bu kayıt için erişim iznin yok.");
};
const equal = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b);
const only = (o: DocumentData, keys: string[]) =>
  Object.keys(o).every((k) => keys.includes(k));
const unchanged = (old: DocumentData, next: DocumentData, keys: string[]) =>
  Object.keys({ ...old, ...next }).every((k) =>
    keys.includes(k) || equal(old[k], next[k])
  );
const time = (v: any) =>
  v instanceof Timestamp && Math.abs(v.toMillis() - Date.now()) < 120000;
async function profile(uid: string) {
  return (await db.doc("users/" + id(uid)).get()).data();
}
async function pending(uid: string) {
  return (await profile(uid))?.deletionPending === true;
}
async function allowedNote(uid: string, owner: string, n: DocumentData) {
  return uid === owner ||
    await active(uid) && await active(owner) && !await blocked(uid, owner) &&
      await follows(uid, owner) &&
      n.updatedAt?.toMillis() > Date.now() - 86400000;
}
export async function canRead(
  a: Actor,
  path: string,
  row: DocumentData | undefined,
): Promise<boolean> {
  const p = path.split("/"), c = p[0], key = p[1], me = a.uid;
  if (!row) {
    return ["users", "usernames"].includes(c!) || c === "posts" ||
      c === "notes" || (p[2] === "likes" && p[3] === me) || c === "saved";
  }
  if (c === "usernames" && p.length === 2) return true;
  if (c === "users" && p.length === 2) {
    return key === me || await active(me) && await active(key!);
  }
  if (c === "users" && p.length === 4 && p[2] === "blocks") return key === me;
  if (!await active(me) && !await pending(me)) return false;
  if (c === "posts" && p.length === 2) {
    return row.uid === me || await visible(me, row);
  }
  if (c === "posts" && p.length === 4) {
    if (row.uid === me && await pending(me)) return true;
    const post = (await db.doc("posts/" + key).get()).data();
    return !!post && (post.uid === me || await visible(me, post));
  }
  if (c === "follows" && p.length === 2) {
    return row.followerUid === me || row.followingUid === me;
  }
  if (c === "saved" && p.length === 4 && p[2] === "posts") return key === me;
  if (c === "notes" && p.length === 2) return allowedNote(me, key!, row);
  if (c === "notifications" && p.length === 2) {
    return row.targetUid === me || row.sourceUid === me;
  }
  if (c === "reports" && p.length === 2) return row.reporterUid === me;
  if (c === "chats") {
    if (p.length === 4 && row.senderUid === me && await pending(me)) {
      return true;
    }
    const chat = p.length === 2
      ? row
      : (await db.doc("chats/" + key).get()).data();
    return chat?.memberIds?.includes(me) === true;
  }
  return false;
}
export async function canWrite(
  a: Actor,
  path: string,
  old: DocumentData | undefined,
  next: DocumentData | undefined,
): Promise<boolean> {
  const p = path.split("/"), c = p[0], key = p[1], me = a.uid;
  const isDelete = !next;
  if (p.length === 2 && c === "usernames") {
    if (isDelete) return old?.uid === me;
    return !old && /^[a-z0-9_]{3,24}$/.test(key!) &&
      !["birarada", "admin", "moderator", "support"].includes(key!) &&
      only(next, ["uid"]) && next.uid === me;
  }
  if (p.length === 2 && c === "users" && key === me) {
    if (!next) return !!old?.deletionPending;
    if (!old) {
      return only(next, [
        "uid",
        "username",
        "displayName",
        "bio",
        "avatarUrl",
        "website",
        "isPrivate",
        "followersCount",
        "followingCount",
        "postsCount",
        "allowStrangerDM",
        "createdAt",
        "deletionPending",
        "termsAcceptedAt",
        "termsVersion",
      ]) && next.uid === me && /^[a-z0-9_]{3,24}$/.test(next.username) &&
        !["birarada", "admin", "moderator", "support"].includes(
          next.username,
        ) && text(next.displayName, 60, true).length >= 2 &&
        next.isPrivate === true && next.deletionPending === false &&
        next.termsVersion === "2026-10-21-free1" &&
        time(next.termsAcceptedAt) && time(next.createdAt) &&
        next.avatarUrl === "" && next.followersCount === 0 &&
        next.followingCount === 0 && next.postsCount === 0 &&
        next.allowStrangerDM === false;
    }
    if (!await active(me) && !await pending(me)) return false;
    return unchanged(old, next, [
      "displayName",
      "bio",
      "website",
      "isPrivate",
      "allowStrangerDM",
      "deletionPending",
    ]) && text(next.displayName, 60, true).length >= 2 &&
      typeof next.bio === "string" && next.bio.length <= 300 &&
      typeof next.website === "string" && next.website.length <= 300 &&
      (!next.website || /^https?:\/\/[^\s]+$/.test(next.website)) &&
      typeof next.isPrivate === "boolean" &&
      typeof next.allowStrangerDM === "boolean" &&
      typeof next.deletionPending === "boolean" &&
      (!old.deletionPending || next.deletionPending === true);
  }
  if (!await active(me) && !await pending(me)) return false;
  if (c === "users" && key === me && p[2] === "blocks" && p.length === 4) {
    return isDelete ||
      p[3] !== me && only(next, ["uid", "createdAt"]) && next.uid === p[3] &&
        time(next.createdAt);
  }
  if (c === "posts" && p.length === 2) return isDelete && old?.uid === me;
  if (c === "posts" && p.length === 4) {
    const post = (await db.doc("posts/" + key).get()).data();
    if (!post) return isDelete && await pending(me) && old?.uid === me;
    if (isDelete) return old?.uid === me || post.uid === me;
    if (!await active(me) || !await visible(me, post)) return false;
    if (p[2] === "likes") {
      return !old && p[3] === me && only(next, ["uid", "createdAt"]) &&
        next.uid === me && time(next.createdAt);
    }
    if (p[2] === "comments") {
      return !old && post.commentsEnabled !== false &&
        only(next, ["uid", "username", "text", "createdAt"]) &&
        next.uid === me && next.username === (await profile(me))?.username &&
        text(next.text, 1000, true).length > 0 && time(next.createdAt);
    }
  }
  if (c === "saved" && key === me && p.length === 4 && p[2] === "posts") {
    if (isDelete) return true;
    const post = (await db.doc("posts/" + id(p[3])).get()).data();
    return !old && !!post && await visible(me, post) &&
      only(next, ["postId", "createdAt"]) && next.postId === p[3] &&
      time(next.createdAt);
  }
  if (c === "notes" && p.length === 2 && key === me) {
    if (isDelete) return true;
    if (!await active(me)) return false;
    const profileMe = await profile(me);
    const validSong = !next.songTitle && !next.songUrl ||
      typeof next.songTitle === "string" && next.songTitle.length <= 120 &&
        next.songTitle.trim().length > 0 &&
        next.songTitle === next.songTitle.trim() &&
        /^https:\/\/(open\.spotify\.com\/track\/[a-zA-Z0-9]{22}|www\.youtube\.com\/watch\?v=[a-zA-Z0-9_-]{11})$/
          .test(next.songUrl);
    return only(next, [
      "uid",
      "username",
      "text",
      "songTitle",
      "songUrl",
      "updatedAt",
    ]) && next.uid === me && next.username === profileMe?.username &&
      typeof next.text === "string" && next.text.length <= 60 &&
      (next.text.trim() || next.songTitle) && validSong && time(next.updatedAt);
  }
  if (c === "follows" && p.length === 2) {
    if (isDelete) return old?.followerUid === me || old?.followingUid === me;
    const follower = next.followerUid, following = next.followingUid;
    if (
      key !== `${follower}_${following}` || follower === following ||
      !await active(follower) || !await active(following) ||
      await blocked(follower, following)
    ) return false;
    if (!old) {
      return follower === me &&
        only(next, ["followerUid", "followingUid", "status", "createdAt"]) &&
        next.status ===
          ((await profile(following))?.isPrivate ? "pending" : "accepted") &&
        time(next.createdAt);
    }
    return old.followingUid === me && old.status === "pending" &&
      next.status === "accepted" && unchanged(old, next, ["status"]);
  }
  if (c === "notifications" && p.length === 2) {
    if (isDelete) return old?.targetUid === me || old?.sourceUid === me;
    if (old) {
      return old.targetUid === me && unchanged(old, next, ["read"]) &&
        next.read === true;
    }
    const target = next.targetUid;
    if (
      next.sourceUid !== me || !await active(target) ||
      await blocked(me, target) || !["follow", "request"].includes(next.type) ||
      !only(next, [
        "sourceUid",
        "targetUid",
        "type",
        "text",
        "read",
        "createdAt",
      ])
    ) return false;
    return next.read === false && typeof next.text === "string" &&
      next.text.length <= 250 && time(next.createdAt);
  }
  if (c === "chats") {
    if (
      p.length === 4 && p[2] === "messages" && isDelete &&
      old?.senderUid === me && await pending(me)
    ) return true;
    const chat = p.length === 2
      ? old
      : (await db.doc("chats/" + key).get()).data();
    if (!chat?.memberIds?.includes(me)) return false;
    if (p.length === 4 && p[2] === "messages") {
      return isDelete && old?.senderUid === me;
    }
    return p.length === 2 && !!next && await pending(me) &&
      next.lastMessage === "" && time(next.lastMessageAt) &&
      unchanged(old!, next, ["lastMessage", "lastMessageAt"]);
  }
  if (c === "reports" && p.length === 2) {
    if (isDelete) return old?.reporterUid === me;
    if (
      old || next.reporterUid !== me || next.targetUid === me ||
      !await active(me) || !time(next.createdAt) ||
      typeof next.reason !== "string" || !next.reason.trim() ||
      next.reason.length > 500
    ) return false;
    if (next.noteSnapshot) {
      const note = (await db.doc("notes/" + id(next.targetUid)).get()).data();
      return only(next, [
        "reporterUid",
        "targetUid",
        "reason",
        "createdAt",
        "noteSnapshot",
      ]) && !!note && await allowedNote(me, next.targetUid, note) &&
        equal(next.noteSnapshot, {
          text: note.text,
          songTitle: note.songTitle,
          songUrl: note.songUrl,
          updatedAt: note.updatedAt,
        });
    }
    if (
      !only(next, [
        "reporterUid",
        "targetUid",
        "postId",
        "reason",
        "createdAt",
      ]) || !await active(next.targetUid) || await blocked(me, next.targetUid)
    ) return false;
    if (next.postId) {
      const post = (await db.doc("posts/" + id(next.postId)).get()).data();
      return !!post && post.uid === next.targetUid && await visible(me, post);
    }
    return true;
  }
  return false;
}
export async function commitClient(
  a: Actor,
  reads: { path: string; rev: any }[],
  writes: Write[],
) {
  if (
    !Array.isArray(reads) || !Array.isArray(writes) || reads.length > 200 ||
    writes.length > 200
  ) deny();
  await rate(a.uid, "client-write", 30);
  const store = db;
  const observed = new Map<string, Snapshot>(),
    beforeObserver = store.readObserver;
  store.readObserver = (s) => observed.set(s.raw.path, s);
  try {
    const config = (await db.doc("appConfig/public").get()).data();
    if (config?.maintenance === true && a.role === "member") {
      throw new HttpsError(
        "unavailable",
        "Kısa bir bakımdayız. Biraz sonra yeniden dene.",
      );
    }
    const tx = new Transaction(store);
    const pending = new Map(writes.map((w) => [w.path, w.data]));
    for (const read of reads) {
      if (typeof read.path !== "string" || read.path.length > 1500) deny();
      const r = await tx.get(db.doc(read.path));
      if (!await canRead(a, read.path, r.data())) deny();
      if (String(r.raw.rev) !== String(read.rev)) {
        throw Object.assign(Error("Concurrent update; retry"), {
          code: "conflict",
        });
      }
    }
    for (const w of writes) {
      if (!["set", "delete"].includes(w.kind) || w.merge || !w.path) deny();
      const s = await tx.get(db.doc(w.path));
      if (w.path === "users/" + a.uid && !s.exists && w.data) {
        const claimed = (await db.doc("usernames/" + id(w.data.username)).get())
          .data();
        if (
          claimed?.uid !== a.uid &&
          pending.get("usernames/" + w.data.username)?.uid !== a.uid
        ) deny();
      }
      if (w.path.startsWith("notifications/") && !s.exists && w.data) {
        const followPath = "follows/" + a.uid + "_" + id(w.data.targetUid);
        const follow = pending.get(followPath) ||
          (await db.doc(followPath).get()).data();
        if (
          follow?.followerUid !== a.uid ||
          follow?.followingUid !== w.data.targetUid ||
          w.path !== "notifications/" + a.uid + "_" + w.data.targetUid
        ) deny();
      }
      if (!await canWrite(a, w.path, s.data(), w.data)) deny();
      if (w.kind === "delete") tx.delete(s.ref);
      else tx.set(s.ref, w.data!);
    }
    for (const row of observed.values()) {
      if (!tx.reads.has(row.raw.path)) tx.reads.set(row.raw.path, row);
    }
    await tx.commit();
    return { ok: true };
  } finally {
    store.readObserver = beforeObserver;
  }
}
