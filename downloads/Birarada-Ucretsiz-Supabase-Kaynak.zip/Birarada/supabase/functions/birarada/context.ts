import { AsyncLocalStorage } from "node:async_hooks";
import { type DocumentData, Records } from "./records.ts";
export type Identity = {
  uid: string;
  email: string;
  emailVerified: boolean;
  authTime: number;
  issuedAt: number;
};
export type Context = {
  db: Records;
  identity: Identity;
  storage: {
    save: (key: string, bytes: Uint8Array, type: string) => Promise<void>;
    remove: (key: string) => Promise<void>;
    read: (key: string, start: number, end: number) => Promise<Response>;
  };
};
export const context = new AsyncLocalStorage<Context>();
export function current() {
  const c = context.getStore();
  if (!c) throw Error("Request context missing");
  return c;
}
export const db = new Proxy({} as Records, {
  get(_t, key) {
    const value = (current().db as any)[key];
    return typeof value === "function" ? value.bind(current().db) : value;
  },
});
export const accounts = {
  async getUser(uid: string) {
    const row = (await db.doc("authUsers/" + uid).get()).data();
    if (!row) throw Error("Account not found");
    const role = (await db.doc("roles/" + uid).get()).data();
    return {
      uid,
      email: current().identity.uid === uid ? current().identity.email : "",
      emailVerified: row.emailVerified,
      customClaims: { biraradaRole: role?.role || "member" },
    };
  },
  async setCustomUserClaims(uid: string, claims: DocumentData) {
    await db.doc("roles/" + uid).set({ role: claims.biraradaRole || "member" });
  },
  async updateUser(_uid: string, _input: DocumentData) {
    /* The atomic accountStatus gate controls this application; Firebase sign-in remains independent. */
  },
  async revokeRefreshTokens(uid: string) {
    await db.doc("roles/" + uid).set({
      reauthAfter: Math.floor(Date.now() / 1000),
    }, { merge: true });
  },
};
export async function saveBlob(key: string, bytes: Uint8Array, type: string) {
  await current().storage.save(key, bytes, type);
}
export async function deleteBlob(key: string) {
  await current().storage.remove(key);
}
export class HttpsError extends Error {
  constructor(public code: string, message: string) {
    super(message);
  }
}
