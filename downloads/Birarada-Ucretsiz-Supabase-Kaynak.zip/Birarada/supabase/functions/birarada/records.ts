export type DocumentData = Record<string, any>;
export type RawRecord = {
  path: string;
  data: DocumentData | null;
  rev: string | number | null;
};
export type Driver = {
  rpc(
    name: string,
    input: Record<string, unknown>,
  ): Promise<{ data: any; error: any }>;
};
export class Timestamp {
  constructor(public seconds: number, public nanoseconds: number) {}
  static now() {
    return Timestamp.fromMillis(Date.now());
  }
  static fromMillis(ms: number) {
    return new Timestamp(Math.floor(ms / 1000), Math.floor((ms % 1000) * 1e6));
  }
  toMillis() {
    return this.seconds * 1000 + this.nanoseconds / 1e6;
  }
  toDate() {
    return new Date(this.toMillis());
  }
  isEqual(t: Timestamp) {
    return this.seconds === t.seconds && this.nanoseconds === t.nanoseconds;
  }
}
export class FieldPath {
  constructor(...parts: string[]) {
    this.parts = parts;
  }
  parts: string[];
  static documentId() {
    return "__name__";
  }
}
export const FieldValue = {
  delete: () => ({ __op: "delete" }),
  arrayUnion: (...values: any[]) => ({ __op: "union", values }),
  serverTimestamp: () => ({ __op: "time" }),
  increment: (value: number) => ({ __op: "increment", value }),
};
export function encode(v: any): any {
  if (v instanceof Timestamp) return { __ts: [v.seconds, v.nanoseconds] };
  if (Array.isArray(v)) return v.map(encode);
  if (v && typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v).filter(([, x]) => x !== undefined).map((
        [k, x],
      ) => [k, encode(x)]),
    );
  }
  return v;
}
export function decode(v: any): any {
  if (v && typeof v === "object" && Array.isArray(v.__ts)) {
    return new Timestamp(v.__ts[0], v.__ts[1]);
  }
  if (Array.isArray(v)) return v.map(decode);
  if (v && typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v).map(([k, x]) => [k, decode(x)]),
    );
  }
  return v;
}
export function safePath(value: string) {
  if (
    !value || value.length > 1500 ||
    !value.split("/").every((p) => /^[a-zA-Z0-9_:\-]{1,160}$/.test(p))
  ) throw Error("Invalid record path");
  return value;
}
export class Snapshot {
  readonly exists: boolean;
  readonly id: string;
  readonly ref: DocumentReference;
  constructor(public db: Records, public raw: RawRecord) {
    this.exists = raw.data !== null;
    this.id = raw.path.split("/").at(-1)!;
    this.ref = db.doc(raw.path);
  }
  data(): DocumentData | undefined {
    return this.exists ? decode(this.raw.data) : undefined;
  }
  get(key: string): any {
    return key.split(".").reduce((a, k) => a?.[k], this.data());
  }
}
export class QuerySnapshot {
  readonly size: number;
  readonly empty: boolean;
  constructor(public docs: (Snapshot & { data(): DocumentData })[]) {
    this.size = docs.length;
    this.empty = !docs.length;
  }
  forEach(cb: (s: Snapshot) => unknown) {
    this.docs.forEach(cb);
  }
}
export class DocumentReference {
  readonly id: string;
  readonly parent: Query;
  constructor(public db: Records, public path: string) {
    safePath(path);
    if (path.split("/").length % 2) throw Error("Invalid document path");
    this.id = path.split("/").at(-1)!;
    this.parent = new Query(db, path.split("/").slice(0, -1).join("/"));
  }
  collection(name: string) {
    return this.db.collection(this.path + "/" + name);
  }
  async get() {
    return (await this.db.getAll(this))[0]!;
  }
  async set(data: DocumentData, options?: { merge?: boolean }) {
    await this.db.runTransaction(async (t) => {
      if (options?.merge) await t.get(this);
      t.set(this, data, options);
    });
  }
  async update(data: DocumentData | FieldPath, value?: any) {
    if (data instanceof FieldPath) data = { [data.parts.join(".")]: value };
    await this.db.runTransaction(async (t) => {
      const s = await t.get(this);
      if (!s.exists) throw Error("Record does not exist");
      t.update(this, data);
    });
  }
  async create(data: DocumentData) {
    await this.db.runTransaction(async (t) => {
      const s = await t.get(this);
      if (s.exists) throw Error("Record exists");
      t.create(this, data);
    });
  }
  async delete() {
    await this.db.runTransaction(async (t) => {
      await t.get(this);
      t.delete(this);
    });
  }
}
type Filter = [string, string, any];
type Order = [string, string];
export class Query {
  filters: Filter[] = [];
  orders: Order[] = [];
  maximum = 1000;
  bounds: { kind: string; values: any[] }[] = [];
  constructor(public db: Records, public path: string, public group = false) {
    safePath(path);
  }
  protected copy() {
    const q = new Query(this.db, this.path, this.group);
    q.filters = [...this.filters];
    q.orders = [...this.orders];
    q.maximum = this.maximum;
    q.bounds = [...this.bounds];
    return q;
  }
  where(field: string, op: string, value: any) {
    const q = this.copy();
    q.filters.push([field, op, value]);
    return q;
  }
  orderBy(field: string, direction = "asc") {
    const q = this.copy();
    q.orders.push([field, direction]);
    return q;
  }
  limit(n: number) {
    const q = this.copy();
    q.maximum = Math.max(1, Math.min(n, 1000));
    return q;
  }
  private bound(kind: string, values: any[]) {
    const q = this.copy();
    q.bounds.push({
      kind,
      values: values[0] instanceof Snapshot
        ? q.orders.map(([field]) =>
          field === "__name__" ? values[0].id : values[0].get(field)
        )
        : values,
    });
    return q;
  }
  startAfter(...v: any[]) {
    return this.bound("after", v);
  }
  startAt(...v: any[]) {
    return this.bound("start", v);
  }
  endAt(...v: any[]) {
    return this.bound("end", v);
  }
  doc(id: string = crypto.randomUUID()) {
    return this.db.doc(this.path + "/" + id);
  }
  async add(data: DocumentData) {
    const r = this.doc();
    await r.create(data);
    return r;
  }
  async get() {
    const limit = this.maximum;
    let offset = 0;
    const rows: Snapshot[] = [];
    while (rows.length < limit) {
      const data = await this.db.rpc("birarada_query", {
        spec: encode({
          path: this.path,
          group: this.group,
          filters: this.filters,
          orders: this.orders,
          limit: Math.min(1000, limit + 100),
          offset,
        }),
      });
      const batch = (data as RawRecord[]).map((raw) =>
        new Snapshot(this.db, raw)
      );
      for (const s of batch) {
        if (this.matchesBounds(s)) {
          rows.push(s);
          if (rows.length === limit) break;
        }
      }
      if (batch.length < Math.min(1000, limit + 100)) break;
      offset += batch.length;
      if (offset > 10000) break;
    }
    return new QuerySnapshot(rows as (Snapshot & { data(): DocumentData })[]);
  }
  private matchesBounds(s: Snapshot) {
    return this.bounds.every((b) => {
      let cmp = 0;
      for (let i = 0; i < b.values.length; i++) {
        const [field, direction] = this.orders[i] || ["__name__", "asc"];
        const a = field === "__name__" ? s.id : s.get(field), v = b.values[i];
        const x = a instanceof Timestamp ? a.toMillis() : a,
          y = v instanceof Timestamp ? v.toMillis() : v;
        cmp = x === y ? 0 : x > y ? 1 : -1;
        if (direction === "desc") cmp = -cmp;
        if (cmp) break;
      }
      return b.kind === "after"
        ? cmp > 0
        : b.kind === "start"
        ? cmp >= 0
        : cmp <= 0;
    });
  }
  count() {
    return {
      get: async () => {
        const result = await this.db.rpc("birarada_query", {
          spec: encode({
            path: this.path,
            group: this.group,
            filters: this.filters,
            count: true,
          }),
        });
        return { data: () => ({ count: Number(result.count) }) };
      },
    };
  }
}
export type Write = {
  kind: "set" | "create" | "delete";
  path: string;
  data?: DocumentData;
  merge?: boolean;
};
function setField(target: any, key: string, value: any) {
  const fields = key.split(".");
  let p = target;
  for (const f of fields.slice(0, -1)) {
    p[f] = p[f] && typeof p[f] === "object" ? p[f] : {};
    p = p[f];
  }
  const field = fields.at(-1)!;
  if (value?.__op === "delete") delete p[field];
  else if (value?.__op === "union") {
    p[field] = [
      ...new Map(
        [...(p[field] || []), ...value.values].map(
          (v) => [JSON.stringify(encode(v)), v],
        ),
      ).values(),
    ];
  } else if (value?.__op === "time") p[field] = Timestamp.now();
  else if (value?.__op === "increment") {
    p[field] = Number(p[field] || 0) + Number(value.value);
  } else p[field] = value;
}
export function applyWrite(before: DocumentData | undefined, write: Write) {
  if (write.kind === "delete") return undefined;
  const out: any = write.merge ? decode(encode(before || {})) : {};
  for (const [k, v] of Object.entries(write.data || {})) setField(out, k, v);
  return out;
}
export class Transaction {
  reads = new Map<string, Snapshot>();
  writes: Write[] = [];
  constructor(public db: Records) {}
  async get(r: DocumentReference): Promise<Snapshot> {
    if (this.reads.has(r.path)) return this.reads.get(r.path)!;
    const s = await r.get();
    this.reads.set(r.path, s);
    return s;
  }
  async getAll(...rs: DocumentReference[]) {
    return Promise.all(rs.map((r) => this.get(r)));
  }
  set(r: DocumentReference, data: DocumentData, options?: { merge?: boolean }) {
    this.writes.push({
      kind: "set",
      path: r.path,
      data,
      merge: options?.merge,
    });
    return this;
  }
  update(r: DocumentReference, data: DocumentData) {
    return this.set(r, data, { merge: true });
  }
  create(r: DocumentReference, data: DocumentData) {
    this.writes.push({ kind: "create", path: r.path, data });
    return this;
  }
  delete(r: DocumentReference) {
    this.writes.push({ kind: "delete", path: r.path });
    return this;
  }
  async commit() {
    for (const w of this.writes) {
      if (!this.reads.has(w.path)) await this.get(this.db.doc(w.path));
    }
    const final = new Map<string, Write>();
    for (const w of this.writes) {
      const prev = final.get(w.path);
      const before = prev
        ? applyWrite(undefined, prev)
        : this.reads.get(w.path)?.data();
      const next = applyWrite(before, w);
      final.set(w.path, {
        kind: w.kind === "delete"
          ? "delete"
          : w.kind === "create"
          ? "create"
          : "set",
        path: w.path,
        ...(next ? { data: next } : {}),
      });
    }
    const okay = await this.db.rpc("birarada_commit", {
      reads: [...this.reads.values()].map((s) => ({
        path: s.raw.path,
        rev: s.raw.rev,
      })),
      writes: [...final.values()].map((w) => ({
        kind: w.kind,
        path: w.path,
        ...(w.data ? { data: encode(w.data) } : {}),
      })),
    });
    if (!okay) {
      throw Object.assign(Error("Concurrent update; retry"), {
        code: "conflict",
      });
    }
  }
}
export class Records {
  readObserver?: (s: Snapshot) => void;
  constructor(public driver: Driver) {}
  async rpc(name: string, input: Record<string, unknown>) {
    const r = await this.driver.rpc(name, input);
    if (r.error) {
      throw Object.assign(
        Error(
          /FREE_/.test(r.error.message || "")
            ? "Ucretsiz plan icin uygulama sinirina ulasildi."
            : "Database operation failed",
        ),
        { code: r.error.code || "database" },
      );
    }
    return r.data;
  }
  doc(path: string) {
    return new DocumentReference(this, path);
  }
  collection(path: string) {
    return new Query(this, path);
  }
  collectionGroup(name: string) {
    return new Query(this, name, true);
  }
  async getAll(...refs: DocumentReference[]) {
    if (!refs.length) return [];
    const rows: Snapshot[] =
      (await this.rpc("birarada_get", { paths: refs.map((r) => r.path) })).map((
        r: RawRecord,
      ) => new Snapshot(this, r));
    for (const row of rows) this.readObserver?.(row);
    return rows;
  }
  batch() {
    const t = new Transaction(this);
    return t;
  }
  async runTransaction<T>(fn: (t: Transaction) => Promise<T>): Promise<T> {
    for (let i = 0; i < 5; i++) {
      const t = new Transaction(this);
      try {
        const result = await fn(t);
        await t.commit();
        return result;
      } catch (e) {
        if ((e as any).code !== "conflict" || i === 4) throw e;
      }
    }
    throw Error("Transaction failed");
  }
  async recursiveDelete(ref: DocumentReference) {
    while (true) {
      const all: RawRecord[] = await this.rpc("birarada_subtree", {
        prefix: ref.path,
        maximum: 200,
      });
      if (!all.length) return;
      const t = this.batch();
      for (const raw of all) {
        const s = new Snapshot(this, raw);
        t.reads.set(raw.path, s);
        t.delete(s.ref);
      }
      await t.commit();
    }
  }
}
