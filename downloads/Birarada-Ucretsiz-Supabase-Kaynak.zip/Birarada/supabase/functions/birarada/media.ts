import { InputError, LIMITS, type MediaKind, type Purpose } from "./domain.ts";
function u32(b: Uint8Array, o: number) {
  if (o + 4 > b.length) throw new InputError("Bozuk medya.");
  return new DataView(b.buffer, b.byteOffset, b.byteLength).getUint32(o);
}
function ascii(b: Uint8Array, o: number, n: number) {
  return String.fromCharCode(...b.subarray(o, o + n));
}
export function inspectJpeg(b: Uint8Array) {
  if (b.length < 4 || b[0] !== 255 || b[1] !== 216) {
    throw new InputError("Fotoğraf JPEG biçiminde olmalı.");
  }
  let o = 2, w = 0, h = 0;
  const chunks = [b.subarray(0, 2)];
  while (o < b.length) {
    const begin = o;
    if (b[o++] !== 255) throw new InputError("Bozuk JPEG.");
    while (b[o] === 255) o++;
    const marker = b[o++];
    if (marker === 218) {
      if (!w || !h || b[b.length - 2] !== 255 || b[b.length - 1] !== 217) {
        throw new InputError("Eksik JPEG.");
      }
      chunks.push(b.subarray(begin));
      break;
    }
    if (marker === 217) break;
    if (marker === 0 || marker === undefined) {
      throw new InputError("Bozuk JPEG.");
    }
    const length = ((b[o] || 0) << 8) | (b[o + 1] || 0);
    if (length < 2 || o + length > b.length) {
      throw new InputError("Bozuk JPEG.");
    }
    if ([192, 193, 194].includes(marker)) {
      h = ((b[o + 3] || 0) << 8) | (b[o + 4] || 0);
      w = ((b[o + 5] || 0) << 8) | (b[o + 6] || 0);
      if (!w || !h || w * h > 16000000) {
        throw new InputError("Fotoğraf en fazla 16 megapiksel olabilir.");
      }
    }
    if (!(marker >= 225 && marker <= 239) && marker !== 254) {
      chunks.push(b.subarray(begin, o + length));
    }
    o += length;
  }
  if (!w || !h || !chunks.some((c) => c[1] === 218)) {
    throw new InputError("Fotoğraf tamamlanmamış.");
  }
  const size = chunks.reduce((n, c) => n + c.length, 0),
    clean = new Uint8Array(size);
  let at = 0;
  for (const c of chunks) {
    clean.set(c, at);
    at += c.length;
  }
  return {
    bytes: clean,
    contentType: "image/jpeg",
    width: w,
    height: h,
    duration: 0,
  };
}
type Box = { type: string; start: number; end: number; data: number };
function boxes(b: Uint8Array, start: number, end: number): Box[] {
  let o = start;
  const out: Box[] = [];
  while (o < end) {
    if (o + 8 > end) throw new InputError("Bozuk MP4.");
    let size = u32(b, o), header = 8;
    if (size === 1) {
      if (o + 16 > end || u32(b, o + 8) !== 0) {
        throw new InputError("MP4 kutusu çok büyük.");
      }
      size = u32(b, o + 12);
      header = 16;
    }
    if (size === 0) size = end - o;
    if (size < header || o + size > end) throw new InputError("Bozuk MP4.");
    out.push({
      type: ascii(b, o + 4, 4),
      start: o,
      end: o + size,
      data: o + header,
    });
    o += size;
    if (out.length > 20000) throw new InputError("MP4 yapısı çok karmaşık.");
  }
  return out;
}
export function inspectMp4(b: Uint8Array, kind: MediaKind, purpose: Purpose) {
  const top = boxes(b, 0, b.length), movie = top.find((x) => x.type === "moov");
  if (
    !movie || !top.some((x) => x.type === "ftyp") ||
    !top.some((x) => x.type === "mdat" && x.end > x.data)
  ) throw new InputError("MP4/M4A dosyası seç.");
  const child = boxes(b, movie.data, movie.end);
  let duration = 0, w = 0, h = 0, video = false, audio = false;
  for (const track of child.filter((x) => x.type === "trak")) {
    const media = boxes(b, track.data, track.end).find((x) =>
      x.type === "mdia"
    );
    if (!media) continue;
    const m = boxes(b, media.data, media.end),
      header = m.find((x) => x.type === "mdhd"),
      handler = m.find((x) => x.type === "hdlr"),
      minf = m.find((x) => x.type === "minf");
    if (!header || !handler || !minf) throw new InputError("Eksik MP4 izi.");
    const v = b[header.data],
      scale = u32(b, header.data + (v === 1 ? 20 : 12)),
      ticks = v === 1
        ? u32(b, header.data + 24) * 4294967296 + u32(b, header.data + 28)
        : u32(b, header.data + 16);
    if (!scale || !ticks || ticks / scale > 181) {
      throw new InputError("Medya en fazla 180 saniye olabilir.");
    }
    duration = Math.max(duration, ticks / scale);
    const stbl = boxes(b, minf.data, minf.end).find((x) => x.type === "stbl"),
      dinf = boxes(b, minf.data, minf.end).find((x) => x.type === "dinf");
    if (!stbl || !dinf) throw new InputError("Eksik MP4 verisi.");
    const dref = boxes(b, dinf.data, dinf.end).find((x) => x.type === "dref");
    if (!dref) throw new InputError("Eksik MP4 verisi.");
    for (const r of boxes(b, dref.data + 8, dref.end)) {
      if (!["url ", "urn "].includes(r.type) || (u32(b, r.data) & 1) !== 1) {
        throw new InputError("Harici medya bağlantısı kabul edilmez.");
      }
    }
    const stsd = boxes(b, stbl.data, stbl.end).find((x) => x.type === "stsd");
    if (!stsd) throw new InputError("Eksik MP4 codec.");
    const samples = boxes(b, stsd.data + 8, stsd.end),
      type = ascii(b, handler.data + 8, 4);
    for (const sample of samples) {
      if (type === "vide") {
        if (!["avc1", "avc3"].includes(sample.type)) {
          throw new InputError(
            "Video H.264 MP4 biçiminde olmalı; HEVC/diğer codec desteklenmiyor.",
          );
        }
        if (sample.data + 28 > sample.end) {
          throw new InputError("Bozuk video boyutu.");
        }
        w = (b[sample.data + 24]! << 8) | b[sample.data + 25]!;
        h = (b[sample.data + 26]! << 8) | b[sample.data + 27]!;
        if (!w || !h || w * h > 16000000) {
          throw new InputError("Video boyutu çok büyük.");
        }
        video = true;
      } else if (type === "soun") {
        if (sample.type !== "mp4a") {
          throw new InputError("Ses AAC M4A biçiminde olmalı.");
        }
        audio = true;
      } else throw new InputError("Bu dosyanın ek izleri desteklenmiyor.");
    }
  }
  const max = purpose === "story" ? 60 : purpose === "reel" ? 90 : 180;
  if (
    duration <= 0 || duration > max + .1 || kind === "video" && !video ||
    kind === "audio" && (!audio || video)
  ) throw new InputError(`Geçerli medya seç; en fazla ${max} saniye.`);
  return {
    bytes: b,
    contentType: kind === "audio" ? "audio/mp4" : "video/mp4",
    width: w,
    height: h,
    duration,
  };
}
export function validateMedia(
  bytes: Uint8Array,
  kind: MediaKind,
  purpose: Purpose,
) {
  if (bytes.length < 1 || bytes.length > LIMITS[kind]) {
    throw new InputError("Medya boyut sınırını aşıyor.");
  }
  return kind === "image"
    ? inspectJpeg(bytes)
    : inspectMp4(bytes, kind, purpose);
}
