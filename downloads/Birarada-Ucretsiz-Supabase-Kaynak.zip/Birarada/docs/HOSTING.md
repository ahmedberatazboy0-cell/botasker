# Güncel destek sayfalarının yayını

Bu ücretsiz sürümün gizlilik metni Firebase Authentication ve Supabase PostgreSQL/Storage/Edge altyapısını açıklar. Onay sürümü `2026-10-21-free1`; uygulama önceki sürümü yeniden kabul ettirir. Eski Firebase-only metin ücretsiz sürüm için yeterli değildir.

`hosting/public/` içindeki privacy.html, delete-account.html, terms.html, child-safety.html ve birarada-legal.css mobil uyumludur. İstenen adresler https://birarada-5650c.web.app üzerinde `/privacy`, `/delete-account`, `/terms`, `/child-safety`.

Firebase Hosting tam bir sürüm dağıtır. Bu klasörü tek başına mevcut sitenin üstüne dağıtmak mevcut ana sayfayı ve dosyalarını kaldırabilir. Bu nedenle dağıtım otomatik çalıştırılmaz.

1. Mevcut sitenin yetkili tam build çıktısı ve Hosting config'ini al.
2. Dört HTML ve CSS dosyasını tam çıktıya ekle; mevcut dosyaları koru.
3. Bu paketin firebase.json dosyasındaki dört kesin yolu mevcut config'teki catch-all kuralından önce ekle. Diğer rewrite, header, redirect ve target ayarlarını koru.
4. Birleştirilmiş siteyi yerel emulator veya yetkili preview kanalında aç; ana sayfa, eski yollar ve dört yeni sayfayı kontrol et.
5. Resmî `firebase login` ile kendi hesabını bağla; birleştirilmiş tam config üzerinden yalnız Hosting'i, açıkça birarada-5650c projesine dağıt. Firestore/Storage/Functions dağıtma.
6. Dört adresi oturum kapalı aç. Sonra uygulama klasöründe `npm run release:live` çalıştır. Bu kontrol Supabase sunucusu ve yeni politika sürümünü de doğrular.

Bu ortamda canlı Hosting oturumu/yayını bulunmuyor. Kaynak HTML yerel doğrulanır; canlıya dağıtıldığı iddia edilmez. Gizlilik açıklaması fotoğraf EXIF temizliği, H.264/AAC biçim sınırı, şifrelenmemiş mesajlar, sorguyla yenileme, gecikebilen istek tabanlı temizlik ve sağlayıcı saklama süreçlerini açıklar.

İşletmeci destek/silme/şikâyet/çocuk güvenliği taleplerini gerçekten takip etmeli; hedef yaş, Play veri güvenliği ve içerik derecesi beyanlarını gerçek davranışa göre tamamlamalıdır. Bir mailto bağlantısı talebi otomatik göndermiş veya hesabı silmiş sayılmaz.
