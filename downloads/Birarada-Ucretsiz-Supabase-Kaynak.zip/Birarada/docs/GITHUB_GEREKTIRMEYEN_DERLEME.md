# GitHub gerektirmeyen üretim derlemesi

Node.js 22/24 ve Chrome/Edge yeterlidir; Java veya Docker gerekmez. Yeni klasöre çıkardığın ücretsiz pakette önce `UCRETSIZ_KUR.bat` çalıştır. Resmî Supabase girişinden sonra şema, özel medya bucket'ı ve Edge API dağıtılır. Güncel yasal sayfalar mevcut tam web çıktısına birleştirilerek yayımlanır; ayrıntılar HOSTING.md içinde.

Ardından `AAB_OLUSTUR.bat` veya `npm run build:no-github` çalıştır. Tip, birim, ücretsiz sunucu, gerçek yerel tarayıcı ve canlı API/yasal sürüm kontrolleri başarısız olursa derleme durur. Windows'ta tarayıcı otomatik bulunur; özel konum CHROMIUM_PATH ile verilebilir.

Mevcut EAS @ahmedberat/birarada, projectId 9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b korunur. Yardımcı yalnız kendi `.birarada-release/` klasöründe derleme kopyası oluşturur. Kaynak app.json, özel env dosyaları, kullanıcı Git geçmişi ve sunucu anahtarları EAS'e kopyalanmaz. Supabase CLI için GitHub'dan imzalı hash listeli resmî araç indirilir; Git hesabı veya Git kurulumu gerekmez.

Expo oturumu yoksa resmî giriş açılır. Terminale dönüş olmazsa Ctrl+C, ardından `npx --yes eas-cli@25.2.0 login --no-browser` ve tekrar BAT. Parola veya tokenı sohbetten paylaşma. Başka proje/keystore oluşturma.

EAS `--freeze-credentials --non-interactive` kullanır. Mevcut imzaya erişilemiyorsa durur. Başarıda yeni `.aab` bağlantısı EAS çıktısındadır. Araç mağazaya otomatik göndermez. Üretilen AAB ayrıca gerçek telefon, imza, hedef API, 16 KB native uyumluluk ve Play Console doğrulamasından geçmelidir. Kaynak testleri bunları kanıtlamaz.
