# Şarkılı notlar

Ana Sayfa → **Notlar · Şarkını paylaş** veya Profil → **Notum ve şarkım** üzerinden açılır. Bir hesap aynı anda bir not yayımlar; yeni paylaşım öncekinin yerini alır. Metin en fazla 60, şarkı/sanatçı adı en fazla 120 karakterdir. Yalnız metin, yalnız şarkı veya ikisi birlikte paylaşılabilir. Şarkı adı ve bağlantısı birlikte girilmelidir.

Spotify'ın tam şarkı bağlantıları ile YouTube video, youtu.be, mobil, Music ve Shorts bağlantıları kabul edilir. Spotify albüm/listesi, YouTube oynatma listesi, kısaltılmış Spotify bağlantısı, başka siteler, HTTP ve uygulama içi komut URL'leri kabul edilmez. Bağlantılar standart HTTPS adresine dönüştürülür; takip parametreleri kaldırılır. Kullanıcı bağlantıya dokunduğunda ilgili servis açılır. Uygulama şarkı dosyası, kapak resmi veya otomatik önizleme indirmez; müzik dosyası yükleme/çalma özelliği ve üçüncü taraf hesap oturumu yoktur.

`notes/{uid}` belgesi yazar kimliği, kullanıcı adı, metin, şarkı adı, standart bağlantı ve sunucunun `updatedAt` zamanını içerir. Başka kullanıcılar yalnız onaylanmış takip ilişkisiyle okuyabilir. Her iki yönde engel, kaldırılmış takip ve silinmekte olan hesap bu erişimi kısıtlar. Genel not listelemesi kapalıdır; takipler 30'luk gruplarla yüklenip notlar ayrı ayrı okunur. **Daha fazla hesap göster** ve **Notları yenile** düğmeleri vardır.

Sunucu erişim kuralı 24 saat dolduğunda takipçilerin okumasını reddeder. Arayüz de zamanlayıcıyla notu gizler. Süre dolması belgenin fiziksel silinmesi değildir: sahibi eski kaydı görebilir, değiştirebilir veya silebilir. Hesap temizliği, profil ve Auth silinmeden önce güncel/süresi dolmuş notu kaldırır; yarım kalmış temizliğin tekrarı desteklenir.

Not şikâyeti, o anda okunabilen notun metnini, şarkı adını, bağlantısını ve tam zaman damgasını kanıt olarak saklar. Kurallar bu kopyayı gerçek kayıtla karşılaştırır; değiştirilmiş/silinmiş/süresi dolmuş notun eski kopyasıyla şikâyet gönderilemez. Şikâyetlerin işletim sorumlusu tarafından incelenmesi hâlâ gereklidir. Başkalarının oluşturduğu şikâyet kopyaları, notun sahibi hesabını sildiğinde otomatik silinmez; gizlilik metninde açıklanmıştır.

## Doğrulama

- `npm test`: 17 test geçti; 8'i bağlantı güvenliği, not doğrulaması ve 24 saat sınırı içindir.
- `npm run test:ui`: 4 test geçti; 3'ü gerçek not düzenleme bileşeninin tarayıcıda doğrulanmasıdır. Hatalı bağlantı, eksik şarkı alanları, kayıt hatasında taslağı koruma, silme onayı ve başka cihazdan güncelleme sırasında taslağı koruma sınandı. Bu üç testin veri callbacks'i simülasyondur; Firebase entegrasyonu değildir.
- `npm run typecheck` ve altı yayın ayarı testi geçti. Android/iOS Hermes ve web export başarılıdır; native AAB değildir.
- Ücretsiz sürümde Firestore kuralları kullanılmaz. PostgreSQL + Edge entegrasyon testleri (npm run test:free), gerçek şarkı notu yazımını, sahte bağlantının reddini ve 120 karakterlik şarkı adını da doğrular. Yetkisiz tablo/RPC erişimi kapalıdır.

Yayın öncesinde iki gerçek hesapla not paylaşma/düzenleme/silme, takip kabulü/geri çekme, iki yönlü engel, şikâyet ve hesap silme akışları canlı Supabase sunucusunda da denenmeli. Kaynak testleri canlı Firebase kimlik doğrulaması veya Android AAB doğrulaması yerine geçmez. TEST_REPORT.md güncel sonuçları belirtir.
