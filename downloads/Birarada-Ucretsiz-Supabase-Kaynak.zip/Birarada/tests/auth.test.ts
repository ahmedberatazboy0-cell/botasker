import { test } from "node:test";
import assert from "node:assert/strict";
import { initializeApp, deleteApp } from "firebase/app";
import {
  initializeAuth,
  inMemoryPersistence,
  connectAuthEmulator,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  deleteUser,
} from "firebase/auth";
test("Firebase Auth emulator: register, logout, invalid login, login, reset request", async () => {
  const app = initializeApp(
      { apiKey: "demo-key", projectId: "demo-birarada" },
      "auth-integration",
    ),
    auth = initializeAuth(app, { persistence: inMemoryPersistence });
  connectAuthEmulator(auth, "http://127.0.0.1:9099", { disableWarnings: true });
  const email = `onboarding-${Date.now()}@example.test`;
  try {
    const result = await createUserWithEmailAndPassword(
      auth,
      email,
      "valid-test-password",
    );
    const uid = result.user.uid;
    assert.equal(auth.currentUser?.uid, uid);
    await signOut(auth);
    assert.equal(auth.currentUser, null);
    await assert.rejects(
      signInWithEmailAndPassword(auth, email, "wrong-password"),
    );
    const again = await signInWithEmailAndPassword(
      auth,
      email,
      "valid-test-password",
    );
    assert.equal(again.user.uid, uid);
    await sendPasswordResetEmail(auth, email);
    const codes = await (
      await fetch(
        "http://127.0.0.1:9099/emulator/v1/projects/demo-birarada/oobCodes",
      )
    ).json();
    assert.ok(
      codes.oobCodes.some(
        (code: { email: string; requestType: string }) =>
          code.email === email && code.requestType === "PASSWORD_RESET",
      ),
    );
    await deleteUser(again.user);
  } finally {
    await deleteApp(app);
  }
});
