import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mergeFeedPages} from '../src/utils/feed';
import type {Post} from '../src/types';
const post=(id:string,caption:string):Post=>({id,caption,uid:'user',username:'user',mediaUrl:'',mediaType:'image',commentsEnabled:true});
test('live records override stale paginated copies without duplicate cards',()=>{
 const first=[post('a','newest'),post('b','edited')],more=[post('b','stale'),post('c','older'),post('c','duplicate')];
 const merged=mergeFeedPages(first,more);
 assert.deepEqual(merged.map(p=>[p.id,p.caption]),[['a','newest'],['b','edited'],['c','older']]);
 assert.equal(more.length,3);assert.equal(more[0]?.caption,'stale');
});
test('empty and single-page feeds retain server ordering',()=>{
 assert.deepEqual(mergeFeedPages([],[]),[]);
 const rows=[post('z','one'),post('a','two')];
 assert.deepEqual(mergeFeedPages(rows,[]),rows);
 assert.deepEqual(mergeFeedPages([],rows),rows);
});
