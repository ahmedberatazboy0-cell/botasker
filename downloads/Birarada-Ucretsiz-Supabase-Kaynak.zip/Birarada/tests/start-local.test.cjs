const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const http = require('node:http');
const net = require('node:net');
const os = require('node:os');
const path = require('node:path');
const { spawn } = require('node:child_process');
const {
  nodeVersionSupported,
  javaMajor,
  testEnvironment,
  assertPortsFree,
  waitForHttp,
  createSupervisor,
} = require('../scripts/start-local.cjs');

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function listen(server) {
  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(0, '127.0.0.1', resolve);
  });
  return server.address().port;
}

async function close(server) {
  if (!server.listening) return;
  await new Promise((resolve, reject) => {
    server.close((error) => error ? reject(error) : resolve());
    server.closeAllConnections?.();
  });
}

async function until(check, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  do {
    const value = await check();
    if (value) return value;
    await delay(20);
  } while (Date.now() < deadline);
  throw new Error('Test condition did not become true before its deadline');
}

function running(pid) {
  if (!pid) return false;
  try {
    process.kill(pid, 0);
    if (process.platform === 'linux') {
      // A terminated orphan may wait for container PID 1 to reap it.
      const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8');
      if (stat.slice(stat.lastIndexOf(')') + 2).startsWith('Z')) return false;
    }
    return true;
  } catch (error) {
    if (error.code === 'ESRCH' || error.code === 'ENOENT') return false;
    throw error;
  }
}

async function readJsonWhenReady(filename) {
  return until(async () => {
    try {
      return JSON.parse(await fsp.readFile(filename, 'utf8'));
    } catch (error) {
      if (error.code === 'ENOENT' || error instanceof SyntaxError) return false;
      throw error;
    }
  });
}

test('Node version check enforces the React Native 20.19.4 minimum', () => {
  for (const version of ['18.20.8', '20.18.9', '20.19.0', '20.19.3']) {
    assert.equal(nodeVersionSupported(version), false, version);
  }
  for (const version of ['20.19.4', '20.20.0', '21.0.0', '22.0.0', '24.19.0']) {
    assert.equal(nodeVersionSupported(version), true, version);
  }
  for (const version of ['', 'not-a-version']) {
    assert.equal(nodeVersionSupported(version), false, version);
  }
});

test('Java version parsing handles supported, old, and unavailable runtimes', () => {
  const versions = [
    ['openjdk version "21.0.6" 2025-01-21\nOpenJDK Runtime Environment', 21],
    ['java version "21.0.2" 2024-01-16 LTS\r\nJava(TM) SE Runtime Environment', 21],
    ['openjdk version "24-ea" 2025-03-18', 24],
    ['openjdk version "17.0.14" 2025-01-21', 17],
    ['java version "1.8.0_401"', 8],
    ['JAVA_HOME is not set and no java command could be found', null],
    ['', null],
  ];
  for (const [output, major] of versions) assert.equal(javaMajor(output), major, output);
});

test('local environment overrides unsafe inherited settings without mutating the parent', () => {
  const parent = {
    PATH: '/example/bin',
    EXPO_PUBLIC_USE_EMULATORS: 'false',
    EXPO_PUBLIC_EMULATOR_HOST: 'remote.example',
    EXPO_PUBLIC_STORAGE_ENABLED: 'true',
    CI: '0',
    EXPO_NO_TELEMETRY: '0',
    EXPO_OFFLINE: '0',
    BROWSER: 'unsafe-inherited-browser',
    NODE_ENV: 'production',
    UNRELATED_SETTING: 'preserved',
  };
  const original = { ...parent };
  const env = testEnvironment(parent);
  assert.equal(env.EXPO_PUBLIC_USE_EMULATORS, 'true');
  assert.equal(env.EXPO_PUBLIC_EMULATOR_HOST, '127.0.0.1');
  assert.equal(env.EXPO_PUBLIC_STORAGE_ENABLED, 'false');
  assert.equal(env.CI, '1');
  assert.equal(env.EXPO_NO_TELEMETRY, '1');
  assert.equal(env.EXPO_OFFLINE, '1');
  assert.equal(env.BROWSER, 'none');
  assert.equal(env.NODE_ENV, 'development');
  assert.equal(env.PATH, parent.PATH);
  assert.equal(env.UNRELATED_SETTING, 'preserved');
  assert.deepEqual(parent, original);
});

test('port conflict detection preserves the existing listener and releases successful probes', async (t) => {
  const server = net.createServer((socket) => socket.end('existing-service'));
  t.after(() => close(server));
  const port = await listen(server);
  await assert.rejects(assertPortsFree([port]));
  const response = await new Promise((resolve, reject) => {
    const client = net.connect({ host: '127.0.0.1', port });
    let text = '';
    client.setEncoding('utf8');
    client.on('data', (chunk) => { text += chunk; });
    client.on('end', () => resolve(text));
    client.on('error', reject);
  });
  assert.equal(response, 'existing-service');
  await close(server);
  await assertPortsFree([port]);
  const replacement = net.createServer();
  t.after(() => close(replacement));
  await new Promise((resolve, reject) => {
    replacement.once('error', reject);
    replacement.listen(port, '127.0.0.1', resolve);
  });
});

test('HTTP readiness waits for the expected service response', async (t) => {
  let requests = 0;
  const server = http.createServer((_, response) => {
    requests += 1;
    response.writeHead(requests === 1 ? 503 : 200);
    response.end(requests >= 3 ? 'expected-ready-service' : 'unrelated-service');
  });
  t.after(() => close(server));
  const port = await listen(server);
  const result = await waitForHttp(`http://127.0.0.1:${port}`, {
    accept: (response, text) => response.status === 200 && text === 'expected-ready-service',
    timeoutMs: 3000,
    pollMs: 20,
    check() {},
  });
  assert.ok(requests >= 3);
  assert.equal(result.status, 200);
  assert.equal(result.text, 'expected-ready-service');
});

test('HTTP readiness times out when a responding service never becomes ready', async (t) => {
  let requests = 0;
  const server = http.createServer((_, response) => {
    requests += 1;
    response.writeHead(503).end('starting');
  });
  t.after(() => close(server));
  const port = await listen(server);
  await assert.rejects(waitForHttp(`http://127.0.0.1:${port}`, {
    accept: (response) => response.status === 200,
    timeoutMs: 200,
    pollMs: 20,
    check() {},
  }));
  assert.ok(requests >= 2, 'a transient not-ready response should be retried');
});

test('HTTP readiness retries connection failures until its deadline', async () => {
  const server = net.createServer();
  const port = await listen(server);
  await close(server);
  const started = Date.now();
  await assert.rejects(waitForHttp(`http://127.0.0.1:${port}`, {
    accept: () => true,
    timeoutMs: 200,
    pollMs: 20,
    check() {},
  }));
  assert.ok(Date.now() - started >= 150, 'connection refusal must not abort the first attempt');
});

test('HTTP readiness propagates supervised child failure promptly', async (t) => {
  const failure = new Error('managed child exited');
  const server = http.createServer((_, response) => response.writeHead(503).end('starting'));
  t.after(() => close(server));
  const port = await listen(server);
  await assert.rejects(waitForHttp(`http://127.0.0.1:${port}`, {
    accept: () => false,
    timeoutMs: 3000,
    pollMs: 20,
    check() { throw failure; },
  }), (error) => error === failure);
});

test('supervisor reports an unexpected successful child exit as failure', async (t) => {
  const supervisor = createSupervisor({ cwd: process.cwd(), env: { ...process.env } });
  t.after(() => supervisor.stop());
  supervisor.spawn('exits-with-zero', process.execPath, ['-e', 'process.exit(0)']);
  let timer;
  const error = await Promise.race([
    supervisor.closed,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Supervisor did not report child exit')), 5000);
    }),
  ]).finally(() => clearTimeout(timer));
  assert.ok(error instanceof Error);
  assert.throws(() => supervisor.check());
});

test('supervisor stops its own process tree and preserves an unrelated process', { timeout: 20000 }, async (t) => {
  const cwd = await fsp.mkdtemp(path.join(os.tmpdir(), 'birarada Türkçe space '));
  const managedFile = path.join(cwd, 'managed.json');
  const descendantFile = path.join(cwd, 'descendant.json');
  const unrelatedFile = path.join(cwd, 'unrelated.json');
  const supervisor = createSupervisor({ cwd, env: { ...process.env } });
  let managedPid;
  let descendantPid;
  let unrelated;
  t.after(async () => {
    await supervisor.stop();
    // Keep the test isolated even when the implementation fails cleanup assertions.
    for (const pid of [managedPid, descendantPid, unrelated?.pid]) {
      if (running(pid)) {
        try { process.kill(pid, 'SIGKILL'); } catch (error) {
          if (error.code !== 'ESRCH') throw error;
        }
      }
    }
    await fsp.rm(cwd, { recursive: true, force: true });
  });
  const leaf = `
    const fs = require('node:fs');
    fs.writeFileSync(process.argv[1], JSON.stringify({ pid: process.pid, cwd: process.cwd() }));
    setInterval(() => {}, 1000);
  `;
  const managed = `
    const fs = require('node:fs');
    const { spawn } = require('node:child_process');
    spawn(process.execPath, ['-e', process.argv[3], process.argv[2]], { stdio: 'ignore' });
    fs.writeFileSync(process.argv[1], JSON.stringify({ pid: process.pid, cwd: process.cwd() }));
    setInterval(() => {}, 1000);
  `;
  unrelated = spawn(process.execPath, ['-e', leaf, unrelatedFile], { cwd, stdio: 'ignore' });
  supervisor.spawn('managed-parent', process.execPath, [
    '-e', managed, managedFile, descendantFile, leaf,
  ]);
  const own = await readJsonWhenReady(managedFile);
  managedPid = own.pid;
  descendantPid = (await readJsonWhenReady(descendantFile)).pid;
  await readJsonWhenReady(unrelatedFile);
  assert.equal(own.cwd, cwd, 'working directory survives spaces and Turkish characters');
  assert.ok(running(managedPid));
  assert.ok(running(descendantPid));
  assert.ok(running(unrelated.pid));
  supervisor.check();
  await supervisor.stop();
  await until(() => !running(managedPid));
  await until(() => !running(descendantPid));
  assert.ok(running(unrelated.pid), 'cleanup must preserve processes outside its managed tree');
  await supervisor.stop();
});
