import { test } from "node:test";
import assert from "node:assert/strict";
import {
  runDeletionPlan,
  type DeletionPlan,
} from "../src/services/deletionPlan";

function model(failAt?: keyof DeletionPlan) {
  const records = {
    identity: true,
    posts: ["own post"],
    activity: ["own comment", "own message"],
    connections: ["follow"],
    privateData: ["saved"],
    profile: true,
    username: true,
    pending: false,
    preview: "own message preview",
  };
  const events: string[] = [];
  const step = (name: keyof DeletionPlan, action: () => void) => async () => {
    events.push(name);
    if (name === failAt) throw Error("injected " + name);
    action();
  };
  const plan: DeletionPlan = {
    confirmIdentity: step("confirmIdentity", () => {}),
    async markPending() {
      await step("markPending", () => {
        records.pending = true;
      })();
      return { profileExists: records.profile };
    },
    removeOwnedPosts: step("removeOwnedPosts", () => {
      records.posts = [];
    }),
    removeAuthoredActivity: step("removeAuthoredActivity", () => {
      records.activity = [];
    }),
    clearChatPreviews: step("clearChatPreviews", () => {
      if (!records.profile) throw Error("permission-denied: profile is absent");
      records.preview = "";
    }),
    removeConnections: step("removeConnections", () => {
      records.connections = [];
    }),
    removePrivateData: step("removePrivateData", () => {
      records.privateData = [];
    }),
    removeProfileAndUsername: step("removeProfileAndUsername", () => {
      records.profile = false;
      records.username = false;
    }),
    removeAuthentication: step("removeAuthentication", () => {
      assert.equal(records.pending, true);
      assert.deepEqual(
        [
          ...records.posts,
          ...records.activity,
          ...records.connections,
          ...records.privateData,
        ],
        [],
      );
      assert.equal(records.profile, false);
      assert.equal(records.username, false);
      assert.equal(records.preview, "");
      records.identity = false;
    }),
  };
  return { records, events, plan };
}

test("failed reauthentication leaves all records untouched and never marks deletion", async () => {
  const { records, events, plan } = model("confirmIdentity");
  await assert.rejects(runDeletionPlan(plan), /confirmIdentity/);
  assert.equal(records.identity, true);
  assert.equal(records.pending, false);
  assert.equal(records.profile, true);
  assert.deepEqual(records.posts, ["own post"]);
  assert.deepEqual(events, ["confirmIdentity"]);
});

test("failure at every cleanup phase preserves authentication for a retry", async () => {
  for (const phase of [
    "markPending",
    "removeOwnedPosts",
    "removeAuthoredActivity",
    "clearChatPreviews",
    "removeConnections",
    "removePrivateData",
    "removeProfileAndUsername",
  ] as const) {
    const { records, events, plan } = model(phase);
    await assert.rejects(runDeletionPlan(plan), new RegExp(phase));
    assert.equal(records.identity, true, phase);
    assert.ok(!events.includes("removeAuthentication"), phase);
  }
});

test("only a complete cleanup may remove authentication", async () => {
  const { records, events, plan } = model();
  await runDeletionPlan(plan);
  assert.equal(records.identity, false);
  assert.equal(events.at(-1), "removeAuthentication");
});

test("retry after interrupted cleanup runs remaining idempotent deletes safely", async () => {
  const { records, plan } = model();
  const cleanup = plan.removeAuthoredActivity;
  plan.removeAuthoredActivity = async () => {
    throw Error("offline");
  };
  await assert.rejects(runDeletionPlan(plan), /offline/);
  assert.equal(records.identity, true);
  assert.deepEqual(records.posts, []);
  plan.removeAuthoredActivity = cleanup;
  await runDeletionPlan(plan);
  assert.equal(records.identity, false);
});

test("Auth deletion can retry after profile removal without a forbidden preview write", async () => {
  const { records, events, plan } = model();
  const removeAuthentication = plan.removeAuthentication;
  plan.removeAuthentication = async () => {
    throw Error("auth/network-request-failed");
  };
  await assert.rejects(runDeletionPlan(plan), /auth\/network-request-failed/);
  assert.equal(records.identity, true);
  assert.equal(records.profile, false);
  assert.equal(records.preview, "");
  const priorPreviewWrites = events.filter(
    (event) => event === "clearChatPreviews",
  ).length;
  plan.removeAuthentication = removeAuthentication;
  await runDeletionPlan(plan);
  assert.equal(records.identity, false);
  assert.equal(
    events.filter((event) => event === "clearChatPreviews").length,
    priorPreviewWrites,
  );
});
