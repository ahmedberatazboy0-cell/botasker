import { test } from "node:test";
import assert from "node:assert/strict";
import { friendly, usernameValid } from "../src/utils/errors";
test("Firebase failures have Turkish messages and do not leak service messages", () => {
  assert.match(
    friendly({
      code: "auth/invalid-credential",
      message: "sensitive upstream context",
    }),
    /hatalı/,
  );
  assert.match(friendly({ code: "permission-denied" }), /iznin/);
  assert.equal(
    friendly({ code: "unknown", message: "secret" }),
    "İşlem tamamlanamadı. Lütfen tekrar dene.",
  );
});
test("usernames reject paths, uppercase and short names", () => {
  for (const name of ["a", "ABc", "a/b", "a b", "x".repeat(25)])
    assert.equal(usernameValid(name), false);
  assert.equal(usernameValid("berat_01"), true);
});
