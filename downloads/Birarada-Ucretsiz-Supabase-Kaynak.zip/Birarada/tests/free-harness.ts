import { PGlite } from "@electric-sql/pglite";
import { readFile } from "node:fs/promises";
import { type Driver, Records } from "../supabase/functions/birarada/records";
import {
  type Dependencies,
  handle,
  type Storage,
} from "../supabase/functions/birarada/gateway";
import type { Identity } from "../supabase/functions/birarada/context";
export async function createDatabase(directory?: string) {
  const pg = new PGlite(directory);
  await pg.exec(
    "do $$ begin if not exists(select from pg_roles where rolname='anon') then create role anon;create role authenticated;create role service_role bypassrls;end if;end $$;create schema if not exists storage;create table if not exists storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[])",
  );
  await pg.exec(
    await readFile(
      new URL(
        "../supabase/migrations/202610210001_birarada.sql",
        import.meta.url,
      ),
      "utf8",
    ),
  );
  return pg;
}
export function databaseDriver(pg: PGlite): Driver {
  return {
    async rpc(name, input) {
      const map: Record<string, [string, string[]]> = {
        birarada_get: ["select public.birarada_get($1::jsonb) as result", [
          "paths",
        ]],
        birarada_query: ["select public.birarada_query($1::jsonb) as result", [
          "spec",
        ]],
        birarada_commit: [
          "select public.birarada_commit($1::jsonb,$2::jsonb) as result",
          ["reads", "writes"],
        ],
        birarada_subtree: ["select public.birarada_subtree($1,$2) as result", [
          "prefix",
          "maximum",
        ]],
        birarada_claim_jobs: [
          "select coalesce(jsonb_agg(to_jsonb(t)),'[]') as result from public.birarada_claim_jobs() t",
          [],
        ],
        birarada_finish_job: [
          "select public.birarada_finish_job($1,$2) as result",
          ["job_id", "success"],
        ],
      };
      try {
        const spec = map[name];
        if (!spec) throw Error("Unknown RPC");
        const values = spec[1].map((k) =>
          typeof input[k] === "object" ? JSON.stringify(input[k]) : input[k]
        );
        const result = await pg.query<{ result: any }>(spec[0], values);
        return { data: result.rows[0]?.result, error: null };
      } catch (e) {
        return {
          data: null,
          error: { code: (e as any).code, message: (e as Error).message },
        };
      }
    },
  };
}
export async function harness() {
  const pg = await createDatabase(),
    driver = databaseDriver(pg),
    db = new Records(driver),
    objects = new Map<string, { bytes: Uint8Array; type: string }>();
  const storage: Storage = {
    async save(key, bytes, type) {
      objects.set(key, { bytes, type });
    },
    async remove(key) {
      objects.delete(key);
    },
    async read(key, start, end) {
      const m = objects.get(key);
      return m
        ? new Response(m.bytes.slice(start, end + 1), {
          status: 206,
          headers: { "Content-Type": m.type },
        })
        : new Response(null, { status: 404 });
    },
    async health() {
      return true;
    },
  };
  const users = new Map<string, Identity>();
  for (const name of ["alice", "bob", "eve", "owner"]) {
    users.set(name, {
      uid: name,
      email: name === "owner"
        ? "ahmedberatazboy0@gmail.com"
        : name + "@example.test",
      emailVerified: true,
      authTime: Math.floor(Date.now() / 1000),
      issuedAt: Math.floor(Date.now() / 1000),
    });
  }
  const deps: Dependencies = {
    driver,
    storage,
    identify: async (token) => {
      const user = users.get(token);
      if (!user) throw Error("Invalid session");
      return user;
    },
  };
  async function request(
    user: string | null,
    route: string,
    input?: any,
    method = "POST",
    extra: Record<string, string> = {},
  ) {
    const headers = {
      ...(user ? { Authorization: "Bearer " + user } : {}),
      ...(method === "POST" ? { "Content-Type": "application/json" } : {}),
      ...extra,
    };
    return handle(
      new Request("http://localhost:5002/" + route, {
        method,
        headers,
        body: input === undefined
          ? undefined
          : input instanceof Uint8Array
          ? input
          : JSON.stringify(input),
      }),
      deps,
    );
  }
  async function call(user: string, action: string, input: any = {}) {
    const response = await request(user, "socialApi", { action, input });
    const result = await response.json();
    return { status: response.status, data: result.data, error: result.error };
  }
  return { pg, driver, db, objects, users, deps, request, call };
}
