import { test } from "node:test";
import assert from "node:assert/strict";
import {
  noteContent,
  noteExpiresAt,
  noteIsActive,
  NOTE_LIFETIME_MS,
  songLink,
} from "../src/utils/notes";

const track = "4uLU6hMCjMI75M1A2tKUQC";
const video = "dQw4w9WgXcQ";

test("Spotify track links discard tracking, locale and fragments", () => {
  for (const value of [
    `https://open.spotify.com/track/${track}?si=tracking#details`,
    ` https://open.spotify.com/intl-tr/track/${track}/?utm_source=share `,
  ])
    assert.deepEqual(songLink(value), {
      url: `https://open.spotify.com/track/${track}`,
      provider: "Spotify",
    });
});

test("YouTube share, mobile, music and shorts links keep only the video ID", () => {
  for (const value of [
    `https://youtu.be/${video}?si=tracking`,
    `https://www.youtube.com/watch?v=${video}&list=private-list&t=60`,
    `https://m.youtube.com/watch?v=${video}`,
    `https://music.youtube.com/watch?v=${video}`,
    `https://youtube.com/shorts/${video}`,
    `https://youtu.be/${video}/`,
  ])
    assert.deepEqual(songLink(value), {
      url: `https://www.youtube.com/watch?v=${video}`,
      provider: "YouTube",
    });
});

test("song links reject spoofed hosts, embedded credentials, unsafe schemes and ports", () => {
  for (const value of [
    `https://open.spotify.com.evil.test/track/${track}`,
    `https://youtube.com.evil.test/watch?v=${video}`,
    `https://www.youtube.com@evil.test/watch?v=${video}`,
    `https://user:pass@www.youtube.com/watch?v=${video}`,
    `http://youtu.be/${video}`,
    `javascript:alert(1)`,
    `data:text/html,hello`,
    `https://127.0.0.1/watch?v=${video}`,
    `https://youtu.be:8443/${video}`,
    `https://spotify.link/shortcut`,
  ])
    assert.throws(() => songLink(value), /Spotify/);
});

test("only tracks or individual videos are accepted, never playlists or malformed IDs", () => {
  for (const value of [
    `https://open.spotify.com/album/${track}`,
    `https://open.spotify.com/playlist/${track}`,
    `https://open.spotify.com/track/short`,
    `https://youtu.be/short`,
    `https://www.youtube.com/watch?list=${track}`,
    `https://www.youtube.com/watch?v=${video}/extra`,
    `https://youtu.be/${video}/extra`,
    `https://www.youtube.com/watch?v=${"x".repeat(501)}`,
  ])
    assert.throws(() => songLink(value));
});

test("notes allow text alone, song alone, or both with canonical links", () => {
  assert.deepEqual(noteContent(" Merhaba ", "", ""), {
    text: "Merhaba",
    songTitle: "",
    songUrl: "",
  });
  assert.deepEqual(
    noteContent(
      "",
      " Sanatçı – Şarkı ",
      `https://youtu.be/${video}?si=tracking`,
    ),
    {
      text: "",
      songTitle: "Sanatçı – Şarkı",
      songUrl: `https://www.youtube.com/watch?v=${video}`,
    },
  );
  assert.equal(
    noteContent(
      "Dinlediğim şarkı",
      "Şarkı",
      `https://open.spotify.com/track/${track}`,
    ).text,
    "Dinlediğim şarkı",
  );
});

test("empty notes and half-completed song fields are rejected", () => {
  assert.throws(() => noteContent("  ", " ", " "), /Bir not/);
  assert.throws(() => noteContent("not", "Şarkı", ""), /birlikte/);
  assert.throws(
    () => noteContent("not", "", `https://youtu.be/${video}`),
    /birlikte/,
  );
});

test("note and song title length limits apply after trimming", () => {
  assert.equal(noteContent("x".repeat(60), "", "").text.length, 60);
  assert.throws(() => noteContent("x".repeat(61), "", ""), /60/);
  assert.equal(
    noteContent("", "x".repeat(120), `https://youtu.be/${video}`).songTitle
      .length,
    120,
  );
  assert.throws(
    () => noteContent("", "x".repeat(121), `https://youtu.be/${video}`),
    /120/,
  );
});

test("24-hour expiration uses the server timestamp, including nanoseconds", () => {
  const note = { updatedAt: { seconds: 1000, nanoseconds: 250000000 } };
  const expires = 1000250 + NOTE_LIFETIME_MS;
  assert.equal(noteExpiresAt(note), expires);
  assert.equal(noteIsActive(note, expires - 1), true);
  assert.equal(noteIsActive(note, expires), false);
  assert.equal(noteIsActive(note, expires + 1), false);
  assert.equal(noteIsActive({ updatedAt: null }), false);
  assert.equal(noteIsActive({ updatedAt: { seconds: NaN } }), false);
});
