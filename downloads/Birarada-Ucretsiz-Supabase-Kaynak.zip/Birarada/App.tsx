import React, { useEffect, useState } from "react";
import { Text, View, ActivityIndicator } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { onAuthStateChanged } from "firebase/auth";
import { doc, onSnapshot } from "./src/database/client";
import { auth, db } from "./src/firebase/client";
import { useSession } from "./src/store/session";
import { AuthScreen, CompleteProfile } from "./src/screens/Auth";
import { Root } from "./src/navigation/Root";
import {
  Page,
  Label,
  Button,
  DeleteAccountForm,
  CommunityAgreement,
} from "./src/components/ui";
import { api } from "./src/services/api";
import { TERMS_VERSION } from "./src/constants/release";
import { friendly } from "./src/utils/errors";
import {
  logout,
  deleteOwnAccount,
  loadPendingDeletion,
} from "./src/services/social";
import type { Profile } from "./src/types";
class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    if (this.state.failed)
      return (
        <Page title="Bir sorun oluştu.">
          <Label>
            Uygulama bu ekranı açamadı. Yeniden deneyebilir veya uygulamayı
            kapatıp açabilirsin.
          </Label>
          <Button
            title="Yeniden dene"
            onPress={() => this.setState({ failed: false })}
          />
          <Button
            secondary
            title="Çıkış yap"
            onPress={async () => {
              await logout();
              this.setState({ failed: false });
            }}
          />
        </Page>
      );
    return this.props.children;
  }
}
function AppContent() {
  const {
      user,
      profile,
      ready,
      deleting,
      deletionPending,
      deletionError,
      set,
    } = useSession(),
    [splash, setSplash] = useState(true),
    [error, setError] = useState(""),
    [retry, setRetry] = useState(0);
  useEffect(() => {
    const timer = setTimeout(() => setSplash(false), 1400);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => {
    let stop: undefined | (() => void);
    let generation = 0;
    let active = true;
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      const current = ++generation;
      stop?.();
      stop = undefined;
      setError("");
      set({
        user: u,
        profile: null,
        ready: !u,
        deletionPending: false,
        deletionError: "",
      });
      if (u) {
        try {
          const pending = await loadPendingDeletion(u.uid);
          if (!active || current !== generation) return;
          set({ deletionPending: pending });
        } catch (e) {
          if (!active || current !== generation) return;
          setError(friendly(e));
          set({ ready: true });
          return;
        }
        stop = onSnapshot(
          doc(db, "users", u.uid),
          (snap) => {
            if (!active || current !== generation) return;
            const nextProfile = snap.exists() ? (snap.data() as Profile) : null;
            set({
              profile: nextProfile,
              ...(nextProfile?.deletionPending === true
                ? { deletionPending: true }
                : {}),
              ready: true,
            });
          },
          (e) => {
            if (!active || current !== generation) return;
            setError(friendly(e));
            set({ ready: true });
          },
        );
      }
    });
    return () => {
      active = false;
      generation += 1;
      unsubscribe();
      stop?.();
    };
  }, [retry]);
  return (
    <>
      {deleting ? (
        <Page title="Hesabın siliniyor…">
          <ActivityIndicator color="#ff925c" />
          <Label>
            Verilerin kaldırılıyor. İşlem tamamlanana kadar uygulamayı açık tut.
          </Label>
        </Page>
      ) : splash || !ready ? (
        <View
          style={{
            flex: 1,
            backgroundColor: "#101112",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
          }}
        >
          <Text style={{ color: "#ff925c", fontSize: 44, fontWeight: "800" }}>
            birarada
          </Text>
          <Text style={{ color: "#a8a6a3" }}>
            Yeni insanlarla, daha güzel anlara.
          </Text>
        </View>
      ) : user && deletionPending ? (
        <Page title="Hesap silmeyi tamamla.">
          <Label>
            Önceki silme işlemi tamamlanmadı. Hesabını kullanmaya devam etmeden
            önce kalan verileri kaldırmak için yeniden onayla.
          </Label>
          {!!deletionError && <Label>{deletionError}</Label>}
          <DeleteAccountForm
            onDelete={deleteOwnAccount}
            onCancel={logout}
            cancelTitle="Şimdilik çıkış yap"
          />
        </Page>
      ) : error ? (
        <Page title="Bağlantıyı yenileyelim.">
          <Label>{error}</Label>
          <Button title="Tekrar dene" onPress={() => setRetry((r) => r + 1)} />
          <Button secondary title="Çıkış yap" onPress={logout} />
        </Page>
      ) : !user ? (
        <AuthScreen />
      ) : !profile ? (
        <CompleteProfile />
      ) : profile.termsVersion !== TERMS_VERSION ? (
        <RenewConsent />
      ) : (
        <Root />
      )}
    </>
  );
}
function RenewConsent() {
  const [accepted, setAccepted] = useState(false);
  return (
    <Page title="Yeni paylaşım özellikleri">
      <Label>
        Fotoğraf/video, hikâyeler, sesli mesajlar ve telefon bildirimleri için
        güncel gizlilik politikasını ve topluluk kurallarını oku.
      </Label>
      <CommunityAgreement value={accepted} onChange={setAccepted} />
      <Button
        title="Onayla ve devam et"
        disabled={!accepted}
        onPress={() =>
          api("acceptTerms", { version: TERMS_VERSION, accepted: true })
        }
      />
      <Button secondary title="Çıkış yap" onPress={logout} />
    </Page>
  );
}
export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <AppErrorBoundary>
        <AppContent />
      </AppErrorBoundary>
    </SafeAreaProvider>
  );
}
