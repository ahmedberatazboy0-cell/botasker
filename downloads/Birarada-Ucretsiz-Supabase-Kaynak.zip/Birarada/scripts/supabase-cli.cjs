"use strict";
const fs = require("node:fs"),
  path = require("node:path"),
  https = require("node:https"),
  { createHash } = require("node:crypto"),
  { gunzipSync } = require("node:zlib");
const VERSION = "2.76.4",
  BASE = `https://github.com/supabase/cli/releases/download/v${VERSION}/`;
function download(url, max = 100000000, redirects = 0) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    if (
      u.protocol !== "https:" ||
      ![
        "github.com",
        "release-assets.githubusercontent.com",
        "objects.githubusercontent.com",
      ].includes(u.hostname) || redirects > 6
    ) return reject(Error("CLI download redirect rejected"));
    const req = https.get(u, { timeout: 60000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        res.resume();
        return download(
          new URL(res.headers.location, u).href,
          max,
          redirects + 1,
        ).then(resolve, reject);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(Error("CLI download failed: HTTP " + res.statusCode));
      }
      const chunks = [];
      let size = 0;
      res.on("data", (c) => {
        size += c.length;
        if (size > max) res.destroy(Error("CLI download too large"));
        else chunks.push(c);
      });
      res.on("error", reject);
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });
    req.on("timeout", () => req.destroy(Error("CLI download timed out")));
    req.on("error", reject);
  });
}
function extractBinary(archive, name) {
  const tar = gunzipSync(archive, { maxOutputLength: 200000000 });
  let found;
  for (let at = 0; at + 512 <= tar.length;) {
    const h = tar.subarray(at, at + 512);
    if (h.every((n) => n === 0)) break;
    const file = h.subarray(0, 100).toString().split("\0")[0],
      size = parseInt(
        h.subarray(124, 136).toString().replace(/\0/g, "").trim() || "0",
        8,
      ),
      type = h[156];
    if (
      !Number.isSafeInteger(size) || size < 0 || at + 512 + size > tar.length
    ) throw Error("Invalid CLI archive");
    if (file === name) {
      if (found || ![0, 48].includes(type)) {
        throw Error("Invalid CLI executable entry");
      }
      found = tar.subarray(at + 512, at + 512 + size);
    }
    at += 512 + Math.ceil(size / 512) * 512;
  }
  if (!found) throw Error("CLI executable missing");
  return found;
}
async function ensureCli(root) {
  const platform = process.platform === "win32"
      ? "windows"
      : process.platform === "darwin"
      ? "darwin"
      : process.platform === "linux"
      ? "linux"
      : null,
    arch = process.arch === "x64"
      ? "amd64"
      : process.arch === "arm64"
      ? "arm64"
      : null;
  if (!platform || !arch) throw Error("Unsupported platform");
  const name = platform === "windows" ? "supabase.exe" : "supabase",
    dir = path.join(root, ".birarada-tools", "supabase-" + VERSION),
    binary = path.join(dir, name),
    mark = binary + ".sha256";
  if (
    fs.existsSync(binary) && fs.existsSync(mark) &&
    !fs.lstatSync(binary).isSymbolicLink()
  ) {
    const sha = createHash("sha256").update(fs.readFileSync(binary)).digest(
      "hex",
    );
    if (fs.readFileSync(mark, "utf8").trim() === sha) return binary;
  }
  console.log("Resmi Supabase CLI indiriliyor ve SHA-256 dogrulaniyor...");
  const file = `supabase_${platform}_${arch}.tar.gz`,
    checks =
      (await download(BASE + `supabase_${VERSION}_checksums.txt`, 200000))
        .toString(),
    line = checks.split("\n").find((l) => l.trim().split(/\s+/)[1] === file),
    expected = line?.trim().split(/\s+/)[0];
  if (!/^[a-f0-9]{64}$/.test(expected || "")) {
    throw Error("Official CLI checksum missing");
  }
  const bytes = await download(BASE + file);
  if (createHash("sha256").update(bytes).digest("hex") !== expected) {
    throw Error("Official CLI checksum mismatch");
  }
  const exe = extractBinary(bytes, name);
  fs.mkdirSync(dir, { recursive: true });
  if (fs.lstatSync(dir).isSymbolicLink()) {
    throw Error("CLI tools directory is a link");
  }
  fs.writeFileSync(binary, exe, { mode: 0o755 });
  fs.writeFileSync(mark, createHash("sha256").update(exe).digest("hex") + "\n");
  return binary;
}
module.exports = { ensureCli, extractBinary, VERSION };
