"use strict";
const path = require("node:path");
const root = path.resolve(__dirname, "..");
process.chdir(root);
const cli = path.join(
  path.dirname(require.resolve("expo/package.json")),
  "bin/cli",
);
process.argv = [
  process.execPath,
  cli,
  "start",
  "--web",
  "--offline",
  "--port",
  "8081",
];
require(cli);
