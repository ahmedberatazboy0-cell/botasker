"use strict";
const path = require("node:path"),
  { createSupervisor, assertPortsFree, waitForHttp, testEnvironment } = require(
    "./start-local.cjs",
  );
async function main() {
  const root = path.resolve(__dirname, "..");
  await assertPortsFree([9099, 5002, 8081, 4400, 4500]);
  const env = {
    ...testEnvironment(process.env),
    APP_ENV: "development",
    EAS_BUILD_PROFILE: "",
  };
  const supervisor = createSupervisor({ cwd: root, env });
  let stopping = false;
  const stop = () => {
    stopping = true;
    void supervisor.stop();
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  try {
    supervisor.spawn("Firebase Auth emulator", process.execPath, [
      path.join(root, "node_modules/firebase-tools/lib/bin/firebase.js"),
      "emulators:start",
      "--project",
      "demo-birarada",
      "--only",
      "auth",
      "--non-interactive",
    ]);
    await waitForHttp(
      "http://127.0.0.1:9099/emulator/v1/projects/demo-birarada/config",
      { accept: (r) => r.status === 200, check: supervisor.check },
    );
    supervisor.spawn("Free local API", process.execPath, [
      "--import",
      "tsx",
      "scripts/free-local-server.mts",
    ]);
    await waitForHttp("http://127.0.0.1:5002/health", {
      accept: (r) => r.status === 200,
      check: supervisor.check,
    });
    supervisor.spawn("Expo", process.execPath, ["scripts/start-ui-check.cjs"]);
    await waitForHttp("http://127.0.0.1:8081", {
      accept: (r) => r.status === 200,
      check: supervisor.check,
    });
    console.log(
      "\nWeb testi: http://localhost:8081\nBu pencere acik kalsin. Yerel hesaplar ve medya canli projeye gonderilmez. Kapatmak icin Ctrl+C.\n",
    );
    const failure = await supervisor.closed;
    if (!stopping) throw failure;
  } finally {
    await supervisor.stop();
    process.removeListener("SIGINT", stop);
    process.removeListener("SIGTERM", stop);
  }
}
module.exports = { main };
if (require.main === module) {
  main().catch((e) => {
    console.error(e.message);
    process.exitCode = 1;
  });
}
