"use strict";
const path = require("node:path"),
  fs = require("node:fs"),
  { createSupervisor, assertPortsFree, waitForHttp, testEnvironment } = require(
    "./start-local.cjs",
  );
async function main() {
  const root = path.resolve(__dirname, "..");
  await assertPortsFree([9099, 5002, 8081, 4400, 4500]);
  const env = {
    ...testEnvironment(process.env),
    APP_ENV: "development",
    EAS_BUILD_PROFILE: "",
    NO_UPDATE_NOTIFIER: "1",
  };
  // The demo emulator does not need the user's real Firebase CLI session.
  // Keep its writable config with this owned local test data, including on CI.
  env.XDG_CONFIG_HOME = path.join(
    path.resolve(env.BIRARADA_LOCAL_DIR || path.join(root, ".birarada-local")),
    "firebase-cli-config",
  );
  fs.mkdirSync(env.XDG_CONFIG_HOME, { recursive: true });
  const supervisor = createSupervisor({ cwd: root, env });
  let stopping = false;
  const stop = () => {
    stopping = true;
    void supervisor.stop();
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
  async function ready(label, url, accept) {
    const started = Date.now();
    console.log(`[Baslatma] ${label}`);
    const progress = setInterval(() => {
      console.log(`[Baslatma] ${label} - ${Math.floor((Date.now() - started) / 1000)} sn bekleniyor...`);
    }, 15000);
    try {
      return await waitForHttp(url, {
        accept,
        timeoutMs: 180000,
        check: supervisor.check,
      });
    } catch (error) {
      throw Error(`${label} hazir olmadi. ${error.message}`);
    } finally {
      clearInterval(progress);
    }
  }
  try {
    console.log("[1/3] Firebase Auth yerel sunucusu baslatiliyor...");
    supervisor.spawn("Firebase Auth emulator", process.execPath, [
      path.join(root, "node_modules/firebase-tools/lib/bin/firebase.js"),
      "emulators:start",
      "--project",
      "demo-birarada",
      "--only",
      "auth",
      "--non-interactive",
    ]);
    await ready(
      "[1/3] Firebase Auth",
      "http://127.0.0.1:9099/emulator/v1/projects/demo-birarada/config",
      (r) => r.status === 200,
    );
    console.log("[2/3] Yerel PostgreSQL ve ozel medya API'si baslatiliyor...");
    supervisor.spawn("Free local API", process.execPath, [
      "--import",
      "tsx",
      "scripts/free-local-server.mts",
    ]);
    await ready("[2/3] Yerel API", "http://127.0.0.1:5002/health", (r, text) => {
      if (r.status !== 200) return false;
      try { const value = JSON.parse(text); return value.service === "birarada-social-free" && value.storageReady === true; }
      catch { return false; }
    });
    console.log("[3/3] Expo ve gercek web uygulama paketi hazirlaniyor...");
    supervisor.spawn("Expo", process.execPath, ["scripts/start-ui-check.cjs"]);
    await ready("[3/3] Expo uygulama paketi", "http://127.0.0.1:8081/index.bundle?platform=web&dev=true&hot=false&lazy=true", (r, text) => r.status === 200 && text.length > 100);
    console.log(
      "\nWeb testi: http://localhost:8081\nBu pencere acik kalsin. Yerel hesaplar ve medya canli projeye gonderilmez. Kapatmak icin Ctrl+C.\n",
    );
    const failure = await supervisor.closed;
    if (!stopping) throw failure;
  } finally {
    await supervisor.stop();
    process.removeListener("SIGINT", stop);
    process.removeListener("SIGTERM", stop);
  }
}
module.exports = { main };
if (require.main === module) {
  main().catch((e) => {
    console.error(e.message);
    process.exitCode = 1;
  });
}
