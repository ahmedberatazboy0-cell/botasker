#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const net = require("node:net");
const { spawn, spawnSync } = require("node:child_process");
const { createHash } = require("node:crypto");

function nodeVersionSupported(version) {
  const [major, minor, patch] = version.replace(/^v/, "").split(".").map(Number);
  return major > 20 || (major === 20 && (minor > 19 || (minor === 19 && patch >= 4)));
}

function javaMajor(output) {
  const match = output.match(/(?:openjdk|java)\s+(?:version\s+)?["']?(\d+)(?:\.(\d+))?/i);
  if (!match) return null;
  return Number(match[1]) === 1 ? Number(match[2]) || null : Number(match[1]);
}

function testEnvironment(parentEnv) {
  return {
    ...parentEnv,
    EXPO_PUBLIC_USE_EMULATORS: "true",
    EXPO_PUBLIC_EMULATOR_HOST: "127.0.0.1",
    EXPO_PUBLIC_STORAGE_ENABLED: "false",
    CI: "1",
    EXPO_NO_TELEMETRY: "1",
    EXPO_OFFLINE: "1",
    NODE_ENV: "development",
    BROWSER: "none",
    FIREBASE_CLI_DISABLE_MOTD: "1",
  };
}

async function assertPortsFree(ports) {
  for (const port of ports) {
    await new Promise((resolve, reject) => {
      const server = net.createServer();
      server.once("error", () => reject(new Error(
        `${port} portu kullanılıyor. Önceden açtığın test ortamını kapatıp tekrar dene.`,
      )));
      server.listen({ host: "127.0.0.1", port, exclusive: true }, () => server.close(resolve));
    });
  }
}

async function waitForHttp(url, { accept, timeoutMs = 300000, pollMs = 500, check = () => {} }) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    check();
    try {
      const response = await fetch(url, {
        headers: { Accept: "text/html,application/json" },
        signal: AbortSignal.timeout(Math.max(1, Math.min(2500, deadline - Date.now()))),
      });
      const text = await response.text();
      if (accept(response, text)) return { status: response.status, text };
    } catch {
      // The owned service may still be starting; retain the bounded deadline.
    }
    await new Promise(resolve => setTimeout(resolve, Math.min(pollMs, Math.max(0, deadline - Date.now()))));
  }
  check();
  throw new Error(`Servis zamanında hazır olmadı: ${url}. Yukarıdaki hata mesajını kontrol et.`);
}

function createSupervisor({ cwd, env }) {
  const children = [];
  let stopping = false;
  let failure;
  let stopPromise;
  let resolveClosed;
  const closed = new Promise(resolve => { resolveClosed = resolve; });
  function fail(error) {
    if (stopping || failure) return;
    failure = error;
    resolveClosed(error);
  }
  function check() {
    if (failure) throw failure;
    if (stopping) throw new Error("Test ortamı kapatıldı.");
  }
  function start(label, command, args) {
    check();
    const child = spawn(command, args, {
      cwd, env, stdio: "inherit", windowsHide: true,
      detached: process.platform !== "win32",
    });
    children.push(child);
    child.once("error", error => fail(new Error(`${label} başlatılamadı: ${error.message}`)));
    child.once("exit", (code, signal) => fail(new Error(
      `${label} beklenmedik şekilde kapandı (${signal || code}). Yukarıdaki hata mesajını kontrol et.`,
    )));
    return child;
  }
  async function terminate(child) {
    if (!child.pid) return;
    if (process.platform === "win32") {
      if (child.exitCode !== null || child.signalCode !== null) return;
      await new Promise(resolve => {
        const killer = spawn("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
          stdio: "ignore", windowsHide: true,
        });
        killer.once("error", resolve);
        killer.once("exit", resolve);
      });
    } else {
      try { process.kill(-child.pid, "SIGTERM"); } catch {}
      const end = Date.now() + 3000;
      while (Date.now() < end) {
        try { process.kill(-child.pid, 0); } catch { return; }
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      try { process.kill(-child.pid, "SIGKILL"); } catch {}
    }
  }
  function stop() {
    if (stopPromise) return stopPromise;
    stopping = true;
    stopPromise = Promise.all(children.map(terminate)).then(() => {
      resolveClosed(failure || new Error("Test ortamı kapatıldı."));
    });
    return stopPromise;
  }
  return { spawn: start, check, stop, closed };
}

function checkJava() {
  const installed = process.env.JAVA_HOME && path.join(process.env.JAVA_HOME, "bin", process.platform === "win32" ? "java.exe" : "java");
  const command = installed && fs.existsSync(installed) ? installed : "java";
  const result = spawnSync(command, ["-version"], { encoding: "utf8", windowsHide: true, timeout: 15000 });
  const major = javaMajor(`${result.stderr || ""}\n${result.stdout || ""}`);
  if (result.error || result.status !== 0 || !major || major < 21) {
    throw new Error("Java 21 veya üzeri gerekli. https://adoptium.net/ adresinden kur, ardından bu pencereyi yeniden aç.");
  }
  console.log(`Node.js ${process.versions.node} · Java ${major}`);
  return command;
}

function installDependencies(root) {
  const lock = fs.readFileSync(path.join(root, "package-lock.json"));
  const digest = createHash("sha256").update(lock).digest("hex");
  const marker = path.join(root, "node_modules", ".birarada-install.sha256");
  const cliPaths = ["expo/bin/cli", "firebase-tools/lib/bin/firebase.js"];
  const ready = cliPaths.every(file => fs.existsSync(path.join(root, "node_modules", file)));
  if (ready && fs.existsSync(marker) && fs.readFileSync(marker, "utf8").trim() === digest) return;
  console.log("\nBağımlılıklar kuruluyor. İlk açılışta internet gerekir; birkaç dakika sürebilir.\n");
  const npmCli = path.join(path.dirname(process.execPath), "node_modules", "npm", "bin", "npm-cli.js");
  const command = fs.existsSync(npmCli) ? process.execPath : process.platform === "win32" ? "npm.cmd" : "npm";
  const args = [...(command === process.execPath ? [npmCli] : []), "ci", "--include=dev", "--no-audit", "--no-fund"];
  const result = spawnSync(command, args, {
    cwd: root, stdio: "inherit", windowsHide: true,
    shell: process.platform === "win32" && command === "npm.cmd",
  });
  if (result.error || result.status !== 0) {
    throw new Error("Bağımlılıklar kurulamadı. İnternet bağlantını ve yukarıdaki npm hatasını kontrol et.");
  }
  fs.writeFileSync(marker, digest + "\n");
}

function openBrowser(url) {
  let command;
  let args;
  if (process.platform === "win32") {
    command = "rundll32.exe";
    args = ["url.dll,FileProtocolHandler", url];
  } else if (process.platform === "darwin") {
    command = "open"; args = [url];
  } else {
    command = "xdg-open"; args = [url];
  }
  const child = spawn(command, args, { stdio: "ignore", windowsHide: true });
  child.on("error", () => console.log("Tarayıcı otomatik açılamadı; terminaldeki adresi elle açabilirsin."));
  child.unref();
}

async function main() {
  const root = path.resolve(__dirname, "..");
  if (!nodeVersionSupported(process.versions.node)) {
    throw new Error("Node.js 20.19.4 veya üzeri gerekli. https://nodejs.org/ adresinden güncel LTS sürümünü kur.");
  }
  for (const file of ["package.json", "package-lock.json", "firebase.json", "firestore.rules", "App.tsx"]) {
    if (!fs.existsSync(path.join(root, file))) throw new Error("ZIP'in tamamını bir klasöre çıkartıp başlat.bat dosyasını oradan aç.");
  }
  console.log("Birarada · yerel test ortamı\n");
  const javaCommand = checkJava();
  await assertPortsFree([8080, 9099, 8081, 4400, 4500]);
  installDependencies(root);
  await assertPortsFree([8080, 9099, 8081, 4400, 4500]);
  const env = testEnvironment(process.env);
  if (path.isAbsolute(javaCommand)) {
    // Firebase invokes the literal `java`; make it use the JDK we validated.
    const pathKey = Object.keys(env).find(key => key.toUpperCase() === "PATH") || "PATH";
    env[pathKey] = path.dirname(javaCommand) + path.delimiter + (env[pathKey] || "");
  }
  const supervisor = createSupervisor({ cwd: root, env });
  let interrupted = false;
  function onSignal() {
    if (interrupted) return;
    interrupted = true;
    console.log("\nTest ortamı kapatılıyor…");
    void supervisor.stop();
  }
  process.on("SIGINT", onSignal);
  process.on("SIGTERM", onSignal);
  process.on("SIGHUP", onSignal);
  try {
    console.log("\nFirebase test sunucuları hazırlanıyor. İlk açılışta emulator indirilebilir.\n");
    supervisor.spawn("Firebase", process.execPath, [
      path.join(root, "node_modules/firebase-tools/lib/bin/firebase.js"),
      "emulators:start", "--project", "demo-birarada", "--only", "auth,firestore", "--non-interactive",
    ]);
    await Promise.all([
      waitForHttp("http://127.0.0.1:9099/emulator/v1/projects/demo-birarada/config", {
        accept: response => response.status === 200,
        check: supervisor.check,
      }),
      waitForHttp("http://127.0.0.1:8080/v1/projects/demo-birarada/databases/(default)/documents/__birarada_launcher_probe?pageSize=1", {
        accept: (response, text) => response.status === 200 || (response.status === 403 && text.includes("PERMISSION_DENIED")),
        check: supervisor.check,
      }),
    ]);
    supervisor.check();
    console.log("\nTest sunucuları hazır. Uygulama açılıyor…\n");
    supervisor.spawn("Expo", process.execPath, [
      path.join(root, "node_modules/expo/bin/cli"),
      "start", "--web", "--offline", "--host", "localhost", "--port", "8081",
    ]);
    const page = await waitForHttp("http://127.0.0.1:8081", {
      accept: (response, text) => response.status === 200 && /<html[\s>]/i.test(text),
      check: supervisor.check,
    });
    // Warm the actual JS bundle before treating the web application as ready.
    const script = page.text.match(/<script\b[^>]*\bsrc=["']([^"']*\.bundle[^"']*)["']/i);
    if (!script) throw new Error("Expo sayfasında uygulama paketi bulunamadı. Yukarıdaki çıktıyı kontrol et.");
    await waitForHttp(new URL(script[1].replace(/&amp;/g, "&"), "http://127.0.0.1:8081").href, {
      accept: (response, text) => response.status === 200 && text.length > 100,
      check: supervisor.check,
    });
    supervisor.check();
    console.log("\nBirarada hazır: http://localhost:8081\nBu pencere açık kalsın. Kapatmak için Ctrl+C kullan.\nTest hesapları yalnızca bu bilgisayardaki emulatorlerde tutulur.\n");
    if (!process.argv.includes("--no-open")) openBrowser("http://localhost:8081");
    const failure = await supervisor.closed;
    if (!interrupted) throw failure;
  } catch (error) {
    if (!interrupted) throw error;
  } finally {
    await supervisor.stop();
    process.removeListener("SIGINT", onSignal);
    process.removeListener("SIGTERM", onSignal);
    process.removeListener("SIGHUP", onSignal);
  }
}

module.exports = { nodeVersionSupported, javaMajor, testEnvironment, assertPortsFree, waitForHttp, createSupervisor };
if (require.main === module) main().catch(error => {
  console.error(`\nBaşlatılamadı: ${error.message}\n`);
  process.exitCode = 1;
});
