"use strict";
const { spawnSync } = require("node:child_process"),
  { randomBytes } = require("node:crypto"),
  fs = require("node:fs"),
  os = require("node:os"),
  path = require("node:path");
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "birarada-free-check-"));
try {
  const result = spawnSync(process.execPath, [
    require.resolve("@playwright/test/cli"),
    "test",
    "--config",
    "playwright.social.config.ts",
  ], {
    cwd: path.resolve(__dirname, ".."),
    stdio: "inherit",
    env: {
      ...process.env,
      BIRARADA_LOCAL_DIR: dir,
      BIRARADA_TEST_SECRET: randomBytes(32).toString("hex"),
    },
  });
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally {
  fs.rmSync(dir, { recursive: true, force: true });
}
