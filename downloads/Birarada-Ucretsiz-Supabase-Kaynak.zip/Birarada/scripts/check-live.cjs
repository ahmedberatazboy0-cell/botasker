"use strict";
const https = require("node:https");
function get(url) {
  return new Promise((resolve, reject) => {
    const q = https.get(url, { timeout: 20000 }, (r) => {
      let body = "";
      r.setEncoding("utf8");
      r.on("data", (x) => {
        body += x;
        if (body.length > 1000000) r.destroy(Error("Response too large"));
      });
      r.on("error", reject);
      r.on("end", () => resolve({ status: r.statusCode, body }));
    });
    q.on("error", reject);
    q.on("timeout", () => q.destroy(Error("Connection timed out")));
  });
}
async function checkBackend() {
  const r = await get(
    "https://qinevhhhdtslnzrtcanq.supabase.co/functions/v1/birarada/health",
  );
  let value;
  try {
    value = JSON.parse(r.body);
  } catch {
    throw Error(
      "Supabase sunucusu henuz dagitilmamis. UCRETSIZ_KUR.bat calistir.",
    );
  }
  if (
    r.status !== 200 || value.service !== "birarada-social-free" ||
    value.protocol !== 3 ||
    value.supabaseProjectId !== "qinevhhhdtslnzrtcanq" ||
    value.firebaseProjectId !== "birarada-5650c" ||
    value.storageReady !== true || value.termsVersion !== "2026-10-21-free1"
  ) throw Error("Ucretsiz sunucu ve ozel Storage kurulumu tamamlanmamis.");
  console.log("Ucretsiz sunucu ve ozel bucket saglik kontrolu gecti.");
}
async function checkLive() {
  await checkBackend();
  for (const route of ["privacy", "delete-account", "terms", "child-safety"]) {
    const r = await get("https://birarada-5650c.web.app/" + route);
    if (
      r.status !== 200 || !r.body.includes("com.birarada.app") ||
      !r.body.includes("2026-10-21-free1") ||
      (route === "privacy" && !r.body.includes("Supabase")) ||
      !r.body.includes("ahmedberatazboy0@gmail.com")
    ) throw Error("Guncel yasal sayfa yayinlanmamis: " + route);
  }
  console.log(
    "Canli sunucu/yasal sayfa kontrolleri gecti. Cihaz, gercek push ve son AAB denetimleri ayrica gerekir.",
  );
}
module.exports = { checkBackend, checkLive };
if (require.main === module) {
  (process.argv.includes("--backend-only") ? checkBackend() : checkLive())
    .catch((e) => {
      console.error(e.message);
      process.exitCode = 1;
    });
}
