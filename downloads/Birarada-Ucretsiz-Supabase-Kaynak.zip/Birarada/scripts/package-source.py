#!/usr/bin/env python3
"""Package only the standalone mobile project; no legacy demos or credentials."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import zipfile

PROJECT = Path(__file__).resolve().parent.parent
ROOT_FILES = (
    ".env.example", ".gitignore", "YASAL_YAYINLA.cjs", "AAB_OLUSTUR.bat", "App.tsx", "README.md", "GEMINIYE_YAPISTIR.txt",
    "TEST_REPORT.md", "UCRETSIZ_KUR.bat", "WEB_TEST.bat", "playwright.social.config.ts", "app.config.ts", "app.json", "eas.json", "firebase.json",
    "index.ts", "package-lock.json",
    "package.json", "playwright.config.ts", "tsconfig.json",
)
SOURCE_DIRS = ("src", "assets", "hosting", "docs", "e2e", "scripts", "tests", "artifacts", "supabase", "integration-ui")
EXCLUDED = {"tests/standalone-html.cjs"}


def package(output: Path):
    files = {}
    candidates = [PROJECT / name for name in ROOT_FILES]
    for name in SOURCE_DIRS:
        for directory, dirs, names in os.walk(PROJECT / name, followlinks=False):
            dirs[:] = sorted(d for d in dirs if not d.startswith(".") and d not in {"node_modules", "lib", "__pycache__"})
            candidates.extend(Path(directory) / n for n in sorted(names))
    for file in candidates:
        relative = file.relative_to(PROJECT).as_posix()
        if file.is_symlink():
            raise ValueError(f"Symbolic link is not allowed: {relative}")
        if not file.is_file() or relative in EXCLUDED:
            continue
        if any(part.startswith(".") or part in {"node_modules", "__pycache__"}
               for part in file.relative_to(PROJECT).parts) and relative not in ROOT_FILES:
            continue
        if (file.suffix.lower() in {".pyc", ".log", ".jks", ".keystore", ".pem", ".key", ".p12", ".pfx", ".apk", ".aab"}
                or file.name == "credentials.json"
                or "serviceaccount" in file.name.lower()
                or "service-account" in file.name.lower()):
            raise ValueError(f"Private or generated file is not allowed: {relative}")
        files[f"Birarada/{relative}"] = file.read_bytes()
    manifest = {
        "artifactType": "standalone_mobile_source",
        "backendProvider": "Supabase with Firebase Authentication",
        "supabaseProjectRef": "qinevhhhdtslnzrtcanq",
        "appName": "Birarada", "applicationId": "com.birarada.app",
        "containsDemoApp": False, "containsSignedAab": False,
        "playStoreReadinessVerified": False,
        "files": {name: hashlib.sha256(data).hexdigest() for name, data in files.items()},
    }
    files["Birarada/SOURCE_MANIFEST.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode()
    if any(name.endswith("/Birarada.html") or "/downloads/" in name
           or name.endswith(("/baslat.bat", "/başlat.bat")) for name in files):
        raise ValueError("Demo delivery path detected")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
    with zipfile.ZipFile(output) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP integrity failed")
        for name, digest in manifest["files"].items():
            if hashlib.sha256(archive.read(name)).hexdigest() != digest:
                raise ValueError(f"ZIP hash mismatch: {name}")
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    output.with_name(output.name + ".sha256").write_text(f"{digest}  {output.name}\n")
    print(json.dumps({"output": str(output), "files": len(files), "bytes": output.stat().st_size,
                      "sha256": digest, "containsDemoApp": False, "containsSignedAab": False}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    package(parser.parse_args().output.resolve())
