import http from "node:http";
import { Readable } from "node:stream";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { createDatabase, databaseDriver } from "../tests/free-harness";
import { handle, type Storage } from "../supabase/functions/birarada/gateway";
import { Records, Timestamp } from "../supabase/functions/birarada/records";
const directory = path.resolve(
  process.env.BIRARADA_LOCAL_DIR || ".birarada-local",
);
await mkdir(directory, { recursive: true });
const pg = await createDatabase(path.join(directory, "db")),
  driver = databaseDriver(pg),
  db = new Records(driver);
function file(key: string) {
  if (!/^private\/[a-zA-Z0-9_:\-]+\/[a-f0-9-]{36}$/i.test(key)) {
    throw Error("Invalid local object path");
  }
  return path.join(directory, "media", key);
}
const storage: Storage = {
  async save(key, bytes) {
    const target = file(key);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, bytes);
  },
  async remove(key) {
    await rm(file(key), { force: true });
  },
  async read(key, start, end) {
    try {
      return new Response(
        new Uint8Array((await readFile(file(key))).subarray(start, end + 1)),
        { status: 206 },
      );
    } catch {
      return new Response(null, { status: 404 });
    }
  },
  async health() {
    return true;
  },
};
async function identify(token: string) {
  const decoded = JSON.parse(
    Buffer.from(token.split(".")[1] || "", "base64url").toString("utf8"),
  );
  if (
    decoded.iss !== "https://securetoken.google.com/demo-birarada" ||
    decoded.aud !== "demo-birarada" || !decoded.sub ||
    decoded.exp < Date.now() / 1000
  ) throw Error("Only local emulator identities are accepted");
  const response = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:lookup?key=local-test",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ idToken: token }),
    },
  );
  const value = await response.json(), user = value.users?.[0];
  if (!response.ok || user?.localId !== decoded.sub) {
    throw Error("Local emulator identity missing");
  }
  return {
    uid: decoded.sub,
    email: user.email || "",
    emailVerified: user.emailVerified === true,
    authTime: decoded.auth_time,
    issuedAt: decoded.iat,
  };
}
const server = http.createServer(async (req, res) => {
  try {
    if (
      req.url === "/__fixtures" && process.env.BIRARADA_TEST_SECRET &&
      req.headers.authorization === "Bearer " + process.env.BIRARADA_TEST_SECRET
    ) {
      let raw = "";
      for await (const chunk of req) {
        raw += chunk;
        if (raw.length > 100000) throw Error("Fixture too large");
      }
      const input = JSON.parse(raw);
      for (const profile of input.profiles || []) {
        const { email, role, ...fields } = profile;
        await db.doc("authUsers/" + profile.uid).set({
          email: email || profile.uid + "@example.test",
          emailVerified: true,
        });
        await db.doc("users/" + profile.uid).set({
          ...fields,
          createdAt: Timestamp.now(),
          termsAcceptedAt: Timestamp.now(),
          termsVersion: "2026-10-21-free1",
          deletionPending: false,
          avatarUrl: "",
          bio: "",
          website: "",
          isPrivate: false,
          allowStrangerDM: true,
        });
        if (profile.role) {
          await db.doc("roles/" + profile.uid).set({ role: profile.role });
        }
      }
      res.writeHead(200, { "Content-Type": "application/json" }).end("{}");
      return;
    }
    const request = new Request(
      "http://127.0.0.1:5002" + req.url,
      {
        method: req.method,
        headers: req.headers as HeadersInit,
        ...(!["GET", "HEAD"].includes(req.method || "GET")
          ? { body: Readable.toWeb(req), duplex: "half" }
          : {}),
      } as RequestInit,
    );
    const response = await handle(request, { driver, storage, identify });
    res.writeHead(response.status, Object.fromEntries(response.headers));
    if (response.body) Readable.fromWeb(response.body as any).pipe(res);
    else res.end();
  } catch {
    res.writeHead(500, { "Content-Type": "application/json" }).end(
      '{"error":{"message":"Local request failed"}}',
    );
  }
});
server.listen(
  5002,
  "127.0.0.1",
  () => console.log("Birarada free local API http://127.0.0.1:5002"),
);
async function close() {
  server.close();
  await pg.close();
  process.exit(0);
}
process.on("SIGTERM", () => {
  void close();
});
process.on("SIGINT", () => {
  void close();
});
