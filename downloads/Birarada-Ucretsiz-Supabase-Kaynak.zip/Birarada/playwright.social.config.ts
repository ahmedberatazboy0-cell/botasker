import { defineConfig } from "@playwright/test";
const { chromePath } = require("./scripts/build-no-github.cjs");
const browser = chromePath(process.env);
if (!browser) throw Error("Arayuz testi icin Chrome veya Edge kur; ozel konum icin CHROMIUM_PATH kullan.");
export default defineConfig({
  testDir: "./integration-ui",
  workers: 1,
  timeout: 120000,
  expect: { timeout: 20000 },
  use: {
    baseURL: "http://127.0.0.1:8081",
    viewport: { width: 390, height: 844 },
    launchOptions: {
      executablePath: browser,
      args: ["--no-sandbox"],
    },
  },
  webServer: {
    command: "node scripts/start-free.cjs",
    // A listening Metro port/HTML page does not mean the app bundle is ready.
    url: "http://127.0.0.1:8081/index.bundle?platform=web&dev=true&hot=false&lazy=true",
    reuseExistingServer: false,
    timeout: 600000,
    stdout: "pipe",
    stderr: "pipe",
    gracefulShutdown: { signal: "SIGTERM", timeout: 10000 },
    env: { CI: "1" },
  },
});
