import { defineConfig } from "@playwright/test";
const { chromePath } = require("./scripts/build-no-github.cjs");
const browser = chromePath(process.env);
if (!browser) throw Error("Arayuz testi icin Chrome veya Edge kur; ozel konum icin CHROMIUM_PATH kullan.");
export default defineConfig({
  testDir: "./e2e",
  workers: 1,
  use: {
    baseURL: "http://127.0.0.1:8081",
    viewport: { width: 390, height: 844 },
    launchOptions: {
      executablePath: browser,
      args: ["--no-sandbox"],
    },
  },
  webServer: {
    command: "node scripts/start-ui-check.cjs",
    cwd: __dirname,
    env: {
      CI: "1",
      EXPO_NO_TELEMETRY: "1",
      EXPO_PUBLIC_USE_EMULATORS: "true",
      EXPO_PUBLIC_STORAGE_ENABLED: "false",
      APP_ENV: "development",
      EAS_BUILD_PROFILE: "",
    },
    url: "http://127.0.0.1:8081/index.bundle?platform=web&dev=true&hot=false&lazy=true",
    reuseExistingServer: true,
    timeout: 600000,
    stdout: "pipe",
    stderr: "pipe",
  },
});
