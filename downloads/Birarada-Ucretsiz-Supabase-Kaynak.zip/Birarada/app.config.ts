import type { ConfigContext, ExpoConfig } from "expo/config";

const {
  checkReleaseEnvironment,
  checkIdentityEnvironment,
  RELEASE_IDENTITY,
  LEGAL_DEFAULTS,
} = require("./scripts/release-check.cjs");

export default ({ config }: ConfigContext): ExpoConfig => {
  checkIdentityEnvironment(process.env);
  const isRelease =
    process.env.APP_ENV === "production" ||
    process.env.EAS_BUILD_PROFILE === "production";
  if (isRelease) checkReleaseEnvironment(process.env);

  const projectId = process.env.EAS_PROJECT_ID;

  return {
    ...config,
    name: config.name || "Birarada",
    slug: config.slug || "birarada",
    version: RELEASE_IDENTITY.version,
    ...(process.env.EXPO_ACCOUNT_OWNER
      ? { owner: process.env.EXPO_ACCOUNT_OWNER }
      : {}),
    ios: {
      ...config.ios,
      bundleIdentifier: RELEASE_IDENTITY.package,
    },
    android: {
      ...config.android,
      package: RELEASE_IDENTITY.package,
      versionCode: RELEASE_IDENTITY.versionCode,
    },
    extra: {
      ...config.extra,
      legal: {
        privacyPolicyUrl:
          process.env.EXPO_PUBLIC_PRIVACY_POLICY_URL ??
          LEGAL_DEFAULTS.EXPO_PUBLIC_PRIVACY_POLICY_URL,
        termsUrl:
          process.env.EXPO_PUBLIC_TERMS_URL ??
          LEGAL_DEFAULTS.EXPO_PUBLIC_TERMS_URL,
        deleteAccountUrl:
          process.env.EXPO_PUBLIC_DELETE_ACCOUNT_URL ??
          LEGAL_DEFAULTS.EXPO_PUBLIC_DELETE_ACCOUNT_URL,
        supportUrl:
          process.env.EXPO_PUBLIC_SUPPORT_URL ??
          LEGAL_DEFAULTS.EXPO_PUBLIC_SUPPORT_URL,
      },
      ...(projectId ? { eas: { projectId } } : {}),
    },
  };
};
