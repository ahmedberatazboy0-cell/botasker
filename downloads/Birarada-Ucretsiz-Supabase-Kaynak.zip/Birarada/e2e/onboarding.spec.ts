import { test, expect } from "@playwright/test";
test("onboarding, login/reset persistence, registration consent and legal destinations", async ({
  page,
}) => {
  test.setTimeout(120000);
  const errors: string[] = [];
  const signUpRequests: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  // This check exercises form gating only. Never create a Firebase account.
  await page.route(/accounts:signUp/, async (route) => {
    signUpRequests.push(route.request().url());
    await route.abort();
  });
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await expect(
    page.getByText("Arkadaşlarını bul", { exact: true }),
  ).toBeVisible({ timeout: 90000 });
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await expect(
    page.getByText("Anlarını paylaş", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await expect(
    page.getByText("Birlikte daha fazlasını yaşa", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(page.getByText("İyi ki geldin.", { exact: true })).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Giriş yap", exact: true }),
  ).toBeDisabled();
  await page.screenshot({ path: "artifacts/auth-mobile.png", fullPage: true });
  await page
    .getByRole("button", { name: "Şifremi unuttum", exact: true })
    .click();
  await expect(
    page.getByText("Yeniden bağlan.", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByText("İyi ki geldin.", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Yeni hesap oluştur", exact: true })
    .click();
  await expect(page.getByText("Aramıza katıl.", { exact: true })).toBeVisible();
  await expect(
    page.getByText("Birarada topluluk kuralları", { exact: true }),
  ).toBeVisible();
  const create = page.getByRole("button", {
    name: "Hesap oluştur",
    exact: true,
  });
  const consent = page.getByRole("checkbox", {
    name: "Kullanım koşullarını ve topluluk kurallarını kabul ediyorum, gizlilik politikasını okudum",
    exact: true,
  });
  await expect(consent).toHaveAttribute("aria-checked", "false");
  await expect(create).toBeDisabled();
  await page
    .getByLabel("E-posta", { exact: true })
    .fill("form-check@example.invalid");
  await page.getByLabel("Şifre", { exact: true }).fill("Temporary-Check-492!");
  await expect(create).toBeDisabled();
  await expect(
    page.getByRole("button", { name: "Google ile devam et", exact: true }),
  ).toBeDisabled();
  await consent.click();
  await expect(consent).toHaveAttribute("aria-checked", "true");
  await expect(create).toBeEnabled();
  await expect(
    page.getByRole("button", { name: "Google ile devam et", exact: true }),
  ).toBeEnabled();
  await page.getByLabel("Şifre", { exact: true }).fill("short");
  await expect(create).toBeDisabled();
  await page.getByLabel("Şifre", { exact: true }).fill("Temporary-Check-492!");
  await expect(create).toBeEnabled();
  await consent.click();
  await expect(create).toBeDisabled();

  // Capture Linking.openURL without opening external sites or a mail client.
  await page.evaluate(() => {
    const testWindow = window as typeof window & { openedLegalUrls: string[] };
    testWindow.openedLegalUrls = [];
    window.open = (url?: string | URL) => {
      testWindow.openedLegalUrls.push(String(url));
      return null;
    };
  });
  for (const title of ["Gizlilik politikası", "Kullanım koşulları", "Destek"]) {
    await page.getByRole("button", { name: title, exact: true }).click();
  }
  await expect
    .poll(() =>
      page.evaluate(
        () =>
          (window as typeof window & { openedLegalUrls: string[] })
            .openedLegalUrls,
      ),
    )
    .toEqual([
      "https://birarada-5650c.web.app/privacy",
      "https://birarada-5650c.web.app/terms",
      "mailto:ahmedberatazboy0@gmail.com",
    ]);
  await page
    .getByRole("button", { name: "Zaten hesabım var", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Yeni hesap oluştur", exact: true })
    .click();
  await expect(consent).toHaveAttribute("aria-checked", "false");
  await expect(create).toBeDisabled();
  expect(signUpRequests).toEqual([]);
  expect(errors).toEqual([]);
});
