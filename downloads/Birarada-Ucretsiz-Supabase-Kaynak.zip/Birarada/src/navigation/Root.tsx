import React from "react";
import { Text, Platform } from "react-native";
import * as Push from "expo-notifications";
import { auth } from "../firebase/client";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {
  Feed,
  ProfileScreen,
  EditProfile,
  Settings,
  Notifications,
} from "../screens/Social";
import { Create, ShortVideos } from "../screens/Media";
import { Saved, Connections } from "../screens/Collections";
import { Notes } from "../screens/Notes";
import { Admin } from "../screens/Admin";
import { StoryViewer } from "../screens/Stories";
import { Explore, PostDetails } from "../screens/Discovery";
import { Chats, Conversation, NewGroup } from "../screens/Messaging";
const Stack = createNativeStackNavigator(),
  Tab = createBottomTabNavigator();
const icons: Record<string, string> = {
  "Ana Sayfa": "◉",
  Keşfet: "⌕",
  Oluştur: "+",
  Reels: "▷",
  Profil: "◎",
};
function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: "#ff925c",
        tabBarInactiveTintColor: "#a8a6a3",
        tabBarStyle: {
          backgroundColor: "#101112",
          borderTopColor: "#303237",
          height: 78,
          paddingBottom: 14,
          paddingTop: 8,
        },
        tabBarLabelStyle: { fontSize: 10 },
        tabBarIcon: ({ color }) => (
          <Text style={{ color, fontSize: 25 }}>{icons[route.name]}</Text>
        ),
      })}
    >
      <Tab.Screen name="Ana Sayfa" component={Feed} />
      <Tab.Screen name="Keşfet" component={Explore} />
      <Tab.Screen name="Oluştur" component={Create} />
      <Tab.Screen name="Reels" component={ShortVideos} />
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
export function Root() {
  const navigation = React.useRef<any>(null),
    handled = React.useRef("");
  React.useEffect(() => {
    if (Platform.OS === "web") return;
    const open = (response: Push.NotificationResponse | null) => {
      if (!response) return;
      const request = response.notification.request,
        data = request.content.data;
      if (
        handled.current === request.identifier ||
        data.targetUid !== auth.currentUser?.uid
      )
        return;
      if (!navigation.current?.isReady()) return;
      handled.current = request.identifier;
      if (
        typeof data.chatId === "string" &&
        /^[a-zA-Z0-9_:\-]{1,160}$/.test(data.chatId)
      )
        navigation.current.navigate("Conversation", { id: data.chatId });
      else if (
        typeof data.postId === "string" &&
        /^[a-zA-Z0-9_:\-]{1,160}$/.test(data.postId)
      )
        navigation.current.navigate("PostDetails", { id: data.postId });
      else navigation.current.navigate("Notifications");
      void Push.clearLastNotificationResponseAsync();
    };
    const subscription = Push.addNotificationResponseReceivedListener(open);
    void Push.getLastNotificationResponseAsync().then(open);
    return () => subscription.remove();
  }, []);
  return (
    <NavigationContainer
      ref={navigation}
      theme={{
        ...DarkTheme,
        colors: {
          ...DarkTheme.colors,
          primary: "#ff925c",
          background: "#101112",
          card: "#101112",
          border: "#303237",
          text: "#f7f2eb",
        },
      }}
    >
      <Stack.Navigator
        screenOptions={{ headerTintColor: "#ff925c", headerBackTitle: "Geri" }}
      >
        <Stack.Screen
          name="Main"
          component={Tabs}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Admin"
          component={Admin}
          options={{ title: "Yönetim paneli" }}
        />
        <Stack.Screen
          name="StoryComposer"
          component={Create}
          options={{ title: "Hikâye oluştur" }}
        />
        <Stack.Screen
          name="StoryViewer"
          component={StoryViewer}
          options={{ title: "Hikâyeler" }}
        />
        <Stack.Screen
          name="PostDetails"
          component={PostDetails}
          options={{ title: "Paylaşım" }}
        />
        <Stack.Screen
          name="NewGroup"
          component={NewGroup}
          options={{ title: "Yeni grup" }}
        />
        <Stack.Screen
          name="Notes"
          component={Notes}
          options={{ title: "Notlar" }}
        />
        <Stack.Screen
          name="Saved"
          component={Saved}
          options={{ title: "Kaydedilenler" }}
        />
        <Stack.Screen
          name="Connections"
          component={Connections}
          options={{ title: "Bağlantıların" }}
        />
        <Stack.Screen
          name="User"
          component={ProfileScreen}
          options={{ title: "Profil" }}
        />
        <Stack.Screen
          name="EditProfile"
          component={EditProfile}
          options={{ title: "Profili düzenle" }}
        />
        <Stack.Screen
          name="Settings"
          component={Settings}
          options={{ title: "Ayarlar" }}
        />
        <Stack.Screen
          name="Notifications"
          component={Notifications}
          options={{ title: "Bildirimler" }}
        />
        <Stack.Screen
          name="Chats"
          component={Chats}
          options={{ title: "Mesajlar" }}
        />
        <Stack.Screen
          name="Conversation"
          component={Conversation}
          options={{ title: "Sohbet" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
