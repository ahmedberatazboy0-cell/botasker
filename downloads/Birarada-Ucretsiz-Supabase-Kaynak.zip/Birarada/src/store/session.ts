import { create } from "zustand";
import type { User } from "firebase/auth";
import type { Profile } from "../types";
export const useSession = create<{
  user: User | null;
  profile: Profile | null;
  ready: boolean;
  deleting: boolean;
  deletionPending: boolean;
  deletionError: string;
  set: (
    v: Partial<{
      user: User | null;
      profile: Profile | null;
      ready: boolean;
      deleting: boolean;
      deletionPending: boolean;
      deletionError: string;
    }>,
  ) => void;
}>((set) => ({
  user: null,
  profile: null,
  ready: false,
  deleting: false,
  deletionPending: false,
  deletionError: "",
  set: (v) => set(v),
}));
