import { useCallback, useEffect, useRef, useState } from "react";
import { api, type Cursor } from "../services/api";
import type { Row } from "../types";
export function useApiList(action: string, input: Record<string, unknown>) {
  const key = JSON.stringify(input),
    generation = useRef(0),
    busy = useRef(false);
  const [rows, setRows] = useState<Row[]>([]),
    [loading, setLoading] = useState(true),
    [paging, setPaging] = useState(false),
    [error, setError] = useState(""),
    [cursor, setCursor] = useState<Cursor>(null),
    [version, setVersion] = useState(0);
  useEffect(() => {
    const current = ++generation.current;
    setRows([]);
    setLoading(true);
    setError("");
    setCursor(null);
    busy.current = false;
    api<{ rows: Row[]; cursor: Cursor }>(action, JSON.parse(key))
      .then((result) => {
        if (generation.current !== current) return;
        setRows(result.rows);
        setCursor(result.cursor || null);
      })
      .catch((e) => {
        if (generation.current === current) setError(e.message);
      })
      .finally(() => {
        if (generation.current === current) setLoading(false);
      });
    return () => {
      generation.current++;
    };
  }, [action, key, version]);
  const loadMore = useCallback(async () => {
    if (busy.current || loading || !cursor) return;
    const current = generation.current;
    busy.current = true;
    setPaging(true);
    setError("");
    try {
      const next = await api<{ rows: Row[]; cursor: Cursor }>(action, {
        ...JSON.parse(key),
        cursor,
      });
      if (current !== generation.current) return;
      setRows((previous) => [
        ...new Map([...previous, ...next.rows].map((r) => [r.id, r])).values(),
      ]);
      setCursor(next.cursor || null);
    } catch (e) {
      if (current === generation.current) setError((e as Error).message);
    } finally {
      if (current === generation.current) {
        busy.current = false;
        setPaging(false);
      }
    }
  }, [action, key, cursor, loading]);
  return {
    rows,
    loading,
    paging,
    error,
    hasMore: !!cursor,
    loadMore,
    refresh: useCallback(() => setVersion((v) => v + 1), []),
  };
}
