import { useEffect, useState } from "react";
import { onIdTokenChanged } from "firebase/auth";
import { auth } from "../firebase/client";
import { api } from "../services/api";
export function useRole() {
  const [role, setRole] = useState("member");
  useEffect(() => {
    let alive = true, generation = 0;
    const stop = onIdTokenChanged(auth, async (user) => {
      const n = ++generation;
      setRole("member");
      if (!user) return;
      try {
        const r = await api("capabilities");
        if (alive && n === generation) setRole(r.role);
      } catch {}
    });
    return () => {
      alive = false;
      stop();
    };
  }, []);
  return role;
}
