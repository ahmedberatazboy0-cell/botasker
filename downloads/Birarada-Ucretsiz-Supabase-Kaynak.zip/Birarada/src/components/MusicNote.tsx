import React, { useState } from "react";
import { Linking, View } from "react-native";
import type { Note } from "../types";
import { songLink } from "../utils/notes";
import { block } from "../services/social";
import { reportNote } from "../services/notes";
import { Button, Label, ReportForm, styles } from "./ui";

export function MusicNote({
  note,
  own = false,
}: {
  note: Note;
  own?: boolean;
}) {
  const [reporting, setReporting] = useState(false);
  const [confirmBlock, setConfirmBlock] = useState(false);
  // Revalidate before opening, including cached or administratively edited data.
  let song: ReturnType<typeof songLink> | null = null;
  try {
    if (note.songUrl) song = songLink(note.songUrl);
  } catch {
    /* No unsafe external link. */
  }
  return (
    <View style={styles.card}>
      <Label muted>{own ? "Senin notun" : `@${note.username}`}</Label>
      {!!note.text && <Label>{note.text}</Label>}
      {!!note.songTitle && <Label>♫ {note.songTitle}</Label>}
      {song && (
        <Button
          secondary
          title={`${song.provider}'da aç`}
          onPress={() => Linking.openURL(song!.url)}
        />
      )}
      {!own && (
        <>
          <Button
            secondary
            title="Notu şikâyet et"
            onPress={() => setReporting((value) => !value)}
          />
          {reporting && (
            <ReportForm
              onSubmit={(reason) => reportNote(note, reason)}
              onCancel={() => setReporting(false)}
            />
          )}
          <Button
            secondary
            title="Hesabı engelle"
            onPress={() => setConfirmBlock(true)}
          />
          {confirmBlock && (
            <>
              <Label>Bu hesabı engellemek istiyor musun?</Label>
              <Button title="Evet, engelle" onPress={() => block(note.uid)} />
              <Button
                secondary
                title="Vazgeç"
                onPress={() => setConfirmBlock(false)}
              />
            </>
          )}
        </>
      )}
    </View>
  );
}
