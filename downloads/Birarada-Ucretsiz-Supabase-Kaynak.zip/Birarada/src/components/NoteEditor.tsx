import React, { useEffect, useState } from "react";
import { View } from "react-native";
import { Button, Field, Label, styles } from "./ui";
import { noteContent } from "../utils/notes";
import type { Note } from "../types";

export function NoteEditor({
  record,
  active,
  onSave,
  onRemove,
}: {
  record: Note | null;
  active: boolean;
  onSave: (text: string, title: string, url: string) => Promise<void>;
  onRemove: () => Promise<void>;
}) {
  const [text, setText] = useState(active ? record?.text || "" : "");
  const [title, setTitle] = useState(active ? record?.songTitle || "" : "");
  const [url, setUrl] = useState(active ? record?.songUrl || "" : "");
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);
  useEffect(() => {
    if (dirty || saving) return;
    setText(active ? record?.text || "" : "");
    setTitle(active ? record?.songTitle || "" : "");
    setUrl(active ? record?.songUrl || "" : "");
  }, [record, active, dirty, saving]);
  let validation = "";
  try {
    noteContent(text, title, url);
  } catch (error) {
    validation = (error as Error).message;
  }
  const change = (setter: (value: string) => void) => (value: string) => {
    setDirty(true);
    setStatus("");
    setConfirmDelete(false);
    setter(value);
  };
  return (
    <View style={styles.card}>
      <Label>Bugün aklında ne var?</Label>
      <Label muted>
        Notun ve şarkın 24 saat boyunca onaylanmış takipçilerine görünür. Yeni
        not öncekinin yerini alır.
      </Label>
      <Field
        placeholder="Notun (en fazla 60 karakter)"
        value={text}
        onChangeText={change(setText)}
        maxLength={60}
        multiline
        editable={!saving}
      />
      <Label muted>{text.length}/60</Label>
      <Field
        placeholder="Şarkı ve sanatçı adı (isteğe bağlı)"
        value={title}
        onChangeText={change(setTitle)}
        maxLength={120}
        editable={!saving}
      />
      <Field
        placeholder="Spotify veya YouTube bağlantısı"
        value={url}
        onChangeText={change(setUrl)}
        maxLength={500}
        keyboardType="url"
        autoCorrect={false}
        editable={!saving}
      />
      <Label muted>
        Spotify’da şarkının, YouTube’da videonun paylaşım bağlantısını yapıştır.
        Şarkı ilgili serviste açılır.
      </Label>
      {dirty && !!validation && <Label muted>{validation}</Label>}
      <Button
        title={active ? "Notu güncelle" : "Notu paylaş"}
        disabled={!!validation || saving}
        onPress={async () => {
          setSaving(true);
          setStatus("");
          try {
            await onSave(text, title, url);
            setDirty(false);
            setStatus("Notun paylaşıldı.");
          } finally {
            setSaving(false);
          }
        }}
      />
      {!!status && <Label>{status}</Label>}
      {!!record && (
        <Button
          secondary
          title="Notumu sil"
          disabled={saving}
          onPress={() => setConfirmDelete(true)}
        />
      )}
      {confirmDelete && (
        <>
          <Label>
            Notunu ve eklediğin şarkı bağlantısını silmek istiyor musun?
          </Label>
          <Button
            title="Evet, notumu sil"
            disabled={saving}
            onPress={async () => {
              setSaving(true);
              setStatus("");
              try {
                await onRemove();
                setDirty(false);
                setText("");
                setTitle("");
                setUrl("");
                setConfirmDelete(false);
                setStatus("Notun silindi.");
              } finally {
                setSaving(false);
              }
            }}
          />
          <Button
            secondary
            title="Vazgeç"
            disabled={saving}
            onPress={() => setConfirmDelete(false)}
          />
        </>
      )}
    </View>
  );
}
