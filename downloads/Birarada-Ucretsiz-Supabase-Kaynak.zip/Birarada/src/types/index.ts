export type Profile = {
  uid: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  website: string;
  isPrivate: boolean;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  allowStrangerDM: boolean;
  deletionPending?: boolean;
  avatarMediaId?: string;
  official?: boolean;
  termsVersion?: string;
};
export type Post = {
  id: string;
  uid: string;
  username: string;
  caption: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  createdAt?: { seconds: number };
  commentsEnabled: boolean;
  kind?: "post" | "reel";
  mediaItems?: import("../services/api").MediaItem[];
  mediaIds?: string[];
};
export type Row = { id: string; [key: string]: any };
export type Note = {
  uid: string;
  username: string;
  text: string;
  songTitle: string;
  songUrl: string;
  updatedAt: { seconds: number; nanoseconds?: number } | null;
};
