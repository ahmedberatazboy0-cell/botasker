export const colors = {
  bg: "#101112",
  surface: "#1b1d20",
  line: "#303237",
  text: "#f7f2eb",
  muted: "#a8a6a3",
  accent: "#ff925c",
  danger: "#ff9494",
};
