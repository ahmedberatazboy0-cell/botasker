import type { Note } from "../types";

export const NOTE_LIFETIME_MS = 24 * 60 * 60 * 1000;

export function songLink(value: string): { url: string; provider: string } {
  const invalid = () =>
    Error("Spotify şarkı bağlantısı veya YouTube video bağlantısı ekle.");
  if (value.length > 500) throw invalid();
  let url: URL;
  try {
    url = new URL(value.trim());
  } catch {
    throw invalid();
  }
  if (url.protocol !== "https:" || url.username || url.password || url.port)
    throw invalid();
  const host = url.hostname.toLowerCase();
  if (host === "open.spotify.com") {
    const track = /^\/(?:intl-[a-z]{2}\/)?track\/([A-Za-z0-9]{22})\/?$/.exec(
      url.pathname,
    );
    if (track)
      return {
        url: `https://open.spotify.com/track/${track[1]}`,
        provider: "Spotify",
      };
  }
  let video: string | null = null;
  if (host === "youtu.be")
    video = /^\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1] ?? null;
  if (
    [
      "youtube.com",
      "www.youtube.com",
      "m.youtube.com",
      "music.youtube.com",
    ].includes(host)
  ) {
    video =
      url.pathname === "/watch"
        ? url.searchParams.get("v")
        : (/^\/shorts\/([A-Za-z0-9_-]{11})\/?$/.exec(url.pathname)?.[1] ??
          null);
  }
  if (video && /^[A-Za-z0-9_-]{11}$/.test(video)) {
    return {
      url: `https://www.youtube.com/watch?v=${video}`,
      provider: "YouTube",
    };
  }
  throw invalid();
}

export function noteContent(text: string, songTitle: string, songUrl: string) {
  const content = {
    text: text.trim(),
    songTitle: songTitle.trim(),
    songUrl: songUrl.trim(),
  };
  if (content.text.length > 60)
    throw Error("Notun en fazla 60 karakter olabilir.");
  if (content.songTitle.length > 120)
    throw Error("Şarkı adı en fazla 120 karakter olabilir.");
  if (!!content.songTitle !== !!content.songUrl)
    throw Error("Şarkı adını ve bağlantısını birlikte ekle.");
  if (!content.text && !content.songTitle)
    throw Error("Bir not yaz veya şarkı ekle.");
  if (content.songUrl) content.songUrl = songLink(content.songUrl).url;
  return content;
}

export function noteExpiresAt(note: Pick<Note, "updatedAt">): number {
  const time = note.updatedAt;
  if (!time || !Number.isFinite(time.seconds)) return 0;
  return time.seconds * 1000 + (time.nanoseconds ?? 0) / 1e6 + NOTE_LIFETIME_MS;
}

export function noteIsActive(
  note: Pick<Note, "updatedAt">,
  now = Date.now(),
): boolean {
  return noteExpiresAt(note) > now;
}
