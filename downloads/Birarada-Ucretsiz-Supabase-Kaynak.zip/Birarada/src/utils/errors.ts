export function friendly(error: unknown): string {
  const code = (error as { code?: string })?.code;
  const messages: Record<string, string> = {
    "auth/invalid-email": "Geçerli bir e-posta adresi yaz.",
    "auth/invalid-credential": "E-posta veya şifre hatalı.",
    "auth/email-already-in-use": "Bu e-posta zaten kullanılıyor.",
    "auth/weak-password": "En az 8 karakterli bir şifre seç.",
    "auth/network-request-failed": "Bağlantını kontrol edip tekrar dene.",
    "auth/too-many-requests":
      "Çok fazla deneme yaptın. Biraz sonra tekrar dene.",
    "auth/operation-not-allowed":
      "Bu giriş yöntemi Firebase konsolunda henüz etkin değil.",
    "auth/wrong-password": "Mevcut şifren doğru değil.",
    "auth/requires-recent-login":
      "Güvenliğin için yeniden giriş yapıp işlemi tekrar onayla.",
    "auth/user-disabled":
      "Bu hesap kullanıma kapatılmış. Destek ile iletişime geç.",
    "permission-denied":
      "Bu içeriğe erişim iznin yok.",
    unavailable: "Şu an çevrimdışısın. Bağlantı gelince yeniden dene.",
    "storage/unauthorized":
      "Bu medyayı yükleme iznin yok.",
    unauthenticated: "Oturumunu yenilemek için çıkış yapıp yeniden giriş yap.",
    "resource-exhausted": "Kullanım sınırına ulaşıldı. Biraz sonra tekrar dene.",
    "invalid-argument": "Bilgilerini kontrol edip tekrar dene.",
    "not-found": "Bu içerik artık bulunamıyor.",
  };
  return (
    (code && messages[code]) ||
    (error instanceof Error && !code
      ? error.message
      : "İşlem tamamlanamadı. Lütfen tekrar dene.")
  );
}
export function usernameValid(value: string) {
  return /^[a-z0-9_]{3,24}$/.test(value);
}
