import { manipulateAsync, SaveFormat } from "expo-image-manipulator";
export async function normalizeImage(uri: string) {
  return (await manipulateAsync(uri, [{ resize: { width: 1440 } }], {
    compress: 0.85,
    format: SaveFormat.JPEG,
  })).uri;
}
