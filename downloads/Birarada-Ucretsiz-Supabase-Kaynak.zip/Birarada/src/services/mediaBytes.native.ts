import { File } from "expo-file-system";
export async function readMediaBytes(uri: string): Promise<ArrayBuffer> {
  return new File(uri).arrayBuffer();
}
