export async function readMediaBytes(uri: string): Promise<ArrayBuffer> {
  const response = await fetch(uri);
  if (!response.ok) throw Error("Seçilen dosya okunamadı. Yeniden seç.");
  return response.arrayBuffer();
}
