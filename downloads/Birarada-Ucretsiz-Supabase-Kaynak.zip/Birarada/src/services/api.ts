import { randomUUID } from "expo-crypto";
import { auth } from "../firebase/client";
import { apiBase, request } from "../database/client";
import { readMediaBytes } from "./mediaBytes";
export const newId = () => randomUUID();
export type MediaKind = "image" | "video" | "audio";
export type MediaItem = {
  id: string;
  kind: MediaKind;
  width?: number;
  height?: number;
  duration?: number;
};
export type Cursor = {
  seconds: number;
  nanoseconds: number;
  id: string;
} | null;
export async function api<T = any>(
  action: string,
  input: Record<string, unknown> = {},
): Promise<T> {
  return request<T>("socialApi", { action, input });
}
export const mediaEndpoint = (
  name: "mediaContent" | "mediaUpload",
  id: string,
) => {
  if (!/^[a-f0-9-]{36}$/i.test(id)) throw Error("Geçersiz medya.");
  return `${apiBase}/${name}?id=${encodeURIComponent(id)}`;
};
export async function uploadMedia(
  uri: string,
  kind: MediaKind,
  purpose: "post" | "story" | "reel" | "message" | "avatar",
  requestId = newId(),
): Promise<MediaItem> {
  if (!auth.currentUser) throw Error("Önce giriş yap.");
  let prepared = uri;
  if (kind === "image") {
    const { normalizeImage } = await import("./normalizeImage");
    prepared = await normalizeImage(uri);
  }
  const bytes = await readMediaBytes(prepared),
    max = kind === "image" ? 10 : kind === "audio" ? 8 : 20;
  if (!bytes.byteLength || bytes.byteLength > max * 1024 ** 2) {
    throw Error(`Dosya en fazla ${max} MB olabilir.`);
  }
  const reserved = await api("createUpload", {
    requestId,
    kind,
    purpose,
    bytes: bytes.byteLength,
  });
  if (reserved.status === "ready") return { id: reserved.id, kind };
  const controller = new AbortController(),
    timer = setTimeout(() => controller.abort(), 90000);
  try {
    const response = await fetch(mediaEndpoint("mediaUpload", reserved.id), {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${await auth.currentUser.getIdToken()}`,
        "Content-Type": "application/octet-stream",
      },
      body: bytes,
      signal: controller.signal,
    });
    if (!response.ok) {
      const r = await response.json().catch(() => ({}));
      throw Error(r.error?.message || "Medya yüklenemedi. Taslağın korunuyor.");
    }
    return { id: reserved.id, kind };
  } finally {
    clearTimeout(timer);
  }
}
