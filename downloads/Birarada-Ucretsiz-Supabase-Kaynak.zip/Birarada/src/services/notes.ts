import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  serverTimestamp,
  setDoc,
} from "../database/client";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import type { Note } from "../types";
import { noteContent, noteIsActive } from "../utils/notes";
import { uid } from "./social";

export async function saveNote(
  text: string,
  songTitle: string,
  songUrl: string,
) {
  const user = useSession.getState().profile;
  if (!user || user.uid !== uid() || user.deletionPending)
    throw Error("Devam etmek için giriş yap.");
  const content = noteContent(text, songTitle, songUrl);
  await setDoc(doc(db, "notes", user.uid), {
    uid: user.uid,
    username: user.username,
    ...content,
    updatedAt: serverTimestamp(),
  });
}

export async function removeNote() {
  await deleteDoc(doc(db, "notes", uid()));
}

export async function reportNote(note: Note, reason: string) {
  const text = reason.trim();
  if (!text || text.length > 500)
    throw Error("Şikâyet nedeni 1–500 karakter olmalı.");
  if (note.uid === uid()) throw Error("Kendi notunu şikâyet edemezsin.");
  if (!noteIsActive(note)) throw Error("Bu notun süresi doldu.");
  await addDoc(collection(db, "reports"), {
    reporterUid: uid(),
    targetUid: note.uid,
    reason: text,
    createdAt: serverTimestamp(),
    noteSnapshot: {
      text: note.text,
      songTitle: note.songTitle,
      songUrl: note.songUrl,
      // Keep the real Firestore Timestamp, including its nanoseconds.
      updatedAt: note.updatedAt,
    },
  });
}
