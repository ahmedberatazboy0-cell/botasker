import * as Picker from "expo-image-picker";
export async function selectMedia({
  camera = false,
  multiple = false,
  videoOnly = false,
}: { camera?: boolean; multiple?: boolean; videoOnly?: boolean } = {}) {
  if (camera && !(await Picker.requestCameraPermissionsAsync()).granted) {
    throw Error(
      "Kamera izni vermelisin. İzni telefon ayarlarından değiştirebilirsin.",
    );
  }
  const options: Picker.ImagePickerOptions = {
    mediaTypes: videoOnly ? ["videos"] : ["images", "videos"],
    quality: 0.8,
    videoMaxDuration: videoOnly ? 90 : 180,
    videoExportPreset: Picker.VideoExportPreset.H264_1280x720,
    allowsMultipleSelection: !camera && multiple,
    selectionLimit: multiple ? 10 : 1,
    allowsEditing: camera || !multiple,
    aspect: [1, 1],
  };
  const result = camera
    ? await Picker.launchCameraAsync(options)
    : await Picker.launchImageLibraryAsync(options);
  return result.canceled ? [] : result.assets;
}
