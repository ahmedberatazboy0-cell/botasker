export interface DeletionPlan {
  confirmIdentity(): Promise<void>;
  markPending(): Promise<{ profileExists: boolean }>;
  removeOwnedPosts(): Promise<void>;
  removeAuthoredActivity(): Promise<void>;
  clearChatPreviews(): Promise<void>;
  removeConnections(): Promise<void>;
  removePrivateData(): Promise<void>;
  removeProfileAndUsername(): Promise<void>;
  removeAuthentication(): Promise<void>;
}

// Authentication is deliberately removed last. Any failed data-cleanup step
// leaves a signed-in identity which can reauthenticate and retry the cleanup.
export async function runDeletionPlan(plan: DeletionPlan): Promise<void> {
  await plan.confirmIdentity();
  const pending = await plan.markPending();
  await plan.removeOwnedPosts();
  await plan.removeAuthoredActivity();
  // A missing profile means a previous run already completed every Firestore
  // phase. Chat preview rules require the still-present deletion marker;
  // repeating that write after profile removal would prevent an Auth retry.
  if (pending.profileExists) await plan.clearChatPreviews();
  await plan.removeConnections();
  await plan.removePrivateData();
  await plan.removeProfileAndUsername();
  await plan.removeAuthentication();
}
