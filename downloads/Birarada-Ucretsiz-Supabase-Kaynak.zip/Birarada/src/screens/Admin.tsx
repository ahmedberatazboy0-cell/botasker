import React, { useEffect, useState } from "react";
import { ScrollView, Switch, View } from "react-native";
import { api, type MediaItem } from "../services/api";
import { useRole } from "../hooks/useRole";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { Button, Field, Label, Page, State, styles } from "../components/ui";
import type { Row } from "../types";

type Confirmation = {
  action: string;
  input: Record<string, unknown>;
  label: string;
};
export function Admin() {
  const role = useRole(),
    allowed = role !== "member",
    senior = role === "owner" || role === "admin";
  const [counts, setCounts] = useState<Record<string, number>>({}),
    [tab, setTab] = useState("reports"),
    [rows, setRows] = useState<Row[]>([]),
    [after, setAfter] = useState<string | null>(null),
    [loading, setLoading] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [reason, setReason] = useState(""),
    [confirmation, setConfirmation] = useState<Confirmation | null>(null),
    [evidence, setEvidence] = useState<{
      report: Row;
      mediaItems: MediaItem[];
    } | null>(null);
  const [uid, setUid] = useState(""),
    [contentId, setContentId] = useState(""),
    [contentKind, setContentKind] = useState("post"),
    [newRole, setNewRole] = useState("moderator"),
    [announcement, setAnnouncement] = useState(""),
    [maintenance, setMaintenance] = useState(false),
    [words, setWords] = useState("");
  async function load(more = false) {
    setLoading(true);
    setError("");
    try {
      const result = await api("adminList", {
        collection: tab,
        ...(more ? { after } : {}),
      });
      setRows((old) => (more ? [...old, ...result.rows] : result.rows));
      setAfter(result.after);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (!senior) return;
    api("getAdminConfig")
      .then((r) => {
        setAnnouncement(r.announcement || "");
        setMaintenance(r.maintenance === true);
        setWords((r.blockedWords || []).join("\n"));
      })
      .catch((e) => setError(e.message));
  }, [senior]);
  useEffect(() => {
    if (!allowed) return;
    api("dashboard")
      .then((r) => setCounts(r.counts))
      .catch((e) => setError(e.message));
  }, [allowed]);
  useEffect(() => {
    setEvidence(null);
    setRows([]);
    setAfter(null);
    if (allowed) void load();
  }, [tab, allowed]);
  if (!allowed)
    return (
      <Page title="Yönetim erişimi">
        <Label>
          Bu hesabın yönetici yetkisi yok. Yetki sunucu tarafından doğrulanır.
        </Label>
      </Page>
    );
  function prepare(
    action: string,
    input: Record<string, unknown>,
    label: string,
  ) {
    if (!reason.trim()) {
      setError("İşlem gerekçesi yazmalısın.");
      return;
    }
    setConfirmation({ action, input: { ...input, reason }, label });
    setError("");
  }
  return (
    <Page title="Birarada yönetimi">
      <Label>
        Yetkin:{" "}
        {role === "owner"
          ? "Hesap sahibi"
          : role === "admin"
            ? "Yönetici"
            : "Moderatör"}
      </Label>
      <View style={[styles.row, { flexWrap: "wrap" }]}>
        {Object.entries(counts).map(([key, value]) => (
          <View key={key} style={styles.card}>
            <Label>
              {
                (
                  {
                    users: "Hesap",
                    posts: "Gönderi",
                    stories: "Hikâye",
                    reports: "Şikâyet",
                    chats: "Sohbet",
                  } as Record<string, string>
                )[key]
              }
              : {value}
            </Label>
          </View>
        ))}
      </View>
      <ScrollView horizontal contentContainerStyle={{ gap: 8 }}>
        {[
          ["reports", "Şikâyetler"],
          ["users", "Hesaplar"],
          ["posts", "Gönderiler"],
          ["stories", "Hikâyeler"],
          ...(senior
            ? [
                ["accountStatus", "Kısıtlamalar"],
                ["auditLog", "İşlem kayıtları"],
              ]
            : []),
        ].map(([value, label]) => (
          <Button
            key={value}
            secondary={tab !== value}
            title={label!}
            onPress={() => setTab(value!)}
          />
        ))}
      </ScrollView>
      <Field
        placeholder="İşlem gerekçesi / inceleme notu"
        multiline
        maxLength={500}
        value={reason}
        onChangeText={setReason}
      />
      <State
        loading={loading && !rows.length}
        error={error}
        empty={!loading && !rows.length}
        retry={() => load()}
      />
      {rows.map((row) => (
        <View key={row.id} style={styles.card}>
          {tab === "reports" ? (
            <>
              <Label>{row.reason}</Label>
              <Label muted>
                Durum: {row.status || "open"} · Hedef: {row.targetUid}
              </Label>
              <Button
                secondary
                title="Kanıtı incele"
                onPress={async () => {
                  setEvidence(await api("reviewReport", { id: row.id }));
                }}
              />
              <Button
                secondary
                title="İncelemeye al"
                onPress={() =>
                  prepare(
                    "resolveReport",
                    { id: row.id, status: "reviewing" },
                    "Şikâyeti incelemeye al",
                  )
                }
              />
              <Button
                secondary
                title="İncelemeyi kapat"
                onPress={() =>
                  prepare(
                    "resolveReport",
                    { id: row.id, status: "closed" },
                    "Şikâyeti kapat",
                  )
                }
              />
              {row.contentId && (
                <Button
                  secondary
                  title="Şikâyet edilen içeriği kaldır"
                  onPress={() =>
                    prepare(
                      "removeContent",
                      {
                        id: row.contentId,
                        kind:
                          row.contentCollection === "stories"
                            ? "story"
                            : "post",
                      },
                      "Şikâyet edilen içeriği kalıcı kaldır",
                    )
                  }
                />
              )}
              <Button
                secondary
                title="Hedef hesabı seç"
                onPress={() => {
                  setUid(row.targetUid);
                  setNotice(
                    "Hedef hesap aşağıdaki hesap yönetimi alanında seçildi.",
                  );
                }}
              />
            </>
          ) : tab === "users" ? (
            <>
              <Label>
                @{row.username} {row.official ? "✓ Resmî hesap" : ""}
              </Label>
              <Label>{row.displayName}</Label>
              <Label muted>{row.id}</Label>
              <Button
                secondary
                title="Bu hesabı yönet"
                onPress={() => setUid(row.id)}
              />
            </>
          ) : tab === "posts" || tab === "stories" ? (
            <>
              <Label>@{row.username}</Label>
              <Label>{row.caption}</Label>
              <Label muted>{row.id}</Label>
              <Button
                secondary
                title="İçeriği kaldır"
                onPress={() =>
                  prepare(
                    "removeContent",
                    { id: row.id, kind: tab === "stories" ? "story" : "post" },
                    "İçeriği kalıcı kaldır",
                  )
                }
              />
            </>
          ) : tab === "auditLog" ? (
            <>
              <Label>{row.action}</Label>
              <Label muted>
                {row.actorUid} → {row.target}
              </Label>
              <Label>{row.reason}</Label>
            </>
          ) : (
            <>
              <Label>{row.id}</Label>
              <Label>{row.suspended ? "Hesap kısıtlandı" : "Hesap açık"}</Label>
              <Label>{row.reason}</Label>
              <Button
                secondary
                title="Hesabı seç"
                onPress={() => setUid(row.id)}
              />
            </>
          )}
        </View>
      ))}
      {!!after && (
        <Button
          secondary
          title={loading ? "Yükleniyor…" : "Daha fazla kayıt"}
          disabled={loading}
          onPress={() => load(true)}
        />
      )}
      <Button secondary title="Listeyi yenile" onPress={() => load()} />
      {evidence && (
        <View style={styles.card}>
          <Label>Şikâyet kanıtı</Label>
          <Label>
            {evidence.report.snapshot?.text ||
              evidence.report.snapshot?.caption ||
              evidence.report.noteSnapshot?.text ||
              evidence.report.reason}
          </Label>
          {evidence.mediaItems.map((item) => (
            <ProtectedMedia
              key={item.id}
              item={item}
              style={{ width: "100%", height: 260, borderRadius: 12 }}
            />
          ))}
          <Label muted>Kanıta erişim süreli ve kayıt altındadır.</Label>
          <Button
            secondary
            title="Kanıtı kapat"
            onPress={() => setEvidence(null)}
          />
        </View>
      )}
      <View style={styles.card}>
        <Label>İçerik yönetimi</Label>
        <Field
          placeholder="Gönderi / hikâye kimliği"
          value={contentId}
          onChangeText={setContentId}
        />
        <View style={styles.row}>
          <Button
            secondary={contentKind !== "post"}
            title="Gönderi / Reels"
            onPress={() => setContentKind("post")}
          />
          <Button
            secondary={contentKind !== "story"}
            title="Hikâye"
            onPress={() => setContentKind("story")}
          />
        </View>
        <Button
          secondary
          title="İçeriği kaldır"
          disabled={!contentId.trim()}
          onPress={() =>
            prepare(
              "removeContent",
              { id: contentId, kind: contentKind },
              "Seçilen içeriği kalıcı kaldır",
            )
          }
        />
      </View>
      {senior && (
        <View style={styles.card}>
          <Label>Hesap yönetimi</Label>
          <Field
            placeholder="Firebase kullanıcı UID"
            value={uid}
            onChangeText={setUid}
          />
          <Button
            secondary
            title="Hesabı kısıtla"
            disabled={!uid}
            onPress={() =>
              prepare(
                "setUserStatus",
                { uid, suspended: true },
                "Hesabı kısıtla ve oturumlarını kapat",
              )
            }
          />
          <Button
            secondary
            title="Kısıtlamayı kaldır"
            disabled={!uid}
            onPress={() =>
              prepare(
                "setUserStatus",
                { uid, suspended: false },
                "Hesabı yeniden aç",
              )
            }
          />
          {role === "owner" && (
            <>
              <Label>Yönetici yetkileri · e-postası doğrulanmış hesaplar</Label>
              <View style={[styles.row, { flexWrap: "wrap" }]}>
                {[
                  ["member", "Üye"],
                  ["moderator", "Moderatör"],
                  ["admin", "Yönetici"],
                ].map(([value, label]) => (
                  <Button
                    key={value}
                    secondary={newRole !== value}
                    title={label!}
                    onPress={() => setNewRole(value!)}
                  />
                ))}
              </View>
              <Button
                title="Yetkiyi değiştir"
                disabled={!uid}
                onPress={() =>
                  prepare(
                    "setRole",
                    { uid, role: newRole },
                    "Kullanıcı yetkisini değiştir",
                  )
                }
              />
            </>
          )}
        </View>
      )}
      {senior && (
        <View style={styles.card}>
          <Label>Uygulama ayarları</Label>
          <Field
            placeholder="Duyuru metni"
            multiline
            value={announcement}
            onChangeText={setAnnouncement}
            maxLength={500}
          />
          <View style={styles.row}>
            <Label>Bakım modu</Label>
            <Switch value={maintenance} onValueChange={setMaintenance} />
          </View>
          <Field
            placeholder="Engellenecek kelimeler · her satıra bir kelime"
            multiline
            value={words}
            onChangeText={setWords}
          />
          <Button
            title="Ayarları kaydet"
            onPress={() =>
              setConfirmation({
                action: "saveConfig",
                input: {
                  announcement,
                  maintenance,
                  blockedWords: words
                    .split("\n")
                    .map((s) => s.trim())
                    .filter(Boolean),
                },
                label: "Uygulama ayarlarını güncelle",
              })
            }
          />
        </View>
      )}
      {confirmation && (
        <View style={styles.card}>
          <Label>{confirmation.label} işlemini onaylıyor musun?</Label>
          <Label>{reason}</Label>
          <Button
            title="Onayla ve uygula"
            onPress={async () => {
              await api(confirmation.action, confirmation.input);
              setConfirmation(null);
              setNotice("İşlem tamamlandı ve kayda alındı.");
              await load();
            }}
          />
          <Button
            secondary
            title="Vazgeç"
            onPress={() => setConfirmation(null)}
          />
        </View>
      )}
      {!!notice && <Label>{notice}</Label>}
    </Page>
  );
}
