import React, { useEffect, useRef, useState } from "react";
import { FlatList, Platform, Pressable, Text, View } from "react-native";
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
} from "../database/client";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useRows } from "../hooks/useRows";
import {
  api,
  type MediaItem,
  type MediaKind,
  newId,
  uploadMedia,
} from "../services/api";
import { selectMedia } from "../services/picker";
import { ProtectedMedia } from "../components/ProtectedMedia";
import {
  Button,
  Field,
  Label,
  Page,
  ReportForm,
  State,
  styles,
} from "../components/ui";
import type { Row } from "../types";

function VoiceRecorder({
  onReady,
  disabled,
}: {
  onReady: (uri: string) => void;
  disabled: boolean;
}) {
  const recorder = useAudioRecorder({
      ...RecordingPresets.HIGH_QUALITY,
      web: { mimeType: "audio/mp4", bitsPerSecond: 128000 },
    }),
    status = useAudioRecorderState(recorder, 250),
    [error, setError] = useState("");
  const stopping = useRef(false);
  async function stop() {
    if (stopping.current) return;
    stopping.current = true;
    try {
      await recorder.stop();
      await setAudioModeAsync({
        allowsRecording: false,
        playsInSilentMode: true,
      });
      if (recorder.uri) onReady(recorder.uri);
    } finally {
      stopping.current = false;
    }
  }
  useEffect(() => {
    if (status.isRecording && status.durationMillis >= 179000) {
      void stop().catch((e) => setError(e.message));
    }
  }, [status.durationMillis]);
  useEffect(
    () => () => {
      if (recorder.isRecording) {
        void recorder.stop().catch(() => {});
        void setAudioModeAsync({ allowsRecording: false }).catch(() => {});
      }
    },
    [recorder],
  );
  return (
    <View style={{ gap: 5 }}>
      <Button
        secondary
        disabled={disabled}
        title={status.isRecording
          ? `Kaydı bitir · ${Math.floor(status.durationMillis / 1000)} sn`
          : "Ses kaydet"}
        onPress={async () => {
          if (status.isRecording) {
            await stop();
            return;
          }
          if (
            Platform.OS === "web" &&
            (typeof MediaRecorder === "undefined" ||
              !MediaRecorder.isTypeSupported("audio/mp4"))
          ) {
            throw Error(
              "Bu tarayıcı AAC ses kaydını desteklemiyor. Sesli mesaj için Android/iOS uygulamasını kullan.",
            );
          }
          const permission = await requestRecordingPermissionsAsync();
          if (!permission.granted) {
            throw Error("Sesli mesaj için mikrofon izni gerekli.");
          }
          await setAudioModeAsync({
            allowsRecording: true,
            playsInSilentMode: true,
          });
          await recorder.prepareToRecordAsync();
          recorder.record();
        }}
      />
      {!!error && <Label>{error}</Label>}
    </View>
  );
}
export function Chats({ navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    chats = useRows(
      query(
        collection(db, "chats"),
        where("memberIds", "array-contains", me),
        orderBy("lastMessageAt", "desc"),
        limit(50),
      ),
    );
  return (
    <Page title="Mesajlar">
      <Button
        title="Yeni grup"
        onPress={() => navigation.navigate("NewGroup")}
      />
      <Label muted>
        Bir kişiye yazmak için profilindeki “Mesaj gönder” düğmesini kullan.
      </Label>
      <State {...chats} empty={!chats.rows.length} retry={chats.refresh} />
      {chats.rows.map((chat) => (
        <Pressable
          accessibilityRole="button"
          key={chat.id}
          style={styles.card}
          onPress={() =>
            navigation.navigate("Conversation", {
              id: chat.id,
              title: chat.title || "Sohbet",
            })}
        >
          <Text style={[styles.text, { fontWeight: "700" }]}>
            {chat.kind === "group" ? chat.title : "Birebir sohbet"}
          </Text>
          <Label>{chat.lastMessage || "Henüz mesaj yok"}</Label>
          <Label muted>{chat.memberIds.length} kişi</Label>
        </Pressable>
      ))}
    </Page>
  );
}
export function NewGroup({ navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    [search, setSearch] = useState(""),
    [title, setTitle] = useState(""),
    [rows, setRows] = useState<Row[]>([]),
    [selected, setSelected] = useState(new Map<string, string>()),
    [error, setError] = useState("");
  const request = useRef(newId());
  useEffect(() => {
    let alive = true;
    const timer = setTimeout(() => {
      api("searchUsers", { search })
        .then((r) => {
          if (alive) setRows(r.rows.filter((u: Row) => u.id !== me));
        })
        .catch((e) => {
          if (alive) setError(e.message);
        });
    }, 350);
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [search, me]);
  return (
    <Page title="Yeni grup">
      <Field
        placeholder="Grup adı"
        value={title}
        onChangeText={setTitle}
        maxLength={60}
      />
      <Field
        placeholder="Kullanıcı adı ara"
        value={search}
        onChangeText={setSearch}
      />
      <Label>{selected.size + 1}/20 kişi</Label>
      {[...selected].map(([uid, name]) => (
        <Button
          key={uid}
          secondary
          title={`✓ @${name} · kaldır`}
          onPress={() =>
            setSelected((old) => {
              const next = new Map(old);
              next.delete(uid);
              return next;
            })}
        />
      ))}
      {rows
        .filter((u) => !selected.has(u.id))
        .map((u) => (
          <Button
            key={u.id}
            secondary
            title={`@${u.username} · ekle`}
            disabled={selected.size >= 19}
            onPress={() =>
              setSelected((old) => new Map(old).set(u.id, u.username))}
          />
        ))}
      {!!error && <Label>{error}</Label>}
      <Button
        title="Grubu oluştur"
        disabled={!title.trim() || !selected.size}
        onPress={async () => {
          const group = await api("createChat", {
            requestId: request.current,
            group: true,
            title,
            members: [...selected.keys()],
          });
          navigation.replace("Conversation", { id: group.id, title });
        }}
      />
      <Label muted>
        Katılımcıların mesaj izinleri ve karşılıklı engelleri korunur.
      </Label>
    </Page>
  );
}
export function Conversation({ route, navigation }: any) {
  const chatId = route.params.id,
    me = useSession((s) => s.profile)!.uid,
    [chat, setChat] = useState<Row | null>(null),
    [chatError, setChatError] = useState("");
  const messages = useRows(
    query(
      collection(db, "chats", chatId, "messages"),
      orderBy("createdAt", "desc"),
      limit(100),
    ),
  );
  const [text, setText] = useState(""),
    [reply, setReply] = useState<Row | null>(null),
    [editing, setEditing] = useState<Row | null>(null),
    [selected, setSelected] = useState<Row | null>(null),
    [confirmDelete, setConfirmDelete] = useState(false),
    [attachment, setAttachment] = useState<
      {
        uri: string;
        kind: MediaKind;
        id?: string;
      } | null
    >(null),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState(""),
    [reporting, setReporting] = useState(false),
    [leave, setLeave] = useState(false),
    [title, setTitle] = useState("");
  const request = useRef(newId()),
    uploaded = useRef<MediaItem | null>(null),
    seenPending = useRef(new Set<string>());
  useEffect(
    () =>
      onSnapshot(
        doc(db, "chats", chatId),
        (snapshot) => {
          setChat(
            snapshot.exists() ? { id: snapshot.id, ...snapshot.data() } : null,
          );
          setTitle(snapshot.data()?.title || "");
        },
        (e) => setChatError(e.message),
      ),
    [chatId],
  );
  useEffect(() => {
    const ids = messages.rows
      .filter((r) => !r.seenBy?.includes(me) && !seenPending.current.has(r.id))
      .map((r) => r.id);
    if (!ids.length) return;
    ids.forEach((key) => seenPending.current.add(key));
    api("markSeen", { chatId, ids }).catch((e) => {
      ids.forEach((key) => seenPending.current.delete(key));
      setNotice(e.message);
    });
  }, [messages.rows, chatId, me]);
  function addAttachment(uri: string, kind: MediaKind) {
    setAttachment({ uri, kind });
    uploaded.current = null;
    request.current = newId();
  }
  async function send() {
    setBusy(true);
    setNotice("");
    try {
      if (editing) await api("editMessage", { chatId, id: editing.id, text });
      else {
        if (attachment && !uploaded.current) {
          uploaded.current = await uploadMedia(
            attachment.uri,
            attachment.kind,
            "message",
          );
        }
        await api("sendMessage", {
          chatId,
          requestId: request.current,
          text,
          mediaIds: uploaded.current ? [uploaded.current.id] : [],
          ...(reply ? { replyTo: reply.id } : {}),
        });
      }
      setText("");
      setAttachment(null);
      setReply(null);
      setEditing(null);
      uploaded.current = null;
      request.current = newId();
    } finally {
      setBusy(false);
    }
  }
  return (
    <Page scroll={false} title={chat?.title || route.params.title || "Sohbet"}>
      <View style={{ paddingHorizontal: 16, gap: 8 }}>
        {!!chatError && <Label>{chatError}</Label>}
        {chat?.kind === "group" && (
          <>
            <Label muted>{chat.memberIds.length} katılımcı</Label>
            {chat.ownerUid === me && (
              <>
                <Field
                  placeholder="Grup adı"
                  value={title}
                  onChangeText={setTitle}
                />
                <Button
                  secondary
                  title="Grup adını kaydet"
                  onPress={() => api("updateGroup", { chatId, title })}
                />
              </>
            )}
            <Button
              secondary
              title="Gruptan ayrıl"
              onPress={() =>
                setLeave(true)}
            />
            {leave && (
              <>
                <Label>Gruptan ayrılmak istiyor musun?</Label>
                <Button
                  title="Evet, ayrıl"
                  onPress={async () => {
                    await api("leaveGroup", { chatId });
                    navigation.goBack();
                  }}
                />
                <Button
                  secondary
                  title="Vazgeç"
                  onPress={() => setLeave(false)}
                />
              </>
            )}
          </>
        )}
        <Button
          secondary
          title="Şikâyet et"
          onPress={() =>
            setReporting(!reporting)}
        />
        {reporting && (
          <ReportForm
            onSubmit={async (reason) => {
              await api("reportChat", {
                chatId,
                reason,
                messageId: selected?.id,
              });
              setReporting(false);
              setNotice("Şikâyetin alındı.");
            }}
            onCancel={() => setReporting(false)}
          />
        )}
      </View>
      <FlatList
        inverted
        data={messages.rows}
        keyExtractor={(r) => r.id}
        keyboardShouldPersistTaps="handled"
        ListEmptyComponent={
          <State {...messages} empty retry={messages.refresh} />
        }
        renderItem={({ item }) => (
          <Pressable
            onLongPress={() => {
              setSelected(item);
              setConfirmDelete(false);
            }}
            onPress={() => {
              setSelected(selected?.id === item.id ? null : item);
              setConfirmDelete(false);
            }}
            style={[
              styles.card,
              {
                marginHorizontal: 16,
                marginVertical: 5,
                maxWidth: "90%",
                alignSelf: item.senderUid === me ? "flex-end" : "flex-start",
                backgroundColor: item.senderUid === me ? "#493328" : "#1b1d20",
              },
            ]}
            accessibilityRole="button"
            accessibilityLabel="Mesaj seçenekleri"
          >
            <Text style={{ color: "#ffb58e", fontSize: 12 }}>
              {item.senderUid === me ? "Sen" : item.senderUid.slice(0, 8)}
            </Text>
            {item.replyTo && <Label muted>↩ Bir mesaja yanıt</Label>}
            {!!item.text && <Label>{item.text}</Label>}
            {item.mediaItems?.map((m: MediaItem) => (
              <ProtectedMedia
                key={m.id}
                item={m}
                style={{
                  width: 240,
                  height: m.kind === "audio" ? 70 : 240,
                  borderRadius: 12,
                }}
              />
            ))}
            <Label muted>
              {item.editedAt ? "Düzenlendi · " : ""}
              {item.senderUid === me &&
                (item.seenBy?.length > 1 ? "Görüldü" : "Gönderildi")}
            </Label>
            {Object.keys(item.reactions || {}).length > 0 && (
              <Label>{Object.values(item.reactions).join(" ")}</Label>
            )}
            {selected?.id === item.id && (
              <View style={{ gap: 8 }}>
                <View style={[styles.row, { flexWrap: "wrap" }]}>
                  {["❤️", "😂", "😮", "😢", "👍", "🔥"].map((emoji) => (
                    <Button
                      key={emoji}
                      secondary
                      title={emoji}
                      onPress={() =>
                        api("reactMessage", {
                          chatId,
                          id: item.id,
                          reaction: item.reactions?.[me] === emoji ? "" : emoji,
                        })}
                    />
                  ))}
                </View>
                <Button
                  secondary
                  title="Yanıtla"
                  onPress={() => {
                    setReply(item);
                    setSelected(null);
                    setEditing(null);
                  }}
                />
                {item.senderUid === me && (
                  <>
                    <Button
                      secondary
                      title="Düzenle"
                      onPress={() => {
                        setEditing(item);
                        setText(item.text);
                        setSelected(null);
                      }}
                    />
                    <Button
                      secondary
                      title="Sil"
                      onPress={() => setConfirmDelete(true)}
                    />
                    {confirmDelete && (
                      <>
                        <Label>Mesajı herkes için silmek istiyor musun?</Label>
                        <Button
                          title="Evet, sil"
                          onPress={async () => {
                            await api("deleteMessage", { chatId, id: item.id });
                            setSelected(null);
                            setConfirmDelete(false);
                          }}
                        />
                        <Button
                          secondary
                          title="Vazgeç"
                          onPress={() => setConfirmDelete(false)}
                        />
                      </>
                    )}
                  </>
                )}
              </View>
            )}
          </Pressable>
        )}
      />
      <View style={{ padding: 14, gap: 8 }}>
        {!!notice && <Label>{notice}</Label>}
        {(reply || editing) && (
          <Button
            secondary
            title={`${
              editing ? "Mesajı düzenliyorsun" : "Bir mesaja yanıtlıyorsun"
            } · vazgeç`}
            disabled={busy}
            onPress={() => {
              setReply(null);
              setEditing(null);
              setText("");
            }}
          />
        )}
        {attachment && (
          <>
            <Label>
              {attachment.kind === "audio"
                ? "Sesli mesaj hazır"
                : "Medya eklendi"}
            </Label>
            <Button
              secondary
              title="Eki kaldır"
              disabled={busy}
              onPress={() => {
                setAttachment(null);
                uploaded.current = null;
              }}
            />
          </>
        )}
        <Field
          placeholder="Mesaj yaz…"
          maxLength={2000}
          value={text}
          onChangeText={setText}
          editable={!busy}
        />
        {!editing && (
          <View style={[styles.row, { flexWrap: "wrap" }]}>
            <Button
              secondary
              title="Fotoğraf / video"
              disabled={busy}
              onPress={async () => {
                const asset = (await selectMedia())[0];
                if (asset) {
                  addAttachment(
                    asset.uri,
                    asset.type === "video" ? "video" : "image",
                  );
                }
              }}
            />
            <VoiceRecorder
              disabled={busy}
              onReady={(uri) => addAttachment(uri, "audio")}
            />
          </View>
        )}
        <Button
          title={editing ? "Düzenlemeyi kaydet" : "Gönder"}
          disabled={busy || (!text.trim() && !attachment)}
          onPress={send}
        />
      </View>
    </Page>
  );
}
