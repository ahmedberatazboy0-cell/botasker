import React, { useCallback, useEffect, useState } from "react";
import {
  ScrollView,
  View,
  Pressable,
  Text,
  useWindowDimensions,
} from "react-native";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import { api } from "../services/api";
import { ProtectedMedia } from "../components/ProtectedMedia";
import {
  Page,
  Button,
  Field,
  Label,
  State,
  ReportForm,
  styles,
} from "../components/ui";
import { useApiList } from "../hooks/useApiList";
import { useSession } from "../store/session";
import type { Row } from "../types";
export function StoriesRail({ navigation }: any) {
  const [rows, setRows] = useState<Row[]>([]),
    [after, setAfter] = useState<string | null>(null),
    [error, setError] = useState("");
  const load = useCallback(
    async (more = false) => {
      try {
        const result = await api("storyFeed", more ? { after } : {});
        setRows((old) => (more ? [...old, ...result.rows] : result.rows));
        setAfter(result.after);
        setError("");
      } catch (e) {
        setError((e as Error).message);
      }
    },
    [after],
  );
  useFocusEffect(
    useCallback(() => {
      void load(false);
    }, []),
  );
  return (
    <View style={{ gap: 8, paddingBottom: 10 }}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ gap: 14, paddingHorizontal: 18 }}
      >
        <Pressable
          onPress={() =>
            navigation.navigate("StoryComposer", { kind: "story" })
          }
          style={{ alignItems: "center", gap: 5 }}
          accessibilityRole="button"
          accessibilityLabel="Hikâye ekle"
        >
          <View
            style={{
              width: 64,
              height: 64,
              borderRadius: 32,
              borderWidth: 2,
              borderColor: "#ff925c",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 30 }}>+</Text>
          </View>
          <Label>Hikâyen</Label>
        </Pressable>
        {rows.map((row) => (
          <Pressable
            key={row.id}
            onPress={() =>
              navigation.navigate("StoryViewer", { uid: row.uid, id: row.id })
            }
            style={{ alignItems: "center", gap: 5 }}
            accessibilityRole="button"
            accessibilityLabel={`@${row.username} hikâyesi`}
          >
            <View
              style={{
                width: 64,
                height: 64,
                borderRadius: 32,
                borderWidth: 2,
                borderColor: "#ff925c",
                padding: 3,
              }}
            >
              {row.mediaItems?.[0]?.kind === "image" ? (
                <ProtectedMedia
                  item={row.mediaItems[0]}
                  style={{ width: 54, height: 54, borderRadius: 27 }}
                />
              ) : (
                <View
                  style={{
                    flex: 1,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ color: "#fff", fontSize: 25 }}>▷</Text>
                </View>
              )}
            </View>
            <Label>@{row.username}</Label>
          </Pressable>
        ))}
        {!!after && (
          <Button
            secondary
            title="Daha fazla kişi"
            onPress={() => load(true)}
          />
        )}
      </ScrollView>
      {!!error && (
        <Button
          secondary
          title="Hikâyeleri yeniden yükle"
          onPress={() => load(false)}
        />
      )}
    </View>
  );
}
export function StoryViewer({ route, navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    data = useApiList("listContent", {
      kind: "story",
      uid: route.params.uid,
      ...(route.params.highlighted ? { highlighted: true } : {}),
      ...(route.params.archived ? { archived: true } : {}),
    });
  const [index, setIndex] = useState(0),
    [report, setReport] = useState(false),
    [title, setTitle] = useState("Öne çıkanlar"),
    [viewers, setViewers] = useState<Row[] | null>(null),
    [viewAfter, setViewAfter] = useState<string | null>(null),
    [notice, setNotice] = useState(""),
    [confirmDelete, setConfirmDelete] = useState(false);
  const focused = useIsFocused(),
    height = Math.max(280, useWindowDimensions().height - 340),
    row = data.rows[index];
  useEffect(() => {
    if (!row) return;
    setViewers(null);
    setNotice("");
    setConfirmDelete(false);
    if (!route.params.highlighted && !route.params.archived)
      api("storyView", { id: row.id }).catch((e) => setNotice(e.message));
  }, [row?.id]);
  useEffect(() => {
    if (
      !row ||
      !focused ||
      row.mediaItems?.[0]?.kind !== "image" ||
      report ||
      viewers
    )
      return;
    const timer = setTimeout(() => {
      if (index + 1 < data.rows.length) setIndex(index + 1);
      else if (data.hasMore) void data.loadMore();
    }, 8000);
    return () => clearTimeout(timer);
  }, [row?.id, index, focused, report, viewers, data.rows.length]);
  async function loadViewers(more = false) {
    const r = await api("storyViewers", {
      id: row!.id,
      ...(more ? { after: viewAfter } : {}),
    });
    setViewers((old) => (more ? [...(old || []), ...r.rows] : r.rows));
    setViewAfter(r.after);
  }
  return (
    <Page title={row ? `@${row.username}` : "Hikâyeler"}>
      <State {...data} empty={!row} retry={data.refresh} />
      {row && (
        <>
          <View style={styles.row}>
            {data.rows.map((r, i) => (
              <View
                key={r.id}
                style={{
                  height: 3,
                  flex: 1,
                  backgroundColor: i === index ? "#ff925c" : "#555",
                }}
              />
            ))}
          </View>
          {row.mediaItems?.[0] && (
            <ProtectedMedia
              item={row.mediaItems[0]}
              active={focused && !report && !viewers}
              loop={false}
              onEnd={() => {
                if (index + 1 < data.rows.length) setIndex((i) => i + 1);
                else if (data.hasMore) void data.loadMore();
              }}
              style={{ width: "100%", height, borderRadius: 12 }}
            />
          )}
          <Label>{row.caption}</Label>
          <View style={styles.row}>
            <Button
              secondary
              title="Önceki"
              disabled={index === 0}
              onPress={() => setIndex((i) => i - 1)}
            />
            <Button
              secondary
              title="Sonraki"
              disabled={index === data.rows.length - 1 && !data.hasMore}
              onPress={async () => {
                if (index + 1 < data.rows.length) setIndex((i) => i + 1);
                else await data.loadMore();
              }}
            />
          </View>
          {row.uid === me ? (
            <>
              <Field
                placeholder="Öne çıkan başlığı"
                value={title}
                onChangeText={setTitle}
                maxLength={30}
              />
              <Button
                secondary
                title={
                  row.highlighted
                    ? "Öne çıkanlardan kaldır"
                    : "Öne çıkanlara ekle"
                }
                onPress={async () => {
                  await api("highlightStory", {
                    id: row.id,
                    enabled: !row.highlighted,
                    title,
                  });
                  data.refresh();
                }}
              />
              <Button
                secondary
                title="Görüntüleyenler"
                onPress={() => loadViewers()}
              />
              {viewers?.map((v) => (
                <Label key={v.id}>@{v.username}</Label>
              ))}
              {!!viewAfter && (
                <Button
                  secondary
                  title="Diğer izleyenler"
                  onPress={() => loadViewers(true)}
                />
              )}
              <Button
                secondary
                title="Hikâyeyi sil"
                onPress={() => setConfirmDelete(true)}
              />
              {confirmDelete && (
                <>
                  <Label>Hikâyeyi kalıcı olarak silmek istiyor musun?</Label>
                  <Button
                    title="Evet, sil"
                    onPress={async () => {
                      await api("deleteContent", { kind: "story", id: row.id });
                      navigation.goBack();
                    }}
                  />
                  <Button
                    secondary
                    title="Vazgeç"
                    onPress={() => setConfirmDelete(false)}
                  />
                </>
              )}
            </>
          ) : (
            <>
              <Button
                secondary
                title="Yanıtla"
                onPress={async () => {
                  const c = await api("createChat", { members: [row.uid] });
                  navigation.navigate("Conversation", {
                    id: c.id,
                    title: `@${row.username}`,
                  });
                }}
              />
              <Button
                secondary
                title="Şikâyet et"
                onPress={() => setReport(!report)}
              />
              {report && (
                <ReportForm
                  onSubmit={async (reason) => {
                    await api("reportContent", {
                      kind: "story",
                      id: row.id,
                      reason,
                    });
                    setReport(false);
                    setNotice("Şikâyetin alındı.");
                  }}
                  onCancel={() => setReport(false)}
                />
              )}
            </>
          )}
        </>
      )}
      {!!notice && <Label>{notice}</Label>}
    </Page>
  );
}
