import React, { useEffect, useState } from "react";
import { FlatList, Pressable, View, useWindowDimensions } from "react-native";
import { useApiList } from "../hooks/useApiList";
import { api } from "../services/api";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { Page, Button, Field, Label, State, styles } from "../components/ui";
import { PostCard } from "../components/PostCard";
import type { Row, Post } from "../types";
export function PostGrid({
  rows,
  open,
}: {
  rows: Row[];
  open: (row: Row) => void;
}) {
  const width = Math.floor((useWindowDimensions().width - 48) / 3);
  return (
    <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 3 }}>
      {rows.map((row) => (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`@${row.username}: ${row.caption}`}
          key={row.id}
          onPress={() => open(row)}
          style={{
            width,
            height: width,
            backgroundColor: "#23262c",
            borderRadius: 3,
            overflow: "hidden",
          }}
        >
          {row.mediaItems?.[0]?.kind === "image" ? (
            <ProtectedMedia
              item={row.mediaItems[0]}
              style={{ width, height: width }}
            />
          ) : (
            <View style={{ padding: 8, justifyContent: "center", flex: 1 }}>
              <Label>
                {row.kind === "reel"
                  ? "▷ Reels"
                  : row.mediaItems?.length
                    ? "▷ Video"
                    : row.caption}
              </Label>
            </View>
          )}
          {row.mediaItems?.length > 1 && (
            <View style={{ position: "absolute", right: 5, top: 5 }}>
              <Label>▣</Label>
            </View>
          )}
        </Pressable>
      ))}
    </View>
  );
}
export function Explore({ navigation }: any) {
  const [search, setSearch] = useState(""),
    [term, setTerm] = useState(""),
    [mode, setMode] = useState("posts"),
    [users, setUsers] = useState<Row[]>([]),
    [userError, setUserError] = useState(""),
    [after, setAfter] = useState<string | null>(null),
    [userLoading, setUserLoading] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setTerm(search), 350);
    return () => clearTimeout(timer);
  }, [search]);
  const content = useApiList("listContent", {
    kind: mode === "reels" ? "reel" : "post",
    search: term.replace(/^#/, ""),
  });
  async function loadUsers(more = false) {
    setUserLoading(true);
    try {
      const r = await api("searchUsers", {
        search: term.replace(/^@/, ""),
        ...(more ? { after } : {}),
      });
      setUsers((old) => (more ? [...old, ...r.rows] : r.rows));
      setAfter(r.after);
      setUserError("");
    } catch (e) {
      setUserError((e as Error).message);
    } finally {
      setUserLoading(false);
    }
  }
  useEffect(() => {
    if (mode === "users") void loadUsers();
  }, [term, mode]);
  return (
    <Page title="Keşfet">
      <Field
        placeholder="Kullanıcı, kelime veya #etiket ara"
        value={search}
        onChangeText={setSearch}
        maxLength={100}
      />
      <View style={styles.row}>
        {[
          ["posts", "Gönderiler"],
          ["users", "Hesaplar"],
          ["reels", "Reels"],
        ].map(([value, label]) => (
          <Button
            key={value}
            title={label!}
            secondary={mode !== value}
            onPress={() => setMode(value!)}
          />
        ))}
      </View>
      {mode === "users" ? (
        <>
          <State
            loading={userLoading}
            error={userError}
            empty={!users.length}
            retry={() => loadUsers()}
          />
          {users.map((user) => (
            <Pressable
              key={user.id}
              style={styles.card}
              onPress={() => navigation.navigate("User", { uid: user.id })}
            >
              <Label>
                @{user.username} {user.official ? "✓" : ""}
              </Label>
              <Label>{user.displayName}</Label>
            </Pressable>
          ))}
          {!!after && (
            <Button
              secondary
              title="Daha fazla hesap"
              onPress={() => loadUsers(true)}
            />
          )}
        </>
      ) : (
        <>
          <State
            {...content}
            empty={!content.rows.length}
            retry={content.refresh}
          />
          <PostGrid
            rows={content.rows}
            open={(row) => navigation.navigate("PostDetails", { id: row.id })}
          />
          {content.hasMore && (
            <Button
              secondary
              title="Daha fazla paylaşım"
              onPress={content.loadMore}
            />
          )}
        </>
      )}
    </Page>
  );
}
export function PostDetails({ route, navigation }: any) {
  const [post, setPost] = useState<Post | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [version, setVersion] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    api<Post>("getContent", { id: route.params.id })
      .then((row) => {
        if (alive) setPost(row);
      })
      .catch((e) => {
        if (alive) setError(e.message);
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [route.params.id, version]);
  return (
    <Page title="Paylaşım">
      <State
        loading={loading}
        error={error}
        empty={!post && !loading}
        retry={() => setVersion((v) => v + 1)}
      />
      {post && (
        <PostCard
          post={post}
          openProfile={(uid) => navigation.push("User", { uid })}
        />
      )}
    </Page>
  );
}
