import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Switch,
  ScrollView,
} from "react-native";
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  doc,
  onSnapshot,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from "../database/client";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useFeed } from "../hooks/useFeed";
import { useRows } from "../hooks/useRows";
import {
  Page,
  Label,
  Button,
  Field,
  State,
  LegalLinks,
  ReportForm,
  DeleteAccountForm,
  styles,
} from "../components/ui";
import { PostCard } from "../components/PostCard";
import {
  feedQuery,
  ownPostsQuery,
  editProfile,
  follow,
  chatWith,
  report,
  block,
  acceptFollow,
  logout,
  sendMessage,
  deleteOwnAccount,
} from "../services/social";
import { friendly } from "../utils/errors";
import type { Profile, Post } from "../types";
import { FollowedNote } from "./Notes";
import { useFocusEffect } from "@react-navigation/native";
import { useApiList } from "../hooks/useApiList";
import { api, uploadMedia } from "../services/api";
import { selectMedia } from "../services/picker";
import { StoriesRail } from "./Stories";
import { PostGrid } from "./Discovery";
import { ProtectedImage } from "../components/ProtectedMedia";
import { ServerBanner } from "../components/ServerBanner";
import { useRole } from "../hooks/useRole";
import { enablePush, disablePush } from "../services/push";
import { auth } from "../firebase/client";
import { sendEmailVerification } from "firebase/auth";
export function Feed({ navigation }: any) {
  const [mode, setMode] = useState("public");
  const data = useApiList(
      mode === "following" ? "followingFeed" : "listContent",
      { kind: "post" },
    ),
    me = useSession((s) => s.profile)!.uid,
    blocks = useRows(query(collection(db, "users", me, "blocks"), limit(200))),
    hidden = new Set(blocks.rows.map((r) => r.id));
  useFocusEffect(
    React.useCallback(() => {
      data.refresh();
    }, [data.refresh]),
  );
  return (
    <Page scroll={false}>
      <View
        style={[styles.row, { padding: 20, justifyContent: "space-between" }]}
      >
        <Text style={[styles.title, { fontSize: 27, color: "#ff925c" }]}>
          birarada
        </Text>
        <View style={styles.row}>
          <Button
            secondary
            title="Bildirimler"
            onPress={() => navigation.navigate("Notifications")}
          />
          <Button
            secondary
            title="Mesajlar"
            onPress={() => navigation.navigate("Chats")}
          />
        </View>
      </View>
      <FlatList
        data={
          blocks.loading || blocks.error
            ? []
            : data.rows.filter((p) => !hidden.has(p.uid))
        }
        onEndReached={() => {
          void data.loadMore();
        }}
        onEndReachedThreshold={0.4}
        ListFooterComponent={
          data.paging ? (
            <Label muted>Yeni paylaşımlar geliyor…</Label>
          ) : data.error && data.rows.length ? (
            <Button secondary title="Tekrar dene" onPress={data.loadMore} />
          ) : null
        }
        keyExtractor={(r) => r.id}
        refreshing={data.loading}
        onRefresh={data.refresh}
        ListHeaderComponent={
          <View style={styles.pad}>
            <StoriesRail navigation={navigation} />
            <ServerBanner />
            <View style={styles.row}>
              <Button
                secondary={mode !== "public"}
                title="Keşfet akışı"
                onPress={() => setMode("public")}
              />
              <Button
                secondary={mode !== "following"}
                title="Takip ettiklerin"
                onPress={() => setMode("following")}
              />
            </View>
            <Button
              secondary
              title="Notlar · Şarkını paylaş"
              onPress={() => navigation.navigate("Notes")}
            />
            <Label muted>MEYDAN · HERKESE AÇIK PAYLAŞIMLAR</Label>
          </View>
        }
        ListEmptyComponent={
          blocks.loading || blocks.error ? (
            <State {...blocks} retry={blocks.refresh} />
          ) : (
            <State {...data} empty retry={data.refresh} />
          )
        }
        renderItem={({ item }) => (
          <PostCard
            post={item as Post}
            blockedUids={hidden}
            openProfile={(id) => navigation.navigate("User", { uid: id })}
          />
        )}
      />
    </Page>
  );
}
export function Explore({ navigation }: any) {
  const [search, setSearch] = useState("");
  const me = useSession((s) => s.profile)!.uid;
  const blocks = useRows(
    query(collection(db, "users", me, "blocks"), limit(200)),
  );
  const hidden = new Set(blocks.rows.map((r) => r.id));
  const users = useRows(
    query(
      collection(db, "users"),
      orderBy("username"),
      where("username", ">=", search.toLowerCase()),
      where("username", "<=", search.toLowerCase() + "\uf8ff"),
      limit(30),
    ),
  );
  return (
    <Page title="Çevrene bak.">
      <Label muted>Yeni bir sohbet, tanıdık bir yüz.</Label>
      <Field
        placeholder="Kullanıcı adı ara"
        value={search}
        onChangeText={setSearch}
      />
      <State
        loading={users.loading || blocks.loading}
        error={users.error || blocks.error}
        empty={!users.rows.some((r) => !hidden.has(r.id))}
        retry={() => {
          users.refresh();
          blocks.refresh();
        }}
      />
      {!blocks.loading &&
        !blocks.error &&
        users.rows
          .filter((r) => !hidden.has(r.id))
          .map((r) => (
            <Pressable
              key={r.id}
              onPress={() => navigation.navigate("User", { uid: r.id })}
              style={styles.card}
            >
              <Text style={styles.text}>{r.displayName}</Text>
              <Label muted>@{r.username}</Label>
            </Pressable>
          ))}
    </Page>
  );
}
export function ProfileScreen({ route, navigation }: any) {
  const current = useSession((s) => s.profile)!,
    id = route?.params?.uid || current.uid,
    [profile, setProfile] = useState<Profile | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [reporting, setReporting] = useState(false),
    [confirmBlock, setConfirmBlock] = useState(false);
  React.useEffect(() => {
    setLoading(true);
    setProfile(null);
    setError("");
    return onSnapshot(
      doc(db, "users", id),
      (s) => {
        setProfile(s.exists() ? (s.data() as Profile) : null);
        setLoading(false);
      },
      (e) => {
        setError(friendly(e));
        setLoading(false);
      },
    );
  }, [id]);
  const blocks = useRows(
    query(collection(db, "users", current.uid, "blocks"), limit(200)),
  );
  const isBlocked = blocks.rows.some((row) => row.id === id);
  const blockedUids = new Set(blocks.rows.map((row) => row.id));
  const relation = useRows(
    query(
      collection(db, "follows"),
      where("followerUid", "==", current.uid),
      where("followingUid", "==", id),
      limit(1),
    ),
  );
  const mine = id === current.uid,
    posts = useApiList("listContent", {
      kind: "post",
      uid: id,
      relation: relation.rows[0]?.status || "none",
    });
  const [grid, setGrid] = useState(true),
    [stats, setStats] = useState<{
      posts: number;
      followers: number;
      following: number;
    } | null>(null);
  useFocusEffect(
    React.useCallback(() => {
      let alive = true;
      api("profileStats", { uid: id })
        .then((value) => {
          if (alive) setStats(value);
        })
        .catch(() => {
          if (alive) setStats(null);
        });
      return () => {
        alive = false;
      };
    }, [id, relation.rows[0]?.status]),
  );
  return (
    <Page title={profile?.displayName || "Profil"}>
      <State
        loading={loading || blocks.loading}
        error={error || blocks.error}
        empty={!profile}
        retry={() => {
          blocks.refresh();
          navigation.replace("User", { uid: id });
        }}
      />
      {isBlocked && (
        <View style={styles.card}>
          <Label>Bu hesabı engelledin.</Label>
          <Label muted>
            Gönderileri gizlenir ve karşılıklı mesajlaşma engellenir.
          </Label>
          <Button
            secondary
            title="Engeli kaldır"
            onPress={() =>
              deleteDoc(doc(db, "users", current.uid, "blocks", id))
            }
          />
        </View>
      )}
      {profile &&
        !loading &&
        !blocks.loading &&
        !blocks.error &&
        !isBlocked && (
          <>
            {!!profile.avatarMediaId && (
              <ProtectedImage
                id={profile.avatarMediaId}
                style={{ width: 90, height: 90, borderRadius: 45 }}
              />
            )}
            {profile.official && <Label>✓ Birarada resmî hesabı</Label>}
            <Label muted>
              @{profile.username} ·{" "}
              {profile.isPrivate ? "Gizli hesap" : "Herkese açık"}
            </Label>
            {stats && (
              <Label>
                {stats.posts} paylaşım · {stats.followers} takipçi ·{" "}
                {stats.following} takip
              </Label>
            )}
            <Label>{profile.bio || "Henüz bir bio eklenmedi."}</Label>
            {mine ? (
              <Button
                secondary
                title="Notum ve şarkım"
                onPress={() => navigation.navigate("Notes")}
              />
            ) : (
              !relation.loading &&
              !relation.error &&
              relation.rows[0]?.status === "accepted" && (
                <FollowedNote user={id} />
              )
            )}
            {!!profile.website && <Label muted>{profile.website}</Label>}
            {mine ? (
              <View style={styles.row}>
                <Button
                  title="Profili düzenle"
                  onPress={() => navigation.navigate("EditProfile")}
                />
                <Button
                  secondary
                  title="Ayarlar"
                  onPress={() => navigation.navigate("Settings")}
                />
              </View>
            ) : (
              <>
                <Button
                  title={
                    relation.rows.length
                      ? relation.rows[0]?.status === "pending"
                        ? "İsteği geri çek"
                        : "Takipten çık"
                      : profile.isPrivate
                        ? "Takip isteği gönder"
                        : "Takip et"
                  }
                  onPress={() => follow(profile)}
                />
                <Button
                  secondary
                  title="Mesaj gönder"
                  onPress={async () =>
                    navigation.navigate("Conversation", {
                      id: await chatWith(profile),
                      title: profile.displayName,
                      otherUid: profile.uid,
                    })
                  }
                />
                <Button
                  secondary
                  title="Hesabı şikâyet et"
                  onPress={() => setReporting(!reporting)}
                />
                {reporting && (
                  <ReportForm
                    onSubmit={(reason) => report(id, reason)}
                    onCancel={() => setReporting(false)}
                  />
                )}
                <Button
                  secondary
                  title="Engelle"
                  onPress={() => setConfirmBlock(true)}
                />
                {confirmBlock && (
                  <View style={styles.card}>
                    <Label>Bu hesabı engellemek istiyor musun?</Label>
                    <Label muted>
                      Gönderileri gizlenir ve karşılıklı mesajlaşma engellenir.
                      Engeli Ayarlar’dan kaldırabilirsin.
                    </Label>
                    <Button
                      title="Evet, engelle"
                      onPress={async () => {
                        await block(id);
                        setConfirmBlock(false);
                      }}
                    />
                    <Button
                      secondary
                      title="Vazgeç"
                      onPress={() => setConfirmBlock(false)}
                    />
                  </View>
                )}
              </>
            )}
            <>
              {mine && (
                <View style={{ gap: 12 }}>
                  <Button
                    secondary
                    title="Kaydedilenler"
                    onPress={() => navigation.navigate("Saved")}
                  />
                  <Button
                    secondary
                    title="Takipçilerim"
                    onPress={() =>
                      navigation.navigate("Connections", { kind: "followers" })
                    }
                  />
                  <Button
                    secondary
                    title="Takip ettiklerim"
                    onPress={() =>
                      navigation.navigate("Connections", { kind: "following" })
                    }
                  />
                </View>
              )}
            </>
            <Button
              secondary
              title="Öne çıkan hikâyeler"
              onPress={() =>
                navigation.navigate("StoryViewer", {
                  uid: id,
                  highlighted: true,
                })
              }
            />
            {mine && (
              <Button
                secondary
                title="Hikâye arşivim · son 30 gün"
                onPress={() =>
                  navigation.navigate("StoryViewer", {
                    uid: id,
                    archived: true,
                  })
                }
              />
            )}
            <View style={styles.row}>
              <Button
                secondary={!grid}
                title="▦ Izgara"
                onPress={() => setGrid(true)}
              />
              <Button
                secondary={grid}
                title="☰ Liste"
                onPress={() => setGrid(false)}
              />
            </View>
            <Label muted>PAYLAŞIMLAR</Label>
            <State
              {...posts}
              empty={!posts.rows.length}
              retry={posts.refresh}
            />
            {grid ? (
              <PostGrid
                rows={posts.rows}
                open={(p) => navigation.navigate("PostDetails", { id: p.id })}
              />
            ) : (
              posts.rows.map((p) => (
                <PostCard
                  key={p.id}
                  post={p as Post}
                  blockedUids={blockedUids}
                  openProfile={(uid) => navigation.push("User", { uid })}
                />
              ))
            )}
            {posts.hasMore && (
              <Button
                secondary
                title="Daha fazla paylaşım"
                onPress={posts.loadMore}
              />
            )}
          </>
        )}
    </Page>
  );
}
export function EditProfile({ navigation }: any) {
  const p = useSession((s) => s.profile)!,
    [name, setName] = useState(p.displayName),
    [bio, setBio] = useState(p.bio),
    [website, setWebsite] = useState(p.website),
    [privacy, setPrivacy] = useState(p.isPrivate),
    [dm, setDm] = useState(p.allowStrangerDM);
  return (
    <Page title="Kendin gibi.">
      {!!p.avatarMediaId && (
        <ProtectedImage
          id={p.avatarMediaId}
          style={{ width: 100, height: 100, borderRadius: 50 }}
        />
      )}
      <Button
        secondary
        title="Profil fotoğrafını değiştir"
        onPress={async () => {
          const asset = (await selectMedia())[0];
          if (!asset) return;
          if (asset.type === "video") throw Error("Profil için fotoğraf seç.");
          const media = await uploadMedia(asset.uri, "image", "avatar");
          await api("setAvatar", { mediaId: media.id });
        }}
      />
      <Field
        placeholder="Görünen ad"
        value={name}
        onChangeText={setName}
        maxLength={60}
      />
      <Field
        placeholder="Bio"
        value={bio}
        onChangeText={setBio}
        multiline
        maxLength={160}
      />
      <Field
        placeholder="Web sitesi"
        value={website}
        onChangeText={setWebsite}
      />
      <Label muted>
        Kullanıcı adın: @{p.username}. Benzersiz kullanıcı adın bu sürümde
        değiştirilemez.
      </Label>
      <View style={styles.row}>
        <Label>Gizli hesap</Label>
        <Switch value={privacy} onValueChange={setPrivacy} />
      </View>
      <View style={styles.row}>
        <Label>Yabancılardan mesaj al</Label>
        <Switch value={dm} onValueChange={setDm} />
      </View>
      <Label muted>
        Gizli hesapların medyasına yalnız onaylı takipçiler erişebilir. Daha
        önce özel paylaştığın içerikler, hesabı açsan da özel kalır.
      </Label>
      <Button
        title="Kaydet"
        disabled={name.trim().length < 2}
        onPress={async () => {
          await editProfile({
            displayName: name.trim(),
            bio,
            website,
            isPrivate: privacy,
            allowStrangerDM: dm,
          });
          navigation.goBack();
        }}
      />
    </Page>
  );
}
export function Settings({ navigation }: any) {
  const role = useRole();
  const p = useSession((s) => s.profile)!,
    [deleting, setDeleting] = useState(false),
    blocks = useRows(
      query(collection(db, "users", p.uid, "blocks"), limit(100)),
    );
  return (
    <Page title="Senin alanın.">
      <Label>Koyu tema · Türkçe</Label>
      <Label muted>
        Konumun paylaşılmaz. Telefon bildirimlerini isteğe bağlı açabilirsin.
      </Label>
      <Button
        secondary
        title="Telefon bildirimlerini aç"
        onPress={enablePush}
      />
      <Button
        secondary
        title="Telefon bildirimlerini kapat"
        onPress={disablePush}
      />
      {role !== "member" && (
        <Button
          title="Yönetim paneli"
          onPress={() => navigation.navigate("Admin")}
        />
      )}
      {!auth.currentUser?.emailVerified && (
        <Button
          secondary
          title="E-postamı doğrula"
          onPress={async () => {
            if (auth.currentUser) await sendEmailVerification(auth.currentUser);
          }}
        />
      )}
      <OwnerActivation />
      <Label>Engellenen hesaplar</Label>
      <State {...blocks} empty={!blocks.rows.length} retry={blocks.refresh} />
      {blocks.rows.map((r) => (
        <View key={r.id} style={styles.card}>
          <Label muted>{r.uid}</Label>
          <Button
            secondary
            title="Engeli kaldır"
            onPress={() => deleteDoc(doc(db, "users", p.uid, "blocks", r.id))}
          />
        </View>
      ))}
      <LegalLinks includeDeletion />
      <Button title="Çıkış yap" onPress={logout} />
      <Button
        secondary
        title="Hesabımı sil"
        onPress={() => setDeleting(!deleting)}
      />
      {deleting && (
        <DeleteAccountForm
          onDelete={deleteOwnAccount}
          onCancel={() => setDeleting(false)}
        />
      )}
    </Page>
  );
}
export function Notifications({ navigation }: any) {
  const id = useSession((s) => s.profile)!.uid,
    requests = useRows(
      query(
        collection(db, "follows"),
        where("followingUid", "==", id),
        where("status", "==", "pending"),
        limit(50),
      ),
    ),
    notifications = useRows(
      query(
        collection(db, "notifications"),
        where("targetUid", "==", id),
        orderBy("createdAt", "desc"),
        limit(50),
      ),
    );
  return (
    <Page title="Senden haber var.">
      <Label>Takip istekleri</Label>
      <State
        {...requests}
        empty={!requests.rows.length}
        retry={requests.refresh}
      />
      {requests.rows.map((r) => (
        <View key={r.id} style={styles.card}>
          <Label>Yeni takip isteği</Label>
          <Button
            secondary
            title="Profili gör"
            onPress={() => navigation.navigate("User", { uid: r.followerUid })}
          />
          <Button title="Kabul et" onPress={() => acceptFollow(r.id, true)} />
          <Button
            secondary
            title="Reddet"
            onPress={() => acceptFollow(r.id, false)}
          />
        </View>
      ))}
      <Label>Bildirimler</Label>
      <State
        {...notifications}
        empty={!notifications.rows.length}
        retry={notifications.refresh}
      />
      {notifications.rows.map((r) => (
        <View key={r.id} style={styles.card}>
          <Label>{r.text}</Label>
          {!r.read && (
            <Button
              secondary
              title="Okundu olarak işaretle"
              onPress={() =>
                updateDoc(doc(db, "notifications", r.id), { read: true })
              }
            />
          )}
        </View>
      ))}
    </Page>
  );
}
export function Chats({ navigation }: any) {
  const id = useSession((s) => s.profile)!.uid,
    blocks = useRows(query(collection(db, "users", id, "blocks"), limit(200))),
    hidden = new Set(blocks.rows.map((r) => r.id)),
    data = useRows(
      query(
        collection(db, "chats"),
        where("memberIds", "array-contains", id),
        orderBy("lastMessageAt", "desc"),
        limit(50),
      ),
    );
  return (
    <Page title="Bir merhaba.">
      <Label muted>
        Yeni sohbet için Keşfet’ten bir profil aç. Yabancılardan mesaj alma
        tercihi korunur.
      </Label>
      <State
        loading={data.loading || blocks.loading}
        error={data.error || blocks.error}
        empty={
          !data.rows.some(
            (r) => !r.memberIds.some((uid: string) => hidden.has(uid)),
          )
        }
        retry={() => {
          data.refresh();
          blocks.refresh();
        }}
      />
      {!blocks.loading &&
        !blocks.error &&
        data.rows
          .filter((r) => !r.memberIds.some((uid: string) => hidden.has(uid)))
          .map((r) => (
            <Pressable
              key={r.id}
              style={styles.card}
              onPress={() =>
                navigation.navigate("Conversation", {
                  id: r.id,
                  title: "Sohbet",
                  otherUid: r.memberIds.find((uid: string) => uid !== id),
                })
              }
            >
              <Label>{r.lastMessage || "Yeni sohbet"}</Label>
              <Label muted>
                {r.memberIds.filter((u: string) => u !== id).join(", ")}
              </Label>
            </Pressable>
          ))}
    </Page>
  );
}
export function Conversation({ route }: any) {
  const id = route.params.id,
    me = useSession((s) => s.profile)!.uid,
    [text, setText] = useState(""),
    [editing, setEditing] = useState<string | null>(null),
    [reporting, setReporting] = useState(false),
    [confirmBlock, setConfirmBlock] = useState(false),
    otherUid: string =
      route.params.otherUid || id.split(":").find((uid: string) => uid !== me),
    blocks = useRows(query(collection(db, "users", me, "blocks"), limit(200))),
    isBlocked = blocks.rows.some((row) => row.id === otherUid);
  const data = useRows(
    !blocks.loading && !blocks.error && !isBlocked
      ? query(
          collection(db, "chats", id, "messages"),
          orderBy("createdAt", "desc"),
          limit(100),
        )
      : null,
  );
  React.useEffect(() => {
    for (const row of data.rows)
      if (!(row.seenBy || []).includes(me))
        updateDoc(doc(db, "chats", id, "messages", row.id), {
          seenBy: [...(row.seenBy || []), me],
        }).catch(() => {});
  }, [data.rows, me, id]);
  if (blocks.loading || blocks.error)
    return (
      <Page title="Sohbet">
        <State {...blocks} retry={blocks.refresh} />
      </Page>
    );
  if (isBlocked)
    return (
      <Page title="Hesap engellendi">
        <Label>
          Bu hesapla mesajlaşma engellendi. Engeli Ayarlar’dan kaldırabilirsin.
        </Label>
      </Page>
    );
  return (
    <Page scroll={false} title={route.params.title}>
      <View style={{ paddingHorizontal: 22, gap: 8 }}>
        <Button
          secondary
          title="Şikâyet et / engelle"
          onPress={() => setReporting(!reporting)}
        />
        {reporting && (
          <ScrollView
            style={{ maxHeight: 360 }}
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ gap: 10 }}
          >
            <ReportForm
              onSubmit={(reason) =>
                report(otherUid, `Sohbet ${id}: ${reason}`.slice(0, 500))
              }
              onCancel={() => setReporting(false)}
            />
            <Button
              secondary
              title="Bu hesabı engelle"
              onPress={() => setConfirmBlock(true)}
            />
            {confirmBlock && (
              <View style={styles.card}>
                <Label>
                  Bu hesabı engelleyip mesajlaşmayı durdurmak istiyor musun?
                </Label>
                <Button title="Evet, engelle" onPress={() => block(otherUid)} />
                <Button
                  secondary
                  title="Vazgeç"
                  onPress={() => setConfirmBlock(false)}
                />
              </View>
            )}
          </ScrollView>
        )}
      </View>
      <FlatList
        inverted
        data={data.rows}
        keyExtractor={(r) => r.id}
        ListEmptyComponent={
          <State {...data} empty={!data.rows.length} retry={data.refresh} />
        }
        renderItem={({ item }) => (
          <View
            style={[
              styles.card,
              {
                margin: 10,
                alignSelf: item.senderUid === me ? "flex-end" : "flex-start",
                maxWidth: "85%",
              },
            ]}
          >
            <Label>{item.text}</Label>
            {item.editedAt && <Label muted>Düzenlendi</Label>}
            <Label muted>
              {(item.seenBy || []).length > 1 ? "Görüldü" : "Gönderildi"}
            </Label>
            {item.senderUid === me && (
              <Button
                secondary
                title="Düzenle"
                onPress={() => {
                  setEditing(item.id);
                  setText(item.text);
                }}
              />
            )}
            {item.senderUid === me && (
              <Button
                secondary
                title="Sil"
                onPress={() =>
                  deleteDoc(doc(db, "chats", id, "messages", item.id))
                }
              />
            )}
          </View>
        )}
      />
      <View style={styles.pad}>
        <Field
          placeholder="Mesajın…"
          value={text}
          onChangeText={setText}
          maxLength={2000}
        />
        <Button
          title={editing ? "Değişikliği kaydet" : "Gönder"}
          disabled={!text.trim()}
          onPress={async () => {
            if (editing)
              await updateDoc(doc(db, "chats", id, "messages", editing), {
                text: text.trim(),
                editedAt: serverTimestamp(),
              });
            else await sendMessage(id, text);
            setEditing(null);
            setText("");
          }}
        />
        {editing && (
          <Button
            secondary
            title="Vazgeç"
            onPress={() => {
              setEditing(null);
              setText("");
            }}
          />
        )}
      </View>
    </Page>
  );
}

function OwnerActivation() {
  const user = auth.currentUser,
    [notice, setNotice] = useState("");
  if (user?.email?.toLowerCase() !== "ahmedberatazboy0@gmail.com") return null;
  return (
    <View style={styles.card}>
      <Label>Birarada resmî hesabı</Label>
      <Label muted>
        E-postanın doğrulanmış olması ve sunucuda hesap sahibi kurulumunun
        etkinleştirilmesi gerekir.
      </Label>
      <Button
        secondary
        title="Resmî hesap ve yönetim yetkisini etkinleştir"
        onPress={async () => {
          await user.reload();
          await user.getIdToken(true);
          await api("activateOwner", { acceptTerms: true });
          await user.getIdToken(true);
          setNotice("Resmî hesap ve yönetim yetkisi etkinleşti.");
        }}
      />
      {!!notice && <Label>{notice}</Label>}
    </View>
  );
}
