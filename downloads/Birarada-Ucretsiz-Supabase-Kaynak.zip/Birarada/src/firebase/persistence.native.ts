import * as FirebaseAuth from "firebase/auth";
import type { Persistence } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
// Metro resolves Firebase's documented React Native entry. The browser .d.ts
// omits this platform export, so describe only that exported function here.
const nativeAuth = FirebaseAuth as typeof FirebaseAuth & {
  getReactNativePersistence(storage: typeof AsyncStorage): Persistence;
};
export const persistence = nativeAuth.getReactNativePersistence(AsyncStorage);
