import {
  indexedDBLocalPersistence,
  browserLocalPersistence,
} from "firebase/auth";
export const persistence = [indexedDBLocalPersistence, browserLocalPersistence];
