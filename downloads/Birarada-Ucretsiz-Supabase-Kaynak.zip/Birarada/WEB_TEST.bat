@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
node scripts\start-free.cjs
set "BIRARADA_EXIT=%errorlevel%"
pause
exit /b %BIRARADA_EXIT%
