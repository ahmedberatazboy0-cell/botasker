import { expect, type Page, test } from "@playwright/test";
import fs from "node:fs/promises";
import { randomUUID } from "node:crypto";
const PASSWORD = "Local-emulator-only-942!";
const users: Record<string, { uid: string; email: string }> = {};
async function auth(action: string, input: any, admin = false) {
  const response = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" + action +
      "?key=local-test",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  const r = await response.json();
  if (!response.ok) throw Error(JSON.stringify(r));
  return r;
}
test.beforeAll(async () => {
  if (!process.env.BIRARADA_TEST_SECRET) {
    throw Error("Only owned local test server allowed");
  }
  const suffix = Date.now();
  const profiles = [];
  for (const name of ["ui", "ui-admin", "ui-victim"]) {
    const email = `${name}-${suffix}@example.test`,
      r = await auth("accounts:signUp", {
        email,
        password: PASSWORD,
        returnSecureToken: true,
      });
    users[name] = { uid: r.localId, email };
    await auth("projects/demo-birarada/accounts:update", {
      localId: r.localId,
      emailVerified: true,
    }, true);
    profiles.push({
      uid: r.localId,
      email,
      username: name.replaceAll("-", "_"),
      displayName: name,
      ...(name === "ui-admin" ? { role: "admin" } : {}),
    });
  }
  const response = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(response.status).toBe(200);
});
test.beforeEach(async ({ page }) => {
  page.on("response", async (r) => {
    if (r.status() >= 400 && r.url().startsWith("http://127.0.0.1:5002")) {
      console.log(
        "LOCAL API ERROR",
        r.status(),
        new URL(r.url()).pathname,
        await r.text().catch(() => ""),
      );
    }
  });
});
async function login(page: Page, name = "ui") {
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await expect(page.getByText("Arkadaşlarını bul", { exact: true }))
    .toBeVisible({ timeout: 90000 });
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await page.getByLabel("E-posta", { exact: true }).fill(users[name]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(PASSWORD);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(page.getByRole("button", { name: "Keşfet akışı", exact: true }))
    .toBeVisible();
}
async function attach(page: Page) {
  const pending = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  await (await pending).setFiles({
    name: "moment.jpg",
    mimeType: "image/jpeg",
    buffer: await fs.readFile("tests/free-photo.jpg"),
  });
  await expect(page.getByText("1. Fotoğraf", { exact: true })).toBeVisible();
}
test("real free-backend login, photo upload and retry preserve the draft and publish once", async ({ page }) => {
  await login(page);
  await page.getByText("Oluştur", { exact: true }).click();
  const caption = "#gece Ücretsiz Birarada fotoğraf";
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  await attach(page);
  let fail = true;
  await page.route("**/socialApi", async (route) => {
    const request = route.request().postDataJSON();
    if (fail && request?.action === "publishContent") {
      fail = false;
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: {
            code: "unavailable",
            message: "Geçici bağlantı hatası; yeniden dene.",
          },
        }),
      });
    } else await route.continue();
  });
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(
    page.getByText("Şu an çevrimdışısın. Bağlantı gelince yeniden dene.", {
      exact: true,
    }),
  ).toBeVisible();
  await expect(page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…"))
    .toHaveValue(caption);
  await expect(page.getByText("1. Fotoğraf", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(page.getByRole("button", { name: "Keşfet akışı", exact: true }))
    .toBeVisible();
  await expect(page.getByText(caption, { exact: true })).toHaveCount(1);
  await expect.poll(() =>
    page.evaluate(() =>
      Array.from(document.images).some((image) =>
        image.src.startsWith("blob:") && image.complete &&
        image.naturalWidth > 0
      )
    )
  ).toBe(true);
  await page.screenshot({
    path: "artifacts/free-feed-mobile.png",
    fullPage: true,
  });
});
test("free-backend photo story appears and becomes a highlight", async ({ page }) => {
  await login(page);
  await page.getByRole("button", { name: "Hikâye ekle", exact: true }).click();
  await attach(page);
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(
    "Ücretsiz hikâye",
  );
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await page.getByRole("button", { name: "@ui hikâyesi", exact: true }).click();
  await expect(page.getByText("Ücretsiz hikâye", { exact: true }))
    .toBeVisible();
  await page.getByRole("button", { name: "Öne çıkanlara ekle", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Öne çıkanlardan kaldır", exact: true }),
  ).toBeVisible();
});
test("free-backend admin panel requires explicit confirmation before account restriction", async ({ page }) => {
  await login(page, "ui-admin");
  await page.getByText("Profil", { exact: true }).click();
  await page.getByRole("button", { name: "Ayarlar", exact: true }).click();
  await page.getByRole("button", { name: "Yönetim paneli", exact: true })
    .click();
  await expect(page.getByText("Yetkin: Yönetici", { exact: true }))
    .toBeVisible();
  await page.getByPlaceholder("İşlem gerekçesi / inceleme notu").fill(
    "Local UI safety check",
  );
  await page.getByPlaceholder("Firebase kullanıcı UID").fill(
    users["ui-victim"]!.uid,
  );
  await page.getByRole("button", { name: "Hesabı kısıtla", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Onayla ve uygula", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Onayla ve uygula", exact: true })
    .click();
  await expect(
    page.getByText("İşlem tamamlandı ve kayda alındı.", { exact: true }),
  ).toBeVisible();
});

test("private H264 video uploads and decodes through authenticated web download", async ({ page }) => {
  await login(page);
  await page.getByText("Oluştur", { exact: true }).click();
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(
    "Özel video görüntüleme testi",
  );
  const chooser = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  await (await chooser).setFiles({
    name: "moment.mp4",
    mimeType: "video/mp4",
    buffer: await fs.readFile("tests/free-video.mp4"),
  });
  await expect(page.getByText("1. Video", { exact: true })).toBeVisible();
  const published = page.waitForResponse((r) =>
    r.url().endsWith("/socialApi") &&
    r.request().postDataJSON()?.action === "publishContent"
  );
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  const mediaId = (await published).request().postDataJSON().input.mediaIds[0];
  let firstDownload = true;
  await page.route("**/mediaContent?id=" + mediaId, async (route) => {
    if (firstDownload) {
      firstDownload = false;
      await route.fulfill({ status: 503, body: "Temporary failure" });
    } else await route.continue();
  });
  await expect(page.getByText("Özel video görüntüleme testi", { exact: true }))
    .toBeVisible();
  await page.getByRole("button", { name: "Videoyu yükle", exact: true }).first()
    .click();
  await expect(
    page.getByText(
      "Medya şu an açılamıyor. Erişim iznini veya bağlantını kontrol et.",
      { exact: true },
    ),
  ).toBeVisible();
  await page.getByRole("button", { name: "Yeniden dene", exact: true }).first()
    .click();
  await expect.poll(() =>
    page.evaluate(() =>
      Array.from(document.querySelectorAll("video")).some((video) =>
        video.src.startsWith("blob:") && video.readyState >= 1 &&
        video.videoWidth === 160
      )
    )
  ).toBe(true);
});

test("private AAC voice message decodes in the real browser audio player", async ({ page }) => {
  const account = await auth("accounts:signInWithPassword", {
    email: users.ui!.email,
    password: PASSWORD,
    returnSecureToken: true,
  });
  const token = account.idToken;
  async function action(action: string, input: any) {
    const r = await fetch("http://127.0.0.1:5002/socialApi", {
      method: "POST",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ action, input }),
    });
    const value = await r.json();
    expect(r.status, JSON.stringify(value)).toBe(200);
    return value.data;
  }
  const bytes = await fs.readFile("tests/free-voice.m4a"),
    mediaId = randomUUID();
  await action("createUpload", {
    requestId: mediaId,
    purpose: "message",
    kind: "audio",
    bytes: bytes.length,
  });
  const upload = await fetch(
    "http://127.0.0.1:5002/mediaUpload?id=" + mediaId,
    {
      method: "PUT",
      headers: { Authorization: "Bearer " + token },
      body: bytes,
    },
  );
  expect(upload.status).toBe(200);
  const chat = await action("createChat", {
    members: [users["ui-admin"]!.uid],
  });
  await action("sendMessage", {
    chatId: chat.id,
    requestId: randomUUID(),
    text: "",
    mediaIds: [mediaId],
  });
  await page.addInitScript(() => {
    const Original = window.Audio;
    (window as any).privateAudioReady = [];
    window.Audio = new Proxy(Original, {
      construct(target, args) {
        const audio = Reflect.construct(target, args);
        audio.addEventListener(
          "loadedmetadata",
          () =>
            (window as any).privateAudioReady.push({
              src: audio.src,
              duration: audio.duration,
            }),
        );
        return audio;
      },
    });
  });
  await login(page);
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page.getByText("Birebir sohbet", { exact: true }).click();
  await page.getByRole("button", { name: "Sesli mesajı yükle", exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Sesli mesajı dinle", exact: true }),
  ).toBeVisible();
  await expect.poll(() =>
    page.evaluate(() =>
      (window as any).privateAudioReady.some((audio: any) =>
        audio.src.startsWith("blob:") && audio.duration > 0
      )
    )
  ).toBe(true);
});
