import React, { useEffect, useRef, useState } from "react";
import { FlatList, Platform, Pressable, Text, View } from "react-native";
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
} from "../database/client";
import {
  RecordingPresets,
  requestRecordingPermissionsAsync,
  setAudioModeAsync,
  useAudioRecorder,
  useAudioRecorderState,
} from "expo-audio";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useRows } from "../hooks/useRows";
import {
  api,
  type MediaItem,
  type MediaKind,
  newId,
  uploadMedia,
} from "../services/api";
import { selectMedia } from "../services/picker";
import { ProtectedMedia } from "../components/ProtectedMedia";
import {
  Button,
  Field,
  Label,
  Page,
  ReportForm,
  State,
  styles,
} from "../components/ui";
import { friendly } from "../utils/errors";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useIsFocused } from "@react-navigation/native";
import {
  Avatar,
  Action,
  Icon,
  TopBar,
  Sheet,
  MenuRow,
} from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { usePerson } from "../hooks/usePerson";
import { timeAgo, clockTime } from "../utils/time";
import type { Row } from "../types";

function VoiceRecorder({
  onReady,
  disabled,
}: {
  onReady: (uri: string) => void;
  disabled: boolean;
}) {
  const recorder = useAudioRecorder({
      ...RecordingPresets.HIGH_QUALITY,
      web: { mimeType: "audio/mp4", bitsPerSecond: 128000 },
    }),
    status = useAudioRecorderState(recorder, 250),
    [error, setError] = useState("");
  const stopping = useRef(false);
  async function stop() {
    if (stopping.current) return;
    stopping.current = true;
    try {
      await recorder.stop();
      await setAudioModeAsync({
        allowsRecording: false,
        playsInSilentMode: true,
      });
      if (recorder.uri) onReady(recorder.uri);
    } finally {
      stopping.current = false;
    }
  }
  useEffect(() => {
    if (status.isRecording && status.durationMillis >= 179000) {
      void stop().catch((e) => setError(e.message));
    }
  }, [status.durationMillis]);
  useEffect(
    () => () => {
      if (recorder.isRecording) {
        void recorder.stop().catch(() => {});
        void setAudioModeAsync({ allowsRecording: false }).catch(() => {});
      }
    },
    [recorder],
  );
  return (
    <View style={{ gap: 5 }}>
      <Button
        secondary
        disabled={disabled}
        title={
          status.isRecording
            ? `Kaydı bitir · ${Math.floor(status.durationMillis / 1000)} sn`
            : "Ses kaydet"
        }
        onPress={async () => {
          if (status.isRecording) {
            await stop();
            return;
          }
          if (
            Platform.OS === "web" &&
            (typeof MediaRecorder === "undefined" ||
              !MediaRecorder.isTypeSupported("audio/mp4"))
          ) {
            throw Error(
              "Bu tarayıcı AAC ses kaydını desteklemiyor. Sesli mesaj için Android/iOS uygulamasını kullan.",
            );
          }
          const permission = await requestRecordingPermissionsAsync();
          if (!permission.granted) {
            throw Error("Sesli mesaj için mikrofon izni gerekli.");
          }
          await setAudioModeAsync({
            allowsRecording: true,
            playsInSilentMode: true,
          });
          await recorder.prepareToRecordAsync();
          recorder.record();
        }}
      />
      {!!error && <Label>{error}</Label>}
    </View>
  );
}
function ChatRow({
  chat,
  me,
  search,
  open,
}: {
  chat: Row;
  me: string;
  search: string;
  open: () => void;
}) {
  const other = usePerson(chat.memberIds?.find((u: string) => u !== me));
  const title =
    chat.kind === "group"
      ? chat.title
      : other?.displayName || other?.username || "Birebir sohbet";
  const queryText = search.trim().toLocaleLowerCase("tr-TR");
  if (
    queryText &&
    ![title, other?.username, chat.lastMessage].some((value) =>
      String(value || "")
        .toLocaleLowerCase("tr-TR")
        .includes(queryText),
    )
  )
    return null;
  return (
    <Pressable
      onPress={open}
      accessibilityRole="button"
      accessibilityLabel={
        chat.kind === "group" ? chat.title : `${title} sohbetini aç`
      }
      style={{
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 16,
        paddingVertical: 12,
        gap: 13,
      }}
    >
      <Avatar
        name={title}
        mediaId={chat.kind === "group" ? undefined : other?.avatarMediaId}
        size={56}
      />
      <View style={{ flex: 1, gap: 5 }}>
        <Text style={{ fontSize: 14, fontWeight: "600", color: c.text }}>
          {title}
        </Text>
        <Text numberOfLines={1} style={{ fontSize: 13, color: c.muted }}>
          {chat.lastMessage || "Bir mesaj gönder"} ·{" "}
          {timeAgo(chat.lastMessageAt)}
        </Text>
      </View>
      <Icon
        name={chat.kind === "group" ? "people-outline" : "chatbubble-outline"}
        size={22}
        color={c.muted}
      />
    </Pressable>
  );
}
export function Chats({ navigation }: any) {
  const me = useSession((s) => s.profile)!;
  const [search, setSearch] = useState("");
  const chats = useRows(
    query(
      collection(db, "chats"),
      where("memberIds", "array-contains", me.uid),
      orderBy("lastMessageAt", "desc"),
      limit(50),
    ),
  );
  const blocks = useRows(
    query(collection(db, "users", me.uid, "blocks"), limit(200)),
  );
  const hidden = new Set(blocks.rows.map((r) => r.id));
  const rows = chats.rows.filter(
    (chat) => !chat.memberIds?.some((u: string) => hidden.has(u)),
  );
  return (
    <Page scroll={false}>
      <TopBar
        title={me.username}
        left={
          <Action
            name="chevron-back"
            label="Geri"
            onPress={() => navigation.goBack()}
          />
        }
        right={
          <Action
            name="create-outline"
            label="Yeni mesaj"
            onPress={() => navigation.navigate("NewChat")}
          />
        }
      />
      <FlatList
        data={blocks.loading || blocks.error ? [] : rows}
        keyExtractor={(r) => r.id}
        refreshing={chats.loading}
        onRefresh={chats.refresh}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 16, paddingTop: 12, gap: 18 }}>
            <Field
              placeholder="Sohbetlerde ara"
              value={search}
              onChangeText={setSearch}
              style={{ borderWidth: 0, borderRadius: 12 }}
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Notlar · Şarkını paylaş"
              onPress={() => navigation.navigate("Notes")}
              style={{
                alignSelf: "flex-start",
                alignItems: "center",
                gap: 7,
                paddingVertical: 8,
              }}
            >
              <View
                style={{
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: c.line,
                  paddingHorizontal: 12,
                  paddingVertical: 8,
                  marginBottom: -15,
                  zIndex: 1,
                  backgroundColor: c.bg,
                }}
              >
                <Text style={{ fontSize: 11, color: c.muted }}>
                  Bir not bırak…
                </Text>
              </View>
              <Avatar name={me.username} mediaId={me.avatarMediaId} size={64} />
              <Text style={{ fontSize: 12, color: c.muted }}>Notun</Text>
            </Pressable>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                paddingBottom: 6,
              }}
            >
              <Text style={{ fontWeight: "700", fontSize: 16, color: c.text }}>
                Mesajlar
              </Text>
              <Pressable
                onPress={() => navigation.navigate("NewGroup")}
                accessibilityRole="button"
                accessibilityLabel="Yeni grup"
              >
                <Text
                  style={{ fontWeight: "600", fontSize: 13, color: c.accent }}
                >
                  Yeni grup
                </Text>
              </Pressable>
            </View>
          </View>
        }
        ListEmptyComponent={
          <State
            loading={chats.loading || blocks.loading}
            error={chats.error || blocks.error}
            empty
            retry={() => {
              chats.refresh();
              blocks.refresh();
            }}
          />
        }
        renderItem={({ item }) => (
          <ChatRow
            chat={item}
            me={me.uid}
            search={search}
            open={() =>
              navigation.navigate("Conversation", {
                id: item.id,
                otherUid: item.memberIds?.find((u: string) => u !== me.uid),
              })
            }
          />
        )}
      />
    </Page>
  );
}
export function NewChat({ navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    [term, setTerm] = useState(""),
    [rows, setRows] = useState<Row[]>([]),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(false);
  useEffect(() => {
    let alive = true;
    const timer = setTimeout(() => {
      setLoading(true);
      setError("");
      api("searchUsers", { search: term })
        .then((r) => {
          if (alive) setRows(r.rows.filter((u: Row) => u.id !== me));
        })
        .catch((e) => {
          if (alive) setError(friendly(e));
        })
        .finally(() => {
          if (alive) setLoading(false);
        });
    }, 300);
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [term, me]);
  return (
    <Page>
      <Field
        placeholder="Ad veya kullanıcı adı ara"
        value={term}
        onChangeText={setTerm}
      />
      <MenuRow
        title="Yeni grup oluştur"
        icon="people-outline"
        onPress={() => navigation.navigate("NewGroup")}
      />
      <State
        loading={loading}
        error={error}
        empty={!rows.length}
        retry={() => setTerm((t) => t + " ")}
      />
      {rows.map((row) => (
        <MenuRow
          key={row.id}
          title={row.username}
          detail={row.displayName}
          icon="person-circle-outline"
          onPress={async () => {
            const result = await api("createChat", { members: [row.id] });
            navigation.replace("Conversation", {
              id: result.id,
              otherUid: row.id,
            });
          }}
        />
      ))}
    </Page>
  );
}
export function NewGroup({ navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    [search, setSearch] = useState(""),
    [title, setTitle] = useState(""),
    [rows, setRows] = useState<Row[]>([]),
    [selected, setSelected] = useState(new Map<string, string>()),
    [error, setError] = useState("");
  const request = useRef(newId());
  useEffect(() => {
    let alive = true;
    const timer = setTimeout(() => {
      api("searchUsers", { search })
        .then((r) => {
          if (alive) setRows(r.rows.filter((u: Row) => u.id !== me));
        })
        .catch((e) => {
          if (alive) setError(e.message);
        });
    }, 350);
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [search, me]);
  return (
    <Page title="Yeni grup">
      <Field
        placeholder="Grup adı"
        value={title}
        onChangeText={setTitle}
        maxLength={60}
      />
      <Field
        placeholder="Kullanıcı adı ara"
        value={search}
        onChangeText={setSearch}
      />
      <Label>{selected.size + 1}/20 kişi</Label>
      {[...selected].map(([uid, name]) => (
        <Button
          key={uid}
          secondary
          title={`✓ @${name} · kaldır`}
          onPress={() =>
            setSelected((old) => {
              const next = new Map(old);
              next.delete(uid);
              return next;
            })
          }
        />
      ))}
      {rows
        .filter((u) => !selected.has(u.id))
        .map((u) => (
          <Button
            key={u.id}
            secondary
            title={`@${u.username} · ekle`}
            disabled={selected.size >= 19}
            onPress={() =>
              setSelected((old) => new Map(old).set(u.id, u.username))
            }
          />
        ))}
      {!!error && <Label>{error}</Label>}
      <Button
        title="Grubu oluştur"
        disabled={!title.trim() || !selected.size}
        onPress={async () => {
          const group = await api("createChat", {
            requestId: request.current,
            group: true,
            title,
            members: [...selected.keys()],
          });
          navigation.replace("Conversation", { id: group.id, title });
        }}
      />
      <Label muted>
        Katılımcıların mesaj izinleri ve karşılıklı engelleri korunur.
      </Label>
    </Page>
  );
}
export function Conversation({ route, navigation }: any) {
  const chatId = route.params.id,
    me = useSession((s) => s.profile)!.uid,
    focused = useIsFocused();
  const [chat, setChat] = useState<Row | null>(null),
    [chatError, setChatError] = useState("");
  const messages = useRows(
    query(
      collection(db, "chats", chatId, "messages"),
      orderBy("createdAt", "desc"),
      limit(100),
    ),
  );
  const otherUid =
      chat?.memberIds?.find((u: string) => u !== me) || route.params.otherUid,
    person = usePerson(otherUid);
  const title =
    chat?.kind === "group"
      ? chat.title
      : person?.displayName ||
        person?.username ||
        route.params.title ||
        "Sohbet";
  const [text, setText] = useState(""),
    [reply, setReply] = useState<Row | null>(null),
    [editing, setEditing] = useState<Row | null>(null),
    [selected, setSelected] = useState<Row | null>(null),
    [confirmDelete, setConfirmDelete] = useState(false),
    [attachment, setAttachment] = useState<{
      uri: string;
      kind: MediaKind;
    } | null>(null),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState(""),
    [reporting, setReporting] = useState(false),
    [details, setDetails] = useState(false),
    [leave, setLeave] = useState(false),
    [groupTitle, setGroupTitle] = useState(""),
    [recording, setRecording] = useState(false),
    [hydrated, setHydrated] = useState(false);
  const request = useRef(newId()),
    uploaded = useRef<MediaItem | null>(null),
    seenPending = useRef(new Set<string>()),
    dirty = useRef(false),
    beforeEditing = useRef("");
  const draftKey = `message-draft:${me}:${chatId}`;
  useEffect(() => {
    let alive = true;
    void AsyncStorage.getItem(draftKey).then((value) => {
      if (alive) {
        if (value && !dirty.current) setText(value);
        setHydrated(true);
      }
    });
    return () => {
      alive = false;
    };
  }, [draftKey]);
  useEffect(() => {
    if (!hydrated || editing) return;
    const timer = setTimeout(() => {
      void AsyncStorage.setItem(draftKey, text);
    }, 300);
    return () => {
      clearTimeout(timer);
      void AsyncStorage.setItem(draftKey, text);
    };
  }, [draftKey, text, hydrated, !!editing]);
  useEffect(() => {
    if (!focused) return;
    return onSnapshot(
      doc(db, "chats", chatId),
      (s) => {
        setChat(s.exists() ? { id: s.id, ...s.data() } : null);
        setChatError("");
        setGroupTitle(s.data()?.title || "");
      },
      (e) => setChatError(friendly(e)),
    );
  }, [chatId, focused]);
  useEffect(() => {
    if (!focused) return;
    const ids = messages.rows
      .filter(
        (r) =>
          r.senderUid !== me &&
          !r.seenBy?.includes(me) &&
          !seenPending.current.has(r.id),
      )
      .map((r) => r.id);
    if (!ids.length) return;
    ids.forEach((id) => seenPending.current.add(id));
    void api("markSeen", { chatId, ids }).catch((e) => {
      ids.forEach((id) => seenPending.current.delete(id));
      setNotice(friendly(e));
    });
  }, [messages.rows, chatId, me, focused]);
  function addAttachment(uri: string, kind: MediaKind) {
    setAttachment({ uri, kind });
    uploaded.current = null;
    request.current = newId();
  }
  const [sendingPreview, setSendingPreview] = useState<{
    id: string;
    text: string;
  } | null>(null);
  async function send() {
    if (busy) return;
    setBusy(true);
    setNotice("");
    setSendingPreview(
      editing ? null : { id: request.current, text: text || "Medya mesajı" },
    );
    try {
      if (editing) await api("editMessage", { chatId, id: editing.id, text });
      else {
        if (attachment && !uploaded.current)
          uploaded.current = await uploadMedia(
            attachment.uri,
            attachment.kind,
            "message",
          );
        await api("sendMessage", {
          chatId,
          requestId: request.current,
          text,
          mediaIds: uploaded.current ? [uploaded.current.id] : [],
          ...(reply ? { replyTo: reply.id } : {}),
        });
      }
      setText(editing ? beforeEditing.current : "");
      setReply(null);
      setEditing(null);
      setAttachment(null);
      setRecording(false);
      uploaded.current = null;
      request.current = newId();
      if (!editing) await AsyncStorage.removeItem(draftKey);
      messages.refresh();
    } finally {
      setSendingPreview(null);
      setBusy(false);
    }
  }
  return (
    <Page scroll={false}>
      <TopBar
        title={title}
        left={
          <>
            <Action
              name="chevron-back"
              label="Geri"
              onPress={() => navigation.goBack()}
            />
            <View style={{ marginRight: 10 }}>
              <Avatar
                name={title}
                mediaId={
                  chat?.kind === "group" ? undefined : person?.avatarMediaId
                }
                size={32}
              />
            </View>
          </>
        }
        right={
          <Action
            name="ellipsis-horizontal"
            label="Sohbet bilgileri"
            onPress={() => setDetails(true)}
          />
        }
      />
      {!!chatError && (
        <Text
          testID="chat-connection-error"
          accessibilityRole="alert"
          style={styles.error}
        >
          {chatError}
        </Text>
      )}
      <FlatList
        inverted
        data={messages.rows}
        keyExtractor={(r) => r.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingHorizontal: 12, paddingVertical: 14 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <State {...messages} empty retry={messages.refresh} />
        }
        renderItem={({ item }) => {
          const own = item.senderUid === me;
          const quoted = messages.rows.find((r) => r.id === item.replyTo);
          return (
            <View
              style={{
                alignItems: own ? "flex-end" : "flex-start",
                marginVertical: 4,
              }}
            >
              <Pressable
                onLongPress={() => {
                  setSelected(item);
                  setConfirmDelete(false);
                }}
                onPress={() => {
                  setSelected(item);
                  setConfirmDelete(false);
                }}
                accessibilityRole="button"
                accessibilityLabel="Mesaj seçenekleri"
                style={{
                  maxWidth: "84%",
                  paddingHorizontal: 14,
                  paddingVertical: 10,
                  borderRadius: 20,
                  backgroundColor: own ? c.outgoing : c.incoming,
                  gap: 5,
                }}
              >
                {chat?.kind === "group" && !own && (
                  <Text
                    style={{ fontSize: 11, fontWeight: "600", color: c.muted }}
                  >
                    {item.senderUid === person?.uid
                      ? person?.username
                      : "Grup üyesi"}
                  </Text>
                )}
                {!!item.replyTo && (
                  <View
                    style={{
                      borderLeftWidth: 2,
                      borderLeftColor: own ? "#ffffffa0" : "#bbb",
                      paddingLeft: 8,
                      paddingVertical: 3,
                    }}
                  >
                    <Text
                      numberOfLines={2}
                      style={{
                        fontSize: 12,
                        color: own ? "#ffffffc0" : c.muted,
                      }}
                    >
                      {quoted?.text || "Bir mesaja yanıt"}
                    </Text>
                  </View>
                )}
                {!!item.text && (
                  <Text
                    style={{
                      fontSize: 15,
                      lineHeight: 21,
                      color: own ? "#fff" : c.text,
                    }}
                  >
                    {item.text}
                  </Text>
                )}
                {item.mediaItems?.map((m: MediaItem) => (
                  <ProtectedMedia
                    key={m.id}
                    item={m}
                    style={{
                      width: 220,
                      height: m.kind === "audio" ? 72 : 240,
                      borderRadius: 12,
                    }}
                  />
                ))}
                {!!item.editedAt && (
                  <Text
                    style={{ fontSize: 10, color: own ? "#ffffffbf" : c.muted }}
                  >
                    Düzenlendi
                  </Text>
                )}
                {Object.keys(item.reactions || {}).length > 0 && (
                  <View
                    style={{
                      alignSelf: "flex-end",
                      backgroundColor: c.bg,
                      borderRadius: 20,
                      paddingHorizontal: 7,
                      paddingVertical: 3,
                    }}
                  >
                    <Text style={{ fontSize: 14 }}>
                      {Object.values(item.reactions).join(" ")}
                    </Text>
                  </View>
                )}
              </Pressable>
              <Text
                style={{
                  fontSize: 10,
                  color: c.muted,
                  paddingHorizontal: 8,
                  marginTop: 3,
                }}
              >
                {clockTime(item.createdAt)}
                {own
                  ? ` · ${item.seenBy?.length > 1 ? "Görüldü" : "Gönderildi"}`
                  : ""}
              </Text>
            </View>
          );
        }}
      />
      {sendingPreview &&
        !messages.rows.some((row) => row.id === sendingPreview.id) && (
          <View
            testID="sending-message"
            style={{
              alignSelf: "flex-end",
              margin: 12,
              padding: 12,
              borderRadius: 16,
              backgroundColor: "#e4f1ff",
              maxWidth: "85%",
            }}
          >
            <Text>{sendingPreview.text}</Text>
            <Label muted>Gönderiliyor…</Label>
          </View>
        )}
      <View
        style={{
          borderTopWidth: 0.5,
          borderTopColor: c.line,
          paddingHorizontal: 12,
          paddingTop: 8,
          paddingBottom: 12,
          gap: 7,
        }}
      >
        {!!notice && (
          <Text accessibilityRole="alert" style={styles.error}>
            {notice}
          </Text>
        )}
        {(reply || editing) && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: c.surface,
              borderRadius: 10,
              paddingLeft: 12,
            }}
          >
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 11, fontWeight: "600", color: c.muted }}>
                {editing ? "Mesajı düzenliyorsun" : "Yanıtlıyorsun"}
              </Text>
              <Text
                numberOfLines={1}
                style={{ fontSize: 13, color: c.text, marginTop: 3 }}
              >
                {(editing || reply)?.text || "Medya mesajı"}
              </Text>
            </View>
            <Action
              name="close"
              label="Yanıtı veya düzenlemeyi iptal et"
              onPress={() => {
                if (editing) setText(beforeEditing.current);
                setReply(null);
                setEditing(null);
              }}
              size={20}
            />
          </View>
        )}
        {attachment && (
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 10,
              padding: 8,
              backgroundColor: c.surface,
              borderRadius: 12,
            }}
          >
            <Icon
              name={
                attachment.kind === "audio"
                  ? "mic-outline"
                  : attachment.kind === "video"
                    ? "videocam-outline"
                    : "image-outline"
              }
            />
            <Text style={{ fontSize: 13, color: c.text, flex: 1 }}>
              {attachment.kind === "audio"
                ? "Ses kaydı hazır"
                : attachment.kind === "video"
                  ? "Video hazır"
                  : "Fotoğraf hazır"}
            </Text>
            <Action
              name="close"
              label="Eki kaldır"
              onPress={() => {
                setAttachment(null);
                uploaded.current = null;
              }}
            />
          </View>
        )}
        {recording && (
          <VoiceRecorder
            disabled={busy}
            onReady={(uri) => {
              addAttachment(uri, "audio");
              setRecording(false);
            }}
          />
        )}
        <View
          style={{
            flexDirection: "row",
            alignItems: "flex-end",
            gap: 4,
            backgroundColor: c.surface,
            borderRadius: 26,
            paddingLeft: 3,
            paddingRight: 3,
          }}
        >
          {!editing && (
            <Action
              name="camera-outline"
              label="Fotoğraf / video"
              color={c.accent}
              disabled={busy}
              onPress={async () => {
                const asset = (await selectMedia())[0];
                if (asset)
                  addAttachment(
                    asset.uri,
                    asset.type === "video" ? "video" : "image",
                  );
              }}
            />
          )}
          <Field
            placeholder="Mesaj yaz…"
            maxLength={2000}
            multiline
            value={text}
            onChangeText={(v) => {
              dirty.current = true;
              setText(v);
            }}
            editable={!busy}
            style={{
              flex: 1,
              borderWidth: 0,
              backgroundColor: "transparent",
              maxHeight: 112,
              minHeight: 44,
              paddingHorizontal: 4,
              paddingVertical: 12,
            }}
          />
          {text.trim() || attachment || editing ? (
            <Action
              name="arrow-up-circle"
              size={34}
              color={c.accent}
              label={editing ? "Düzenlemeyi kaydet" : "Gönder"}
              disabled={busy || (!text.trim() && !attachment)}
              onPress={send}
            />
          ) : (
            <Action
              name="mic-outline"
              label="Sesli mesaj kaydet"
              disabled={busy}
              onPress={() => setRecording((v) => !v)}
            />
          )}
        </View>
      </View>
      <Sheet
        visible={!!selected}
        title="Mesaj"
        onClose={() => {
          setSelected(null);
          setConfirmDelete(false);
        }}
      >
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            paddingBottom: 10,
          }}
        >
          {["❤️", "😂", "😮", "😢", "👍", "🔥"].map((emoji) => (
            <Pressable
              key={emoji}
              accessibilityRole="button"
              accessibilityLabel={`${emoji} tepkisi`}
              onPress={async () => {
                try {
                  await api("reactMessage", {
                    chatId,
                    id: selected!.id,
                    reaction: selected?.reactions?.[me] === emoji ? "" : emoji,
                  });
                  messages.refresh();
                  setSelected(null);
                } catch (e) {
                  setNotice(friendly(e));
                  setSelected(null);
                }
              }}
              style={{ padding: 10 }}
            >
              <Text style={{ fontSize: 25 }}>{emoji}</Text>
            </Pressable>
          ))}
        </View>
        <MenuRow
          title="Yanıtla"
          icon="arrow-undo-outline"
          onPress={() => {
            setReply(selected);
            setEditing(null);
            setSelected(null);
          }}
        />
        {selected?.senderUid === me && (
          <>
            <MenuRow
              title="Düzenle"
              icon="pencil-outline"
              onPress={() => {
                beforeEditing.current = text;
                setEditing(selected);
                setText(selected.text || "");
                setSelected(null);
              }}
            />
            <MenuRow
              title="Sil"
              icon="trash-outline"
              danger
              onPress={() => setConfirmDelete(true)}
            />
          </>
        )}
        {confirmDelete && (
          <>
            <Label>Mesajı herkes için silmek istiyor musun?</Label>
            <Button
              title="Evet, sil"
              onPress={async () => {
                await api("deleteMessage", { chatId, id: selected!.id });
                messages.refresh();
                setSelected(null);
                setConfirmDelete(false);
              }}
            />
            <Button
              secondary
              title="Vazgeç"
              onPress={() => setConfirmDelete(false)}
            />
          </>
        )}
        {selected?.senderUid !== me && (
          <MenuRow
            title="Mesajı şikâyet et"
            icon="flag-outline"
            danger
            onPress={() => setReporting(true)}
          />
        )}
      </Sheet>
      <Sheet
        visible={details}
        title="Sohbet bilgileri"
        onClose={() => setDetails(false)}
      >
        {person && chat?.kind !== "group" && (
          <MenuRow
            title={person.username}
            detail="Profili görüntüle"
            icon="person-outline"
            onPress={() => {
              setDetails(false);
              navigation.navigate("User", { uid: person.uid });
            }}
          />
        )}
        {chat?.kind === "group" && (
          <>
            <Label>{chat.memberIds.length} katılımcı</Label>
            {chat.ownerUid === me && (
              <>
                <Field
                  placeholder="Grup adı"
                  value={groupTitle}
                  onChangeText={setGroupTitle}
                />
                <Button
                  secondary
                  title="Grup adını kaydet"
                  onPress={() =>
                    api("updateGroup", { chatId, title: groupTitle })
                  }
                />
              </>
            )}
            <MenuRow
              title="Gruptan ayrıl"
              icon="exit-outline"
              danger
              onPress={() => setLeave(true)}
            />
            {leave && (
              <>
                <Label>Gruptan ayrılmak istiyor musun?</Label>
                <Button
                  title="Evet, ayrıl"
                  onPress={async () => {
                    await api("leaveGroup", { chatId });
                    navigation.goBack();
                  }}
                />
                <Button
                  secondary
                  title="Vazgeç"
                  onPress={() => setLeave(false)}
                />
              </>
            )}
          </>
        )}
        <MenuRow
          title="Şikâyet et"
          icon="flag-outline"
          danger
          onPress={() => {
            setDetails(false);
            setReporting(true);
          }}
        />
      </Sheet>
      <Sheet
        visible={reporting}
        title="Şikâyet et"
        onClose={() => setReporting(false)}
      >
        <ReportForm
          onSubmit={async (reason) => {
            await api("reportChat", {
              chatId,
              reason,
              messageId: selected?.id,
            });
            setSelected(null);
            setReporting(false);
            setNotice("Şikâyetin alındı.");
          }}
          onCancel={() => setReporting(false)}
        />
      </Sheet>
    </Page>
  );
}
