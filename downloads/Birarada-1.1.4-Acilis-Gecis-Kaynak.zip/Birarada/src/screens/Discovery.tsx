import React, { useEffect, useState } from "react";
import {
  ScrollView,
  FlatList,
  Pressable,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import { Avatar, Icon, Segments } from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { useApiList } from "../hooks/useApiList";
import { api, cachedApi } from "../services/api";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { Page, Button, Field, Label, State, styles } from "../components/ui";
import { PostCard } from "../components/PostCard";
import type { Row, Post } from "../types";
export function PostGrid({
  rows,
  open,
}: {
  rows: Row[];
  open: (row: Row) => void;
}) {
  const [container, setContainer] = useState(
    Math.min(useWindowDimensions().width, 680),
  );
  const width = (container - 4) / 3;
  return (
    <View
      onLayout={(e) => setContainer(e.nativeEvent.layout.width)}
      style={{ flexDirection: "row", flexWrap: "wrap", gap: 2, width: "100%" }}
    >
      {rows.map((row) => (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`@${row.username}: ${row.caption}`}
          key={row.id}
          onPress={() => open(row)}
          style={{
            width,
            height: (width * 4) / 3,
            backgroundColor: c.surface,
            borderRadius: 0,
            overflow: "hidden",
          }}
        >
          {row.mediaItems?.[0]?.kind === "image" ? (
            <ProtectedMedia
              item={row.mediaItems[0]}
              style={{ width, height: (width * 4) / 3 }}
            />
          ) : (
            <View style={{ padding: 8, justifyContent: "center", flex: 1 }}>
              <Label>
                {row.kind === "reel"
                  ? "▷ Reels"
                  : row.mediaItems?.length
                    ? "▷ Video"
                    : row.caption}
              </Label>
            </View>
          )}
          {row.mediaItems?.length > 1 && (
            <View style={{ position: "absolute", right: 5, top: 5 }}>
              <Icon name="copy" color="#fff" size={19} />
            </View>
          )}
        </Pressable>
      ))}
    </View>
  );
}
export function Explore({ navigation }: any) {
  const [search, setSearch] = useState(""),
    [term, setTerm] = useState(""),
    [mode, setMode] = useState("posts"),
    [users, setUsers] = useState<Row[]>([]),
    [userError, setUserError] = useState(""),
    [after, setAfter] = useState<string | null>(null),
    [userLoading, setUserLoading] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setTerm(search), 350);
    return () => clearTimeout(timer);
  }, [search]);
  const content = useApiList(
    "listContent",
    {
      kind: mode === "reels" ? "reel" : "post",
      search: term.replace(/^#/, ""),
    },
    { enabled: mode !== "users", pollInterval: 15000 },
  );
  async function loadUsers(more = false) {
    setUserLoading(true);
    try {
      const r = await api("searchUsers", {
        search: term.replace(/^@/, ""),
        ...(more ? { after } : {}),
      });
      setUsers((old) => (more ? [...old, ...r.rows] : r.rows));
      setAfter(r.after);
      setUserError("");
    } catch (e) {
      setUserError((e as Error).message);
    } finally {
      setUserLoading(false);
    }
  }
  useEffect(() => {
    if (mode === "users") void loadUsers();
  }, [term, mode]);
  return (
    <Page scroll={false}>
      <ScrollView
        contentContainerStyle={{ gap: 12, paddingTop: 12 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ paddingHorizontal: 14 }}>
          <Field
            placeholder="Kullanıcı, kelime veya #etiket ara"
            value={search}
            onChangeText={setSearch}
            maxLength={100}
          />
        </View>
        <View style={{ paddingHorizontal: 14 }}>
          <Segments
            value={mode}
            onChange={setMode}
            items={[
              { value: "posts", label: "Gönderiler" },
              { value: "users", label: "Hesaplar" },
              { value: "reels", label: "Reels" },
            ]}
          />
        </View>
        {mode === "users" ? (
          <>
            <State
              loading={userLoading}
              error={userError}
              empty={!users.length}
              retry={() => loadUsers()}
            />
            {users.map((user) => (
              <Pressable
                key={user.id}
                accessibilityRole="button"
                accessibilityLabel={`@${user.username} hesabını aç`}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                }}
                onPress={() => navigation.navigate("User", { uid: user.id })}
              >
                <Avatar
                  name={user.displayName || user.username}
                  mediaId={user.avatarMediaId}
                  size={48}
                />
                <View>
                  <Text
                    style={{ fontSize: 14, fontWeight: "600", color: c.text }}
                  >
                    {user.username} {user.official ? "✓" : ""}
                  </Text>
                  <Text style={{ fontSize: 13, color: c.muted, marginTop: 3 }}>
                    {user.displayName}
                  </Text>
                </View>
              </Pressable>
            ))}
            {!!after && (
              <Button
                secondary
                title="Daha fazla hesap"
                onPress={() => loadUsers(true)}
              />
            )}
          </>
        ) : (
          <>
            <State
              {...content}
              empty={!content.rows.length}
              retry={content.refresh}
            />
            <PostGrid
              rows={content.rows}
              open={(row) => navigation.navigate("PostDetails", { id: row.id })}
            />
            {content.hasMore && (
              <Button
                secondary
                title="Daha fazla paylaşım"
                onPress={content.loadMore}
              />
            )}
          </>
        )}
      </ScrollView>
    </Page>
  );
}
export function PostDetails({ route, navigation }: any) {
  const [post, setPost] = useState<Post | null>(
      () => cachedApi<Post>("getContent", { id: route.params.id }) || null,
    ),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [version, setVersion] = useState(0);
  useEffect(() => {
    let alive = true;
    const warm = cachedApi<Post>("getContent", { id: route.params.id });
    setLoading(!warm);
    setError("");
    setPost(warm || null);
    api<Post>("getContent", { id: route.params.id })
      .then((row) => {
        if (alive) setPost(row);
      })
      .catch((e) => {
        if (alive) {
          setError(e.message);
          if (["permission-denied", "unauthenticated"].includes(e?.code))
            setPost(null);
        }
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [route.params.id, version]);
  return (
    <Page scroll={false}>
      <ScrollView testID="post-details">
        <State
          loading={loading}
          error={error}
          empty={!post && !loading}
          retry={() => setVersion((v) => v + 1)}
        />
        {post && (
          <PostCard
            post={post}
            openProfile={(uid) => navigation.push("User", { uid })}
          />
        )}
      </ScrollView>
    </Page>
  );
}
