import React, { useState } from "react";
import { Text, View, Platform } from "react-native";
import app from "../../app.json";
import Constants from "expo-constants";
import { Page, Button, Label } from "../components/ui";
import { api } from "../services/api";
import { apiBase } from "../database/client";
import { withDeadline } from "../utils/deadline";
export function ConnectionCheck() {
  const [rows, setRows] = useState<
    { label: string; ms?: number; detail: string }[]
  >([]);
  return (
    <Page title="Bağlantı kontrolü">
      <Label>
        Uygulama:{" "}
        {Platform.OS === "web"
          ? app.expo.version
          : Constants.nativeAppVersion || app.expo.version}{" "}
        · kod{" "}
        {Platform.OS === "web"
          ? app.expo.android.versionCode
          : Constants.nativeBuildVersion || app.expo.android.versionCode}
      </Label>
      <Label muted>
        Bu ölçüm telefondaki gerçek bağlantıyı kontrol eder. Mesaj, şifre veya
        cihaz anahtarı kaydetmez.
      </Label>
      <Button
        title="Bağlantıyı ölç"
        onPress={async () => {
          setRows([]);
          for (const [label, work] of [
            [
              "Sunucu",
              () =>
                withDeadline(async (signal) => {
                  const r = await fetch(apiBase + "/health", { signal });
                  const v = await r.json();
                  if (!r.ok) throw Error("Sunucu hazır değil.");
                  return String(v.revision || "Sürüm okunamadı.");
                }, 15000),
            ],
            [
              "Oturumlu okuma",
              async () => {
                await api("connectionProbe");
                return "Oturum doğrulandı.";
              },
            ],
          ] as [string, () => Promise<string>][]) {
            const started = Date.now();
            try {
              const detail = await work();
              setRows((old) => [
                ...old,
                { label, ms: Date.now() - started, detail },
              ]);
            } catch (e) {
              setRows((old) => [
                ...old,
                {
                  label,
                  detail:
                    e instanceof Error ? e.message : "Bağlantı kurulamadı.",
                },
              ]);
            }
          }
        }}
      />
      {rows.map((row) => (
        <View key={row.label} style={{ paddingVertical: 10 }}>
          <Text>
            {row.label}: {row.ms === undefined ? "Başarısız" : `${row.ms} ms`}
          </Text>
          <Label muted>{row.detail}</Label>
        </View>
      ))}
    </Page>
  );
}
