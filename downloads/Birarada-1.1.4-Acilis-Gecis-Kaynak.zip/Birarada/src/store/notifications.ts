import { create } from "zustand";
export const useNotificationState = create<{ unread:number; error:string; pushError:string; set:(v:Partial<{unread:number;error:string;pushError:string}>)=>void }>(set=>({unread:0,error:"",pushError:"",set}));
