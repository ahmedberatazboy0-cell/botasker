import React from "react";
import { warmMainScreens } from "../services/prefetch";
import { Platform, View } from "react-native";
import { Avatar, Icon, type IconName } from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { useSession } from "../store/session";
import { ConnectionCheck } from "../screens/ConnectionCheck";
import { NotificationCenter } from "../components/NotificationCenter";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {
  Feed,
  ProfileScreen,
  EditProfile,
  Settings,
  Notifications,
} from "../screens/Social";
import { Create, ShortVideos } from "../screens/Media";
import { Saved, Connections } from "../screens/Collections";
import { Notes } from "../screens/Notes";
import { Admin } from "../screens/Admin";
import { StoryViewer } from "../screens/Stories";
import { Explore, PostDetails } from "../screens/Discovery";
import { Chats, Conversation, NewGroup, NewChat } from "../screens/Messaging";
const Stack = createNativeStackNavigator(),
  Tab = createBottomTabNavigator();
const icons: Record<string, [IconName, IconName]> = {
  "Ana Sayfa": ["home-outline", "home"],
  Keşfet: ["search-outline", "search"],
  Oluştur: ["add-circle-outline", "add-circle"],
  Reels: ["play-circle-outline", "play-circle"],
  Profil: ["person-circle-outline", "person-circle"],
};
function Tabs() {
  const profile = useSession((s) => s.profile);
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarShowLabel: false,
        tabBarActiveTintColor: c.text,
        tabBarInactiveTintColor: c.text,
        tabBarStyle: {
          backgroundColor: c.bg,
          borderTopColor: c.line,
          height: Platform.OS === "ios" ? 80 : 62,
          paddingBottom: Platform.OS === "ios" ? 22 : 8,
          paddingTop: 8,
        },
        tabBarAccessibilityLabel: route.name,
        tabBarIcon: ({ focused }) =>
          route.name === "Profil" ? (
            <Avatar
              name={profile?.username}
              mediaId={profile?.avatarMediaId}
              size={27}
              ring={focused}
            />
          ) : (
            <Icon name={icons[route.name]![focused ? 1 : 0]} size={27} />
          ),
      })}
    >
      <Tab.Screen name="Ana Sayfa" component={Feed} />
      <Tab.Screen name="Keşfet" component={Explore} />
      <Tab.Screen name="Oluştur" component={Create} />
      <Tab.Screen name="Reels" component={ShortVideos} />
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
export function Root() {
  const uid = useSession((s) => s.profile?.uid);
  React.useEffect(() => {
    if (uid) warmMainScreens(uid);
  }, [uid]);
  const navigation = React.useRef<any>(null);
  const [ready, setReady] = React.useState(false);
  return (
    <NavigationContainer
      ref={navigation}
      onReady={() => setReady(true)}
      theme={{
        ...DefaultTheme,
        colors: {
          ...DefaultTheme.colors,
          primary: c.accent,
          background: c.bg,
          card: c.bg,
          border: c.line,
          text: c.text,
        },
      }}
    >
      <View style={{ flex: 1 }}>
        <Stack.Navigator
          screenOptions={{
            headerTintColor: c.text,
            headerBackTitle: "Geri",
            headerTitleStyle: { fontSize: 17, fontWeight: "600" },
            headerShadowVisible: false,
          }}
        >
          <Stack.Screen
            name="Main"
            component={Tabs}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Admin"
            component={Admin}
            options={{ title: "Yönetim paneli" }}
          />
          <Stack.Screen
            name="StoryComposer"
            component={Create}
            options={{ title: "Hikâye oluştur" }}
          />
          <Stack.Screen
            name="StoryViewer"
            component={StoryViewer}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="PostDetails"
            component={PostDetails}
            options={{ title: "Paylaşım" }}
          />
          <Stack.Screen
            name="NewChat"
            component={NewChat}
            options={{ title: "Yeni mesaj" }}
          />
          <Stack.Screen
            name="NewGroup"
            component={NewGroup}
            options={{ title: "Yeni grup" }}
          />
          <Stack.Screen
            name="Notes"
            component={Notes}
            options={{ title: "Notlar" }}
          />
          <Stack.Screen
            name="Saved"
            component={Saved}
            options={{ title: "Kaydedilenler" }}
          />
          <Stack.Screen
            name="Connections"
            component={Connections}
            options={{ title: "Bağlantıların" }}
          />
          <Stack.Screen
            name="User"
            component={ProfileScreen}
            options={{ title: "Profil" }}
          />
          <Stack.Screen
            name="EditProfile"
            component={EditProfile}
            options={{ title: "Profili düzenle" }}
          />
          <Stack.Screen
            name="Settings"
            component={Settings}
            options={{ title: "Ayarlar" }}
          />
          <Stack.Screen
            name="ConnectionCheck"
            component={ConnectionCheck}
            options={{ title: "Bağlantı kontrolü" }}
          />
          <Stack.Screen
            name="Notifications"
            component={Notifications}
            options={{ title: "Bildirimler" }}
          />
          <Stack.Screen
            name="Chats"
            component={Chats}
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Conversation"
            component={Conversation}
            options={{ headerShown: false }}
          />
        </Stack.Navigator>
        <NotificationCenter navigation={navigation} ready={ready} />
      </View>
    </NavigationContainer>
  );
}
