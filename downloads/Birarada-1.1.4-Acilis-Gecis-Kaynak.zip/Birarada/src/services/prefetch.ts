import { api } from "./api";
import {
  collection,
  getDocs,
  limit,
  orderBy,
  query,
  where,
} from "../database/client";
import { auth, db } from "../firebase/client";
const warmed = new WeakSet<object>();
export function warmMainScreens(uid: string) {
  const user = auth.currentUser;
  if (!user || user.uid !== uid || warmed.has(user)) return;
  warmed.add(user);
  // Bounded warm-up of own profile, inbox and two recent conversations.
  void (async () => {
    const tasks = [
      () => api("listContent", { kind: "post", uid, relation: "none" }),
      async () => {
        const chats = await getDocs(
          query(
            collection(db, "chats"),
            where("memberIds", "array-contains", uid),
            orderBy("lastMessageAt", "desc"),
            limit(50),
          ),
        );
        const people = [
          ...new Set(
            chats.docs
              .slice(0, 10)
              .flatMap((row) => row.data()?.memberIds || []),
          ),
        ]
          .filter((id) => id !== uid)
          .slice(0, 20);
        await Promise.allSettled([
          ...(people.length
            ? [
                getDocs(
                  query(
                    collection(db, "users"),
                    where("uid", "in", people),
                    limit(20),
                  ),
                ),
              ]
            : []),
          ...chats.docs
            .slice(0, 2)
            .map((chat) =>
              getDocs(
                query(
                  collection(db, "chats", chat.id, "messages"),
                  orderBy("createdAt", "desc"),
                  limit(100),
                ),
              ),
            ),
        ]);
      },
      () => api("profileStats", { uid }),
    ];
    await Promise.allSettled(
      tasks.map((task) =>
        auth.currentUser === user ? task() : Promise.resolve(),
      ),
    );
  })();
}
