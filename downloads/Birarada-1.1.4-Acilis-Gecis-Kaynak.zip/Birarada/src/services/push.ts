import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import Constants from "expo-constants";
import { Platform } from "react-native";
import { api, newId } from "./api";
const KEY = "birarada:push-token",
  PROOF = "birarada:push-installation";
export async function enablePush() {
  if (Platform.OS === "web" || !Device.isDevice)
    throw Error(
      "Telefon bildirimleri fiziksel Android/iOS cihazında kullanılabilir.",
    );
  await configurePush();
  const existing = await Notifications.getPermissionsAsync(),
    permission = existing.granted
      ? existing
      : await Notifications.requestPermissionsAsync();
  if (!permission.granted)
    throw Error(
      "Bildirim izni verilmedi. Telefon ayarlarından değiştirebilirsin.",
    );
  const projectId = Constants.expoConfig?.extra?.eas?.projectId;
  if (!projectId)
    throw Error("Bu kurulumun gerçek Expo proje bağlantısı eksik.");
  const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  let installation = await AsyncStorage.getItem(PROOF);
  if (!installation) {
    installation = newId() + newId();
    await AsyncStorage.setItem(PROOF, installation);
  }
  await api("registerPush", { token, installation });
  await AsyncStorage.setItem(KEY, token);
}
export async function disablePush() {
  const token = await AsyncStorage.getItem(KEY);
  if (!token) return;
  await api("unregisterPush", { token });
  await AsyncStorage.removeItem(KEY);
}

export async function configurePush() {
  if (Platform.OS === "web") return;
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowBanner: false,
      shouldShowList: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });
  if (Platform.OS === "android")
    await Notifications.setNotificationChannelAsync("social", {
      name: "Mesajlar ve etkileşimler",
      importance: Notifications.AndroidImportance.HIGH,
      sound: "default",
      enableVibrate: true,
      vibrationPattern: [0, 250, 150, 250],
      lockscreenVisibility: Notifications.AndroidNotificationVisibility.PRIVATE,
    });
}
export async function syncPushIfEnabled() {
  if (Platform.OS === "web" || !(await AsyncStorage.getItem(KEY))) return;
  const permission = await Notifications.getPermissionsAsync();
  if (permission.granted) await enablePush();
}
