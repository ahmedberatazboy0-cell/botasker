type Sink<T> = { next: (value: T) => void; error?: (error: any) => void };
export function createLiveReads({ grace = 1500, freshFor = 1500 } = {}) {
  const entries = new Map<string, any>();
  return {
    subscribe<T>(
      key: string,
      start: (
        next: (v: T) => void,
        error: (e: any) => void,
      ) => { stop: () => void; refresh: () => void },
      next: (v: T) => void,
      error?: (e: any) => void,
    ) {
      let entry = entries.get(key);
      const sink: Sink<T> = { next, error };
      if (!entry) {
        entry = {
          sinks: new Set<Sink<T>>(),
          hasValue: false,
          last: undefined,
          error: undefined,
          at: 0,
          timer: undefined,
          source: undefined,
        };
        entries.set(key, entry);
        entry.sinks.add(sink);
        entry.source = start(
          (value: T) => {
            entry.last = value;
            entry.hasValue = true;
            entry.error = undefined;
            entry.at = Date.now();
            for (const target of entry.sinks) target.next(value);
          },
          (e: any) => {
            entry.error = e;
            if (["permission-denied", "unauthenticated"].includes(e?.code)) {
              entry.last = undefined;
              entry.hasValue = false;
            }
            for (const target of entry.sinks) target.error?.(e);
          },
        );
      } else {
        clearTimeout(entry.timer);
        entry.sinks.add(sink);
        if (entry.hasValue) next(entry.last);
        if (entry.error || Date.now() - entry.at >= freshFor)
          entry.source.refresh();
      }
      return () => {
        entry.sinks.delete(sink);
        if (entry.sinks.size) return;
        entry.timer = setTimeout(() => {
          if (entry.sinks.size) return;
          entry.source.stop();
          if (entries.get(key) === entry) entries.delete(key);
        }, grace);
      };
    },
    clear() {
      for (const entry of entries.values()) {
        clearTimeout(entry.timer);
        entry.source.stop();
        entry.sinks.clear();
      }
      entries.clear();
    },
  };
}
