type Destination = {
  screen: "Conversation" | "PostDetails" | "User" | "Notifications";
  params?: { id?: string; uid?: string };
};
const valid = (v: unknown): v is string =>
  typeof v === "string" && /^[a-zA-Z0-9_:\-]{1,160}$/.test(v);
export function notificationDestination(row: any): Destination {
  const target = row?.target || row || {};
  if (valid(target.chatId))
    return { screen: "Conversation", params: { id: target.chatId } };
  if (valid(target.postId) || valid(row?.postId))
    return {
      screen: "PostDetails",
      params: { id: target.postId || row.postId },
    };
  const uid = target.userId || row?.actorUid || row?.sourceUid;
  if (valid(uid)) return { screen: "User", params: { uid } };
  return { screen: "Notifications" };
}
export function notificationText(
  row: any,
  username?: string,
  privateAccount = false,
) {
  const who = username ? "@" + username : "Birisi";
  if (row?.type === "like") return `${who} gönderini beğendi.`;
  if (row?.type === "comment") return `${who} gönderine yorum yaptı.`;
  if (row?.type === "message") return `${who} sana mesaj gönderdi.`;
  if (row?.type === "group") return `${who} seni bir gruba ekledi.`;
  if (row?.type === "follow" || row?.type === "request")
    return privateAccount
      ? `${who} seni takip etmek istiyor.`
      : `${who} seni takip etmeye başladı.`;
  return row?.text || "Yeni bir bildirimin var.";
}
