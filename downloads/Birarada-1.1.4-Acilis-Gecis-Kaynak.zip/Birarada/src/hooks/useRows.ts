import { useEffect, useState, useCallback } from "react";
import {
  onSnapshot,
  cachedQuery,
  Query,
  DocumentData,
} from "../database/client";
import { useIsFocused } from "@react-navigation/native";
import { friendly } from "../utils/errors";
import { useSession } from "../store/session";
import type { Row } from "../types";
export function useRows(q: Query<DocumentData> | null) {
  const focused = useIsFocused(),
    account = useSession((s) => s.user?.uid || s.profile?.uid || ""),
    spec = q ? JSON.stringify(q.spec) : "",
    identity = `${account}:${spec}`;
  const warm = q ? cachedQuery(q) : undefined;
  const [state, setState] = useState({
      identity,
      rows: warm
        ? warm.docs.map((d) => ({ id: d.id, ...d.data() }) as Row)
        : ([] as Row[]),
      loaded: !!warm,
      loading: !!q && !warm,
      error: "",
      offline: false,
    }),
    [retry, setRetry] = useState(0);
  useEffect(() => {
    if (!focused) return;
    if (!spec) {
      setState({
        identity,
        rows: [],
        loaded: true,
        loading: false,
        error: "",
        offline: false,
      });
      return;
    }
    let alive = true;
    const cached = cachedQuery(new Query<DocumentData>(JSON.parse(spec)));
    setState((old) =>
      old.identity === identity
        ? { ...old, loading: !old.loaded, error: "" }
        : {
            identity,
            rows: cached
              ? cached.docs.map((d) => ({ id: d.id, ...d.data() }) as Row)
              : [],
            loaded: !!cached,
            loading: !cached,
            error: "",
            offline: false,
          },
    );
    const stop = onSnapshot(
      new Query<DocumentData>(JSON.parse(spec)),
      { includeMetadataChanges: true },
      (snap) => {
        if (alive)
          setState({
            identity,
            rows: snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Row),
            loaded: true,
            offline: snap.metadata.fromCache,
            loading: false,
            error: "",
          });
      },
      (e) => {
        if (alive)
          setState((old) => ({
            ...old,
            error: friendly(e),
            loading: false,
            ...(["permission-denied", "unauthenticated"].includes(e?.code)
              ? { rows: [], loaded: false }
              : {}),
          }));
      },
    );
    return () => {
      alive = false;
      stop();
    };
  }, [identity, spec, retry, focused]);
  const matches = state.identity === identity;
  return {
    rows: matches ? state.rows : [],
    loading: !!q && (!matches || state.loading),
    error: matches ? state.error : "",
    offline: matches && state.offline,
    refresh: useCallback(() => setRetry((n) => n + 1), []),
  };
}
