import { useEffect, useState } from "react";
import { doc, getDoc, cachedDoc } from "../database/client";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import type { Profile } from "../types";
const cache = new Map<string, { person: Profile; until: number }>();
const pending = new Map<string, Promise<Profile | null>>();
export function usePerson(uid?: string) {
  const me = useSession((s) => s.profile);
  const key = `${me?.uid || ""}:${uid || ""}`;
  const [value, setValue] = useState<{ key: string; person: Profile | null }>({
    key,
    person: uid
      ? (cachedDoc(doc(db, "users", uid))?.data() as Profile) || null
      : null,
  });
  useEffect(() => {
    if (!uid || !me || uid === me.uid) return;
    let alive = true;
    const saved = cache.get(key);
    if (saved && saved.until > Date.now()) {
      setValue({ key, person: saved.person });
      return;
    }
    const preview = cachedDoc(doc(db, "users", uid));
    if (preview?.exists()) setValue({ key, person: preview.data() as Profile });
    let request = pending.get(key);
    if (!request) {
      request = getDoc(doc(db, "users", uid))
        .then((s) => (s.exists() ? (s.data() as Profile) : null))
        .catch(() => null);
      pending.set(key, request);
      void request.then((person) => {
        pending.delete(key);
        if (person) {
          cache.set(key, { person, until: Date.now() + 60000 });
          if (cache.size > 256) cache.delete(cache.keys().next().value!);
        }
      });
    }
    void request.then((person) => {
      if (alive) setValue({ key, person });
    });
    return () => {
      alive = false;
    };
  }, [key, uid, me?.uid]);
  if (uid && uid === me?.uid) return me;
  return value.key === key ? value.person : null;
}
