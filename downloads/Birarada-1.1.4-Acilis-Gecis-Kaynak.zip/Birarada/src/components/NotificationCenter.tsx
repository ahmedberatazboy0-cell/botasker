import React, { useEffect, useRef, useState } from "react";
import { Animated, Platform, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Push from "expo-notifications";
import {
  collection,
  doc,
  limit,
  onSnapshot,
  orderBy,
  query,
  updateDoc,
  where,
} from "../database/client";
import { auth, db } from "../firebase/client";
import { useSession } from "../store/session";
import { useNotificationState } from "../store/notifications";
import {
  notificationDestination,
  notificationText,
} from "../utils/notificationTarget";
import { useForeground } from "../hooks/useForeground";
import { usePerson } from "../hooks/usePerson";
import { configurePush, syncPushIfEnabled } from "../services/push";
import { friendly } from "../utils/errors";
import { Icon } from "./social-ui";
import type { Row } from "../types";
export function NotificationCenter({
  navigation,
  ready,
}: {
  navigation: React.RefObject<any>;
  ready: boolean;
}) {
  const me = useSession((s) => s.profile),
    active = useForeground(),
    inset = useSafeAreaInsets();
  const [banner, setBanner] = useState<Row | null>(null),
    movement = useRef(new Animated.Value(-100)).current;
  const seen = useRef(new Set<string>()),
    primed = useRef(false),
    pending = useRef<Push.NotificationResponse | null>(null),
    handled = useRef("");
  const person = usePerson(banner?.sourceUid),
    set = useNotificationState((s) => s.set);
  const open = (row: any) => {
    if (!navigation.current?.isReady()) return;
    const target = notificationDestination(row);
    navigation.current.navigate(target.screen, target.params);
    setBanner(null);
    if (row.id)
      void updateDoc(doc(db, "notifications", row.id), { read: true }).catch(
        () => {},
      );
  };
  const show = (row: Row) => {
    if (seen.current.has(row.id)) return;
    seen.current.add(row.id);
    if (seen.current.size > 500)
      seen.current.delete(seen.current.values().next().value!);
    const current = navigation.current?.getCurrentRoute();
    if (
      row.type === "message" &&
      current?.name === "Conversation" &&
      current.params?.id === (row.target?.chatId || row.chatId)
    )
      return;
    setBanner(row);
  };
  useEffect(() => {
    seen.current.clear();
    primed.current = false;
    setBanner(null);
    set({ unread: 0, error: "" });
  }, [me?.uid]);
  useEffect(() => {
    if (!me?.uid || !active) return;
    return onSnapshot(
      query(
        collection(db, "notifications"),
        where("targetUid", "==", me.uid),
        orderBy("createdAt", "desc"),
        limit(30),
      ),
      { pollInterval: 3000 },
      (snap) => {
        const rows = snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Row);
        set({ unread: rows.filter((row) => !row.read).length, error: "" });
        if (primed.current) {
          const newest = rows.find(
            (row) => !row.read && !seen.current.has(row.id),
          );
          if (newest) show(newest);
        }
        for (const row of rows) seen.current.add(row.id);
        primed.current = true;
        if (Platform.OS !== "web")
          void Push.setBadgeCountAsync(
            rows.filter((row) => !row.read).length,
          ).catch(() => {});
      },
      (error) => set({ error: friendly(error) }),
    );
  }, [me?.uid, active]);
  useEffect(() => {
    if (Platform.OS === "web") return;
    void configurePush()
      .then(syncPushIfEnabled)
      .catch((e) => set({ pushError: friendly(e) }));
    const received = Push.addNotificationReceivedListener((notification) => {
      const data = notification.request.content.data;
      if (data.targetUid !== auth.currentUser?.uid) return;
      show({
        id: String(data.notificationId || notification.request.identifier),
        ...data,
        body: notification.request.content.body,
      });
    });
    const clicked = Push.addNotificationResponseReceivedListener((response) => {
      pending.current = response;
      handlePending();
    });
    const handlePending = () => {
      const response = pending.current;
      if (!response || !navigation.current?.isReady()) return;
      const request = response.notification.request,
        data = request.content.data;
      if (
        data.targetUid === auth.currentUser?.uid &&
        handled.current !== request.identifier
      ) {
        handled.current = request.identifier;
        open({ ...data, id: data.notificationId });
      }
      pending.current = null;
      void Push.clearLastNotificationResponseAsync();
    };
    void Push.getLastNotificationResponseAsync().then((response) => {
      pending.current = response;
      handlePending();
    });
    return () => {
      received.remove();
      clicked.remove();
    };
  }, [me?.uid, ready]);
  useEffect(() => {
    if (!banner) return;
    movement.stopAnimation();
    movement.setValue(-100);
    Animated.spring(movement, {
      toValue: 0,
      useNativeDriver: Platform.OS !== "web",
      friction: 9,
    }).start();
    const timer = setTimeout(
      () =>
        Animated.timing(movement, {
          toValue: -100,
          duration: 180,
          useNativeDriver: Platform.OS !== "web",
        }).start(({ finished }) => {
          if (finished)
            setBanner((current) =>
              current?.id === banner.id ? null : current,
            );
        }),
      5500,
    );
    return () => {
      clearTimeout(timer);
      movement.stopAnimation();
    };
  }, [banner?.id]);
  if (!banner) return null;
  return (
    <Animated.View
      testID="notification-banner"
      style={{
        position: "absolute",
        top: inset.top + 8,
        left: 12,
        right: 12,
        zIndex: 2000,
        elevation: 12,
        transform: [{ translateY: movement }],
        alignItems: "center",
      }}
    >
      <View
        style={{
          width: "100%",
          maxWidth: 500,
          backgroundColor: "#171717",
          borderRadius: 18,
          flexDirection: "row",
          alignItems: "center",
          padding: 12,
          gap: 10,
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Bildirimi aç"
          onPress={() => open(banner)}
          style={{
            flex: 1,
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Icon
            name={banner.type === "message" ? "chatbubble" : "notifications"}
            color="#fff"
            size={23}
          />
          <View style={{ flex: 1 }}>
            <Text style={{ color: "#fff", fontWeight: "700" }}>Birarada</Text>
            <Text
              accessibilityRole="alert"
              style={{ color: "#f0f0f0", marginTop: 3 }}
            >
              {banner.body ||
                notificationText(banner, person?.username, me?.isPrivate)}
            </Text>
          </View>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Bildirimi kapat"
          onPress={() => setBanner(null)}
          style={{ padding: 8 }}
        >
          <Icon name="close" size={20} color="#fff" />
        </Pressable>
      </View>
    </Animated.View>
  );
}
