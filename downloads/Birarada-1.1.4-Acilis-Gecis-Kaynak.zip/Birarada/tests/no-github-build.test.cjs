"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");
const {
  buildWithoutGithub,
  commandSpec,
  chromePath,
  ownedState,
  prepareProject,
  validProject,
} = require("../scripts/build-no-github.cjs");
// An isolated fixture ID, never persisted as real application metadata.
const PROJECT = {
  projectId: "00000000-0000-4000-8000-000000000123",
  owner: "test-owner",
  slug: "birarada",
};
const actualRoot = path.resolve(__dirname, "..");

function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "birarada-helper-test-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  for (const name of [
    "App.tsx",
    "app.config.ts",
    "app.json",
    "eas.json",
    "index.ts",
    "package.json",
    "package-lock.json",
    "tsconfig.json",
    "src",
    "assets",
  ])
    fs.cpSync(path.join(actualRoot, name), path.join(root, name), {
      recursive: true,
    });
  fs.writeFileSync(
    path.join(root, "google-services.json"),
    JSON.stringify({
      project_info: {
        project_id: "birarada-5650c",
        project_number: "510479812993",
      },
      client: [
        {
          api_key: [{ current_key: "AIza" + "A".repeat(35) }],
          client_info: {
            mobilesdk_app_id: "1:510479812993:android:0000000000000000",
            android_client_info: { package_name: "com.birarada.app" },
          },
        },
      ],
    }),
  );
  const cfg = JSON.parse(fs.readFileSync(path.join(root, "app.json")));
  cfg.expo.owner = PROJECT.owner;
  cfg.expo.extra = { ...cfg.expo.extra, eas: { projectId: PROJECT.projectId } };
  fs.writeFileSync(path.join(root, "app.json"), JSON.stringify(cfg));
  fs.mkdirSync(path.join(root, "scripts"));
  fs.copyFileSync(
    path.join(actualRoot, "scripts/release-check.cjs"),
    path.join(root, "scripts/release-check.cjs"),
  );
  fs.copyFileSync(
    path.join(actualRoot, "scripts/firebase-android.cjs"),
    path.join(root, "scripts/firebase-android.cjs"),
  );
  fs.mkdirSync(path.join(root, "node_modules"));
  fs.writeFileSync(
    path.join(root, ".env.local"),
    "PRIVATE_FIXTURE=do-not-copy\n",
  );
  fs.writeFileSync(path.join(root, "credentials.json"), "do-not-copy");
  fs.mkdirSync(path.join(root, ".git"));
  return root;
}

function runner(options = {}) {
  const calls = [];
  const run = (command, args, config) => {
    calls.push({ command, args, config });
    if (args[1] === options.failedTest) return { status: 1 };
    if (args.includes("whoami"))
      return options.authError
        ? { status: 1, stderr: options.authError }
        : { status: 0, stdout: "test-owner" };
    if (args.at(-1) === "init") {
      const file = path.join(config.cwd, "app.json");
      const app = JSON.parse(fs.readFileSync(file));
      app.expo.owner = PROJECT.owner;
      app.expo.extra = {
        eas: { projectId: options.badId || PROJECT.projectId },
      };
      fs.writeFileSync(file, JSON.stringify(app));
    }
    if (args.includes("build") && options.failBuild) return { status: 1 };
    return { status: 0 };
  };
  return { run, calls };
}

const execute = (root, mocked, extra = {}) =>
  buildWithoutGithub({
    root,
    run: mocked.run,
    verifyTools: (_root, env) => env,
    env: {},
    log: () => {},
    ...extra,
  });

test("a failed free-backend test stops before login, project creation or build", async (t) => {
  const root = fixture(t),
    mocked = runner({ failedTest: "test:free" });
  await assert.rejects(execute(root, mocked), /test:free/);
  assert.equal(
    mocked.calls.some(
      (c) =>
        c.args.includes("whoami") ||
        c.args.includes("init") ||
        c.args.includes("build"),
    ),
    false,
  );
});

test("network denial is not treated as a missing login", async (t) => {
  const root = fixture(t),
    mocked = runner({ authError: "Request failed: 403 Forbidden" });
  await assert.rejects(execute(root, mocked), /ağ hatası/);
  assert.equal(
    mocked.calls.some(
      (c) => c.args.includes("login") || c.args.includes("init"),
    ),
    false,
  );
});

test("missing login uses the official browser flow and obtains the real CLI-returned ID", async (t) => {
  const root = fixture(t),
    mocked = runner({ authError: "Not logged in" });
  const appBefore = fs.readFileSync(path.join(root, "app.json"));
  const dynamicBefore = fs.readFileSync(path.join(root, "app.config.ts"));
  const result = await execute(root, mocked);
  assert.deepEqual(result.project, PROJECT);
  assert.equal(
    mocked.calls.some(
      (c) => c.args.includes("login") && c.args.includes("--browser"),
    ),
    true,
  );
  for (const call of mocked.calls.filter((c) =>
    c.args.some((a) => /eas-cli/.test(a)),
  )) {
    assert.equal(call.config.env.EAS_NO_VCS, "1");
    assert.equal(path.isAbsolute(call.config.env.EAS_PROJECT_ROOT), true);
    assert.equal(call.command, "npx");
  }
  assert.equal(
    mocked.calls.some((c) => /git/i.test(c.command)),
    false,
  );
  assert.deepEqual(fs.readFileSync(path.join(root, "app.json")), appBefore);
  assert.deepEqual(
    fs.readFileSync(path.join(root, "app.config.ts")),
    dynamicBefore,
  );
  assert.equal(fs.existsSync(path.join(result.work, ".env.local")), false);
  assert.equal(fs.existsSync(path.join(result.work, ".git")), false);
  assert.equal(
    fs.existsSync(path.join(result.work, "credentials.json")),
    false,
  );
  const eas = JSON.parse(fs.readFileSync(path.join(result.work, "eas.json")));
  assert.equal(eas.build.production.env.EAS_PROJECT_ID, PROJECT.projectId);
  assert.equal(eas.build.preview.env.EAS_PROJECT_ID, PROJECT.projectId);
  const build = mocked.calls.find((c) => c.args.includes("build"));
  assert.equal(build.config.env.EXPO_PUBLIC_USE_EMULATORS, "false");
  assert.equal(build.config.env.EXPO_PUBLIC_STORAGE_ENABLED, "false");
  assert.equal(build.args.includes("--auto-submit"), false);
  assert.equal(build.args.includes("--freeze-credentials"), true);
  assert.equal(build.args.includes("--non-interactive"), true);
});

test("missing or malformed returned project ID cannot start a build", async (t) => {
  const root = fixture(t),
    mocked = runner({ badId: "not-a-project" });
  await assert.rejects(execute(root, mocked), /kimliği/);
  assert.equal(
    mocked.calls.some((c) => c.args.includes("build")),
    false,
  );
  assert.equal(
    fs.existsSync(path.join(root, ".birarada-release/project.json")),
    false,
  );
});

test("a retry retains the selected EAS project rather than silently changing identity", async (t) => {
  const root = fixture(t),
    first = runner();
  await execute(root, first);
  const second = runner({ badId: "00000000-0000-4000-8000-000000000999" });
  await assert.rejects(execute(root, second), /projesi değişmiş/);
  assert.equal(
    second.calls.some((c) => c.args.includes("build")),
    false,
  );
  assert.deepEqual(
    JSON.parse(
      fs.readFileSync(path.join(root, ".birarada-release/project.json")),
    ),
    PROJECT,
  );
});

test("a failed cloud build propagates failure and never emits success", async (t) => {
  const root = fixture(t),
    mocked = runner({ failBuild: true }),
    lines = [];
  await assert.rejects(
    execute(root, mocked, { log: (line) => lines.push(line) }),
    /başarısız/,
  );
  assert.equal(
    lines.some((line) => line.startsWith("EAS komutu tamamlandı")),
    false,
  );
});

test("owned work folders do not overwrite an unrelated user directory", (t) => {
  const root = fixture(t),
    directory = path.join(root, ".birarada-release");
  fs.mkdirSync(directory);
  fs.writeFileSync(path.join(directory, "my-file.txt"), "keep");
  assert.throws(() => ownedState(root), /ait değil/);
  assert.equal(
    fs.readFileSync(path.join(directory, "my-file.txt"), "utf8"),
    "keep",
  );
});

test("a second helper cannot replace a running build's working files", async (t) => {
  const root = fixture(t),
    state = ownedState(root),
    mocked = runner();
  fs.writeFileSync(
    path.join(state, "run.lock"),
    JSON.stringify({ pid: process.pid, nonce: "fixture-lock" }),
  );
  await assert.rejects(execute(root, mocked), /zaten çalışıyor/);
  assert.equal(mocked.calls.length, 0);
  assert.equal(
    JSON.parse(fs.readFileSync(path.join(state, "run.lock"))).nonce,
    "fixture-lock",
  );
});

test("Windows npm commands reject shell metacharacters and locate Chrome or Edge", () => {
  for (const arg of ["a & echo fail", "$(fail)", "`fail`", "x;fail", "a|fail"])
    assert.throws(() => commandSpec("npm", [arg], "win32"), /Güvensiz/);
  assert.deepEqual(
    commandSpec("npx", ["--yes", "eas-cli@25.2.0", "init"], "win32"),
    ["cmd.exe", ["/d", "/s", "/c", "npx --yes eas-cli@25.2.0 init"]],
  );
  assert.equal(
    chromePath(
      { CHROMIUM_PATH: "installed-browser" },
      (p) => p === "installed-browser",
    ),
    "installed-browser",
  );
  assert.equal(
    chromePath({ CHROMIUM_PATH: "missing" }, () => false),
    null,
  );
});

test("staged production config resolves with actual Expo tooling in an isolated fixture", (t) => {
  const root = fixture(t);
  fs.rmSync(path.join(root, "node_modules"), { recursive: true });
  fs.symlinkSync(
    path.join(actualRoot, "node_modules"),
    path.join(root, "node_modules"),
    process.platform === "win32" ? "junction" : "dir",
  );
  const work = prepareProject(root, ownedState(root), validProject(PROJECT));
  const output = spawnSync(
    process.execPath,
    [path.join(actualRoot, "node_modules/expo/bin/cli"), "config", "--json"],
    {
      cwd: work,
      encoding: "utf8",
      env: {
        ...process.env,
        APP_ENV: "production",
        EAS_PROJECT_ID: PROJECT.projectId,
        EXPO_ACCOUNT_OWNER: PROJECT.owner,
        EXPO_PUBLIC_USE_EMULATORS: "false",
        EXPO_PUBLIC_STORAGE_ENABLED: "false",
        EXPO_NO_TELEMETRY: "1",
      },
    },
  );
  assert.equal(output.status, 0, output.stderr);
  const cfg = JSON.parse(output.stdout);
  assert.equal(cfg.android.package, "com.birarada.app");
  assert.equal(cfg.android.versionCode, 6);
  assert.equal(cfg.ios.bundleIdentifier, "com.birarada.app");
  assert.equal(cfg.extra.eas.projectId, PROJECT.projectId);
});

test("Windows browser discovery accepts actual mixed-case process.env keys after copying", () => {
  const cases = [
    [
      { ProgramFiles: "C:\\Program Files" },
      "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    ],
    [
      { "ProgramFiles(x86)": "C:\\Program Files (x86)" },
      "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    ],
    [
      { ProgramW6432: "D:\\Program Files" },
      "D:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    ],
    [
      { LocalAppData: "C:\\Users\\Ahmed Berat\\AppData\\Local" },
      "C:\\Users\\Ahmed Berat\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe",
    ],
    [
      { LOCALAPPDATA: "C:\\Users\\Çağrı\\AppData\\Local" },
      "C:\\Users\\Çağrı\\AppData\\Local\\Microsoft\\Edge\\Application\\msedge.exe",
    ],
  ];
  for (const [environment, executable] of cases) {
    assert.equal(
      chromePath({ ...environment }, (file) => file === executable, "win32"),
      executable,
    );
  }
});

test("explicit browser paths accept surrounding CMD quotes without falling back from a missing override", () => {
  const executable =
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
  assert.equal(
    chromePath(
      { Chromium_Path: `"${executable}"` },
      (file) => file === executable,
      "win32",
    ),
    executable,
  );
  assert.equal(
    chromePath(
      { CHROMIUM_PATH: "missing", ProgramFiles: "C:\\Program Files" },
      (file) => file === executable,
      "win32",
    ),
    null,
  );
});

test("failed live verification prevents EAS access and production build", async (t) => {
  const root = fixture(t),
    mocked = runner({ failedTest: "release:live" });
  await assert.rejects(execute(root, mocked), /release:live/);
  assert.equal(
    mocked.calls.some(
      (c) => c.args.includes("whoami") || c.args.includes("build"),
    ),
    false,
  );
});
test("Windows BAT invokes the shared helper with a quoted path and the helper passes local preflight",()=>{
 const bat=fs.readFileSync(path.join(actualRoot,"AAB_OLUSTUR.bat"),"utf8");
 assert.ok(bat.includes('cd /d "%~dp0"'));
 assert.ok(bat.includes('node "%~dp0scripts\\build-no-github.cjs"'));
 assert.ok(!bat.includes('/*'));
 const result=spawnSync(process.execPath,[path.join(actualRoot,'scripts/build-no-github.cjs'),'--check'],{cwd:actualRoot,encoding:'utf8',env:{...process.env,...(process.platform==='linux'?{CHROMIUM_PATH:'/usr/bin/chromium'}:{})}});
 assert.equal(result.status,0,result.stderr);assert.match(result.stdout,/önkontrolü geçti/);
});
