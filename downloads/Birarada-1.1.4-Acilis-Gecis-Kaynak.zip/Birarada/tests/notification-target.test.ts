import {test} from "node:test";
import assert from "node:assert/strict";
import {notificationDestination,notificationText} from "../src/utils/notificationTarget";
test("push and inbox records share validated message, post and profile destinations",()=>{
 assert.deepEqual(notificationDestination({target:{chatId:"group-1"}}),{screen:"Conversation",params:{id:"group-1"}});
 assert.deepEqual(notificationDestination({target:{postId:"post-1"},sourceUid:"sender"}),{screen:"PostDetails",params:{id:"post-1"}});
 assert.deepEqual(notificationDestination({sourceUid:"sender"}),{screen:"User",params:{uid:"sender"}});
 assert.deepEqual(notificationDestination({chatId:"../../bad"}),{screen:"Notifications"});
 assert.match(notificationText({type:"like"},"deniz"),/@deniz.*beğendi/);
 assert.match(notificationText({type:"follow"},"deniz",true),/istiyor/);
});
