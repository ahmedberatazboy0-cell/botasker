import { test } from "node:test";
import assert from "node:assert/strict";
import { createLiveReads } from "../src/utils/liveReads";
test("identical screen subscriptions share a producer across rapid tab switches", async () => {
  const live = createLiveReads({ grace: 20, freshFor: 1000 });
  let starts = 0,
    stops = 0,
    refreshes = 0;
  let emit!: (v: number) => void;
  const start = (next: (v: number) => void) => {
    starts++;
    emit = next;
    return {
      stop: () => {
        stops++;
      },
      refresh: () => {
        refreshes++;
      },
    };
  };
  const a: number[] = [],
    b: number[] = [];
  const one = live.subscribe("alice:q", start, (v) => a.push(v));
  emit(1);
  one();
  const two = live.subscribe("alice:q", start, (v) => b.push(v));
  assert.equal(starts, 1);
  assert.deepEqual(b, [1]);
  assert.equal(refreshes, 0);
  two();
  await new Promise((r) => setTimeout(r, 30));
  assert.equal(stops, 1);
  live.clear();
});
test("clearing the auth session stops producers and a denied read is never replayed", () => {
  const live = createLiveReads();
  let fail!: (e: any) => void;
  let stops = 0,
    refreshes = 0;
  const start = (next: (v: number) => void, error: (e: any) => void) => {
    fail = error;
    next(1);
    return { stop: () => stops++, refresh: () => refreshes++ };
  };
  live.subscribe("alice", start, () => {});
  fail({ code: "permission-denied" });
  const values: number[] = [];
  live.subscribe("alice", start, (v) => values.push(v));
  assert.deepEqual(values, []);
  assert.equal(refreshes, 1);
  live.clear();
  assert.equal(stops, 1);
});
