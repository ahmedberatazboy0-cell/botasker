import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { harness } from "./free-harness";
import { encode, Timestamp } from "../supabase/functions/birarada/records";
test("real follow, like, group and message writes enqueue targeted high-priority push and preserve failures", async (t) => {
  const h = await harness();
  const sent: any[] = [];
  h.deps.push = async (messages) => {
    sent.push(...messages);
    return { data: messages.map(() => ({ status: "ok", id: randomUUID() })) };
  };
  const commit = async (who: string, path: string, data: any) => {
    const old = await h.db.doc(path).get();
    const r = await h.request(who, "documents", {
      operation: "commit",
      reads: [{ path, rev: old.raw.rev }],
      writes: [{ kind: "set", path, data: encode(data) }],
    });
    assert.equal(r.status, 200, await r.text());
  };
  try {
    for (const uid of ["alice", "bob", "eve"]) {
      await h.db.doc("users/" + uid).set({
        uid,
        username: uid + "_user",
        displayName: uid,
        isPrivate: false,
        deletionPending: false,
        allowStrangerDM: true,
        createdAt: Timestamp.now(),
      });
      assert.equal(
        (
          await h.call(uid, "registerPush", {
            token: `ExpoPushToken[test-${uid}]`,
            installation: randomUUID() + randomUUID(),
          })
        ).status,
        200,
      );
    }
    await h.db.doc("users/alice").update({ isPrivate: true });
    await t.test(
      "follow requests reach only the target installation",
      async () => {
        const path = "follows/bob_alice",
          n = "notifications/bob_alice";
        const r = await h.request("bob", "documents", {
          operation: "commit",
          reads: [],
          writes: [
            {
              kind: "set",
              path,
              data: encode({
                followerUid: "bob",
                followingUid: "alice",
                status: "pending",
                createdAt: Timestamp.now(),
              }),
            },
            {
              kind: "set",
              path: n,
              data: encode({
                sourceUid: "bob",
                targetUid: "alice",
                type: "follow",
                text: "follow",
                read: false,
                createdAt: Timestamp.now(),
              }),
            },
          ],
        });
        assert.equal(r.status, 200, await r.text());
        const notice = sent.find((m) => m.data.type === "follow");
        assert.ok(notice);
        assert.equal(notice.to, "ExpoPushToken[test-alice]");
        assert.match(notice.body, /@bob_user.*takip etmek istiyor/);
        assert.equal(notice.priority, "high");
        assert.equal(notice.channelId, "social");
        assert.equal(notice.data.targetUid, "alice");
      },
    );
    await h.db.doc("users/alice").update({ isPrivate: false });
    const postId = randomUUID();
    assert.equal(
      (
        await h.call("alice", "publishContent", {
          requestId: postId,
          kind: "post",
          caption: "notification test",
          mediaIds: [],
        })
      ).status,
      200,
    );
    await t.test(
      "a like links to the real post rather than the sender profile",
      async () => {
        await commit("bob", `posts/${postId}/likes/bob`, {
          uid: "bob",
          createdAt: Timestamp.now(),
        });
        const notice = sent.find((m) => m.data.type === "like");
        assert.ok(notice);
        assert.equal(notice.data.postId, postId);
        assert.match(notice.body, /@bob_user.*beğendi/);
      },
    );
    let chatId = "";
    await t.test(
      "group creation and messages target all other members without disclosing message text",
      async () => {
        const created = await h.call("alice", "createChat", {
          members: ["bob", "eve"],
          group: true,
          title: "Deneme Grubu",
          requestId: randomUUID(),
        });
        assert.equal(created.status, 200, JSON.stringify(created));
        chatId = created.data.id;
        assert.deepEqual(
          sent
            .filter((m) => m.data.type === "group")
            .map((m) => m.data.targetUid)
            .sort(),
          ["bob", "eve"],
        );
        const r = await h.call("alice", "sendMessage", {
          chatId,
          requestId: randomUUID(),
          text: "PRIVATE_MESSAGE_BODY",
          mediaIds: [],
        });
        assert.equal(r.status, 200, JSON.stringify(r));
        const notices = sent.filter((m) => m.data.type === "message");
        assert.deepEqual(notices.map((m) => m.data.targetUid).sort(), [
          "bob",
          "eve",
        ]);
        assert.ok(
          notices.every(
            (m) =>
              m.data.chatId === chatId &&
              !m.body.includes("PRIVATE_MESSAGE_BODY") &&
              m.data.notificationId,
          ),
        );
        assert.equal(
          (await h.call("bob", "leaveGroup", { chatId })).status,
          200,
        );
        const before = sent.length;
        await h.call("alice", "sendMessage", {
          chatId,
          requestId: randomUUID(),
          text: "after leaving",
          mediaIds: [],
        });
        assert.equal(
          sent.slice(before).filter((m) => m.data.targetUid === "bob").length,
          0,
        );
      },
    );
    await t.test(
      "self-test is scoped, idempotent and status never exposes device tokens",
      async () => {
        const requestId = randomUUID();
        const first = await h.call("alice", "testPush", { requestId });
        assert.equal(first.status, 200);
        const other = await h.call("bob", "testPush", { requestId });
        assert.equal(other.status, 200);
        assert.notEqual(first.data.id, other.data.id);
        const before = sent.length;
        await h.call("alice", "testPush", { requestId });
        assert.equal(sent.length, before);
        const status = await h.call("alice", "pushStatus", {});
        assert.equal(status.status, 200);
        assert.equal(status.data.devices[0].status, "accepted");
        assert.ok(!JSON.stringify(status.data).includes("ExpoPushToken"));
      },
    );
    await t.test(
      "credential failures stay in the outbox and a dead device is removed",
      async () => {
        h.deps.push = async (messages) => ({
          data: messages.map(() => ({
            status: "error",
            details: { error: "InvalidCredentials" },
          })),
        });
        await commit("eve", `posts/${postId}/likes/eve`, {
          uid: "eve",
          createdAt: Timestamp.now(),
        });
        const queued = await h.pg.query<{ count: number }>(
          "select count(*)::int count from public.birarada_jobs",
        );
        assert.ok(queued.rows[0]!.count > 0);
        assert.ok(
          (
            await h.db
              .collection("pushDevices")
              .where("uid", "==", "alice")
              .get()
          ).size > 0,
        );
        h.deps.push = async (messages) => ({
          data: messages.map(() => ({
            status: "error",
            details: { error: "DeviceNotRegistered" },
          })),
        });
        await h.pg.exec("update public.birarada_jobs set available_at=now()");
        await h.call("eve", "appConfig", {});
        assert.equal(
          (
            await h.db
              .collection("pushDevices")
              .where("uid", "==", "alice")
              .get()
          ).size,
          0,
        );
      },
    );
  } finally {
    await h.pg.close();
  }
});
