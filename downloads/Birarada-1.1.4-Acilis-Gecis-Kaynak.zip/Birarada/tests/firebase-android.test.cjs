"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  fs = require("node:fs"),
  os = require("node:os"),
  path = require("node:path");
const {
  validateAndroidConfig,
  requireAndroidConfig,
} = require("../scripts/firebase-android.cjs");
const valid = () => ({
  project_info: {
    project_id: "birarada-5650c",
    project_number: "510479812993",
  },
  client: [
    {
      client_info: {
        android_client_info: { package_name: "com.birarada.app" },
        mobilesdk_app_id: "1:510479812993:android:0000000000000000000000",
      },
      api_key: [{ current_key: "AIza" + "A".repeat(35) }],
    },
  ],
});
test("Android push config rejects another Firebase project/package and incomplete SDK files", () => {
  assert.doesNotThrow(() => validateAndroidConfig(valid()));
  for (const change of [
    (c) => (c.project_info.project_id = "other"),
    (c) => (c.project_info.project_number = "0"),
    (c) =>
      (c.client[0].client_info.android_client_info.package_name = "other.app"),
    (c) => delete c.client[0].api_key,
    (c) => (c.client[0].client_info.mobilesdk_app_id = "web-id"),
    (c) => (c.private_key = "forbidden"),
  ]) {
    const value = valid();
    change(value);
    assert.throws(() => validateAndroidConfig(value));
  }
});
test("Android push config must be a real file and never a symlink", () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "birarada-push-config-"));
  try {
    assert.throws(() => requireAndroidConfig(root));
    const target = path.join(root, "google-services.json");
    fs.writeFileSync(target, JSON.stringify(valid()));
    assert.doesNotThrow(() => requireAndroidConfig(root));
    if (process.platform !== "win32") {
      fs.renameSync(target, target + ".real");
      fs.symlinkSync(target + ".real", target);
      assert.throws(() => requireAndroidConfig(root));
    }
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});
