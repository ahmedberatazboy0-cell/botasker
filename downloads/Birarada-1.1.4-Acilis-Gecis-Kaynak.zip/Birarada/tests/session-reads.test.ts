import { test } from "node:test";
import assert from "node:assert/strict";
import { createSessionReads, stableKey } from "../src/utils/sessionReads";
test("warm screen results are immediately available while a slow fresh read is pending", async () => {
  const cache = createSessionReads();
  await cache.load("alice", "feed", async () => [1]);
  let finish!: (x: number[]) => void;
  const update = cache.load(
    "alice",
    "feed",
    () => new Promise<number[]>((r) => (finish = r)),
  );
  await Promise.resolve();
  assert.deepEqual(cache.peek("alice", "feed"), [1]);
  finish([2]);
  await update;
  assert.deepEqual(cache.peek("alice", "feed"), [2]);
});
test("session isolation, expiry, access denial and bounded capacity preserve privacy", async () => {
  let clock = 1;
  const cache = createSessionReads({ ttl: 10, maximum: 2, now: () => clock });
  await cache.load("alice", "a", async () => [1]);
  assert.equal(cache.peek("bob", "a"), undefined);
  clock = 12;
  assert.equal(cache.peek("alice", "a"), undefined);
  await cache.load("alice", "a", async () => [1]);
  await assert.rejects(
    cache.load("alice", "a", async () => {
      throw Object.assign(Error("denied"), { code: "permission-denied" });
    }),
  );
  assert.equal(cache.peek("alice", "a"), undefined);
  for (const k of ["a", "b", "c"]) await cache.load("alice", k, async () => k);
  assert.equal(cache.peek("alice", "a"), undefined);
  cache.clear();
  assert.equal(cache.peek("alice", "b"), undefined);
});
test("invalidated or previous-session responses never repopulate the cache", async () => {
  const cache = createSessionReads();
  let finish!: (v: number) => void;
  const old = cache.load(
    "alice",
    "a",
    () => new Promise<number>((r) => (finish = r)),
  );
  await Promise.resolve();
  cache.invalidate("alice");
  finish(1);
  await old;
  assert.equal(cache.peek("alice", "a"), undefined);
  let next!: (v: number) => void;
  const work = cache.load(
    "alice",
    "b",
    () => new Promise<number>((r) => (next = r)),
  );
  await Promise.resolve();
  cache.clear();
  next(2);
  await work;
  assert.equal(cache.peek("alice", "b"), undefined);
  assert.equal(stableKey({ b: 2, a: 1 }), stableKey({ a: 1, b: 2 }));
});
