import { test } from "node:test";
import assert from "node:assert/strict";
import { createSingleFlight } from "../supabase/functions/birarada/singleFlight";
test("account lookups coalesce overlaps but always recheck the next request", async () => {
  const read = createSingleFlight<number>();
  let calls = 0,
    finish!: (v: number) => void;
  const job = () => {
    calls++;
    return new Promise<number>((r) => (finish = r));
  };
  const first = read("token", job),
    second = read("token", job);
  await Promise.resolve();
  finish(1);
  assert.deepEqual(await Promise.all([first, second]), [1, 1]);
  assert.equal(calls, 1);
  await read("token", async () => {
    calls++;
    return 2;
  });
  assert.equal(calls, 2);
  await assert.rejects(
    read("bad", async () => {
      throw Error("revoked");
    }),
  );
  assert.equal(await read("bad", async () => 3), 3);
});
