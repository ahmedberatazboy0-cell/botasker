import { test } from "node:test";
import assert from "node:assert/strict";
import { harness } from "./free-harness";
test("temporary identity transport outage returns retryable 503 while invalid authentication remains 401", async () => {
  const h = await harness();
  try {
    h.deps.identify = async () => {
      throw Object.assign(Error("upstream detail"), { code: "unavailable" });
    };
    const retry = await h.request("alice", "socialApi", {
      action: "appConfig",
    });
    assert.equal(retry.status, 503);
    assert.equal((await retry.json()).error.code, "unavailable");
    h.deps.identify = async () => {
      throw Error("revoked");
    };
    assert.equal(
      (await h.request("alice", "socialApi", { action: "appConfig" })).status,
      401,
    );
  } finally {
    await h.pg.close();
  }
});
