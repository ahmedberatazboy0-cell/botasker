@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title Birarada - AAB Olustur
where.exe node >nul 2>nul
if errorlevel 1 (
  echo Node.js bulunamadi. https://nodejs.org/ adresinden LTS surumunu kur.
  pause
  exit /b 1
)
node "%~dp0scripts\build-no-github.cjs"
set "BIRARADA_BUILD_EXIT=%errorlevel%"
pause
exit /b %BIRARADA_BUILD_EXIT%
