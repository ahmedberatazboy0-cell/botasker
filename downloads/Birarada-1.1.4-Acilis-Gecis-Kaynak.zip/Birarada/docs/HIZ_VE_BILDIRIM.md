# Birarada 1.1.4: yükleme, mesajlar ve bildirimler

29 Ekim 2026. `com.birarada.app`, **1.1.4/code6**, Edge **2026-10-27-instant1**. Hesaplar, veritabanı şeması, EAS projesi ve upload imzası korunur.

## Ekranların açılması

1.1.4 ile sabit 1,4 saniyelik açılış beklemesi kaldırıldı. Ziyaret edilmiş profilin başlığı ve sayaçları, bellekteki okuma süresi dolmuş olsa da ekran yerinde dururken yeniden doğrulanır. Bu işlem diske kalıcı veri yazmaz ve ilk oturum doğrulamasını atlamaz.

- Oturum profili ve gerekli onaylar doğrulandıktan sonra ana sayfanın yüklenmesini beklemeden kendi gönderilerin, gelen kutun, ilk 10 sohbetteki kişilerin profilleri ve son iki konuşmanın 100 mesajı sınırlı olarak ön yüklenir. Kendi profil başlığı mevcut oturum profilinden gelir.
- Önceden yetkili olarak okunan veriler yalnız çalışan oturumun belleğinde tutulur; disk önbelleği oluşturulmaz. Bellek en fazla 80 okuma ve 60 saniye ile sınırlıdır. Ekran güncel veriyi arka planda yeniden ister; soğuk ağ gecikmesi ortadan kalkmış sayılmaz.
- Aynı sorgunun dinleyicileri paylaşılır. Profil ve konuşma üst bilgisi sorguları ekran gizlendiğinde durur; geçici sohbet hatası sonraki başarılı okumada temizlenir. Hızlı sekme dönüşleri yeni bir sorgu fırtınası yaratmaz. Aynı anda başlayan Google hesap doğrulaması birleştirilir; sonraki istek güncel hesabı yeniden kontrol eder. Rol, kısıtlama ve engeller her sunucu isteğinde denetlenir.
- Oturum değişimi önbelleği temizler; izin reddi ilgili veriyi kaldırır. Yazımlar ilgili ekranları geçersizleştirip yeniler. Gönderi ve hesap gizliliği sunucuda korunur.
- Mesaj gönderirken “Gönderiliyor…” balonu gösterilir. Başarılı sunucu yanıtı gelmeden mesaj gönderilmiş sayılmaz; başarısızlıkta taslak korunur. Geçmiş mesaj sorgusu ve ön yükleme aynı 100 mesaj sınırını kullanır.
- Ayarlar → **Bağlantı kontrolü** gerçek telefondan sunucu ve oturumlu okuma sürelerini ölçer, sürüm/kodu gösterir. Mesaj veya giriş anahtarı kaydetmez.

## Uygulama içi bildirim

Takip isteği/takip, beğeni, yorum, mesaj ve gruba eklenme için üstten animasyonlu kart ve okunmamış sayaç bulunur. İlk açılışta eski bildirimler tekrar oynatılmaz. Mesaj bildirimi ilgili konuşmaya, beğeni ilgili gönderiye, takip profile gider. Açık konuşmadaki yeni mesaj için ikinci bir kart gösterilmez. Uygulama öndeyken yeni kayıtlar 3 saniyede sorgulanır; bu polling süresi anlık teslim garantisi değildir.

## Telefon bildirimi kurulumu

1. ZIP'i yeni klasöre tamamen çıkar; **GUNCELLE_VE_AAB.bat** çalıştır. Mevcut Edge sunucusu güncellenir. Testler atlanmadan AAB aşamasına geçilir.
2. Derleyici, Firebase Android açık yapılandırmasını `npm run notifications:setup` ile resmî Firebase CLI üzerinden alır. Gerekirse doğru Firebase projesinde `com.birarada.app` Android kaydı oluşturulur. Bu işlem Blaze açmaz, imzayı değiştirmez. Yanlış proje/paket veya eksik dosya derlemeyi durdurur.
3. **BILDIRIM_KUR.bat** resmî Expo Android credentials ekranını açar. Mevcut proje → **production → Google Service Account → Push Notifications (FCM V1)** bölümünde geçerli FCM v1 yetkisi bulunmalı. Mevcut Android keystore'u değiştirme. Özel servis hesabı anahtarını sohbete, GitHub'a veya kaynak klasörüne koyma; yalnız resmî sağlayıcı akışında kullan.
4. Yeni AAB'yi mevcut Play test kanalına yükle; telefonda güncelle. Uygulamada **Telefon bildirimlerini aç** ve Android iznini onayla. Önceden izin verdiysen kayıt yeni oturumda güncellenir.
5. **Bildirimler → Deneme bildirimi gönder**. Uygulamayı arka plana alıp gerçek teslimi kontrol et. **Bildirim bağlantısını kontrol et** cihaz kaydı/son Expo gönderim durumunu gösterir. `InvalidCredentials`, EAS FCM v1 yetkisinin kontrol edilmesi gerektiğini belirtir.

Expo'nun isteği kabul etmesi telefona teslim edildiği anlamına gelmez. Android izinleri, pil tasarrufu, ağ, sağlayıcı durumu ve FCM yetkileri teslimi etkiler. Bu çalışma ortamında Expo/Firebase oturumu ve fiziksel Android cihazı olmadığı için gerçek teslim doğrulanmadı. iOS push ayrıca APNs yetkisi gerektirir; Android kurulumu bunu yapmaz.

Sunucu bildirimleri toplu ve yüksek öncelikli gönderir; grup oluşturma ve mesajlar diğer mevcut üyelere yönlendirilir. Push metnine özel mesaj içeriği eklenmez. Geçici/FCM yetki hataları kalıcı iş kuyruğunda yeniden denemeye bırakılır; geçersiz cihaz kaydı kaldırılır. Yeniden deneme sonraki API trafiğiyle çalışır; mevcut SQL kuyruğu başarısız denemeyi 5 dakika erteler ve en fazla 20 kez dener. Sürekli çalışan ücretsiz cron servisi eklenmedi. Expo gönderim makbuzları ayrıca sorgulanmaz; durum ekranı yalnız ilk gönderim kabulünü/hatasını gösterir. Okunmuş/iptal edilmiş, eski, engellenmiş veya artık görünür olmayan kayıtlar gönderilmez.

Buradaki telefon bildirimleri **push** bildirimidir. Operatör SMS hizmeti bağlı değildir.

## İki hesapla cihaz kontrolü

- A herkese açık fotoğraf/video paylaşır; B ana sayfa/Keşfet'te görür. Gizli gönderi yalnız izinli hesaplara görünmeli.
- B, A'nın gönderisini beğenir; A uygulama açıkken animasyonu, arka plandayken telefon bildirimini kontrol eder. Dokunma doğru gönderiyi açmalı.
- Gizli A'ya B takip isteği gönderir; A kabul eder, B'nin ilişki durumu güncellenir.
- A grup kurar; B gruba eklenme bildirimini alır. İki yönde mesaj/yanıt/tepki gönderilir; gruptan çıkan kullanıcı yeni grup mesajı almamalı.
- Profil ve sohbetler arasında geçiş yap; veri görünür kalmalı. Gerçek soğuk bağlantı yavaşsa Bağlantı kontrolü sonuçlarını sürümle birlikte kaydet.

Yerel otomatik testlerin ayrıntılı sonuçları [TEST_REPORT.md](../TEST_REPORT.md). Bu kaynak ZIP'i yeni imzalı AAB veya Play onayı değildir.
