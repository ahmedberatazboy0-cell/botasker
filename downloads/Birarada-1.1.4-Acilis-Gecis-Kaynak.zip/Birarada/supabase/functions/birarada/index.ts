declare const EdgeRuntime: { waitUntil(work: Promise<unknown>): void };
import { createRemoteJWKSet, jwtVerify } from "npm:jose@6.1.0";
import { createSingleFlight } from "./singleFlight.ts";
import { handle, type Storage } from "./gateway.ts";
import type { Driver } from "./records.ts";
import type { Identity } from "./context.ts";
const PROJECT = "birarada-5650c",
  REF = "qinevhhhdtslnzrtcanq";
const base = Deno.env.get("SUPABASE_URL")!,
  key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
if (new URL(base).hostname !== REF + ".supabase.co" || !key) {
  throw Error("Birarada project configuration mismatch");
}
const headers = { apikey: key, Authorization: `Bearer ${key}` };
const driver: Driver = {
  async rpc(name, input) {
    try {
      const response = await fetch(base + "/rest/v1/rpc/" + name, {
        method: "POST",
        headers: { ...headers, "Content-Type": "application/json" },
        body: JSON.stringify(input),
        signal: AbortSignal.timeout(10000),
      });
      const data = await response.json();
      return response.ok
        ? { data, error: null }
        : { data: null, error: { code: data.code, message: data.message } };
    } catch {
      return {
        data: null,
        error: { code: "unavailable", message: "Database unavailable" },
      };
    }
  },
};
const storage: Storage = {
  async save(path, bytes, type) {
    const response = await fetch(
      base + "/storage/v1/object/birarada-media/" + path,
      {
        method: "POST",
        headers: {
          ...headers,
          "Content-Type": type,
          "x-upsert": "true",
          "Cache-Control": "private, no-store",
        },
        body: new Uint8Array(bytes).buffer,
      },
    );
    if (!response.ok) throw Error("Private media upload failed");
  },
  async remove(path) {
    if (!/^private\/[a-zA-Z0-9_:\-]+\/[a-f0-9-]{36}$/i.test(path)) {
      throw Error("Invalid object path");
    }
    const response = await fetch(base + "/storage/v1/object/birarada-media", {
      method: "DELETE",
      headers: { ...headers, "Content-Type": "application/json" },
      body: JSON.stringify({ prefixes: [path] }),
    });
    if (!response.ok && response.status !== 404) {
      throw Error("Private media removal failed");
    }
  },
  async read(path, start, end) {
    if (!/^private\/[a-zA-Z0-9_:\-]+\/[a-f0-9-]{36}$/i.test(path)) {
      throw Error("Invalid object path");
    }
    return fetch(
      base + "/storage/v1/object/authenticated/birarada-media/" + path,
      { headers: { ...headers, Range: `bytes=${start}-${end}` } },
    );
  },
  async health() {
    const response = await fetch(base + "/storage/v1/bucket/birarada-media", {
      headers,
    });
    if (!response.ok) return false;
    const bucket = await response.json();
    return bucket.id === "birarada-media" && bucket.public === false;
  },
};
const jwks = createRemoteJWKSet(
  new URL(
    "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com",
  ),
);
const accountLookup = createSingleFlight<any>();
async function identify(token: string): Promise<Identity> {
  const { payload } = await jwtVerify(token, jwks, {
    issuer: "https://securetoken.google.com/" + PROJECT,
    audience: PROJECT,
    algorithms: ["RS256"],
  });
  if (
    !payload.sub ||
    typeof payload.auth_time !== "number" ||
    typeof payload.iat !== "number"
  )
    throw Error("Invalid Firebase identity");
  // Current account lookup catches disabled/deleted users and revoked authentication.
  const user = await accountLookup(token, async () => {
    const unavailable = () =>
      Object.assign(Error("Identity service unavailable"), {
        code: "unavailable",
      });
    const response = await fetch(
      "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyC2TYgUREM8QWSg_RcunLQfnb_GXGboHT8",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken: token }),
        signal: AbortSignal.timeout(12000),
      },
    ).catch(() => {
      throw unavailable();
    });
    if (response.status === 429 || response.status >= 500) throw unavailable();
    const result = await response.json().catch(() => {
      throw unavailable();
    });
    if (!response.ok) throw Error("Invalid Firebase session");
    return result.users?.[0];
  });
  if (
    !user ||
    user.localId !== payload.sub ||
    user.disabled ||
    Number(user.validSince || 0) > payload.auth_time
  )
    throw Error("Invalid Firebase session");
  return {
    uid: payload.sub,
    email: user.email || "",
    emailVerified: user.emailVerified === true,
    authTime: payload.auth_time,
    issuedAt: payload.iat,
  };
}
Deno.serve((request) =>
  handle(request, {
    driver,
    storage,
    identify,
    background: (work) => EdgeRuntime.waitUntil(work),
    push: async (messages) => {
      const response = await fetch("https://exp.host/--/api/v2/push/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(messages),
        signal: AbortSignal.timeout(12000),
      });
      if (!response.ok) throw Error("Push unavailable");
      return response.json();
    },
  }),
);
