// Coalesce only overlapping lookups. Never retain a successful account lookup.
export function createSingleFlight<T>(maximum = 128) {
  const pending = new Map<string, Promise<T>>();
  return (key: string, read: () => Promise<T>): Promise<T> => {
    const existing = pending.get(key);
    if (existing) return existing;
    const work = Promise.resolve()
      .then(read)
      .finally(() => {
        if (pending.get(key) === work) pending.delete(key);
      });
    if (pending.size < maximum) pending.set(key, work);
    return work;
  };
}
