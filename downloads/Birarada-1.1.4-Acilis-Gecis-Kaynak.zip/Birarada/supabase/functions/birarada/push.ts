import type { Records } from "./records.ts";
import {
  active,
  blocked,
  cachedRecord,
  primeRecords,
  seedReadRecords,
  visible,
  withReadCache,
} from "./core.ts";
type Job = { id: any; kind: string; payload: { path: string } };
export async function deliverPushJobs(
  db: Records,
  jobs: Job[],
  send?: (messages: any[]) => Promise<any>,
) {
  const outcomes = new Map(jobs.map((job) => [job.id, false]));
  try {
    await withReadCache(async () => {
      const notices = await db.getAll(
        ...jobs.map((job) => db.doc(job.payload.path)),
      );
      seedReadRecords(notices);
      const byPath = new Map(notices.map((row) => [row.raw.path, row]));
      const paths: string[] = [];
      for (const row of notices) {
        const n = row.data();
        if (!n) continue;
        for (const uid of [n.sourceUid, n.targetUid])
          paths.push(`users/${uid}`, `accountStatus/${uid}`);
        paths.push(
          `users/${n.sourceUid}/blocks/${n.targetUid}`,
          `users/${n.targetUid}/blocks/${n.sourceUid}`,
        );
        if (n.type === "follow" || n.type === "request")
          paths.push(`follows/${n.sourceUid}_${n.targetUid}`);
        if (n.target?.postId) paths.push(`posts/${n.target.postId}`);
        if (n.target?.chatId) paths.push(`chats/${n.target.chatId}`);
      }
      await primeRecords(paths);
      const ready: { job: Job; n: any; body: string; target: any }[] = [];
      for (const job of jobs) {
        const row = byPath.get(job.payload.path),
          n = row?.data();
        if (
          !n ||
          n.read ||
          !(await active(n.targetUid)) ||
          !(await active(n.sourceUid)) ||
          (await blocked(n.sourceUid, n.targetUid)) ||
          n.createdAt?.toMillis() < Date.now() - 86400000
        ) {
          outcomes.set(job.id, true);
          continue;
        }
        const person = await cachedRecord(`users/${n.sourceUid}`),
          name = person?.username ? "@" + person.username : "Birisi";
        let body =
            n.type === "test"
              ? "Birarada deneme bildirimi."
              : "Yeni bir bildirimin var.",
          target: any = { userId: n.sourceUid };
        if (n.type === "follow" || n.type === "request") {
          const relation = await cachedRecord(
            `follows/${n.sourceUid}_${n.targetUid}`,
          );
          if (!relation) {
            outcomes.set(job.id, true);
            continue;
          }
          body =
            relation.status === "pending"
              ? `${name} seni takip etmek istiyor.`
              : `${name} seni takip etmeye başladı.`;
        } else if (n.type === "message" || n.type === "group") {
          const chatId = n.target?.chatId,
            chat = chatId && (await cachedRecord(`chats/${chatId}`));
          if (!chat?.memberIds?.includes(n.targetUid)) {
            outcomes.set(job.id, true);
            continue;
          }
          body =
            n.type === "group"
              ? `${name} seni bir gruba ekledi.`
              : `${name} sana mesaj gönderdi.`;
          target = { chatId };
        } else if (n.type === "like" || n.type === "comment") {
          const postId = n.target?.postId,
            post = postId && (await cachedRecord(`posts/${postId}`));
          if (!post || !(await visible(n.targetUid, post))) {
            outcomes.set(job.id, true);
            continue;
          }
          body =
            n.type === "like"
              ? `${name} gönderini beğendi.`
              : `${name} gönderine yorum yaptı.`;
          target = { postId };
        }
        ready.push({ job, n, body, target });
      }
      const targets = [...new Set(ready.map((item) => item.n.targetUid))];
      if (!targets.length) return;
      const devices = await db
        .collection("pushDevices")
        .where("uid", "in", targets)
        .where("enabled", "==", true)
        .limit(100)
        .get();
      const messages: any[] = [],
        owners: { job: Job; device: any }[] = [];
      for (const item of ready) {
        const own = devices.docs
          .filter((d) => d.get("uid") === item.n.targetUid)
          .slice(0, 10);
        if (!own.length) {
          outcomes.set(item.job.id, true);
          continue;
        }
        for (const device of own) {
          messages.push({
            to: device.get("token"),
            title: "Birarada",
            body: item.body,
            sound: "default",
            priority: "high",
            channelId: "social",
            ttl: 3600,
            data: {
              ...item.target,
              targetUid: item.n.targetUid,
              sourceUid: item.n.sourceUid,
              type: item.n.type,
              notificationId: item.job.payload.path.split("/").at(-1),
            },
          });
          owners.push({ job: item.job, device });
        }
      }
      if (!messages.length || !send) return;
      const reply = await send(messages),
        tickets = reply?.data;
      if (!Array.isArray(tickets) || tickets.length !== messages.length) return;
      const failed = new Set<any>();
      for (let i = 0; i < tickets.length; i++) {
        const ticket = tickets[i],
          owner = owners[i]!;
        if (
          ticket?.status === "error" &&
          ticket.details?.error === "DeviceNotRegistered"
        )
          await owner.device.ref.delete();
        else {
          const code =
            typeof ticket?.details?.error === "string"
              ? ticket.details.error
              : "";
          const valid =
            ticket?.status === "ok" && typeof ticket.id === "string";
          if (!valid) failed.add(owner.job.id);
          await owner.device.ref.update({
            lastTicketStatus: valid ? "accepted" : "error",
            lastErrorCode: [
              "InvalidCredentials",
              "MessageTooBig",
              "MessageRateExceeded",
            ].includes(code)
              ? code
              : valid
                ? ""
                : "PushUnavailable",
            ...(valid ? { lastAcceptedAt: Date.now() } : {}),
          });
        }
      }
      for (const owner of owners)
        outcomes.set(owner.job.id, !failed.has(owner.job.id));
    });
  } catch {
    /* Keep failures in the durable outbox; inbox records remain intact. */
  }
  for (const job of jobs)
    await db.rpc("birarada_finish_job", {
      job_id: job.id,
      success: outcomes.get(job.id) === true,
    });
}
