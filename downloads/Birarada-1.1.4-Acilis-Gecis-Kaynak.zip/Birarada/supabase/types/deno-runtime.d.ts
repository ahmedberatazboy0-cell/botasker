// Minimal runtime surface for offline type checking; deployment uses native Deno.
declare const Deno: {
  env: {get(name: string): string | undefined};
  serve(handler: (request: Request) => Response | Promise<Response>): unknown;
};
