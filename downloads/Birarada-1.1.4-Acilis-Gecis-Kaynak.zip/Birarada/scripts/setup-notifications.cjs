"use strict";
const fs = require("node:fs"),
  path = require("node:path"),
  os = require("node:os"),
  { spawnSync } = require("node:child_process");
const {
  validateAndroidConfig,
  requireAndroidConfig,
} = require("./firebase-android.cjs");
const root = path.resolve(__dirname, ".."),
  project = "birarada-5650c";
function main() {
  if (fs.existsSync(path.join(root, "google-services.json"))) {
    requireAndroidConfig(root);
    console.log(
      "Firebase Android acik yapilandirmasi dogrulandi. FCM v1 yetkisi EAS hesabinda ayrica bulunmali.",
    );
    return;
  }
  const cli = path.join(
    path.dirname(require.resolve("firebase-tools/package.json")),
    "lib/bin/firebase.js",
  );
  const run = (args, capture = false) => {
    const r = spawnSync(
      process.execPath,
      [cli, ...args, "--project", project],
      {
        cwd: root,
        env: process.env,
        encoding: "utf8",
        stdio: capture ? "pipe" : "inherit",
      },
    );
    if (r.error || r.status !== 0)
      throw Object.assign(
        Error(
          "Firebase Android kurulumu tamamlanmadi. Resmi Firebase girisini/proje erisimini kontrol et; sifre veya anahtar gonderme.",
        ),
        {
          authRequired:
            /not logged in|authentication required|firebase login|failed to authenticate/i.test(
              (r.stdout || "") + " " + (r.stderr || ""),
            ),
        },
      );
    return capture ? JSON.parse(r.stdout).result : undefined;
  };
  let apps;
  try {
    apps = run(["apps:list", "ANDROID", "--json"], true);
  } catch (e) {
    if (!e.authRequired) throw e;
    console.log(
      "Mevcut Firebase hesabi dogrulanamadi. Resmi tarayici girisi aciliyor.",
    );
    run(["login", "--no-localhost"]);
    apps = run(["apps:list", "ANDROID", "--json"], true);
  }
  if (!Array.isArray(apps)) throw Error("Firebase uygulama listesi okunamadi.");
  let app = apps.find((a) => a.packageName === "com.birarada.app");
  if (!app)
    app = run(
      [
        "apps:create",
        "ANDROID",
        "Birarada",
        "--package-name",
        "com.birarada.app",
        "--json",
      ],
      true,
    );
  if (!app?.appId) throw Error("Firebase Android uygulama kimligi olusmadi.");
  const temp = fs.mkdtempSync(
      path.join(os.tmpdir(), "birarada-android-public-"),
    ),
    file = path.join(temp, "google-services.json");
  try {
    run(["apps:sdkconfig", "ANDROID", app.appId, "--out", file]);
    const config = validateAndroidConfig(
      JSON.parse(fs.readFileSync(file, "utf8")),
    );
    fs.writeFileSync(
      path.join(root, "google-services.json"),
      JSON.stringify(config, null, 2) + "\n",
      { flag: "wx" },
    );
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
  console.log(
    "Android Firebase yapilandirmasi hazir. Ozel anahtar olusturulmadi veya koda eklenmedi.",
  );
  console.log(
    "FCM v1 servis hesabi EAS'te yoksa: npx eas-cli@25.2.0 credentials --platform android -> production -> Google Service Account / Push Notifications. Mevcut Android keystore'u koru.",
  );
  console.log(
    "FCM v1 yetkisi ve gercek telefona teslim bu arac tarafindan dogrulanmadi.",
  );
}
module.exports = { main };
if (require.main === module) {
  try {
    main();
  } catch (e) {
    console.error(e.message);
    process.exitCode = 1;
  }
}
