#!/usr/bin/env node
"use strict";

// This check never prints variable values, credentials, or account details.
const RELEASE_IDENTITY = Object.freeze({
  package: "com.birarada.app",
  version: "1.1.4",
  versionCode: 6,
  firebaseProjectId: "birarada-5650c",
});
const LEGAL_DEFAULTS = Object.freeze({
  EXPO_PUBLIC_PRIVACY_POLICY_URL: "https://birarada-5650c.web.app/privacy",
  EXPO_PUBLIC_TERMS_URL: "https://birarada-5650c.web.app/terms",
  EXPO_PUBLIC_DELETE_ACCOUNT_URL: "https://birarada-5650c.web.app/delete-account",
  EXPO_PUBLIC_SUPPORT_URL: "mailto:ahmedberatazboy0@gmail.com",
});
const LEGAL_VARIABLES = [
  "EXPO_PUBLIC_PRIVACY_POLICY_URL",
  "EXPO_PUBLIC_TERMS_URL",
  "EXPO_PUBLIC_DELETE_ACCOUNT_URL",
  "EXPO_PUBLIC_SUPPORT_URL",
];

function getIdentityProblems(env) {
  const problems = [];
  for (const name of ["EXPO_PUBLIC_ANDROID_PACKAGE", "ANDROID_PACKAGE"]) {
    if (env[name] !== undefined && env[name] !== RELEASE_IDENTITY.package) {
      problems.push(`${name} conflicts with the fixed application identity com.birarada.app.`);
    }
  }
  if (env.ANDROID_VERSION_CODE !== undefined &&
      env.ANDROID_VERSION_CODE !== String(RELEASE_IDENTITY.versionCode)) {
    problems.push("ANDROID_VERSION_CODE conflicts with this update candidate (versionCode 6).");
  }
  if (env.EXPO_PUBLIC_FIREBASE_PROJECT_ID !== undefined &&
      env.EXPO_PUBLIC_FIREBASE_PROJECT_ID !== RELEASE_IDENTITY.firebaseProjectId) {
    problems.push("EXPO_PUBLIC_FIREBASE_PROJECT_ID conflicts with the production Firebase project birarada-5650c.");
  }
  return problems;
}

function checkIdentityEnvironment(env) {
  const problems = getIdentityProblems(env);
  if (problems.length) throw new Error(problems.join("\n"));
}

function isSupportUrl(value) {
  if (isPublicHttpsUrl(value)) return true;
  if (typeof value !== "string") return false;
  // A published support email is sufficient for contacting the developer.
  const match = /^mailto:([^?\s]+)$/i.exec(value);
  return !!match && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(match[1]) &&
    isPublicHttpsUrl(`https://${match[1].split("@")[1]}`);
}

function isPublicHttpsUrl(value) {
  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase();
    if (url.protocol !== "https:" || url.username || url.password) return false;
    // Legal pages must be public web pages, never loopback, test, or private URLs.
    if (!hostname.includes(".") || hostname.includes(":")) return false;
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(hostname)) return false;
    if (/\.(localhost|local|test|invalid|example)$/.test(hostname)) return false;
    if (/(^|\.)example\.(com|net|org)$/.test(hostname)) return false;
    return true;
  } catch {
    return false;
  }
}

function getReleaseProblems(env) {
  const problems = getIdentityProblems(env);
  if (env.EXPO_PUBLIC_USE_EMULATORS !== "false") {
    problems.push("EXPO_PUBLIC_USE_EMULATORS must explicitly be false.");
  }
  if (env.EXPO_PUBLIC_STORAGE_ENABLED !== "false") {
    problems.push("EXPO_PUBLIC_STORAGE_ENABLED must remain false; client Storage SDK access is forbidden. Private media uses the authenticated server gateway.");
  }
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(env.EAS_PROJECT_ID || "")) {
    problems.push("EAS_PROJECT_ID must identify your real Expo EAS project.");
  }
  for (const name of LEGAL_VARIABLES) {
    const value = env[name] === undefined ? LEGAL_DEFAULTS[name] : env[name];
    const isValid = name === "EXPO_PUBLIC_SUPPORT_URL"
      ? isSupportUrl(value)
      : isPublicHttpsUrl(value);
    if (!isValid) {
      problems.push(name === "EXPO_PUBLIC_SUPPORT_URL"
        ? `${name} must be a valid mailto contact or public HTTPS support page.`
        : `${name} must point to your published public HTTPS page; placeholders are rejected.`);
    }
  }
  return problems;
}

function checkReleaseEnvironment(env) {
  const problems = getReleaseProblems(env);
  if (problems.length) {
    throw new Error(`Android release configuration is incomplete:\n- ${problems.join("\n- ")}\nSee docs/PLAY_STORE_RELEASE.md.`);
  }
}

module.exports = {
  RELEASE_IDENTITY, LEGAL_DEFAULTS, LEGAL_VARIABLES,
  isPublicHttpsUrl, isSupportUrl, getIdentityProblems, checkIdentityEnvironment,
  getReleaseProblems, checkReleaseEnvironment,
};

if (require.main === module) {
  try {
    // Match Expo's .env/.env.local handling while respecting existing shell variables.
    require("@expo/env").loadProjectEnv(process.cwd(), { mode: "production", silent: true });
    checkReleaseEnvironment(process.env);
    console.log("Release environment guard passed. This does not verify account ownership, published legal content, Firebase deployment, device behavior, or create an AAB.");
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
