"use strict";
const fs = require("node:fs"),
  path = require("node:path");
function validateAndroidConfig(config) {
  if (
    config?.project_info?.project_id !== "birarada-5650c" ||
    String(config.project_info.project_number) !== "510479812993"
  )
    throw Error(
      "Firebase Android dosyasi beklenen Birarada projesine ait degil.",
    );
  if (
    /"(?:private_key|client_secret|refresh_token|access_token)"/.test(
      JSON.stringify(config),
    )
  )
    throw Error(
      "Bu dosya acik Android yapilandirmasi olmali; ozel anahtar kabul edilmez.",
    );
  const client = config.client?.find(
    (c) =>
      c.client_info?.android_client_info?.package_name === "com.birarada.app",
  );
  if (
    !client ||
    !/^1:510479812993:android:[a-f0-9]+$/i.test(
      client.client_info?.mobilesdk_app_id || "",
    )
  )
    throw Error("Firebase Android uygulama kimligi/paket adi dogrulanamadi.");
  if (
    !client.api_key?.some((k) =>
      /^AIza[A-Za-z0-9_-]{35}$/.test(k.current_key || ""),
    )
  )
    throw Error("Firebase Android acik API anahtari eksik veya gecersiz.");
  return config;
}
function requireAndroidConfig(root) {
  const file = path.join(root, "google-services.json");
  if (!fs.existsSync(file))
    throw Error(
      "Android bildirim yapilandirmasi eksik. BILDIRIM_KUR.bat veya npm run notifications:setup calistir.",
    );
  if (fs.lstatSync(file).isSymbolicLink())
    throw Error("Android yapilandirmasi baglanti dosyasi olamaz.");
  return validateAndroidConfig(JSON.parse(fs.readFileSync(file, "utf8")));
}
module.exports = { validateAndroidConfig, requireAndroidConfig };
