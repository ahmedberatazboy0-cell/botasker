@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
if not exist "node_modules\firebase-tools\package.json" (
  call npm ci --include=dev --no-audit --no-fund
  if errorlevel 1 goto failed
)
call npm run notifications:setup
if errorlevel 1 goto failed
echo FCM v1 yetkisini Expo hesabinda kontrol et. Ozel anahtari sohbete veya kaynak klasorune koyma.
call npx --yes eas-cli@25.2.0 credentials --platform android
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Bildirim kurulumu tamamlanmadi. Yukaridaki hatayi kontrol et.
pause
exit /b 1
