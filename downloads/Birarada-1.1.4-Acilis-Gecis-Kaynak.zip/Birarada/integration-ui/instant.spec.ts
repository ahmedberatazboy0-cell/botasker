import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
async function metric(name: string, value: number) {
  const file = "artifacts/warm-navigation.json";
  let previous: any = {};
  try {
    previous = JSON.parse(await fs.readFile(file, "utf8"));
  } catch {}
  await fs.writeFile(
    file,
    JSON.stringify(
      {
        ...previous,
        version: "1.1.4",
        date: "2026-10-29",
        environment:
          "Local Chromium, Firebase Auth emulator, PGlite and real gateway; not a physical device",
        [name]: value,
      },
      null,
      2,
    ) + "\n",
  );
}
const password = "Local-instant-ui-only-642!";
type Account = { uid: string; email: string; token: string; username: string };
let accounts: Record<string, Account>;
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  expect(r.status, await r.clone().text()).toBe(200);
  return r.json();
}
async function data(who: string, route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + accounts[who]!.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  expect(r.status, await r.clone().text()).toBe(200);
  return (await r.json()).data;
}
const api = (who: string, action: string, input: any = {}) =>
  data(who, "socialApi", { action, input });
async function privacy(who: string, value: boolean) {
  const path = "users/" + accounts[who]!.uid,
    old = (
      await data(who, "documents", { operation: "get", paths: [path] })
    )[0];
  await data(who, "documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ path, kind: "set", data: { ...old.data, isPrivate: value } }],
  });
}
async function login(page: Page, who: string) {
  await page.goto("/", { waitUntil: "commit" });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page.getByLabel("E-posta", { exact: true }).fill(accounts[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function closeBanner(page: Page) {
  const close = page.getByRole("button", {
    name: "Bildirimi kapat",
    exact: true,
  });
  if (await close.isVisible()) await close.click();
}
test.beforeEach(async () => {
  accounts = {};
  const profiles = [];
  const suffix = randomUUID().slice(0, 8);
  for (const who of ["alice", "bob"]) {
    const email = `instant-${who}-${suffix}@example.test`,
      created = await auth("accounts:signUp", {
        email,
        password,
        returnSecureToken: true,
      });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: created.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password,
      returnSecureToken: true,
    });
    accounts[who] = {
      uid: created.localId,
      email,
      token: signed.idToken,
      username: who + "_" + suffix,
    };
    profiles.push({
      uid: created.localId,
      email,
      username: accounts[who]!.username,
      displayName: who === "bob" ? "Bob Instant" : "Alice Instant",
    });
  }
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(r.status).toBe(200);
});
test("profile grid and post details stay usable during a fifteen-second revalidation", async ({
  page,
}) => {
  const caption = "Warm profile " + randomUUID();
  const post = await api("alice", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption,
    mediaIds: [],
  });
  const warmed = page.waitForResponse(
    (r) =>
      r.url().endsWith("/socialApi") &&
      r.request().postDataJSON()?.action === "listContent" &&
      r.request().postDataJSON()?.input.uid === accounts.alice!.uid,
  );
  await login(page, "alice");
  await warmed;
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  let waiting = 0;
  await page.route("**/socialApi", async (route) => {
    const action = route.request().postDataJSON()?.action;
    if (["listContent", "getContent"].includes(action)) {
      waiting++;
      await gate;
    }
    await route.continue().catch(() => {});
  });
  const begin = Date.now();
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  try {
    const cell = page.getByRole("button", {
      name: "@" + accounts.alice!.username + ": " + caption,
      exact: true,
    });
    await expect(cell).toBeVisible({ timeout: 1500 });
    await cell.click();
    await expect(
      page.getByTestId("post-details").getByTestId("post-" + post.id),
    ).toBeVisible({ timeout: 1500 });
    const elapsed = Date.now() - begin;
    expect(elapsed).toBeLessThan(2500);
    await metric("profileAndPostDetailsMs", elapsed);
    expect(waiting).toBeGreaterThan(0);
    await page.waitForTimeout(15000);
    await expect(
      page.getByTestId("post-details").getByTestId("post-" + post.id),
    ).toBeVisible();
  } finally {
    release();
  }
});
test("recent inbox and conversation content render while the next document read is stalled", async ({
  page,
}) => {
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await api("bob", "sendMessage", {
    chatId: chat.id,
    requestId: randomUUID(),
    text: "Already delivered and cached",
    mediaIds: [],
  });
  const warmed = page.waitForResponse((r) => {
    if (!r.url().endsWith("/documents")) return false;
    const b = r.request().postDataJSON(),
      items = b?.operation === "batch" ? b.items : [b];
    return items.some(
      (i: any) => i?.spec?.path === `chats/${chat.id}/messages`,
    );
  });
  await login(page, "alice");
  await warmed;
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  await page.route("**/documents", async (route) => {
    await gate;
    await route.continue().catch(() => {});
  });
  const started = Date.now();
  try {
    await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
    await page
      .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
      .click({ timeout: 1800 });
    await expect(
      page.getByText("Already delivered and cached", { exact: true }),
    ).toBeVisible({ timeout: 1500 });
    await metric("inboxAndConversationMs", Date.now() - started);
  } finally {
    release();
  }
});
test("a real follow request shows an animated actionable banner and is accepted by the recipient", async ({
  page,
  browser,
}) => {
  await privacy("bob", true);
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
  });
  const bob = await context.newPage();
  try {
    await login(bob, "bob");
    await login(page, "alice");
    await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
    await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
    await page
      .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
      .fill(accounts.bob!.username);
    await page
      .getByRole("button", {
        name: `@${accounts.bob!.username} hesabını aç`,
        exact: true,
      })
      .click();
    await page
      .getByRole("button", { name: "Takip isteği gönder", exact: true })
      .click();
    const banner = bob.getByTestId("notification-banner");
    await expect(banner).toContainText("takip etmek istiyor", {
      timeout: 10000,
    });
    await expect(bob.getByTestId("notification-count")).toBeVisible();
    await bob.screenshot({ path: "artifacts/instant-follow-notification.png" });
    await closeBanner(bob);
    await bob.getByRole("button", { name: "Bildirimler", exact: true }).click();
    await bob.getByRole("button", { name: "Kabul et", exact: true }).click();
    await expect(
      page.getByRole("button", { name: "Takipten çık", exact: true }),
    ).toBeVisible({ timeout: 15000 });
  } finally {
    await context.close();
  }
});
test("a photo published in the editor can be liked by another account and the banner opens that post", async ({
  page,
  browser,
}) => {
  const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    }),
    bob = await context.newPage();
  try {
    await login(page, "alice");
    await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
    const caption = "Actual shared photo " + randomUUID();
    await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
    const chooser = page.waitForEvent("filechooser");
    await page
      .getByRole("button", { name: "Galeriden seç", exact: true })
      .click();
    await (
      await chooser
    ).setFiles({
      name: "photo.jpg",
      mimeType: "image/jpeg",
      buffer: await fs.readFile("tests/free-photo.jpg"),
    });
    const published = page.waitForResponse(
      (r) =>
        r.url().endsWith("/socialApi") &&
        r.request().postDataJSON()?.action === "publishContent",
    );
    await page.getByRole("button", { name: "Paylaş", exact: true }).click();
    const id = (await (await published).json()).data.id;
    await expect(page.getByTestId("post-" + id)).toBeVisible();
    await login(bob, "bob");
    await bob
      .getByTestId("post-" + id)
      .getByRole("button", { name: "Beğen", exact: true })
      .click();
    const banner = page.getByTestId("notification-banner");
    await expect(banner).toContainText("gönderini beğendi", { timeout: 10000 });
    await banner
      .getByRole("button", { name: "Bildirimi aç", exact: true })
      .click();
    await expect(
      page.getByTestId("post-details").getByTestId("post-" + id),
    ).toBeVisible();
  } finally {
    await context.close();
  }
});
test("group creation and a real message notify the other member and open the correct conversation", async ({
  page,
  browser,
}) => {
  const context = await browser.newContext({
      viewport: { width: 390, height: 844 },
    }),
    bob = await context.newPage();
  try {
    await login(bob, "bob");
    await login(page, "alice");
    await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
    await page.getByRole("button", { name: "Yeni mesaj", exact: true }).click();
    await page
      .getByRole("button", { name: "Yeni grup oluştur", exact: true })
      .click();
    await page.getByPlaceholder("Grup adı").fill("Instant Test Group");
    await page
      .getByPlaceholder("Kullanıcı adı ara", { exact: true })
      .fill(accounts.bob!.username);
    await page
      .getByRole("button", {
        name: "@" + accounts.bob!.username + " · ekle",
        exact: true,
      })
      .click();
    await page
      .getByRole("button", { name: "Grubu oluştur", exact: true })
      .click();
    await expect(page.getByPlaceholder("Mesaj yaz…")).toBeVisible();
    await expect(bob.getByTestId("notification-banner")).toContainText(
      "gruba ekledi",
      { timeout: 10000 },
    );
    await closeBanner(bob);
    await page
      .getByPlaceholder("Mesaj yaz…")
      .fill("Hello from the actual group");
    await page.getByRole("button", { name: "Gönder", exact: true }).click();
    await expect(bob.getByTestId("notification-banner")).toContainText(
      "sana mesaj gönderdi",
      { timeout: 10000 },
    );
    await bob
      .getByRole("button", { name: "Bildirimi aç", exact: true })
      .click();
    await expect(bob.getByPlaceholder("Mesaj yaz…")).toBeVisible();
    await expect(
      bob.getByText("Hello from the actual group", { exact: true }),
    ).toBeVisible();
  } finally {
    await context.close();
  }
});
test("repeated profile and feed navigation does not trigger a read storm or rate-limit errors", async ({
  page,
}) => {
  const errors: number[] = [];
  let reads = 0;
  page.on("response", (r) => {
    if (r.url().endsWith("/documents")) {
      reads++;
      if (r.status() === 429) errors.push(r.status());
    }
  });
  await login(page, "alice");
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  for (let i = 0; i < 8; i++) {
    await page.getByRole("tab", { name: "Profil", exact: true }).click();
    await expect(
      page.getByText("Alice Instant", { exact: true }),
    ).toBeVisible();
    await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
  }
  expect(errors).toEqual([]);
  expect(reads).toBeLessThan(45);
  await metric("documentHttpReadsForEightProfileHomeCycles", reads);
});
test("connection diagnostics report real timings and notification checks do not claim device delivery", async ({
  page,
}) => {
  await login(page, "alice");
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await page
    .getByRole("button", { name: "Profil menüsü", exact: true })
    .click();
  await page.getByRole("button", { name: "Ayarlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Bağlantı kontrolü", exact: true })
    .click();
  await expect(page.getByText(/Uygulama: 1\.1\.4 · kod 6/)).toBeVisible();
  await page
    .getByRole("button", { name: "Bağlantıyı ölç", exact: true })
    .click();
  await expect(
    page.getByText("2026-10-27-instant1", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Oturum doğrulandı.", { exact: true }),
  ).toBeVisible();
  await page.getByRole("link", { name: /back/ }).click();
  await page.getByRole("link", { name: /back/ }).click();
  await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
  await page.getByRole("button", { name: "Bildirimler", exact: true }).click();
  await page
    .getByRole("button", {
      name: "Bildirim bağlantısını kontrol et",
      exact: true,
    })
    .click();
  await expect(
    page.getByText(
      "Bu hesap için kayıtlı telefon yok. Önce telefon bildirimlerini aç.",
      { exact: true },
    ),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Deneme bildirimi gönder", exact: true })
    .click();
  await expect(
    page.getByText(
      "Deneme isteği kuyruğa alındı. Telefon bildirimini ayrıca kontrol et.",
      { exact: true },
    ),
  ).toBeVisible();
  const result = await data("alice", "documents", {
    operation: "query",
    spec: {
      path: "notifications",
      group: false,
      filters: [["targetUid", "==", accounts.alice!.uid]],
      orders: [],
      limit: 30,
    },
  });
  expect(result.some((r: any) => r.data.type === "test")).toBe(true);
});
test("a delayed failed send shows pending state, keeps the draft and retries as exactly one message", async ({
  page,
}) => {
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await login(page, "alice");
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
    .click();
  let fail = true;
  await page.route("**/socialApi", async (route) => {
    if (fail && route.request().postDataJSON()?.action === "sendMessage") {
      fail = false;
      await new Promise((r) => setTimeout(r, 1200));
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: {
            code: "unavailable",
            message: "Deneme bağlantı kesintisi. Taslağın korunuyor.",
          },
        }),
      });
      return;
    }
    await route.continue();
  });
  const text = "Draft survives an actual failed send " + randomUUID();
  await page.getByPlaceholder("Mesaj yaz…").fill(text);
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  await expect(page.getByTestId("sending-message")).toContainText(
    "Gönderiliyor…",
  );
  await expect(page.getByTestId("sending-message")).toBeHidden();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue(text);
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue("");
  await expect(
    page
      .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
      .filter({ hasText: text }),
  ).toBeVisible();
  const result = await data("bob", "documents", {
    operation: "query",
    spec: {
      path: `chats/${chat.id}/messages`,
      group: false,
      filters: [],
      orders: [],
      limit: 100,
    },
  });
  expect(result.filter((r: any) => r.data.text === text)).toHaveLength(1);
});
test("chat metadata recovers from a temporary failure and stops polling behind a profile", async ({
  page,
}) => {
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await login(page, "alice");
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  let fail = true,
    hiddenReads = 0,
    count = false;
  await page.route("**/documents", async (route) => {
    const b = route.request().postDataJSON(),
      items = b?.operation === "batch" ? b.items : [b];
    const reads = items.some(
      (i: any) =>
        i?.operation === "get" && i.paths.includes(`chats/${chat.id}`),
    );
    if (count && reads) hiddenReads++;
    if (fail && reads) {
      fail = false;
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: {
            code: "unavailable",
            message: "Geçici sohbet bağlantısı kesildi.",
          },
        }),
      });
      return;
    }
    await route.continue();
  });
  await page
    .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
    .click();
  await expect(page.getByTestId("chat-connection-error")).toBeVisible();
  await expect(page.getByTestId("chat-connection-error")).toBeHidden({
    timeout: 7000,
  });
  await page
    .getByRole("button", { name: "Sohbet bilgileri", exact: true })
    .click();
  await page
    .getByRole("button", { name: accounts.bob!.username, exact: true })
    .click();
  await expect(
    page.getByRole("button", { name: "Takip et", exact: true }),
  ).toBeVisible();
  await page.waitForTimeout(1800);
  count = true;
  await page.waitForTimeout(6500);
  expect(hiddenReads).toBe(0);
});
test("profile and inbox warm up even while the first home feed is still waiting", async ({
  page,
}) => {
  const caption = "Independent profile " + randomUUID();
  await api("alice", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption,
    mediaIds: [],
  });
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await api("bob", "sendMessage", {
    chatId: chat.id,
    requestId: randomUUID(),
    text: "Ready before home finishes",
    mediaIds: [],
  });
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  let held = false,
    holdStats = false;
  const ready = new Set<string>();
  page.on("response", async (r) => {
    if (r.status() !== 200) return;
    const body = r.request().postDataJSON();
    let key = "";
    if (
      r.url().endsWith("/socialApi") &&
      body?.input?.uid === accounts.alice!.uid
    ) {
      if (body.action === "listContent") key = "profile";
      if (body.action === "profileStats") key = "stats";
    } else if (r.url().endsWith("/documents")) {
      const items = body?.operation === "batch" ? body.items : [body];
      if (
        items.some(
          (item: any) => item?.spec?.path === `chats/${chat.id}/messages`,
        )
      )
        key = "messages";
    }
    if (key) {
      await r.finished();
      ready.add(key);
    }
  });
  await page.route("**/socialApi", async (route) => {
    const b = route.request().postDataJSON();
    if (b?.action === "listContent" && !b.input.uid) {
      held = true;
      await gate;
    } else if (holdStats && b?.action === "profileStats") await gate;
    await route.continue().catch(() => {});
  });
  try {
    await login(page, "alice");
    await expect
      .poll(() => [...ready].sort(), { timeout: 5000 })
      .toEqual(["messages", "profile", "stats"]);
    expect(held).toBe(true);
    holdStats = true;
    const started = Date.now();
    await page.getByRole("tab", { name: "Profil", exact: true }).click();
    await expect(
      page.getByRole("button", {
        name: "@" + accounts.alice!.username + ": " + caption,
        exact: true,
      }),
    ).toBeVisible({ timeout: 1500 });
    await expect(
      page.getByRole("button", { name: "Gönderiler", exact: true }),
    ).toContainText("1");
    expect(Date.now() - started).toBeLessThan(2500);
    await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
    await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
    await page
      .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
      .click();
    await expect(
      page.getByText("Ready before home finishes", { exact: true }),
    ).toBeVisible();
    await metric("independentWarmupWhileHomeFeedHeld", 1);
  } finally {
    release();
  }
});
test("returning to a visited profile keeps its header and counts after memory TTL expires", async ({
  page,
}) => {
  const caption = "Keep this profile " + randomUUID();
  await api("bob", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption,
    mediaIds: [],
  });
  await login(page, "alice");
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
  await page
    .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
    .fill(accounts.bob!.username);
  await page
    .getByRole("button", {
      name: `@${accounts.bob!.username} hesabını aç`,
      exact: true,
    })
    .click();
  const cell = page.getByRole("button", {
    name: "@" + accounts.bob!.username + ": " + caption,
    exact: true,
  });
  await expect(cell).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Gönderiler", exact: true }),
  ).toContainText("1");
  await cell.click();
  await expect(page.getByTestId("post-details")).toBeVisible();
  await page.evaluate(() => {
    const w = window as any;
    w.__biraradaOriginalNow = Date.now;
    Date.now = () => w.__biraradaOriginalNow() + 65000;
  });
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  let stalled = 0;
  const hold = async (route: any) => {
    stalled++;
    await gate;
    await route.continue().catch(() => {});
  };
  await page.route("**/documents", hold);
  await page.route("**/socialApi", hold);
  try {
    await page.getByRole("link", { name: /back/ }).click();
    await expect.poll(() => stalled).toBeGreaterThan(0);
    await expect(
      page
        .getByTestId("profile-content")
        .getByText("Bob Instant", { exact: true }),
    ).toBeVisible({
      timeout: 1500,
    });
    await expect(cell).toBeVisible({ timeout: 1500 });
    await expect(
      page.getByRole("button", { name: "Gönderiler", exact: true }),
    ).toContainText("1");
  } finally {
    await page
      .evaluate(() => {
        const w = window as any;
        Date.now = w.__biraradaOriginalNow;
        delete w.__biraradaOriginalNow;
      })
      .catch(() => {});
    release();
  }
});
