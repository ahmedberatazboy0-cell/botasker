import { test, expect, type Page, type BrowserContext } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
const PASS = "Local-only-redesign-928!";
const users: Record<
  string,
  { uid: string; email: string; token: string; username: string }
> = {};
let chatId = "",
  postId = "";
const caption = "Güzel bir güne küçük bir mola. #birarada";
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  const v = await r.json();
  expect(r.status, JSON.stringify(v)).toBe(200);
  return v;
}
async function request(who: string, route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + users[who]!.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  const v = await r.json();
  expect(r.status, JSON.stringify(v)).toBe(200);
  return v.data;
}
const action = (who: string, action: string, input: any) =>
  request(who, "socialApi", { action, input });
async function record(who: string, path: string) {
  return (
    await request(who, "documents", { operation: "get", paths: [path] })
  )[0].data;
}
async function login(page: Page, who = "deniz") {
  page.on("response", async (r) => {
    if (r.status() >= 400 && r.url().startsWith("http://127.0.0.1:5002"))
      console.log(
        "LOCAL TEST API",
        r.status(),
        new URL(r.url()).pathname,
        await r.text(),
      );
  });
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await expect(
    page.getByText("Arkadaşlarını bul", { exact: true }),
  ).toBeVisible({ timeout: 90000 });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click();
  await page.getByLabel("E-posta", { exact: true }).fill(users[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(PASS);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible({ timeout: 30000 });
}
async function conversation(page: Page) {
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Ece sohbetini aç", exact: true })
    .click();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toBeVisible();
}
test.beforeEach(async () => {
  expect(process.env.BIRARADA_TEST_SECRET).toBeTruthy();
  const profiles = [];
  const suffix = Date.now().toString(36);
  for (const [key, displayName, isPrivate] of [
    ["deniz", "Deniz", false],
    ["ece", "Ece", false],
    ["private", "Gizli Hesap", true],
  ] as const) {
    const email = `design-${key}-${Date.now()}@example.test`,
      a = await auth("accounts:signUp", {
        email,
        password: PASS,
        returnSecureToken: true,
      });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: a.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password: PASS,
      returnSecureToken: true,
    });
    const username = key + "_design_" + suffix;
    users[key] = { uid: a.localId, email, token: signed.idToken, username };
    profiles.push({ uid: a.localId, email, username, displayName });
  }
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(r.status).toBe(200);
  chatId = (await action("deniz", "createChat", { members: [users.ece!.uid] }))
    .id;
  await action("ece", "sendMessage", {
    chatId,
    requestId: randomUUID(),
    text: "Birlikte güzel anılar biriktirelim. 🌿",
    mediaIds: [],
  });
});
test("compact mobile navigation fits narrow screens and the new-message composer resolves real profiles", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.setViewportSize({ width: 320, height: 700 });
  await login(page);
  for (const name of ["Ana Sayfa", "Keşfet", "Oluştur", "Reels", "Profil"])
    await expect(page.getByRole("tab", { name, exact: true })).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Ece sohbetini aç", exact: true }),
  ).toBeVisible();
  await page.getByPlaceholder("Sohbetlerde ara").fill("Ece");
  await expect(
    page.getByRole("button", { name: "Ece sohbetini aç", exact: true }),
  ).toBeVisible();
  await page.getByPlaceholder("Sohbetlerde ara").fill("Böyle biri yok");
  await expect(
    page.getByRole("button", { name: "Ece sohbetini aç", exact: true }),
  ).toHaveCount(0);
  await page.getByPlaceholder("Sohbetlerde ara").fill("");
  await page.getByRole("button", { name: "Yeni mesaj", exact: true }).click();
  await page
    .getByPlaceholder("Ad veya kullanıcı adı ara")
    .fill(users.ece!.username);
  await page
    .getByRole("button", { name: users.ece!.username, exact: true })
    .click();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toBeVisible();
  expect(errors).toEqual([]);
});
test("carousel, like, saved post and comments persist through the real backend", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  const choosing = page.waitForEvent("filechooser");
  await page
    .getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  const photo = await fs.readFile("tests/free-photo.jpg");
  await (
    await choosing
  ).setFiles([
    { name: "moment-1.jpg", mimeType: "image/jpeg", buffer: photo },
    { name: "moment-2.jpg", mimeType: "image/jpeg", buffer: photo },
  ]);
  await expect(page.getByText("2. Fotoğraf", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await expect(page.getByText(caption, { exact: false })).toBeVisible();
  const post = (
    await action("deniz", "listContent", {
      kind: "post",
      uid: users.deniz!.uid,
    })
  ).rows.find((p: any) => p.caption === caption);
  expect(post).toBeTruthy();
  postId = post.id;
  const card = page.getByTestId("post-" + postId);
  await expect(card).toBeVisible();
  await expect(card.getByText("1/2", { exact: true })).toBeVisible();
  await page.getByTestId("media-carousel-" + postId).evaluate((el) => {
    el.scrollLeft = el.clientWidth;
  });
  await expect(card.getByText("2/2", { exact: true })).toBeVisible();
  await card.getByRole("button", { name: "Beğen", exact: true }).click();
  await expect
    .poll(
      async () =>
        !!(await record("deniz", `posts/${postId}/likes/${users.deniz!.uid}`)),
    )
    .toBe(true);
  await expect(
    card.getByRole("button", { name: "Beğeniyi geri al", exact: true }),
  ).toBeVisible();
  await card.getByRole("button", { name: "Kaydet", exact: true }).click();
  await expect
    .poll(
      async () =>
        !!(await record("deniz", `saved/${users.deniz!.uid}/posts/${postId}`)),
    )
    .toBe(true);
  await expect(
    card.getByRole("button", { name: "Kaydedildi", exact: true }),
  ).toBeVisible();
  await card.getByRole("button", { name: "Yorumlar", exact: true }).click();
  await page.getByPlaceholder("Bir şey söyle…").fill("Burada olmak güzel.");
  await page.getByRole("button", { name: "Yorum gönder", exact: true }).click();
  await expect(
    page.getByText("Burada olmak güzel.", { exact: false }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Kapat", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeHidden();
  await page.screenshot({ path: "artifacts/redesign-feed.png" });
});
test("profile editing, stats and menu survive real navigation and a reload", async ({
  page,
}) => {
  const mediaId = randomUUID(),
    bytes = await fs.readFile("tests/free-photo.jpg");
  await action("deniz", "createUpload", {
    requestId: mediaId,
    kind: "image",
    purpose: "post",
    bytes: bytes.length,
  });
  const upload = await fetch(
    "http://127.0.0.1:5002/mediaUpload?id=" + mediaId,
    {
      method: "PUT",
      headers: { Authorization: "Bearer " + users.deniz!.token },
      body: bytes,
    },
  );
  expect(upload.status).toBe(200);
  await action("deniz", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption: "Küçük anların albümü.",
    mediaIds: [mediaId],
  });
  await login(page);
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Profili düzenle", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Profili düzenle", exact: true })
    .click();
  await page
    .getByPlaceholder("Bio", { exact: true })
    .fill("Küçük anlar, güzel hikâyeler. 🌿");
  await page.getByRole("button", { name: "Kaydet", exact: true }).click();
  await expect(
    page.getByText("Küçük anlar, güzel hikâyeler. 🌿", { exact: true }),
  ).toBeVisible();
  await expect
    .poll(async () => (await record("deniz", "users/" + users.deniz!.uid)).bio)
    .toBe("Küçük anlar, güzel hikâyeler. 🌿");
  await page.screenshot({ path: "artifacts/redesign-profile.png" });
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await expect(
    page.getByText("Küçük anlar, güzel hikâyeler. 🌿", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Profil menüsü", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Kaydedilenler", exact: true })
    .click();
  await expect(page.getByText("Sana kalsın.", { exact: true })).toBeVisible();
});
test("song-note publishing and explicit deletion work against PostgreSQL", async ({
  page,
}) => {
  await login(page);
  await page
    .getByRole("button", { name: "Notlar · Şarkını paylaş", exact: true })
    .click();
  await page
    .getByLabel("Notun (en fazla 60 karakter)")
    .fill("Güne bir şarkı bırak.");
  await page
    .getByLabel("Şarkı ve sanatçı adı (isteğe bağlı)")
    .fill("Rick Astley – Never Gonna Give You Up");
  await page
    .getByLabel("Spotify veya YouTube bağlantısı")
    .fill("https://youtu.be/dQw4w9WgXcQ?si=discard");
  await page.getByRole("button", { name: "Notu paylaş", exact: true }).click();
  await expect
    .poll(
      async () => (await record("deniz", "notes/" + users.deniz!.uid))?.songUrl,
    )
    .toBe("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  await expect(
    page.getByText("Notun paylaşıldı.", { exact: true }),
  ).toBeVisible();
  await page.screenshot({ path: "artifacts/redesign-notes.png" });
  await page.getByRole("button", { name: "Notumu sil", exact: true }).click();
  expect(await record("deniz", "notes/" + users.deniz!.uid)).toBeTruthy();
  await page.getByRole("button", { name: "Vazgeç", exact: true }).click();
  await page.getByRole("button", { name: "Notumu sil", exact: true }).click();
  await page
    .getByRole("button", { name: "Evet, notumu sil", exact: true })
    .click();
  await expect
    .poll(() => record("deniz", "notes/" + users.deniz!.uid))
    .toBeNull();
});
test("message draft survives navigation and sending preserves the real recipient and text", async ({
  page,
}) => {
  await login(page);
  await conversation(page);
  await page.getByPlaceholder("Mesaj yaz…").fill("Gün batımında buluşalım.");
  await page.getByRole("button", { name: "Geri", exact: true }).click();
  await page
    .getByRole("button", { name: "Ece sohbetini aç", exact: true })
    .click();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue(
    "Gün batımında buluşalım.",
  );
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue("");
  await expect(
    page
      .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
      .filter({ hasText: "Gün batımında buluşalım." }),
  ).toBeVisible();
  await page.screenshot({ path: "artifacts/redesign-chat.png" });
});
test("reply, reaction, edit and delete require the intended message and explicit confirmation", async ({
  page,
}) => {
  await login(page);
  await conversation(page);
  const incoming = page
    .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
    .filter({ hasText: "Birlikte güzel anılar biriktirelim." });
  await incoming.click();
  await page.getByRole("button", { name: "❤️ tepkisi", exact: true }).click();
  await expect(incoming.getByText("❤️", { exact: true })).toBeVisible();
  await incoming.click();
  await page.getByRole("button", { name: "Yanıtla", exact: true }).click();
  await page.getByPlaceholder("Mesaj yaz…").fill("Yeni mesaj, yeni anılar.");
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  let own = page
    .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
    .filter({ hasText: "Yeni mesaj, yeni anılar." });
  await expect(own).toBeVisible();
  await own.click();
  await page.getByRole("button", { name: "Düzenle", exact: true }).click();
  await page.getByPlaceholder("Mesaj yaz…").fill("Yeni mesaj, güzel anılar.");
  await page
    .getByRole("button", { name: "Düzenlemeyi kaydet", exact: true })
    .click();
  own = page
    .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
    .filter({ hasText: "Yeni mesaj, güzel anılar." });
  await expect(own).toBeVisible();
  await own.click();
  await page.getByRole("button", { name: "Sil", exact: true }).click();
  await expect(own).toBeVisible();
  await page.getByRole("button", { name: "Vazgeç", exact: true }).click();
  await expect(own).toBeVisible();
  await page.getByRole("button", { name: "Sil", exact: true }).click();
  await page.getByRole("button", { name: "Evet, sil", exact: true }).click();
  await expect(own).toHaveCount(0);
});
test("incoming changes appear in the focused conversation and seen status reflects the other account", async ({
  page,
  browser,
}) => {
  await login(page);
  await conversation(page);
  const id = randomUUID();
  await action("ece", "sendMessage", {
    chatId,
    requestId: id,
    text: "Bu mesaj diğer hesaptan geldi.",
    mediaIds: [],
  });
  await expect(
    page.getByText("Bu mesaj diğer hesaptan geldi.", { exact: true }),
  ).toBeVisible({ timeout: 12000 });
  await expect
    .poll(async () =>
      (await record("ece", `chats/${chatId}/messages/${id}`)).seenBy.includes(
        users.deniz!.uid,
      ),
    )
    .toBe(true);
  await page
    .getByPlaceholder("Mesaj yaz…")
    .fill("Görüldü bilgisini kontrol et.");
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  const bubble = page
    .getByRole("button", { name: "Mesaj seçenekleri", exact: true })
    .filter({ hasText: "Görüldü bilgisini kontrol et." });
  await expect(bubble).toBeVisible();
  const context = await browser.newContext();
  try {
    const second = await context.newPage();
    await login(second, "ece");
    await second.getByRole("button", { name: "Mesajlar", exact: true }).click();
    await second
      .getByRole("button", { name: "Deniz sohbetini aç", exact: true })
      .click();
    await expect(
      second.getByText("Görüldü bilgisini kontrol et.", { exact: true }),
    ).toBeVisible();
    await expect(bubble.locator("..").getByText(/Görüldü/)).toBeVisible({
      timeout: 12000,
    });
  } finally {
    await context.close();
  }
});
test("new group creation, title changes and departure use real membership checks", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page.getByRole("button", { name: "Yeni grup", exact: true }).click();
  await page.getByPlaceholder("Grup adı").fill("Yakın arkadaşlar");
  await page.getByPlaceholder("Kullanıcı adı ara").fill(users.ece!.username);
  await page
    .getByRole("button", {
      name: `@${users.ece!.username} · ekle`,
      exact: true,
    })
    .click();
  await page
    .getByRole("button", { name: "Grubu oluştur", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Sohbet bilgileri", exact: true })
    .click();
  await page.getByPlaceholder("Grup adı").fill("Günün planı");
  await page
    .getByRole("button", { name: "Grup adını kaydet", exact: true })
    .click();
  await expect(page.getByPlaceholder("Grup adı")).toHaveValue("Günün planı");
  await page
    .getByRole("button", { name: "Gruptan ayrıl", exact: true })
    .click();
  await page.getByRole("button", { name: "Evet, ayrıl", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Yeni mesaj", exact: true }),
  ).toBeVisible();
});
test("follow, profile reporting and block confirmation remain accessible after the redesign", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
  await page
    .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
    .fill(users.ece!.username);
  await page.getByText(users.ece!.username, { exact: true }).click();
  await page.getByRole("button", { name: "Takip et", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Takipten çık", exact: true }),
  ).toBeVisible();
  await expect
    .poll(
      async () =>
        !!(await record(
          "deniz",
          `follows/${users.deniz!.uid}_${users.ece!.uid}`,
        )),
    )
    .toBe(true);
  await page
    .getByRole("button", { name: "Hesap seçenekleri", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Hesabı şikâyet et", exact: true })
    .click();
  await page
    .getByRole("radio", { name: "Spam veya dolandırıcılık", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Şikâyeti gönder", exact: true })
    .click();
  await expect(
    page.getByText("Şikâyetin iletildi", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Kapat", exact: true })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Hesap seçenekleri", exact: true })
    .click();
  await page.getByRole("button", { name: "Engelle", exact: true }).click();
  expect(
    await record("deniz", `users/${users.deniz!.uid}/blocks/${users.ece!.uid}`),
  ).toBeNull();
  await page
    .getByRole("button", { name: "Evet, engelle", exact: true })
    .click();
  await expect(
    page.getByText("Bu hesabı engelledin.", { exact: true }),
  ).toBeVisible();
  await expect
    .poll(
      async () =>
        !!(await record(
          "deniz",
          `users/${users.deniz!.uid}/blocks/${users.ece!.uid}`,
        )),
    )
    .toBe(true);
  await page
    .getByRole("button", { name: "Engeli kaldır", exact: true })
    .click();
  await expect
    .poll(() =>
      record("deniz", `users/${users.deniz!.uid}/blocks/${users.ece!.uid}`),
    )
    .toBeNull();
});

test("Reel upload, playback, comments and saving use the real authenticated media gateway", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  await page.getByRole("tab", { name: "Reels", exact: true }).first().click();
  await page
    .getByPlaceholder("Açıklama, #etiket, @kullanıcı…")
    .fill("Küçük bir hareket, yeni bir hikâye.");
  const choosing = page.waitForEvent("filechooser");
  await page
    .getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  await (
    await choosing
  ).setFiles({
    name: "design-reel.mp4",
    mimeType: "video/mp4",
    buffer: await fs.readFile("tests/free-video.mp4"),
  });
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await page.getByRole("tab", { name: "Reels", exact: true }).click();
  await expect(
    page
      .getByTestId("reels-feed")
      .getByText("Küçük bir hareket, yeni bir hikâye.", { exact: true }),
  ).toBeVisible();
  await expect
    .poll(() =>
      page
        .getByTestId("reels-feed")
        .locator("video")
        .evaluateAll((videos) =>
          (videos as HTMLVideoElement[]).some(
            (v) =>
              v.src.startsWith("blob:") &&
              v.readyState >= 1 &&
              v.videoWidth === 160,
          ),
        ),
    )
    .toBe(true);
  await page.getByRole("button", { name: "Beğen", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Beğeniyi geri al", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Kaydet", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Kaydedildi", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Yorumlar", exact: true }).click();
  await page.getByPlaceholder("Bir şey söyle…").fill("Güzel bir reel!");
  await page.getByRole("button", { name: "Yorum gönder", exact: true }).click();
  await expect(
    page.getByText("Güzel bir reel!", { exact: false }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Kapat", exact: true }).click();
  await page.screenshot({ path: "artifacts/redesign-reels.png" });
});

test("private account requests stay locked until the other account explicitly accepts", async ({
  page,
  browser,
}) => {
  const context = await browser.newContext();
  try {
    const owner = await context.newPage();
    await login(owner, "private");
    await owner.getByRole("tab", { name: "Profil", exact: true }).click();
    await owner
      .getByRole("button", { name: "Profili düzenle", exact: true })
      .click();
    await owner
      .getByRole("switch", { name: "Gizli hesap", exact: true })
      .click();
    await owner.getByRole("button", { name: "Kaydet", exact: true }).click();
    await expect
      .poll(
        async () =>
          (await record("private", "users/" + users.private!.uid)).isPrivate,
      )
      .toBe(true);
    await login(page);
    await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
    await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
    await page
      .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
      .fill(users.private!.username);
    await page.getByText(users.private!.username, { exact: true }).click();
    await expect(
      page.getByText("Bu hesap gizli", { exact: true }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Takip isteği gönder", exact: true })
      .click();
    await expect(
      page.getByRole("button", { name: "İsteği geri çek", exact: true }),
    ).toBeVisible();
    const path = `follows/${users.deniz!.uid}_${users.private!.uid}`;
    await expect
      .poll(async () => (await record("deniz", path)).status)
      .toBe("pending");
    await owner.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
    await owner
      .getByRole("button", { name: "Bildirimler", exact: true })
      .click();
    await owner.getByRole("button", { name: "Kabul et", exact: true }).click();
    await expect
      .poll(async () => (await record("private", path)).status)
      .toBe("accepted");
    await expect(
      page.getByRole("button", { name: "Takipten çık", exact: true }),
    ).toBeVisible({ timeout: 15000 });
    await expect(page.getByText("Bu hesap gizli", { exact: true })).toHaveCount(
      0,
    );
  } finally {
    await context.close();
  }
});

test("story paging, direct replies and viewer records persist across both accounts", async ({
  page,
}) => {
  const ids: string[] = [];
  for (const caption of ["Günün ilk hikâyesi.", "Günün ikinci hikâyesi."]) {
    const mediaId = randomUUID(),
      bytes = await fs.readFile("tests/free-photo.jpg");
    await action("ece", "createUpload", {
      requestId: mediaId,
      kind: "image",
      purpose: "story",
      bytes: bytes.length,
    });
    const upload = await fetch(
      "http://127.0.0.1:5002/mediaUpload?id=" + mediaId,
      {
        method: "PUT",
        headers: { Authorization: "Bearer " + users.ece!.token },
        body: bytes,
      },
    );
    expect(upload.status).toBe(200);
    const id = randomUUID();
    await action("ece", "publishContent", {
      requestId: id,
      kind: "story",
      caption,
      mediaIds: [mediaId],
    });
    ids.push(id);
  }
  await login(page);
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
  await page
    .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
    .fill(users.ece!.username);
  await page.getByText(users.ece!.username, { exact: true }).click();
  if (
    await page
      .getByRole("button", { name: "Engeli kaldır", exact: true })
      .count()
  ) {
    await page
      .getByRole("button", { name: "Engeli kaldır", exact: true })
      .click();
    await expect
      .poll(() =>
        record("deniz", `users/${users.deniz!.uid}/blocks/${users.ece!.uid}`),
      )
      .toBeNull();
  }
  await expect(
    page.getByRole("button", { name: /^(Takip et|Takipten çık)$/ }),
  ).toBeVisible();
  if (await page.getByRole("button", { name: "Takip et", exact: true }).count())
    await page.getByRole("button", { name: "Takip et", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Takipten çık", exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", {
      name: `@${users.ece!.username} hikâyesi`,
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: `@${users.ece!.username} hikâyesi`,
      exact: true,
    })
    .click();
  await expect(
    page.getByText("Günün ikinci hikâyesi.", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Sonraki hikâye", exact: true })
    .click();
  await expect(
    page.getByText("Günün ilk hikâyesi.", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Önceki hikâye", exact: true })
    .click();
  await expect(
    page.getByText("Günün ikinci hikâyesi.", { exact: true }),
  ).toBeVisible();
  await page.getByPlaceholder("Mesaj gönder…").fill("Hikâyene selam!");
  await page
    .getByRole("button", { name: "Hikâyeye yanıt gönder", exact: true })
    .click();
  await expect(
    page.getByText("Yanıtın gönderildi.", { exact: true }),
  ).toBeVisible();
  await expect
    .poll(async () =>
      (await action("ece", "storyViewers", { id: ids[1] })).rows.some(
        (r: any) => r.id === users.deniz!.uid,
      ),
    )
    .toBe(true);
  await page.screenshot({ path: "artifacts/redesign-story.png" });
  await page
    .getByRole("button", { name: "Hikâyeyi kapat", exact: true })
    .click();
  await conversation(page);
  await expect(
    page.getByText("Hikâyene selam!", { exact: true }),
  ).toBeVisible();
});

test("a temporary profile sync failure preserves the active conversation and unsent draft", async ({
  page,
}) => {
  await login(page);
  await conversation(page);
  await page
    .getByPlaceholder("Mesaj yaz…")
    .fill("Bağlantı gidince taslağım kalsın.");
  let failOnce = true;
  await page.route("**/documents", async (route) => {
    const input = route.request().postDataJSON();
    if (
      failOnce &&
      (input?.operation === "batch" ? input.items : [input]).some(
        (read: any) =>
          read?.operation === "get" &&
          read.paths?.includes("users/" + users.deniz!.uid),
      )
    ) {
      failOnce = false;
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: { code: "unavailable", message: "Geçici bağlantı kesintisi." },
        }),
      });
    } else await route.continue();
  });
  const notice = page.getByText(
    "Şu an çevrimdışısın. Bağlantı gelince yeniden dene.",
    { exact: true },
  );
  await expect(notice).toBeVisible({ timeout: 15000 });
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue(
    "Bağlantı gidince taslağım kalsın.",
  );
  await expect(
    page.getByText("Bağlantıyı yenileyelim.", { exact: true }),
  ).toHaveCount(0);
  await expect(notice).toHaveCount(0, { timeout: 15000 });
  await expect(page.getByPlaceholder("Mesaj yaz…")).toHaveValue(
    "Bağlantı gidince taslağım kalsın.",
  );
});
