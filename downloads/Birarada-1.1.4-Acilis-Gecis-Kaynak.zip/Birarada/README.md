# Birarada 1.1.4 — açılış ve sayfa geçişleri

Açılıştaki sabit 1,4 saniyelik bekleme kaldırıldı. Oturum doğrulandıktan sonra profil ve mesaj ön yüklemesi ana sayfa isteğinden bağımsız başlıyor; daha önce açılmış profilin başlığı ve sayaçları yeniden doğrulanırken ekranda kalıyor. Bu sürümde sunucu kodu ve gereken Edge revizyonu değişmedi.

Profil, gönderi ayrıntısı, gelen kutusu ve son iki sohbetin daha önce yetkili olarak alınan verileri oturum belleğinden gösterilir; güncel veri arkada doğrulanır. Ekranlar arasında geçişte aynı sorgu yeniden çoğaltılmaz. Takip, beğeni, grup ve mesaj bildirimleri için animasyonlu uygulama içi kart, sayaç ve doğru ekrana geçiş eklendi. Ayrıntılı davranış ve telefon kurulumu: [HIZ_VE_BILDIRIM.md](docs/HIZ_VE_BILDIRIM.md).

Akış yenilenirken kartların kaybolması, gizli hesap paylaşımının yanlış akışa dönmesi, profilde eski gönderilerin kalması ve bağlantı sonrası takılı kalan hata durumları düzeltildi. Ayrıntılar [docs/AKIS_DUZELTMELERI.md](docs/AKIS_DUZELTMELERI.md).

Beyaz arayüz, kenardan kenara gönderiler, hikâye halkaları, 3 sütunlu profil/keşfet ızgarası, tam ekran Reels ve konuşma balonlarıyla uygulama yeniden düzenlendi. Birarada adı ve logosu korunur. Çalışan özellikler ve sınırlar [docs/YENI_ARAYUZ.md](docs/YENI_ARAYUZ.md), gerçek kontroller [TEST_REPORT.md](TEST_REPORT.md) içindedir.

Paket **com.birarada.app**, **versionName 1.1.4 / versionCode 6**. Önceki düzeltme code5 kullanıyordu; bu güncelleme code6 kullanır. Mevcut EAS **@ahmedberat/birarada**, proje **9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b**, mevcut upload keystore korunur. Firebase Authentication **birarada-5650c**, sosyal veri/özel medya Supabase **qinevhhhdtslnzrtcanq** üzerinden çalışır.

## Windows'ta mevcut uygulamayı güncelleme

ZIP'in tamamını yeni bir klasöre çıkar. Aynı klasörde iki kurulum/derleme penceresini birlikte çalıştırma. Node.js 22/24 LTS ve Chrome veya Edge bulunmalı. Yerel Firebase Auth emulator testi Java gerektirmez.

**GUNCELLE_VE_AAB.bat** dosyasını aç. Bu yardımcı:

1. Bağımlılıkları kurar; tip ve güvenlik testlerini çalıştırır.
2. Resmî Supabase CLI ile mevcut projedeki Edge sunucusunu günceller. Akışın erişim sorguları toplu hale getirilir. Bu güncelleme veritabanı migration'ı çalıştırmaz, hesapları/medyayı silmez, ücretli plan açmaz. Hesaba bağlı oturum yoksa sağlayıcının resmî giriş ekranını açar.
3. Firebase Android açık yapılandırmasını resmî CLI ile alır; ardından uygulama, sunucu ve tarayıcı testlerini, canlı sunucu sürümü ve mevcut yasal sayfa kontrollerini çalıştırır. Başarısız kontrol atlanmaz.
4. Telefon push bildirimi için EAS hesabındaki FCM v1 yetkisini **BILDIRIM_KUR.bat** ile kontrol et. Gizli anahtar kaynaklara veya sohbete eklenmez.
5. Mevcut EAS projesi ve mevcut imza ile üretim AAB derlemesini başlatır. Yeni AAB indirme bağlantısı EAS çıktısında görünür. Mağazaya otomatik göndermez.

CMD'den aynı işlem:

```bat
npm run backend:update
npm run build:no-github
```

İlk sunucu kurulumu için `UCRETSIZ_KUR.bat` / `npm run backend:deploy` bulunur; mevcut çalışan projede yukarıdaki güncelleme yeterlidir. Yasal sayfaların içeriği değişmedi; güncel sayfalar mevcut sitede zaten yayımlandıysa yeniden yayın gerekmiyor. Gerektiğinde mevcut siteyi koruyan `npm run legal:deploy` kullanılır.

## Web'de kontrol

Bağımlılıklar kurulduktan sonra **WEB_TEST.bat** veya `npm run web:local`; adres **http://localhost:8081**. Pencere açık kalmalı. Yerel Auth emulator, PostgreSQL uyumlu PGlite ve özel medya API'si kullanılır. Bu moddaki hesaplar yereldir; canlı hesapların ve sunucu verilerinin yerine geçmez. Otomatik test kullanıcıları yalnız test başlatıcısında oluşturulur; üretime örnek hesap veya içerik eklenmez.

## Hesap ve altyapı

Firebase girişleri ve Supabase verileri korunur. Eski Firestore içeriği otomatik taşınmaz. Sunucu sağlık yanıtında `revision: 2026-10-27-instant1` beklenir; eski sunucuyla yeni derleme önkontrolde durur. Eski uygulama da güncel sunucuyu kullanmaya devam edebilir.

Parola, token, service_role veya imzalama anahtarı kaynak paketine eklenmez. Yönetim yetkisi sunucudaki role kaydından gelir. Doğrulanmış sahip hesabı, Ayarlar'daki resmî hesap etkinleştirmesiyle mevcut owner UID'ye bağlanır; istemci kendine yönetici yetkisi veremez. Destek: **ahmedberatazboy0@gmail.com**.

Medya yalnız yetkili oturumla açılır. Fotoğraf istemcide JPEG'e çevrilir, EXIF sunucuda kaldırılır. Ücretsiz altyapıda video H.264 MP4, ses AAC M4A olmalı; sunucuda video dönüştürme yoktur. Native ses kaydı bulunur; tarayıcı kaydı desteği biçim/cihaza bağlıdır. Sohbetler uygulama öndeyken 3 saniyede, normal kayıtlar 10 saniyede, beğeni/kaydetme listeleri 60 saniyede sorgulanır. Gizli ekranlardaki liste sorguları durur; yazımdan sonra ilgili yerel listeler yenilenir. Ana sayfanın ilk sayfası öndeyken 15 saniyede yenilenir. Daha eski sayfalara geçildiğinde kaydırma sırasında listeyi kısaltmamak için bu otomatik yenileme durur; aşağı çekme veya ekrana dönüş listeyi tazeler. Bu, WebSocket veya uçtan uca şifreleme değildir.

Ücretsiz sağlayıcı kotaları ve proje askıya alma koşulları geçerlidir. Uygulamadaki kota korumaları sağlayıcı faturası/kota hesabının yerine geçmez. Telefon push gönderimi toplu ve yüksek önceliklidir; geçici hatalar kuyrukta kalır. Gerçek FCM/EAS bağlantısı ve telefona teslimi ayrıca doğrulanmalıdır. Operatör SMS gönderimi yoktur.

**Bu ZIP kaynak kodudur. Yeni imzalı AAB bu bulut oturumunda üretilmedi; yeni sürüm gerçek Android cihazda henüz denenmedi.** Son AAB'nin imzası, hedef API ve 16 KB native uyumluluğu Play Console'da doğrulanmalı. Mevcut Play hesabında görünen kapalı test koşulları ayrıca geçerlidir.
