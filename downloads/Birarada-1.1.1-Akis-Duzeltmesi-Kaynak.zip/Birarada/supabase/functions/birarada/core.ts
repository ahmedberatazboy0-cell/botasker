import {
  type DocumentData,
  FieldPath,
  FieldValue,
  type Query,
  Timestamp,
  type Transaction,
} from "./records.ts";
import { accounts, current, db, deleteBlob, HttpsError } from "./context.ts";
import { AsyncLocalStorage } from "node:async_hooks";
import { createHash } from "node:crypto";
const process = {
  env: {
    OWNER_EMAIL: "ahmedberatazboy0@gmail.com",
    ENABLE_OWNER_BOOTSTRAP: "true",
    GCLOUD_PROJECT: "birarada-5650c",
  },
};
type DecodedIdToken = Record<string, any>;
import {
  type Actor,
  canMessage,
  canView,
  id,
  InputError,
  LIMITS,
  parseUpload,
  rangeHeader,
  REACTIONS,
  requireRole,
  roleFromToken,
  safeMembers,
  searchTokens,
  text,
  uuid,
} from "./domain.ts";
const now = () => Timestamp.now();
const hash = (s: string) => createHash("sha256").update(s).digest("hex");
const ref = (collection: string, key: string) =>
  db.collection(collection).doc(id(key));
const requestCache = new AsyncLocalStorage<
  Map<string, Promise<DocumentData | undefined>>
>();
function cachedRecord(path: string) {
  const cache = requestCache.getStore();
  if (cache?.has(path)) return cache.get(path)!;
  const promise = db
    .doc(path)
    .get()
    .then((row) => row.data());
  cache?.set(path, promise);
  return promise;
}
async function data(collection: string, key: string) {
  return cachedRecord(`${collection}/${id(key)}`);
}
// One bounded database round trip for a feed page's authorization records.
// The cache is scoped to one API request, never shared across users or requests.
async function primeRecords(paths: string[]) {
  const cache = requestCache.getStore();
  if (!cache) return;
  const missing = [...new Set(paths)].filter((path) => !cache.has(path));
  if (!missing.length) return;
  const rows = await db.getAll(...missing.map((path) => db.doc(path)));
  for (const row of rows) cache.set(row.raw.path, Promise.resolve(row.data()));
}
async function primeVisibility(viewer: string, posts: DocumentData[]) {
  const paths = [`users/${viewer}`, `accountStatus/${viewer}`];
  for (const owner of new Set(posts.map((post) => id(String(post.uid))))) {
    paths.push(`users/${owner}`, `accountStatus/${owner}`);
    if (viewer !== owner)
      paths.push(
        `follows/${viewer}_${owner}`,
        `users/${viewer}/blocks/${owner}`,
        `users/${owner}/blocks/${viewer}`,
      );
  }
  await primeRecords(paths);
}

function actor(token: DecodedIdToken | Record<string, any>): Actor {
  return {
    uid: id(token.uid),
    role: roleFromToken(token),
    emailVerified: token.email_verified === true,
  };
}
export async function active(uid: string) {
  const [profile, status] = await Promise.all([
    data("users", uid),
    data("accountStatus", uid),
  ]);
  return !!profile && !profile.deletionPending && status?.suspended !== true;
}
export async function blocked(a: string, b: string) {
  const paths = [
    `users/${id(a)}/blocks/${id(b)}`,
    `users/${id(b)}/blocks/${id(a)}`,
  ];
  if (requestCache.getStore()) {
    await primeRecords(paths);
    return (await Promise.all(paths.map(cachedRecord))).some(Boolean);
  }
  return (await db.getAll(...paths.map((path) => db.doc(path)))).some(
    (row) => row.exists,
  );
}

export async function follows(a: string, b: string) {
  return (await data("follows", `${a}_${b}`))?.status === "accepted";
}
export async function visible(
  viewer: string,
  post: DocumentData,
  story = false,
) {
  const owner = String(post.uid),
    profile = await data("users", owner);
  return canView({
    self: viewer === owner,
    viewerActive: await active(viewer),
    ownerActive: await active(owner),
    blocked: viewer === owner ? false : await blocked(viewer, owner),
    follows: viewer === owner ? true : await follows(viewer, owner),
    isPrivate: profile?.isPrivate === true || post.audience === "private",
    expired: story && (post.expiresAt?.toMillis?.() || 0) <= Date.now(),
  });
}
async function mayMessage(a: string, b: string) {
  const profile = await data("users", b);
  return canMessage({
    self: a === b,
    viewerActive: await active(a),
    ownerActive: await active(b),
    blocked: await blocked(a, b),
    follows: false,
    isPrivate: true,
    strangerAllowed: profile?.allowStrangerDM === true,
    followsViewer: await follows(b, a),
  });
}
async function chatAccess(uid: string, chatId: string, writing = false) {
  const chat = await data("chats", chatId);
  if (!chat || !chat.memberIds?.includes(uid)) {
    throw new HttpsError("permission-denied", "Bu sohbetin üyesi değilsin.");
  }
  if (writing) {
    for (const member of chat.memberIds) {
      if (
        !(await active(member)) ||
        (member !== uid && (await blocked(uid, member)))
      ) {
        throw new HttpsError(
          "permission-denied",
          "Bu sohbette mesaj gönderemezsin.",
        );
      }
    }
  }
  return chat;
}
function serialize(value: any): any {
  if (value instanceof Timestamp) {
    return { seconds: value.seconds, nanoseconds: value.nanoseconds };
  }
  if (Array.isArray(value)) return value.map(serialize);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).map(([k, v]) => [k, serialize(v)]),
    );
  }
  return value;
}
async function rate(uid: string, scope: string, max: number, bytes = 0) {
  const key = hash(`${uid}:${scope}:${Math.floor(Date.now() / 60000)}`),
    target = ref("rateLimits", key);
  const daily = ref(
    "rateLimits",
    hash(`${uid}:upload:${new Date().toISOString().slice(0, 10)}`),
  );
  await db.runTransaction(async (tx) => {
    const row = await tx.get(target),
      dailyRow = bytes ? await tx.get(daily) : null;
    if (
      (row.data()?.count || 0) >= max ||
      (bytes && (dailyRow?.data()?.bytes || 0) + bytes > 200 * 1024 ** 2)
    ) {
      throw new HttpsError(
        "resource-exhausted",
        "İşlem sınırına ulaştın. Biraz sonra yeniden dene.",
      );
    }
    tx.set(target, {
      count: (row.data()?.count || 0) + 1,
      expiresAt: Timestamp.fromMillis(Date.now() + 2 * 86400000),
    });
    if (bytes) {
      tx.set(daily, {
        bytes: (dailyRow?.data()?.bytes || 0) + bytes,
        expiresAt: Timestamp.fromMillis(Date.now() + 2 * 86400000),
      });
    }
  });
}
async function audit(a: Actor, action: string, target: string, reason: string) {
  await db.collection("auditLog").add({
    actorUid: a.uid,
    actorRole: a.role,
    action,
    target,
    reason,
    createdAt: now(),
  });
}
function cursor(query: Query, value: unknown) {
  if (!value) return query;
  const c = value as { seconds?: unknown; nanoseconds?: unknown; id?: unknown };
  if (
    !Number.isSafeInteger(c.seconds) ||
    !Number.isSafeInteger(c.nanoseconds) ||
    Number(c.nanoseconds) < 0 ||
    Number(c.nanoseconds) > 999999999
  ) {
    throw new InputError("Geçersiz sayfa.");
  }
  return query.startAfter(
    new Timestamp(Number(c.seconds), Number(c.nanoseconds)),
    id(c.id),
  );
}
function ordered(query: Query) {
  return query
    .orderBy("createdAt", "desc")
    .orderBy(FieldPath.documentId(), "desc");
}
function nextOf(row: any) {
  const t = row.data().createdAt as Timestamp;
  return { seconds: t.seconds, nanoseconds: t.nanoseconds, id: row.id };
}
async function notify(
  sourceUid: string,
  targetUid: string,
  type: string,
  label: string,
  target: Record<string, string>,
  key: string,
) {
  if (
    sourceUid === targetUid ||
    !(await active(targetUid)) ||
    (await blocked(sourceUid, targetUid))
  ) {
    return;
  }
  // Deterministic event IDs make Firestore trigger retries idempotent.
  const targetRef = ref("notifications", hash(key));
  await db.runTransaction(async (tx) => {
    if ((await tx.get(targetRef)).exists) return;
    tx.create(targetRef, {
      sourceUid,
      targetUid,
      type,
      text: label,
      read: false,
      createdAt: now(),
      target,
    });
  });
}

export async function mediaReadable(a: Actor, media: DocumentData) {
  if (a.role !== "member" && a.emailVerified) {
    const grant = await data("reviewGrants", `${a.uid}_${media.id}`);
    if (grant && grant.expiresAt?.toMillis() > Date.now()) {
      const report = await data("reports", grant.reportId);
      if (report?.snapshot?.mediaIds?.includes(media.id)) return true;
    }
  }
  if (!(await active(media.uid))) return false;
  if (a.uid === media.uid && !media.attachedTo) {
    return media.expiresAt?.toMillis() > Date.now();
  }
  const attached = media.attachedTo;
  if (!attached) return false;
  if (attached.collection === "users") {
    const profile = await data("users", attached.id);
    return (
      profile?.avatarMediaId === media.id && !(await blocked(a.uid, media.uid))
    );
  }
  if (attached.collection === "posts" || attached.collection === "stories") {
    const post = await data(attached.collection, attached.id);
    if (!post?.mediaIds?.includes(media.id)) return false;
    if (
      attached.collection === "stories" &&
      post.expiresAt?.toMillis() <= Date.now()
    ) {
      if (a.uid === media.uid) return true;
      if (!post.highlighted) return false;
      return visible(a.uid, post);
    }
    return visible(a.uid, post, attached.collection === "stories");
  }
  if (attached.collection === "messages") {
    const chat = await chatAccess(a.uid, attached.chatId);
    const message = (
      await db
        .doc(`chats/${id(attached.chatId)}/messages/${id(attached.id)}`)
        .get()
    ).data();
    return (
      !!message?.mediaIds?.includes(media.id) &&
      chat.memberIds.includes(a.uid) &&
      !(await blocked(a.uid, media.uid))
    );
  }
  return false;
}
async function attach(
  tx: Transaction,
  ids: string[],
  uid: string,
  purpose: string,
  attachedTo: Record<string, string>,
) {
  const rows = ids.length
    ? await tx.getAll(...ids.map((key) => ref("media", key)))
    : [];
  for (const row of rows) {
    const m = row.data();
    if (
      !m ||
      m.uid !== uid ||
      m.status !== "ready" ||
      m.purpose !== purpose ||
      m.attachedTo ||
      m.expiresAt.toMillis() <= Date.now()
    ) {
      throw new HttpsError(
        "failed-precondition",
        "Medya yüklemesini tamamlayıp yeniden dene.",
      );
    }
  }
  return Object.assign(
    () =>
      rows.forEach((row) =>
        tx.update(row.ref, {
          attachedTo,
          attachedAt: now(),
          expiresAt: FieldValue.delete(),
        }),
      ),
    {
      items: rows.map((row) => ({
        id: row.id,
        kind: row.get("kind"),
        width: row.get("width"),
        height: row.get("height"),
        duration: row.get("duration"),
      })),
    },
  );
}

async function dispatch(
  a: Actor,
  action: string,
  input: Record<string, any>,
): Promise<any> {
  if (action === "activateOwner") {
    const ownerEmail = process.env.OWNER_EMAIL?.trim().toLowerCase();
    if (process.env.ENABLE_OWNER_BOOTSTRAP !== "true" || !ownerEmail) {
      throw new HttpsError(
        "failed-precondition",
        "Resmî hesap kurulumu sunucuda henüz etkin değil.",
      );
    }
    const user = await accounts.getUser(a.uid);
    if (
      !user.emailVerified ||
      !a.emailVerified ||
      user.email?.toLowerCase() !== ownerEmail ||
      input.acceptTerms !== true
    ) {
      throw new HttpsError(
        "permission-denied",
        "Doğrulanmış hesap sahibi oturumu ve koşul onayı gerekli.",
      );
    }
    const ownerRef = ref("system", "owner"),
      usernameRef = ref("usernames", "birarada"),
      profileRef = ref("users", a.uid);
    await db.runTransaction(async (tx) => {
      const [owner, name, profile] = await tx.getAll(
        ownerRef,
        usernameRef,
        profileRef,
      );
      if (owner?.exists && owner.get("uid") !== a.uid) {
        throw new HttpsError(
          "permission-denied",
          "Hesap sahibi daha önce başka bir kullanıcı kimliğine bağlandı.",
        );
      }
      if (name?.exists && name.get("uid") !== a.uid) {
        throw new HttpsError(
          "already-exists",
          "Resmî kullanıcı adı kullanılıyor. Sunucu yöneticisi kontrol etmeli.",
        );
      }
      if (profile?.get("deletionPending") === true) {
        throw new HttpsError(
          "failed-precondition",
          "Önce başlatılan hesap silme işlemini tamamlamalısın.",
        );
      }
      const oldName = profile?.get("username"),
        old =
          oldName && oldName !== "birarada"
            ? await tx.get(ref("usernames", oldName))
            : null;
      if (!owner?.exists) {
        tx.create(ownerRef, {
          uid: a.uid,
          email: ownerEmail,
          createdAt: now(),
        });
      }
      tx.set(usernameRef, { uid: a.uid });
      if (old?.get("uid") === a.uid) tx.delete(old.ref);
      const initial = {
        uid: a.uid,
        username: "birarada",
        displayName: "Birarada",
        bio: "Birarada resmî hesabı",
        avatarUrl: "",
        website: "https://birarada-5650c.web.app",
        isPrivate: false,
        followersCount: 0,
        followingCount: 0,
        postsCount: 0,
        allowStrangerDM: true,
        createdAt: now(),
        deletionPending: false,
        termsAcceptedAt: now(),
        termsVersion: "2026-10-21-free1",
        official: true,
      };
      tx.set(
        profileRef,
        profile?.exists
          ? {
              ...profile.data(),
              username: "birarada",
              displayName: "Birarada",
              official: true,
            }
          : initial,
      );
    });
    await accounts.setCustomUserClaims(a.uid, {
      ...user.customClaims,
      biraradaRole: "owner",
    });
    await audit(
      { ...a, role: "owner" },
      "activateOwner",
      a.uid,
      "Doğrulanmış e-posta ve tek seferlik UID bağlantısı",
    );
    return { ok: true };
  }
  if (action === "acceptTerms") {
    if (input.version !== "2026-10-21-free1" || input.accepted !== true) {
      throw new InputError("Güncel koşulları açıkça onaylamalısın.");
    }
    await ref("users", a.uid).update({
      termsVersion: "2026-10-21-free1",
      termsAcceptedAt: now(),
    });
    return { ok: true };
  }
  if (action === "cleanupSocialData") {
    const profile = await data("users", a.uid);
    if (profile && !profile.deletionPending) {
      throw new HttpsError("failed-precondition", "Hesap silme onayı gerekli.");
    }
    const owned = await db.collection("media").where("uid", "==", a.uid).get();
    await removeAttachedMedia(owned.docs.map((row) => row.id));
    for (const collection of ["posts", "stories", "pushDevices"]) {
      const rows = await db
        .collection(collection)
        .where("uid", "==", a.uid)
        .get();
      for (const row of rows.docs) await db.recursiveDelete(row.ref);
    }
    await db.recursiveDelete(db.doc(`timelines/${a.uid}`));
    return { ok: true };
  }
  if (action === "capabilities") {
    return {
      role: a.role,
      emailVerified: a.emailVerified,
      protocol: 2,
      media: true,
      project: process.env.GCLOUD_PROJECT,
    };
  }
  if (!(await active(a.uid))) {
    throw new HttpsError(
      "permission-denied",
      "Hesabın kullanıma kapalı veya silinme aşamasında.",
    );
  }
  const reading = [
    "listContent",
    "followingFeed",
    "getContent",
    "storyFeed",
    "profileStats",
    "getAdminConfig",
    "searchUsers",
    "storyViewers",
    "dashboard",
    "adminList",
    "appConfig",
  ].includes(action);
  await rate(a.uid, reading ? "read" : "write", reading ? 100 : 30);
  const config = await data("appConfig", "public");
  if (!reading && config?.maintenance === true && a.role === "member") {
    throw new HttpsError(
      "unavailable",
      "Kısa bir bakımdayız. Biraz sonra tekrar dene.",
    );
  }

  if (action === "createUpload") {
    const upload = parseUpload(input),
      target = ref("media", upload.mediaId),
      existing = await target.get();
    if (existing.exists) {
      if (existing.data()?.uid !== a.uid) {
        throw new HttpsError(
          "permission-denied",
          "Bu işlem kimliği kullanılamaz.",
        );
      }
      return { id: existing.id, status: existing.data()?.status };
    }
    await rate(a.uid, "upload", 8, upload.bytes);
    await target.create({
      id: upload.mediaId,
      uid: a.uid,
      kind: upload.kind,
      purpose: upload.purpose,
      declaredBytes: upload.bytes,
      status: "pending",
      createdAt: now(),
      expiresAt: Timestamp.fromMillis(Date.now() + 3600000),
    });
    return { id: upload.mediaId, status: "pending" };
  }
  if (action === "publishContent") {
    const key = uuid(input.requestId),
      kind = input.kind;
    if (!["post", "story", "reel"].includes(kind)) {
      throw new InputError("Geçersiz paylaşım.");
    }
    const caption = text(input.caption || "", 2200),
      mediaIds = Array.isArray(input.mediaIds) ? input.mediaIds.map(uuid) : [];
    if (
      new Set(mediaIds).size !== mediaIds.length ||
      mediaIds.length > (kind === "post" ? 10 : 1) ||
      (!mediaIds.length && (kind !== "post" || !caption))
    ) {
      throw new InputError(
        "Gönderiye metin veya en fazla 10 medya ekle. Hikâye/Reels tek medya içermeli.",
      );
    }
    const words = (config?.blockedWords || []) as string[];
    if (words.some((w) => caption.toLocaleLowerCase("tr-TR").includes(w))) {
      throw new InputError("İçerik topluluk kurallarına uygun değil.");
    }
    const profile = (await data("users", a.uid))!,
      collection = kind === "story" ? "stories" : "posts",
      target = ref(collection, key);
    await db.runTransaction(async (tx) => {
      const previous = await tx.get(target);
      if (previous.exists) {
        const old = previous.data()!;
        if (old.uid !== a.uid) {
          throw new HttpsError("permission-denied", "Geçersiz işlem.");
        }
        if (
          old.caption !== caption ||
          old.kind !== kind ||
          JSON.stringify(old.mediaIds) !== JSON.stringify(mediaIds) ||
          old.commentsEnabled !== (input.commentsEnabled !== false)
        ) {
          throw new HttpsError(
            "failed-precondition",
            "Bu paylaşım daha önce farklı içerikle yayınlandı. Yeni bir paylaşım oluştur.",
          );
        }
        return;
      }
      const finish = await attach(tx, mediaIds, a.uid, kind, {
        collection,
        id: key,
      });
      tx.create(target, {
        uid: a.uid,
        username: profile.username,
        caption,
        kind,
        protocol: 2,
        mediaIds,
        mediaItems: finish.items,
        mediaType: kind === "reel" ? "video" : "image",
        mediaUrl: "",
        commentsEnabled: input.commentsEnabled !== false,
        audience: profile.isPrivate ? "private" : "public",
        tags: searchTokens(caption),
        createdAt: now(),
        ...(kind === "story"
          ? {
              expiresAt: Timestamp.fromMillis(Date.now() + 86400000),
              highlighted: false,
              highlightTitle: "",
            }
          : {}),
      });
      finish();
    });
    return { id: key };
  }
  if (action === "listContent") {
    const kind = ["post", "reel", "story"].includes(input.kind)
      ? input.kind
      : "post";
    const source = kind === "story" ? "stories" : "posts";
    let q: Query = db.collection(source);
    if (input.uid) q = q.where("uid", "==", id(input.uid));
    else q = q.where("audience", "==", "public");
    if (kind === "reel") q = q.where("kind", "==", "reel");
    if (input.highlighted === true && source === "stories") {
      q = q.where("highlighted", "==", true);
    }
    const terms = searchTokens(text(input.search || "", 100));
    if (terms[0]) q = q.where("tags", "array-contains", terms[0]);
    const result = await cursor(ordered(q), input.cursor).limit(40).get();
    await primeVisibility(
      a.uid,
      result.docs.map((row) => row.data()!),
    );
    const rows: any[] = [];
    let last: any;
    for (const row of result.docs) {
      last = row;
      const p = row.data()!;
      const storyExpired =
        source === "stories" && p.expiresAt?.toMillis() <= Date.now();
      if (
        storyExpired &&
        !(input.highlighted === true && p.highlighted) &&
        !(
          input.archived === true &&
          p.uid === a.uid &&
          p.createdAt.toMillis() > Date.now() - 30 * 86400000
        )
      ) {
        continue;
      }
      if (
        !(await visible(a.uid, p)) ||
        terms.some((t) => !(p.tags || []).includes(t))
      ) {
        continue;
      }
      rows.push({ id: row.id, ...serialize(p) });
      if (rows.length === 20) break;
    }
    return {
      rows,
      cursor:
        last && (result.size === 40 || rows.length === 20)
          ? nextOf(last)
          : null,
    };
  }
  if (action === "profileStats") {
    const uid = id(input.uid);
    if (!(await active(uid)) || (await blocked(a.uid, uid))) {
      throw new HttpsError("permission-denied", "Profil görünür değil.");
    }
    const values = await Promise.all([
      db.collection("posts").where("uid", "==", uid).count().get(),
      db
        .collection("follows")
        .where("followingUid", "==", uid)
        .where("status", "==", "accepted")
        .count()
        .get(),
      db
        .collection("follows")
        .where("followerUid", "==", uid)
        .where("status", "==", "accepted")
        .count()
        .get(),
    ]);
    return {
      posts: values[0]!.data().count,
      followers: values[1]!.data().count,
      following: values[2]!.data().count,
    };
  }
  if (action === "getContent") {
    const collection = input.kind === "story" ? "stories" : "posts",
      key = id(input.id),
      content = await data(collection, key);
    if (
      !content ||
      !(await visible(
        a.uid,
        content,
        collection === "stories" && !content.highlighted,
      ))
    ) {
      throw new HttpsError("permission-denied", "İçerik görünür değil.");
    }
    return { id: key, ...serialize(content) };
  }
  if (action === "followingFeed") {
    const result = await cursor(
      ordered(db.collection(`timelines/${a.uid}/posts`)),
      input.cursor,
    )
      .limit(40)
      .get();
    await primeRecords(result.docs.map((entry) => `posts/${entry.id}`));
    const candidates = await Promise.all(
      result.docs.map((entry) => data("posts", entry.id)),
    );
    await primeVisibility(
      a.uid,
      candidates.filter((post): post is DocumentData => !!post),
    );
    const rows: any[] = [];
    let last: any;
    for (const entry of result.docs) {
      last = entry;
      const post = await data("posts", entry.id);
      if (
        post &&
        (post.uid === a.uid || (await follows(a.uid, post.uid))) &&
        (await visible(a.uid, post))
      ) {
        rows.push({ id: entry.id, ...serialize(post) });
      }
      if (rows.length === 20) break;
    }
    return {
      rows,
      cursor:
        last && (result.size === 40 || rows.length === 20)
          ? nextOf(last)
          : null,
    };
  }
  if (action === "storyFeed") {
    let q: Query = db
      .collection("follows")
      .where("followerUid", "==", a.uid)
      .where("status", "==", "accepted")
      .orderBy(FieldPath.documentId());
    if (input.after) q = q.startAfter(id(input.after));
    const following = await q.limit(25).get(),
      owners: string[] = [
        ...(!input.after ? [a.uid] : []),
        ...following.docs.map((r) => r.get("followingUid")),
      ];
    const rows: any[] = [];
    for (const owner of owners) {
      const posts = await db
        .collection("stories")
        .where("uid", "==", owner)
        .where("createdAt", ">", Timestamp.fromMillis(Date.now() - 86400000))
        .orderBy("createdAt", "desc")
        .limit(1)
        .get();
      const latest = posts.docs[0];
      if (latest && (await visible(a.uid, latest.data()!, true))) {
        rows.push({ id: latest.id, ...serialize(latest.data()) });
      }
    }
    return {
      rows,
      after: following.size === 25 ? following.docs.at(-1)?.id : null,
    };
  }
  if (action === "searchUsers") {
    const prefix = text(input.search || "", 24).toLocaleLowerCase("tr-TR");
    let q: Query = db
      .collection("users")
      .orderBy("username")
      .startAt(prefix)
      .endAt(prefix + "\uf8ff");
    if (input.after) {
      q = db
        .collection("users")
        .orderBy("username")
        .startAfter(text(input.after, 24))
        .endAt(prefix + "\uf8ff");
    }
    const result = await q.limit(30).get(),
      rows: any[] = [];
    for (const row of result.docs) {
      if ((await active(row.id)) && !(await blocked(a.uid, row.id))) {
        rows.push({ id: row.id, ...serialize(row.data()) });
      }
    }
    return {
      rows,
      after: result.size === 30 ? result.docs.at(-1)?.get("username") : null,
    };
  }
  if (action === "storyView") {
    const story = await data("stories", id(input.id));
    if (!story || !(await visible(a.uid, story, true))) {
      throw new HttpsError("permission-denied", "Hikâye görünür değil.");
    }
    if (story.uid !== a.uid) {
      await db
        .doc(`stories/${id(input.id)}/views/${a.uid}`)
        .set({ uid: a.uid, viewedAt: now() });
    }
    return { ok: true };
  }
  if (action === "storyViewers") {
    const key = id(input.id),
      story = await data("stories", key);
    if (story?.uid !== a.uid) {
      throw new HttpsError(
        "permission-denied",
        "Yalnız kendi hikâyenin izleyenlerini görebilirsin.",
      );
    }
    let q: Query = db
      .collection(`stories/${key}/views`)
      .orderBy("viewedAt", "desc");
    if (input.after) {
      const after = await db
        .doc(`stories/${key}/views/${id(input.after)}`)
        .get();
      if (after.exists) q = q.startAfter(after);
    }
    const result = await q.limit(50).get();
    return {
      rows: await Promise.all(
        result.docs.map(async (r) => ({
          id: r.id,
          ...serialize(r.data()),
          username: (await data("users", r.id))?.username || "Silinmiş hesap",
        })),
      ),
      after: result.size === 50 ? result.docs.at(-1)?.id : null,
    };
  }
  if (action === "highlightStory") {
    const target = ref("stories", id(input.id));
    if ((await target.get()).data()?.uid !== a.uid) {
      throw new HttpsError("permission-denied", "Bu hikâye sana ait değil.");
    }
    await target.update({
      highlighted: input.enabled === true,
      highlightTitle: text(input.title || "Öne çıkanlar", 30, true),
    });
    return { ok: true };
  }
  if (action === "setAvatar") {
    const mediaId = uuid(input.mediaId);
    await db.runTransaction(async (tx) => {
      const profile = await tx.get(ref("users", a.uid));
      const finish = await attach(tx, [mediaId], a.uid, "avatar", {
        collection: "users",
        id: a.uid,
      });
      tx.update(profile.ref, { avatarMediaId: mediaId });
      finish();
    });
    return { ok: true };
  }
  if (action === "createChat") {
    const members = safeMembers(input.members, a.uid),
      group = members.length > 2 || input.group === true;
    for (const other of members) {
      if (other !== a.uid && !(await mayMessage(a.uid, other))) {
        throw new HttpsError(
          "permission-denied",
          "Seçilen kişilerden biri bu sohbeti kabul etmiyor.",
        );
      }
    }
    // Check every pair before adding people to a group, not only its creator.
    if (group) {
      for (const x of members) {
        for (const y of members) {
          if (x < y && (await blocked(x, y))) {
            throw new HttpsError(
              "permission-denied",
              "Engelli hesaplar aynı gruba eklenemez.",
            );
          }
        }
      }
    }
    const key = group ? uuid(input.requestId) : members.join(":"),
      target = ref("chats", key),
      title = group ? text(input.title, 60, true) : "Sohbet";
    await db.runTransaction(async (tx) => {
      const existing = await tx.get(target);
      if (existing.exists) {
        if (!existing.data()?.memberIds.includes(a.uid)) {
          throw new HttpsError("permission-denied", "Geçersiz sohbet.");
        }
        tx.update(target, { protocol: 2 });
        return;
      }
      tx.create(target, {
        protocol: 2,
        kind: group ? "group" : "direct",
        title,
        ownerUid: a.uid,
        memberIds: members,
        createdAt: now(),
        lastMessage: "",
        lastMessageAt: now(),
      });
    });
    return { id: key };
  }
  if (action === "updateGroup") {
    const key = id(input.chatId),
      chat = await chatAccess(a.uid, key, true);
    if (chat.kind !== "group" || chat.ownerUid !== a.uid) {
      throw new HttpsError(
        "permission-denied",
        "Grubu yalnız kurucusu düzenleyebilir.",
      );
    }
    await ref("chats", key).update({ title: text(input.title, 60, true) });
    return { ok: true };
  }
  if (action === "leaveGroup") {
    const target = ref("chats", id(input.chatId));
    await db.runTransaction(async (tx) => {
      const chat = (await tx.get(target)).data();
      if (!chat || chat.kind !== "group" || !chat.memberIds.includes(a.uid)) {
        throw new HttpsError("permission-denied", "Grubun üyesi değilsin.");
      }
      const members = chat.memberIds.filter((u: string) => u !== a.uid);
      tx.update(target, {
        memberIds: members,
        ownerUid: chat.ownerUid === a.uid ? members[0] || "" : chat.ownerUid,
      });
    });
    return { ok: true };
  }
  if (action === "sendMessage") {
    const chatId = id(input.chatId),
      chat = await chatAccess(a.uid, chatId, true),
      key = uuid(input.requestId);
    const message = text(input.text || "", 2000),
      mediaIds: string[] = Array.isArray(input.mediaIds)
        ? input.mediaIds.map(uuid)
        : [];
    if (mediaIds.length > 1 || (!message && !mediaIds.length)) {
      throw new InputError("Bir mesaj veya tek medya ekle.");
    }
    const target = db.doc(`chats/${chatId}/messages/${key}`);
    await db.runTransaction(async (tx) => {
      const existing = await tx.get(target);
      if (existing.exists) {
        const old = existing.data()!;
        if (old.senderUid !== a.uid) {
          throw new HttpsError("permission-denied", "Geçersiz mesaj.");
        }
        if (
          old.text !== message ||
          JSON.stringify(old.mediaIds) !== JSON.stringify(mediaIds) ||
          (old.replyTo || "") !== (input.replyTo || "")
        ) {
          throw new HttpsError(
            "failed-precondition",
            "Bu mesaj zaten gönderildi. Yeni bir mesaj oluştur.",
          );
        }
        return;
      }
      const replied = input.replyTo
        ? await tx.get(db.doc(`chats/${chatId}/messages/${id(input.replyTo)}`))
        : null;
      if (replied && !replied.exists) {
        throw new InputError("Yanıtlanan mesaj artık yok.");
      }
      const finish = await attach(tx, mediaIds, a.uid, "message", {
        collection: "messages",
        chatId,
        id: key,
      });
      tx.create(target, {
        senderUid: a.uid,
        text: message,
        mediaIds,
        mediaItems: finish.items,
        type: mediaIds.length ? "media" : "text",
        createdAt: now(),
        seenBy: [a.uid],
        reactions: {},
        ...(input.replyTo ? { replyTo: id(input.replyTo) } : {}),
      });
      tx.update(ref("chats", chatId), {
        protocol: 2,
        lastMessage: mediaIds.length ? "Medya mesajı" : message.slice(0, 100),
        lastMessageAt: now(),
      });
      finish();
    });
    return { id: key };
  }
  if (
    ["reactMessage", "editMessage", "markSeen", "deleteMessage"].includes(
      action,
    )
  ) {
    const chatId = id(input.chatId);
    await chatAccess(a.uid, chatId, action !== "markSeen");
    if (action === "markSeen") {
      if (!Array.isArray(input.ids) || input.ids.length > 100) {
        throw new InputError("Geçersiz mesaj listesi.");
      }
      const batch = db.batch();
      for (const key of input.ids) {
        batch.update(db.doc(`chats/${chatId}/messages/${id(key)}`), {
          seenBy: FieldValue.arrayUnion(a.uid),
        });
      }
      await batch.commit();
      return { ok: true };
    }
    const target = db.doc(`chats/${chatId}/messages/${id(input.id)}`),
      message = (await target.get()).data();
    if (!message) throw new HttpsError("not-found", "Mesaj bulunamadı.");
    if (action === "reactMessage") {
      if (input.reaction !== "" && !REACTIONS.includes(input.reaction)) {
        throw new InputError("Geçersiz tepki.");
      }
      await target.update(
        new FieldPath("reactions", a.uid),
        input.reaction || FieldValue.delete(),
      );
    } else {
      if (message.senderUid !== a.uid) {
        throw new HttpsError("permission-denied", "Mesaj sana ait değil.");
      }
      if (action === "deleteMessage") await target.delete();
      else {
        await target.update({
          text: text(input.text, 2000, true),
          editedAt: now(),
        });
      }
    }
    return { ok: true };
  }
  if (action === "registerPush") {
    const token = text(input.token, 200, true);
    if (!/^(Expo|Exponent)PushToken\[[A-Za-z0-9_\-]+\]$/.test(token)) {
      throw new InputError("Geçersiz bildirim kaydı.");
    }
    const target = ref("pushDevices", hash(token));
    const installation = text(input.installation, 72, true);
    if (!/^[a-f0-9-]{72}$/i.test(installation)) {
      throw new InputError("Geçersiz cihaz bağlantısı.");
    }
    await db.runTransaction(async (tx) => {
      const existing = await tx.get(target);
      if (
        existing.exists &&
        existing.data()?.uid !== a.uid &&
        existing.data()?.installationHash !== hash(installation)
      ) {
        throw new HttpsError(
          "permission-denied",
          "Cihaz bağlantısı doğrulanamadı.",
        );
      }
      tx.set(target, {
        uid: a.uid,
        token,
        installationHash: hash(installation),
        enabled: true,
        updatedAt: now(),
      });
    });
    return { ok: true };
  }
  if (action === "unregisterPush") {
    const target = ref("pushDevices", hash(text(input.token, 200, true)));
    if ((await target.get()).data()?.uid === a.uid) await target.delete();
    return { ok: true };
  }
  if (action === "appConfig") {
    return {
      announcement: config?.announcement || "",
      maintenance: config?.maintenance === true,
    };
  }
  if (action === "reportChat") {
    const chatId = id(input.chatId),
      chat = await chatAccess(a.uid, chatId),
      reason = text(input.reason, 500, true);
    const message = input.messageId
      ? (
          await db.doc(`chats/${chatId}/messages/${id(input.messageId)}`).get()
        ).data()
      : null;
    if (input.messageId && !message) {
      throw new HttpsError("not-found", "Mesaj bulunamadı.");
    }
    if (chat.kind === "group" && !message) {
      throw new InputError("Şikâyet etmek istediğin mesajı önce seç.");
    }
    const targetUid =
      message?.senderUid || chat.memberIds.find((u: string) => u !== a.uid);
    if (!targetUid || targetUid === a.uid) {
      throw new InputError("Kendi mesajını şikâyet edemezsin.");
    }
    await ref(
      "reports",
      hash(`${a.uid}:chat:${chatId}:${input.messageId || "general"}`),
    ).set({
      reporterUid: a.uid,
      targetUid,
      reason,
      chatId,
      messageId: input.messageId || "",
      snapshot: {
        text: message?.text || "",
        mediaIds: message?.mediaIds || [],
      },
      createdAt: now(),
      status: "open",
    });
    return { ok: true };
  }
  if (action === "reportContent") {
    const collection = input.kind === "story" ? "stories" : "posts",
      key = id(input.id),
      content = await data(collection, key);
    if (
      !content ||
      content.uid === a.uid ||
      !(await visible(
        a.uid,
        content,
        collection === "stories" && !content.highlighted,
      ))
    ) {
      throw new HttpsError(
        "permission-denied",
        "Bu içeriği şikâyet edemezsin.",
      );
    }
    const keyHash = hash(`${a.uid}:${collection}:${key}`);
    await ref("reports", keyHash).set({
      reporterUid: a.uid,
      targetUid: content.uid,
      contentCollection: collection,
      contentId: key,
      reason: text(input.reason, 500, true),
      snapshot: {
        caption: content.caption || "",
        mediaIds: content.mediaIds || [],
      },
      createdAt: now(),
      status: "open",
    });
    return { ok: true };
  }
  if (action === "deleteContent") {
    const collection = input.kind === "story" ? "stories" : "posts",
      target = ref(collection, id(input.id)),
      post = (await target.get()).data();
    if (post?.uid !== a.uid) {
      throw new HttpsError("permission-denied", "Bu paylaşım sana ait değil.");
    }
    await db.recursiveDelete(target);
    return { ok: true };
  }

  // Every management route is checked here on the server, regardless of UI state.
  requireRole(a, "moderator");
  if (action === "reviewReport") {
    const key = id(input.id),
      report = await data("reports", key);
    if (!report) throw new HttpsError("not-found", "Şikâyet bulunamadı.");
    const mediaIds =
        report.snapshot?.mediaIds || report.noteSnapshot?.mediaIds || [],
      mediaItems = [];
    for (const keyId of mediaIds) {
      const media = await data("media", uuid(keyId));
      if (!media) continue;
      await ref("reviewGrants", `${a.uid}_${keyId}`).set({
        reportId: key,
        expiresAt: Timestamp.fromMillis(Date.now() + 15 * 60000),
      });
      mediaItems.push({ id: keyId, kind: media.kind });
    }
    await audit(a, "reviewReport", key, "Şikâyet kanıtı görüntülendi");
    return { report: { id: key, ...serialize(report) }, mediaItems };
  }
  if (action === "dashboard") {
    const counts = await Promise.all(
      ["users", "posts", "stories", "reports", "chats"].map(async (c) => [
        c,
        (await db.collection(c).count().get()).data().count,
      ]),
    );
    return { counts: Object.fromEntries(counts), role: a.role };
  }
  if (action === "adminList") {
    const collection = input.collection;
    if (
      ![
        "reports",
        "users",
        "auditLog",
        "posts",
        "stories",
        "accountStatus",
      ].includes(collection)
    ) {
      throw new InputError("Geçersiz yönetim listesi.");
    }
    if (collection === "auditLog" || collection === "accountStatus") {
      requireRole(a, "admin");
    }
    let q: Query = db.collection(collection).orderBy(FieldPath.documentId());
    if (input.after) q = q.startAfter(id(input.after));
    const rows = await q.limit(30).get();
    return {
      rows: rows.docs.map((r) => ({ id: r.id, ...serialize(r.data()) })),
      after: rows.size === 30 ? rows.docs.at(-1)?.id : null,
    };
  }
  if (action === "resolveReport") {
    const target = ref("reports", id(input.id));
    if (!(await target.get()).exists) {
      throw new HttpsError("not-found", "Şikâyet bulunamadı.");
    }
    await target.update({
      status: input.status === "reviewing" ? "reviewing" : "closed",
      resolution: text(input.reason, 500, true),
      resolvedBy: a.uid,
      resolvedAt: now(),
    });
    await audit(a, action, target.id, text(input.reason, 500, true));
    return { ok: true };
  }
  if (action === "removeContent") {
    const collection = input.kind === "story" ? "stories" : "posts",
      target = ref(collection, id(input.id)),
      reason = text(input.reason, 500, true);
    await audit(a, action, `${collection}:${target.id}`, reason);
    await db.recursiveDelete(target);
    return { ok: true };
  }
  requireRole(a, "admin");
  if (action === "setUserStatus") {
    const targetUid = id(input.uid),
      targetUser = await accounts.getUser(targetUid),
      reason = text(input.reason, 500, true);
    if (
      targetUid === a.uid ||
      targetUser.customClaims?.biraradaRole === "owner" ||
      targetUser.customClaims?.biraradaRole === "admin"
    ) {
      throw new InputError("Bu yönetici hesabı buradan kısıtlanamaz.");
    }
    // Write the database gate first: revoked tokens cannot continue reading media.
    await db.runTransaction(async (tx) => {
      const profile = await tx.get(ref("users", targetUid));
      tx.set(ref("accountStatus", targetUid), {
        suspended: input.suspended === true,
        reason,
        changedAt: now(),
        changedBy: a.uid,
      });
      if (profile.exists) {
        tx.update(profile.ref, { suspended: input.suspended === true });
      }
    });
    await accounts.updateUser(targetUid, {
      disabled: input.suspended === true,
    });
    if (input.suspended === true) await accounts.revokeRefreshTokens(targetUid);
    await audit(a, action, targetUid, reason);
    return { ok: true };
  }
  if (action === "getAdminConfig") {
    return config || { announcement: "", maintenance: false, blockedWords: [] };
  }
  if (action === "saveConfig") {
    const words: string[] = Array.isArray(input.blockedWords)
      ? input.blockedWords.map((w: unknown) =>
          text(w, 40, true).toLocaleLowerCase("tr-TR"),
        )
      : [];
    if (words.length > 100) {
      throw new InputError("En fazla 100 kelime ekleyebilirsin.");
    }
    await ref("appConfig", "public").set({
      announcement: text(input.announcement || "", 500),
      maintenance: input.maintenance === true,
      blockedWords: words,
      updatedAt: now(),
      updatedBy: a.uid,
    });
    await audit(a, action, "public", "Uygulama ayarları güncellendi");
    return { ok: true };
  }
  requireRole(a, "owner");
  if (action === "setRole") {
    const targetUid = id(input.uid),
      target = await accounts.getUser(targetUid),
      role = input.role;
    if (
      !["member", "moderator", "admin"].includes(role) ||
      targetUid === a.uid ||
      target.customClaims?.biraradaRole === "owner" ||
      !target.emailVerified
    ) {
      throw new InputError("Doğrulanmış bir hesap ve geçerli yetki seç.");
    }
    await accounts.setCustomUserClaims(targetUid, {
      ...target.customClaims,
      biraradaRole: role,
    });
    await accounts.revokeRefreshTokens(targetUid);
    await audit(a, action, targetUid, `Yeni yetki: ${role}`);
    return { ok: true };
  }
  throw new HttpsError("invalid-argument", "Bilinmeyen işlem.");
}

export async function removeAttachedMedia(ids: unknown) {
  if (!Array.isArray(ids)) return;
  for (const key of ids) {
    const target = ref("media", uuid(key)),
      media = (await target.get()).data();
    if (media?.path) await deleteBlob(media.path);
    await target.delete();
  }
}

export async function apiCall(
  a: Actor,
  action: string,
  input: Record<string, any>,
) {
  return requestCache.run(new Map(), () =>
    dispatch(a, text(action, 40, true), input),
  );
}
export { rate, serialize };
