import { useEffect, useState } from "react";
import { AppState, Platform } from "react-native";
const visible = () =>
  Platform.OS === "web"
    ? typeof document === "undefined" || document.visibilityState !== "hidden"
    : AppState.currentState !== "background" &&
      AppState.currentState !== "inactive";
export function useForeground() {
  const [active, setActive] = useState(visible);
  useEffect(() => {
    const update = () => setActive(visible());
    const subscription = AppState.addEventListener("change", update);
    if (Platform.OS === "web")
      document.addEventListener("visibilitychange", update);
    return () => {
      subscription.remove();
      if (Platform.OS === "web")
        document.removeEventListener("visibilitychange", update);
    };
  }, []);
  return active;
}
