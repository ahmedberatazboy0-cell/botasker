import { useEffect, useState, useCallback } from "react";
import { onSnapshot, Query, DocumentData } from "../database/client";
import { useIsFocused } from "@react-navigation/native";
import { friendly } from "../utils/errors";
import { useSession } from "../store/session";
import type { Row } from "../types";
export function useRows(q: Query<DocumentData> | null) {
  const focused = useIsFocused(),
    account = useSession((s) => s.user?.uid || s.profile?.uid || ""),
    spec = q ? JSON.stringify(q.spec) : "",
    identity = `${account}:${spec}`;
  const [state, setState] = useState({
      identity,
      rows: [] as Row[],
      loaded: false,
      loading: !!q,
      error: "",
      offline: false,
    }),
    [retry, setRetry] = useState(0);
  useEffect(() => {
    if (!focused) return;
    if (!spec) {
      setState({
        identity,
        rows: [],
        loaded: true,
        loading: false,
        error: "",
        offline: false,
      });
      return;
    }
    let alive = true;
    setState((old) =>
      old.identity === identity
        ? { ...old, loading: !old.loaded, error: "" }
        : {
            identity,
            rows: [],
            loaded: false,
            loading: true,
            error: "",
            offline: false,
          },
    );
    const stop = onSnapshot(
      new Query(JSON.parse(spec)),
      { includeMetadataChanges: true },
      (snap) => {
        if (alive)
          setState({
            identity,
            rows: snap.docs.map((d) => ({ id: d.id, ...d.data() })),
            loaded: true,
            offline: snap.metadata.fromCache,
            loading: false,
            error: "",
          });
      },
      (e) => {
        if (alive)
          setState((old) => ({ ...old, error: friendly(e), loading: false }));
      },
    );
    return () => {
      alive = false;
      stop();
    };
  }, [identity, spec, retry, focused]);
  const matches = state.identity === identity;
  return {
    rows: matches ? state.rows : [],
    loading: !!q && (!matches || state.loading),
    error: matches ? state.error : "",
    offline: matches && state.offline,
    refresh: useCallback(() => setRetry((n) => n + 1), []),
  };
}
