import { useCallback, useEffect, useRef, useState } from "react";
import { useIsFocused } from "@react-navigation/native";
import { api, type Cursor } from "../services/api";
import { useSession } from "../store/session";
import { friendly } from "../utils/errors";
import { useForeground } from "./useForeground";
import type { Row } from "../types";
export function useApiList(
  action: string,
  input: Record<string, unknown>,
  { pollInterval = 0, enabled = true } = {},
) {
  const account = useSession((s) => s.user?.uid || s.profile?.uid || ""),
    key = JSON.stringify(input),
    identity = `${account}:${action}:${key}`,
    focused = useIsFocused(),
    foreground = useForeground(),
    generation = useRef(0),
    busy = useRef(false),
    paged = useRef(false),
    latest = useRef(identity);
  latest.current = identity;
  const [state, setState] = useState({
      identity,
      rows: [] as Row[],
      cursor: null as Cursor,
      loaded: false,
      loading: true,
      refreshing: false,
      paging: false,
      error: "",
      failedPage: false,
    }),
    [version, setVersion] = useState(0);
  const refresh = useCallback(() => setVersion((v) => v + 1), []);
  useEffect(() => {
    if (!focused || !foreground || !enabled) return;
    const current = ++generation.current;
    busy.current = false;
    paged.current = false;
    const load = async (silent = false) => {
      if (
        busy.current ||
        current !== generation.current ||
        (silent && paged.current)
      )
        return;
      busy.current = true;
      setState((old) =>
        old.identity === identity
          ? {
              ...old,
              loading: !old.loaded,
              refreshing: old.loaded && !silent,
              paging: false,
              error: "",
              failedPage: false,
            }
          : {
              identity,
              rows: [],
              cursor: null,
              loaded: false,
              loading: true,
              refreshing: false,
              paging: false,
              error: "",
              failedPage: false,
            },
      );
      try {
        const result = await api<{ rows: Row[]; cursor: Cursor }>(
          action,
          JSON.parse(key),
        );
        if (current !== generation.current || latest.current !== identity)
          return;
        setState({
          identity,
          rows: result.rows,
          cursor: result.cursor || null,
          loaded: true,
          loading: false,
          refreshing: false,
          paging: false,
          error: "",
          failedPage: false,
        });
      } catch (e) {
        if (current === generation.current && latest.current === identity)
          setState((old) => ({
            ...old,
            loading: false,
            refreshing: false,
            error: friendly(e),
          }));
      } finally {
        if (current === generation.current) busy.current = false;
      }
    };
    void load();
    const timer = pollInterval
      ? setInterval(() => {
          void load(true);
        }, pollInterval)
      : undefined;
    return () => {
      generation.current++;
      if (timer) clearInterval(timer);
    };
  }, [
    action,
    key,
    identity,
    version,
    focused,
    foreground,
    enabled,
    pollInterval,
  ]);
  const loadMore = useCallback(async () => {
    if (
      busy.current ||
      state.loading ||
      !state.cursor ||
      state.identity !== identity ||
      !focused ||
      !foreground ||
      !enabled
    )
      return;
    const current = generation.current;
    busy.current = true;
    paged.current = true;
    setState((old) => ({ ...old, paging: true, error: "", failedPage: false }));
    try {
      const next = await api<{ rows: Row[]; cursor: Cursor }>(action, {
        ...JSON.parse(key),
        cursor: state.cursor,
      });
      if (current !== generation.current || latest.current !== identity) return;
      setState((old) => ({
        ...old,
        rows: [
          ...new Map(
            [...old.rows, ...next.rows].map((r) => [r.id, r]),
          ).values(),
        ],
        cursor: next.cursor || null,
        paging: false,
      }));
    } catch (e) {
      if (current === generation.current && latest.current === identity)
        setState((old) => ({
          ...old,
          error: friendly(e),
          paging: false,
          failedPage: true,
        }));
    } finally {
      if (current === generation.current) busy.current = false;
    }
  }, [
    action,
    key,
    identity,
    state.cursor,
    state.loading,
    state.identity,
    focused,
    foreground,
    enabled,
  ]);
  const matches = state.identity === identity;
  return {
    rows: matches ? state.rows : [],
    loading: enabled && (!matches || state.loading),
    refreshing: matches && state.refreshing,
    paging: matches && state.paging,
    error: matches ? state.error : "",
    hasMore: matches && !!state.cursor,
    loadMore,
    refresh,
    retry: state.failedPage ? loadMore : refresh,
  };
}
