import React, { useEffect, useRef, useState } from "react";
import {
  FlatList,
  Pressable,
  ScrollView,
  Switch,
  Text,
  View,
  Share,
  useWindowDimensions,
  type ViewToken,
} from "react-native";
import { Image } from "expo-image";
import { useIsFocused, useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { ImagePickerAsset } from "expo-image-picker";
import { api, newId, uploadMedia, type MediaItem } from "../services/api";
import { selectMedia } from "../services/picker";
import { collection, doc, onSnapshot, query, limit } from "../database/client";
import { db } from "../firebase/client";
import { usePerson } from "../hooks/usePerson";
import { useRows } from "../hooks/useRows";
import { useApiList } from "../hooks/useApiList";
import {
  Action,
  Avatar,
  Icon,
  MenuRow,
  Segments,
  Sheet,
  TopBar,
} from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { useVideoPlayer, VideoView } from "expo-video";
import { useSession } from "../store/session";
import {
  Page,
  Label,
  Field,
  Button,
  State,
  ReportForm,
  styles,
} from "../components/ui";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { PostCard } from "../components/PostCard";
import type { Post } from "../types";
import { toggleLike, toggleSaved } from "../services/social";

export function Create({ route, navigation }: any) {
  const profile = useSession((s) => s.profile)!,
    initial = route?.params?.kind || "post";
  const [kind, setKind] = useState<"post" | "story" | "reel">(initial),
    [caption, setCaption] = useState(""),
    [assets, setAssets] = useState<ImagePickerAsset[]>([]),
    [comments, setComments] = useState(true),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const request = useRef(newId()),
    uploads = useRef(new Map<string, MediaItem>());
  useEffect(() => {
    if (route?.params?.kind) setKind(route.params.kind);
  }, [route?.params?.kind]);
  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(`draft:${profile.uid}`).then((value) => {
      if (alive && value) setCaption(value);
    });
    return () => {
      alive = false;
    };
  }, [profile.uid]);
  async function choose(camera = false) {
    const selected = await selectMedia({
      camera,
      multiple: kind === "post",
      videoOnly: kind === "reel",
    });
    if (selected.length) {
      setAssets(selected);
      uploads.current.clear();
      request.current = newId();
      setNotice("");
    }
  }
  async function submit() {
    setBusy(true);
    setNotice("");
    try {
      const ids: string[] = [];
      for (let i = 0; i < assets.length; i++) {
        const asset = assets[i]!;
        setNotice(`Medya yükleniyor ve işleniyor: ${i + 1}/${assets.length}`);
        let item = uploads.current.get(asset.uri);
        if (!item) {
          item = await uploadMedia(
            asset.uri,
            asset.type === "video" ? "video" : "image",
            kind,
          );
          uploads.current.set(asset.uri, item);
        }
        ids.push(item.id);
      }
      const published = await api("publishContent", {
        requestId: request.current,
        kind,
        caption,
        mediaIds: ids,
        commentsEnabled: comments,
      });
      setAssets([]);
      setCaption("");
      uploads.current.clear();
      request.current = newId();
      await AsyncStorage.removeItem(`draft:${profile.uid}`);
      setNotice("Paylaşımın yayınlandı.");
      if (kind === "story") navigation.goBack();
      else
        navigation.navigate("Ana Sayfa", {
          feedMode: profile.isPrivate ? "following" : "public",
          publishedId: published.id,
        });
    } finally {
      setBusy(false);
    }
  }
  const [advanced, setAdvanced] = useState(false);
  const width = Math.min(useWindowDimensions().width, 680);
  return (
    <Page scroll={false}>
      <TopBar
        title={
          kind === "story"
            ? "Yeni hikâye"
            : kind === "reel"
              ? "Yeni reel"
              : "Yeni gönderi"
        }
        left={
          <Action
            name="close"
            label="Paylaşımı kapat"
            disabled={busy}
            onPress={() =>
              navigation.canGoBack()
                ? navigation.goBack()
                : navigation.navigate("Ana Sayfa")
            }
          />
        }
        right={
          <Button
            title={busy ? "Paylaşılıyor…" : "Paylaş"}
            disabled={
              busy || (!assets.length && (kind !== "post" || !caption.trim()))
            }
            onPress={submit}
          />
        }
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
        keyboardShouldPersistTaps="handled"
      >
        <Segments
          value={kind}
          items={[
            { value: "post", label: "Gönderi" },
            { value: "story", label: "Hikâye" },
            { value: "reel", label: "Reels" },
          ]}
          onChange={(value) => {
            if (busy) return;
            setKind(value as any);
            setAssets([]);
            uploads.current.clear();
            request.current = newId();
          }}
        />
        {assets.length ? (
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
          >
            {assets.map((asset, index) => (
              <View
                key={asset.uri}
                style={{
                  width,
                  height: width,
                  backgroundColor: c.surface,
                  position: "relative",
                }}
              >
                {asset.type === "video" ? (
                  <LocalVideo uri={asset.uri} size={width} />
                ) : (
                  <Image
                    source={asset.uri}
                    style={{ width, height: width }}
                    contentFit="contain"
                  />
                )}
                <View
                  style={{
                    position: "absolute",
                    right: 10,
                    top: 10,
                    backgroundColor: "#fff",
                    borderRadius: 25,
                  }}
                >
                  <Action
                    name="close"
                    label="Kaldır"
                    disabled={busy}
                    onPress={() => {
                      setAssets((old) => old.filter((_, i) => i !== index));
                      request.current = newId();
                    }}
                  />
                </View>
                <View
                  style={{
                    position: "absolute",
                    bottom: 12,
                    left: 12,
                    backgroundColor: "#0009",
                    padding: 7,
                    borderRadius: 8,
                  }}
                >
                  <Text style={{ fontSize: 12, color: "#fff" }}>
                    {index + 1}. {asset.type === "video" ? "Video" : "Fotoğraf"}
                  </Text>
                </View>
              </View>
            ))}
          </ScrollView>
        ) : (
          <View
            style={{
              height: Math.min(width, 330),
              alignItems: "center",
              justifyContent: "center",
              gap: 14,
              backgroundColor: c.surface,
            }}
          >
            <Icon
              name={kind === "reel" ? "videocam-outline" : "images-outline"}
              size={58}
              color={c.muted}
            />
            <Text style={{ fontSize: 20, fontWeight: "600", color: c.text }}>
              Bir anını paylaş
            </Text>
            <Text style={{ fontSize: 13, color: c.muted }}>
              Fotoğraf veya video seçerek başla.
            </Text>
            <Button
              title="Galeriden seç"
              onPress={() => choose()}
              disabled={busy}
            />
          </View>
        )}
        <View
          style={{
            flexDirection: "row",
            padding: 12,
            gap: 10,
            borderBottomWidth: 0.5,
            borderBottomColor: c.line,
          }}
        >
          <View style={{ flex: 1 }}>
            {!!assets.length && (
              <Button
                secondary
                title="Galeriden seç"
                onPress={() => choose()}
                disabled={busy}
              />
            )}
          </View>
          <Button
            secondary
            title="Kamera / kırp"
            onPress={() => choose(true)}
            disabled={busy}
          />
        </View>
        <View
          style={{
            padding: 16,
            flexDirection: "row",
            alignItems: "flex-start",
            gap: 12,
          }}
        >
          <Avatar
            name={profile.username}
            mediaId={profile.avatarMediaId}
            size={34}
          />
          <View style={{ flex: 1 }}>
            <Text
              style={{
                fontSize: 13,
                fontWeight: "600",
                color: c.text,
                marginBottom: 6,
              }}
            >
              {profile.username}
            </Text>
            <Field
              placeholder="Açıklama, #etiket, @kullanıcı…"
              multiline
              maxLength={2200}
              value={caption}
              editable={!busy}
              onChangeText={setCaption}
              style={{
                minHeight: 85,
                borderWidth: 0,
                backgroundColor: c.bg,
                padding: 0,
              }}
            />
            <Text style={{ fontSize: 11, color: c.muted, textAlign: "right" }}>
              {caption.length}/2200
            </Text>
          </View>
        </View>
        <View style={{ paddingHorizontal: 16, gap: 12 }}>
          <Text style={{ fontSize: 12, color: c.muted }}>
            {profile.isPrivate
              ? "Onaylı takipçilerinle paylaşılacak."
              : "Herkese açık olarak paylaşılacak."}
            {kind === "story" ? " Hikâyen 24 saat görünür." : ""}
          </Text>
          <MenuRow
            title="Paylaşım ayarları"
            icon="options-outline"
            onPress={() => setAdvanced((v) => !v)}
          />
          {advanced && (
            <>
              {kind !== "story" && (
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <Label>Yorumlara izin ver</Label>
                  <Switch
                    disabled={busy}
                    value={comments}
                    onValueChange={setComments}
                  />
                </View>
              )}
              <Button
                secondary
                title="Açıklamayı taslak kaydet"
                disabled={busy}
                onPress={async () => {
                  await AsyncStorage.setItem(`draft:${profile.uid}`, caption);
                  setNotice(
                    "Açıklama bu cihaza kaydedildi. Medyayı yeniden seçmelisin.",
                  );
                }}
              />
            </>
          )}
          {!!notice && (
            <Text
              accessibilityLiveRegion="polite"
              style={{ fontSize: 13, color: c.muted }}
            >
              {notice}
            </Text>
          )}
        </View>
      </ScrollView>
    </Page>
  );
}
function LocalVideo({ uri, size }: { uri: string; size: number }) {
  const player = useVideoPlayer(uri, (p) => {
    p.loop = false;
  });
  return (
    <VideoView
      player={player}
      style={{ width: size, height: size }}
      nativeControls
      contentFit="contain"
    />
  );
}

function Reel({
  post,
  active,
  height,
  navigation,
}: {
  post: Post;
  active: boolean;
  height: number;
  navigation: any;
}) {
  const focused = useIsFocused(),
    person = usePerson(post.uid),
    me = useSession((s) => s.profile)!.uid;
  const [comments, setComments] = useState(false),
    [reporting, setReporting] = useState(false),
    [saved, setSaved] = useState(false);
  const likes = useRows(
      query(collection(db, "posts", post.id, "likes"), limit(500)),
    ),
    liked = likes.rows.some((r) => r.id === me);
  useEffect(
    () =>
      onSnapshot(
        doc(db, "saved", me, "posts", post.id),
        (snap) => setSaved(snap.exists()),
        () => {},
      ),
    [post.id, me],
  );
  return (
    <View style={{ height, backgroundColor: "#080808" }}>
      {post.mediaItems?.[0] && (
        <ProtectedMedia
          item={post.mediaItems[0]}
          active={active && focused && !comments && !reporting}
          style={{ width: "100%", height }}
        />
      )}
      <View
        pointerEvents="box-none"
        style={{
          position: "absolute",
          top: 12,
          left: 16,
          right: 10,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "700", color: "#fff" }}>
          Reels
        </Text>
        <Action
          name="camera-outline"
          label="Reel oluştur"
          color="#fff"
          onPress={() => navigation.navigate("Oluştur", { kind: "reel" })}
        />
      </View>
      <View
        style={{
          position: "absolute",
          bottom: 25,
          right: 8,
          alignItems: "center",
          gap: 10,
        }}
      >
        <View style={{ alignItems: "center" }}>
          <Action
            name={liked ? "heart" : "heart-outline"}
            label={liked ? "Beğeniyi geri al" : "Beğen"}
            color={liked ? c.danger : "#fff"}
            size={30}
            onPress={async () => {
              await toggleLike(post);
              likes.refresh();
            }}
          />
          <Text style={{ color: "#fff", fontSize: 12 }}>
            {likes.rows.length || ""}
          </Text>
        </View>
        <Action
          name="chatbubble-outline"
          label="Yorumlar"
          color="#fff"
          size={28}
          onPress={() => setComments(true)}
        />
        <Action
          name="paper-plane-outline"
          label="Paylaş"
          color="#fff"
          size={28}
          onPress={() =>
            Share.share({ message: `@${post.username}: ${post.caption}` })
          }
        />
        <Action
          name={saved ? "bookmark" : "bookmark-outline"}
          label={saved ? "Kaydedildi" : "Kaydet"}
          color="#fff"
          onPress={async () => {
            await toggleSaved(post.id);
            setSaved(!saved);
          }}
        />
        <Action
          name="ellipsis-horizontal"
          label="Şikâyet"
          color="#fff"
          onPress={() => setReporting(true)}
        />
      </View>
      <View
        style={{
          position: "absolute",
          bottom: 20,
          left: 12,
          right: 75,
          gap: 10,
          padding: 8,
          backgroundColor: "#0003",
          borderRadius: 10,
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`@${post.username} profilini aç`}
          onPress={() => navigation.navigate("User", { uid: post.uid })}
          style={{ flexDirection: "row", alignItems: "center", gap: 9 }}
        >
          <Avatar
            name={post.username}
            mediaId={person?.avatarMediaId}
            size={33}
          />
          <Text style={{ color: "#fff", fontSize: 14, fontWeight: "700" }}>
            {post.username}
          </Text>
        </Pressable>
        <Text
          numberOfLines={3}
          style={{ color: "#fff", fontSize: 13, lineHeight: 19 }}
        >
          {post.caption}
        </Text>
      </View>
      {comments && (
        <PostCard
          post={post}
          hideMedia
          commentsOnly
          onCommentsClose={() => setComments(false)}
          openProfile={(uid) => navigation.navigate("User", { uid })}
        />
      )}
      <Sheet
        visible={reporting}
        title="Şikâyet et"
        onClose={() => setReporting(false)}
      >
        <ReportForm
          onSubmit={async (reason) => {
            await api("reportContent", { kind: "reel", id: post.id, reason });
            setReporting(false);
          }}
          onCancel={() => setReporting(false)}
        />
      </Sheet>
    </View>
  );
}
export function ShortVideos({ navigation }: any) {
  const data = useApiList("listContent", { kind: "reel" }),
    [active, setActive] = useState(""),
    [height, setHeight] = useState(
      Math.max(360, useWindowDimensions().height - 62),
    );
  const change = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) =>
    setActive(viewableItems[0]?.item.id || ""),
  );
  return (
    <Page scroll={false}>
      <View
        testID="reels-feed"
        style={{ flex: 1, backgroundColor: "#080808" }}
        onLayout={(e) => setHeight(Math.round(e.nativeEvent.layout.height))}
      >
        <FlatList
          data={data.rows}
          pagingEnabled
          showsVerticalScrollIndicator={false}
          keyExtractor={(r) => r.id}
          initialNumToRender={2}
          maxToRenderPerBatch={2}
          windowSize={3}
          onViewableItemsChanged={change.current}
          viewabilityConfig={{ itemVisiblePercentThreshold: 70 }}
          onEndReached={data.loadMore}
          onEndReachedThreshold={0.7}
          refreshing={data.refreshing}
          onRefresh={data.refresh}
          getItemLayout={(_, i) => ({
            length: height,
            offset: height * i,
            index: i,
          })}
          ListEmptyComponent={
            <View
              style={{ backgroundColor: c.bg, margin: 24, borderRadius: 16 }}
            >
              <State {...data} empty retry={data.refresh} />
              <Button
                secondary
                title="İlk reelini oluştur"
                onPress={() => navigation.navigate("Oluştur", { kind: "reel" })}
              />
            </View>
          }
          renderItem={({ item }) => (
            <Reel
              post={item as Post}
              height={height}
              active={active === item.id}
              navigation={navigation}
            />
          )}
        />
      </View>
    </Page>
  );
}
