// Include token acquisition and response decoding in the deadline, not only fetch().
export async function withDeadline<T>(
  work: (signal: AbortSignal) => Promise<T>,
  milliseconds = 45000,
): Promise<T> {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout>;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => {
      reject(
        Object.assign(Error("Bağlantı zaman aşımına uğradı. Yeniden dene."), {
          code: "deadline-exceeded",
        }),
      );
      controller.abort();
    }, milliseconds);
  });
  try {
    return await Promise.race([
      Promise.resolve().then(() => work(controller.signal)),
      timeout,
    ]);
  } finally {
    clearTimeout(timer!);
  }
}
