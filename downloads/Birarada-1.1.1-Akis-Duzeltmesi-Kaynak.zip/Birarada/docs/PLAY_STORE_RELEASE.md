# Birarada Android yayını

Güncel durum ve doğrulama: [TEST_REPORT.md](../TEST_REPORT.md). Kurulum: [CANLI_KURULUM.md](CANLI_KURULUM.md).

Paket `com.birarada.app`, sürüm1.1.1/versionCode3. Mevcut EAS projesi `@ahmedberat/birarada`, UUID `9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b`. 1.0.0/versionCode1 önceki sürümü Play Console'a yüklendi; 1.1.0/code2 de yüklendi; bu hata düzeltmesi code3 kullanır. Mevcut EAS upload keystore korunmalı; uygulama kimliği değişmemeli. Yeni sosyal özellikler için yeni derleme gerekir; eski AAB bunları içermez.

1. Mevcut çalışan proje için `GUNCELLE_VE_AAB.bat` veya `npm run backend:update` ile Edge sunucusunu güncelle. Yeni sunucu kurulumu gerekmez; veriler korunur. Mevcut yasal sayfalar değişmedi.
2. Doğrulanmış owner hesabını etkinleştir. Gerçek telefonda iki hesapla gizlilik/engelleme/takip, kamera/fotoğraf/video, hikâye/Reels, grup/sesli mesaj, şikâyet/yönetim ve hesap silme akışlarını kontrol et. Push için güvenli EAS FCM kurulumunu ve gerçek teslimi doğrula.
3. `AAB_OLUSTUR.bat` ile önkoşulları/testleri çalıştır; EAS'in verdiği yeni `.aab` dosyasını indir. EAS mevcut credentials'ı kullanır; eksikse durur.
4. Son AAB'nin package/versionCode, imza, hedef API ve 16 KB native uyumluluğunu Play Console kontrolleriyle doğrula. Kaynak testlerinin geçmesi bu son binary kontrollerinin yerine geçmez.
5. Data safety, hedef yaş, içerik derecesi, reklam beyanı, uygulama erişim bilgileri, mağaza görselleri ve destek/yasal URL'leri gerçek veri davranışına göre doldur. Moderasyon/silme/çocuk güvenliği süreçlerini işlet. Konsolun hesabına uyguladığı test şartlarına uy; inceleme ve yayımlanma süresi Google tarafından belirlenir.

Bu kaynak paketi AAB veya mağaza onayı değildir. Yeni üretim AAB'si bu bulut ortamında oluşturulmadı; yetkili Supabase/Firebase/Expo oturumları bulunmadığı için dağıtım tamamlanmadı.
