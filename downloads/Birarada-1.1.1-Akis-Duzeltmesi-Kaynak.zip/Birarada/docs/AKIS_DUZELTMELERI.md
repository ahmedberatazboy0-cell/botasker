# Birarada 1.1.1 — akış ve yükleme düzeltmeleri

23 Ekim 2026. Paket `com.birarada.app`, versionCode **3**. Mevcut EAS projesi, kullanıcılar ve upload keystore korunur. Önceki Play Console paketinin kodu 2'dir.

## Düzeltilen davranışlar

- Aynı listeye dönünce veya yenileyince kartlar önce silinmez. İlk yükleme ile arka plandaki yenileme ayrı durumlarda tutulur. Farklı hesap/sorgu sonuçları birbirine gösterilmez; geç kalan eski yanıtlar güncel listeyi ezmez.
- Profilde daha önce açılmış gönderi ızgarası, yeni paylaşım sonrasında ekrana dönüldüğünde yenilenir. Reels ve diğer API listeleri de ekran odağında yenilenir; görünmeyen ekranlar API listesi yüklemez.
- Gizli hesaptan paylaşım sonrası kendi içeriğini içeren **Takip ettiklerin** akışı açılır. Herkese açık hesaptan paylaşım sonrası **Keşfet akışı** açılır. Gizli gönderiler herkese açık keşfet/Reels'e eklenmez; onaylı takipçiler takip akışından erişir.
- Açık ve öndeki ana sayfa ilk sayfası 15 saniyede sessizce yenilenir. Bu WebSocket veya anında teslim garantisi değildir. Sayfalama başladıktan sonra kaydırılan eski kartları kesmemek için otomatik ilk-sayfa yenilemesi durur; aşağı çekme veya ekrana dönüş yeniler. Sayfalama hatasında doğru işlem yeniden denenir; boş filtrelenmiş sayfada sonraki sayfayı istemek için düğme vardır.
- Geçici kayıt okuma hatası başarılı sonraki abonelik yanıtında temizlenir. Gönderi detayındaki yeniden deneme de önceki hata durumunu temizler.
- API isteğinin 45 saniyelik süresi artık token beklemeyi ve JSON çözmeyi de kapsar. Süre aşımında yükleme biter ve yeniden deneme mesajı gösterilir. Eski hesaptan gelen yanıt yeni oturumda kabul edilmez.
- Yerel yazım, devam eden eski okuma sırasında gelirse yenileme kaybolmaz; okumanın ardından güncel sorgu tekrarlanır.
- Sunucuda bir akış sayfasının profil, kısıtlama, takip ve engel kayıtları toplu okunur. Takip akışındaki gönderiler de toplu getirilir. Önbellek yalnız tek API isteği içindedir; yeni istekte gizlilik/engel/kısıtlama yeniden denetlenir. DB şeması değişmez.

## Güncelleme

ZIP'in tamamını yeni klasöre çıkar. İçteki `Birarada` klasöründe **GUNCELLE_VE_AAB.bat** aç. Aynı klasörde başka kurulum çalışmasın. Yardımcı yeni Edge sürümünü mevcut Supabase projesine dağıtır; kontrolleri geçince mevcut EAS projesi ve imzasıyla üretim AAB başlatır. Oturum yoksa sağlayıcının resmi girişini ister. Şifre/token/anahtar dosyaya veya sohbete eklenmez.

Bu çalışmada kaynak ve yerel entegrasyon testleri hazırlanmıştır. Canlı backend dağıtımı, 1.1.1 imzalı AAB ve bu AAB'nin fiziksel telefondaki doğrulaması bu bulut oturumunda yapılmadı. Yeni AAB üretilince aynı kapalı test kanalına güncelleme olarak yüklenmeli; eski AAB bu düzeltmeleri içermez. Kod 3 hesabınızda başka bir derleme için kullanılmışsa daha yüksek kod gerekir.
