import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { harness } from "./free-harness";
import { Timestamp } from "../supabase/functions/birarada/records";
test("a full feed batches authorization reads while enforcing private, suspended and blocked owners", async () => {
  const h = await harness();
  try {
    const now = Timestamp.now();
    for (const uid of ["alice", "bob", "eve"])
      await h.db.doc("users/" + uid).set({
        uid,
        username: uid + "_user",
        isPrivate: false,
        createdAt: now,
        deletionPending: false,
      });
    for (let i = 0; i < 35; i++)
      await h.db.doc("posts/" + randomUUID()).set({
        uid: "alice",
        username: "alice_user",
        kind: "post",
        caption: "post " + i,
        audience: "public",
        createdAt: Timestamp.fromMillis(Date.now() - i * 1000),
        mediaIds: [],
        mediaItems: [],
      });
    const rpc = h.driver.rpc.bind(h.driver);
    let gets = 0;
    h.driver.rpc = async (name, input) => {
      if (name === "birarada_get") gets++;
      return rpc(name, input);
    };
    const page = await h.call("bob", "listContent", { kind: "post" });
    assert.equal(page.status, 200, JSON.stringify(page));
    assert.equal(page.data.rows.length, 20);
    assert.ok(
      gets <= 12,
      `A feed page must not perform one authorization database round trip per post; got ${gets}`,
    );
    const next = await h.call("bob", "listContent", {
      kind: "post",
      cursor: page.data.cursor,
    });
    assert.equal(next.data.rows.length, 15);
    assert.equal(
      new Set([...page.data.rows, ...next.data.rows].map((r: any) => r.id))
        .size,
      35,
    );
    let failBatch = true;
    h.driver.rpc = async (name, input) => {
      if (
        failBatch &&
        name === "birarada_get" &&
        (input.paths as string[]).length > 10
      ) {
        failBatch = false;
        return {
          data: null,
          error: { code: "temporary", message: "database unavailable" },
        };
      }
      return rpc(name, input);
    };
    // Use many distinct owners so the authorization batch itself fails once.
    await h.db.doc("users/eve").update({ bio: "still active" });
    for (const uid of ["owner-one", "owner-two", "owner-three"])
      await h.db
        .doc("users/" + uid)
        .set({
          uid,
          username: uid.replaceAll("-", "_"),
          isPrivate: false,
          deletionPending: false,
        });
    for (const uid of ["owner-one", "owner-two", "owner-three"])
      await h.db
        .doc("posts/" + randomUUID())
        .set({
          uid,
          kind: "post",
          audience: "public",
          caption: uid,
          createdAt: Timestamp.now(),
        });
    assert.equal((await h.call("bob", "listContent", {})).status, 500);
    const recovered = await h.call("bob", "listContent", {});
    assert.equal(recovered.status, 200);
    assert.equal(recovered.data.rows.length, 20);
    // Remove the extra owners' posts for the following privacy checks.
    for (const uid of ["owner-one", "owner-two", "owner-three"]) {
      const extra = await h.db
        .collection("posts")
        .where("uid", "==", uid)
        .get();
      for (const row of extra.docs) await row.ref.delete();
    }
    await h.db.doc("users/alice").update({ isPrivate: true });
    assert.equal((await h.call("bob", "listContent", {})).data.rows.length, 0);
    await h.db.doc("follows/bob_alice").set({
      followerUid: "bob",
      followingUid: "alice",
      status: "accepted",
      createdAt: now,
    });
    const approved = await h.call("bob", "followingFeed", {});
    assert.equal(approved.data.rows.length, 20);
    await h.db
      .doc("users/alice/blocks/bob")
      .set({ uid: "bob", createdAt: now });
    assert.equal(
      (await h.call("bob", "followingFeed", {})).data.rows.length,
      0,
    );
    await h.db.doc("users/alice/blocks/bob").delete();
    await h.db.doc("accountStatus/alice").set({ suspended: true });
    assert.equal(
      (await h.call("bob", "followingFeed", {})).data.rows.length,
      0,
    );
    assert.equal(
      (await h.call("eve", "listContent", { uid: "alice" })).data.rows.length,
      0,
    );
  } finally {
    await h.pg.close();
  }
});
