import { test } from "node:test";
import assert from "node:assert/strict";
import { withDeadline } from "../src/utils/deadline";
test("a stalled token acquisition stops waiting and never starts the network call after expiry", async () => {
  let resume!: () => void,
    network = 0;
  const token = new Promise<void>((r) => {
    resume = r;
  });
  const pending = withDeadline(async (signal) => {
    await token;
    if (signal.aborted) return;
    network++;
  }, 15);
  await assert.rejects(pending, (e: any) => e.code === "deadline-exceeded");
  resume();
  await new Promise((r) => setTimeout(r, 5));
  assert.equal(network, 0);
});
test("an unresponsive transport is bounded even if it ignores AbortSignal", async () => {
  let signal!: AbortSignal;
  await assert.rejects(
    withDeadline(async (s) => {
      signal = s;
      return new Promise(() => {});
    }, 15),
    (e: any) => e.code === "deadline-exceeded",
  );
  assert.equal(signal.aborted, true);
});
test("successful requests and immediate failures preserve their result", async () => {
  assert.equal(await withDeadline(async () => 7, 30), 7);
  const failure = Error("offline");
  await assert.rejects(
    withDeadline(async () => {
      throw failure;
    }, 30),
    (e) => e === failure,
  );
});
