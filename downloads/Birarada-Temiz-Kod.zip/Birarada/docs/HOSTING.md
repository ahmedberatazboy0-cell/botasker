# Birarada public support pages

Prepared 20 October 2026. The source files below are ready for local review; this document is not evidence that they are deployed or that Firebase authentication is available.

| Requested URL | Source file |
| --- | --- |
| `https://birarada-5650c.web.app/privacy` | `hosting/public/privacy.html` |
| `https://birarada-5650c.web.app/delete-account` | `hosting/public/delete-account.html` |
| `https://birarada-5650c.web.app/terms` | `hosting/public/terms.html` |
| `https://birarada-5650c.web.app/child-safety` | `hosting/public/child-safety.html` |

All pages are Turkish, responsive, static HTML. Their only asset is `hosting/public/birarada-legal.css`; there are no scripts, web fonts, trackers, build steps, or additional dependencies. The navigation, canonical URLs, app package (`com.birarada.app`) and public contact (`ahmedberatazboy0@gmail.com`) are shared consistently. The contact address came from the app owner; no legal entity or address has been invented.

## Preserve the existing website before deployment

Firebase Hosting deploys a complete release. Deploying only this directory would remove files belonging to the existing website from the next release, even though the rewrites match only the four exact routes. **Do not deploy this directory over the existing live site on its own.**

1. Authenticate with the owner's existing Firebase account using the Firebase CLI's supported sign-in flow; do not paste tokens, service accounts, private keys or passwords into chat or source.
2. Confirm authorized access to project `birarada-5650c`, the Hosting site, existing live release and existing Hosting configuration. Keep the existing website's authoritative build output and config.
3. Build the existing website through its supported workflow. Overlay these four HTML files and `birarada-legal.css` into that complete output. Resolve any filename collision explicitly.
4. Merge only the four exact rewrites from `firebase.json` into the existing configuration, before any existing catch-all rewrite. Keep the existing redirects, headers, functions, targets and unrelated rewrites. The proposed mobile config does not add a catch-all or alter the website homepage.
5. Preview the full merged output through a local Hosting emulator or an authorized preview channel. Check the original homepage and representative existing routes as well as all four support pages, CSS and navigation. Review the current and merged file lists.
6. With a complete preserved-site release and authorized Firebase session, deploy **Hosting only** using the merged config and the explicit project/site. Do not include Firestore rules, indexes or Storage in a Hosting-only change.
7. Check all four public URLs in a signed-out browser. They must return the correct readable HTML without login; check CSS, mobile viewport, e-mail links, and the existing homepage. Retain a rollback path to the prior release.

At preparation time the root task confirmed the Firebase CLI had no authenticated session. Public publication and signed-out live-URL checks therefore remain unverified. The environment must also permit the Firebase CLI/API and the requested `birarada-5650c.web.app` destination before live checks.

## Content and owner review

The privacy and deletion text follows the current source: Firebase email/password Auth, Firestore profile/social text/messages, no advertising/Analytics integration, disabled native Google login and media upload, public profile fields, post-level visibility, client-side deletion with reauthentication and Auth removed last. It states that deletion can fail midway and require retry; other participants' messages, membership history and other people's reports are not automatically deleted. Browser/device caches and provider logs have separate behavior.

The deletion page provides an in-app route and a public mailto request path from the registered e-mail address. A mailto click prepares a message; it does not submit a request or erase a live account. No guaranteed response or deletion deadline is claimed. A separate local HTML demo does not create a Firebase account.

The child-safety page explicitly prohibits CSAE/CSAM, sexual grooming, sextortion and trafficking; names the in-app reason and support contact; explains possible removal/account measures and legally required authority reporting. It does not claim a staffed moderation system, automatic scanning or verified response times.

Before a public Play Store release, the app owner still needs to:

- Verify this contact is actively monitored for deletion, moderation and child-safety requests, and operate those processes. A public policy page alone is not an operating moderation process.
- Confirm the developer/data-controller identity and any jurisdiction-specific disclosures legally required for the intended audience. No legal entity, physical address or chosen governing jurisdiction was supplied.
- Set and operate retention schedules for the residual conversation/security records, provider logs and backups; this source currently has no automatic expiration for those records and the text says so.
- Confirm the app's actual target age range, Play content rating and child-safety declaration. The safety standard's under-18 definition does not implement an age gate or decide the target audience.
- Complete a full account-deletion test against the deployed rules/indexes and backend, then verify that the published notice matches the actual data removal behavior. Reassess the policy when enabling media, analytics, ads, push notifications or additional login providers.
- Make any consent-version update intentionally in app source when these terms are adopted; this document does not silently change the app's stored terms version.

## Local validation

Executed on 20 October 2026 (Europe/Istanbul; `2026-10-19T22:29:12.901Z`): **22 checks passed** against the real Firebase Hosting emulator, using the project's installed Firebase CLI and installed Chromium through Playwright. All four exact routes returned HTTP 200 with HTML and their own title, package, contact, date and canonical URL; the shared CSS returned HTTP 200 with the CSS content type. `/` and an unrelated route returned 404, confirming no replacement homepage or catch-all. All four pages rendered without horizontal overflow at 320, 390 and 1280 pixels, with the intended stylesheet, navigation and no scripts. The deletion mailto recipient/subject and keyboard skip-to-content link passed. No browser runtime errors were recorded. This validates local routing/rendering, not a deployment, mailbox delivery, legal compliance or live account deletion.

The Firebase Hosting emulator can serve these files on a loopback port without deploying. Run from the project root (the folder containing `package.json`) with the existing dependency installation:

```sh
npx firebase emulators:start --project demo-birarada --only hosting --non-interactive
```

Use local HTTP requests or an installed browser against the emulator for `/privacy`, `/delete-account`, `/terms`, `/child-safety` and `/birarada-legal.css`. Check unknown routes return 404 (there is no catch-all), and remember that this isolated support-page preview intentionally contains no replacement homepage. The root task records the actual commands, exit status and results used for validation; this section is a reproduction guide, not a claim of a live deployment.
