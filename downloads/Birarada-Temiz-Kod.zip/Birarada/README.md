# Birarada

Birarada mobil uygulamasının Expo / React Native kaynak kodu. Paket tek bir uygulama içerir: App.tsx, src/, assets/, Firebase kuralları ve Android AAB derleme aracı. Eski Express sunucusu, tek dosyalık HTML demosu, örnek hesapla giriş ve demo başlatıcıları teslimata dahil değildir.

Uygulama adı **Birarada**, Android paket adı ve iOS kimliği **com.birarada.app**, sürüm **1.0.0**, ilk Android sürüm kodu **1**. Bu kimlik değiştirilmemelidir. Daha önce versionCode 1 yüklendiyse yeni yükleme için sürüm kodunun artırılması gerekir.

## Başlangıç

ZIP'i çıkarıp Birarada klasörünü aç. package.json, App.tsx ve AAB_OLUSTUR.bat bu klasörün içindedir. Ana uygulama olarak açılacak bir HTML dosyası yoktur. hosting/public/ altındaki HTML dosyaları yalnız gizlilik, hesap silme ve kullanım koşulları sayfalarıdır.

Node.js LTS ve Java 21 kurulu olsun. Arayüz kontrolleri için Chrome veya Edge gerekir. Windows'ta **AAB_OLUSTUR.bat** dosyasını çalıştır. Araç kontrolleri çalıştırır; başarılı olursa resmî Expo girişini ve gerçek EAS projesi bağlantısını açıp Android AAB derlemesini başlatır. Kaynaklar Expo'ya gönderilir; Git veya GitHub kurulumu gerekmez. Başarısız kontrol atlanmaz. Ayrıntılar: [derleme rehberi](docs/GITHUB_GEREKTIRMEYEN_DERLEME.md).

Bu ZIP imzalı AAB içermez. Play Store'a yüklenebilir dosya, üretim derlemesi tamamlandıktan sonra EAS'in verdiği .aab dosyasıdır. Araç otomatik mağaza yayını veya Firebase dağıtımı yapmaz. Doğrulananlar ve kalan işler [TEST_REPORT.md](TEST_REPORT.md) içinde belirtilmiştir.

## Uygulama

- E-posta/şifre ile Firebase Authentication ve benzersiz kullanıcı adlı profil.
- Metin gönderileri, beğeni, yorum, kaydetme ve kullanıcı arama.
- Gizli hesap, takip isteği, metin mesajlaşması ve uygulama içi takip bildirimleri.
- Şarkı adı ve Spotify/YouTube bağlantılı notlar. Ana Sayfa → **Notlar · Şarkını paylaş**, Profil → **Notum ve şarkım**. Şarkı ilgili serviste açılır. [Notlar](docs/NOTLAR.md).
- Engelleme, gerekçeli şikâyet ve onay/yeniden doğrulama ile hesap silme.

Bu özelliklerin tümünün gerçek Firebase/cihaz entegrasyonu doğrulanmış değildir. Kamera, galeri, video, ses dosyası yükleme/çalma ve native Google girişi kapalıdır; bunların işlevsiz düğmeleri gösterilmez. Uygulama içi reklam ve Analytics entegrasyonu yoktur.

## Firebase

src/firebase/client.ts kullanıcının verdiği **birarada-5650c** web istemci yapılandırmasını içerir. Bu bilgiler herkese açık istemci ayarlarıdır; yönetici yetkisi veya Android imzası sağlamaz. Hesap ve veriler Firebase'e bağlanır; tarayıcıda örnek hesapla giriş yapılmaz.

Firebase Console'da Email/Password sağlayıcısı ve Cloud Firestore kurulumu gerekir. firestore.rules, firestore.indexes.json ve erişimi kapalı storage.rules pakettedir. Kurallar çalışma zamanı testleri geçtikten sonra yetkili hesapla dağıtılmalıdır. Gizli hesabın gönderileri onaylı takipçilere açıktır; hesap gizliliği eski gönderilerin erişimini değiştirmez. Notların takipçi erişimi 24 saat sonra kapanır; süresi dolan not kaydı otomatik fiziksel silinmez.

Yasal sayfalar hosting/public/ altındadır. Mevcut web sitesi korunarak birleştirilip yayımlanmalıdır; yalnız bu klasörü mevcut sitenin üstüne dağıtma. [Hosting rehberi](docs/HOSTING.md).

## Geliştirme ve doğrulama

Komutları package.json dosyasının olduğu klasörde çalıştır:

```sh
npm ci
npm run typecheck
npm test
npm run test:release
npm run test:auth
npm run test:rules
npm run test:ui
```

Uygulamayı geliştirme sırasında açmak için npm start, web görünümü için npm run web kullanılır. .env.example herkese açık canlı proje ayarlarını içerir. Yerel emulator kullanımı için EXPO_PUBLIC_USE_EMULATORS=true açıkça seçilir; üretim derlemesi emulator kullanımını reddeder. Test dosyaları uygulama kullanıcılarına bir demo ekranı göstermez; doğrulama için geliştirme araçlarıdır. Özel tarayıcı konumu CHROMIUM_PATH ile verilebilir.

## Yayın durumu

İmzalı üretim AAB'si, 40 Firestore güvenlik testinin çalışma zamanı sonucu, canlı Firebase/yasal sayfa kurulumu ve gerçek telefon doğrulaması tamamlanmadı. Moderasyon, destek/silme talepleri ve Play Console veri/yaş/içerik beyanları işletim sorumlusunca tamamlanmalıdır. Sunucudan spam sınırlama ve atomik veri silme yoktur. Bu kaynak paketinin temizlenmesi yayın onayı değildir. [Yayın rehberi](docs/PLAY_STORE_RELEASE.md).

Destek: **ahmedberatazboy0@gmail.com**. Kaynaklara parola, token, service account veya üretim imzalama anahtarı eklenmemelidir.
