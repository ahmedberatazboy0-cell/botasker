import { useEffect, useState } from "react";
import { AppState } from "react-native";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "../firebase/client";
import type { Note } from "../types";
import { friendly } from "../utils/errors";
import { noteContent, noteExpiresAt, noteIsActive } from "../utils/notes";

export function useNote(user: string, enabled = true) {
  const [retry, setRetry] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [result, setResult] = useState<{
    user: string;
    retry: number;
    note: Note | null;
    loading: boolean;
    error: string;
    denied: boolean;
  }>({
    user: "",
    retry: 0,
    note: null,
    loading: true,
    error: "",
    denied: false,
  });
  useEffect(() => {
    if (!enabled) return;
    let current = true;
    setResult({
      user,
      retry,
      note: null,
      loading: true,
      error: "",
      denied: false,
    });
    const stop = onSnapshot(
      doc(db, "notes", user),
      (snap) => {
        if (!current) return;
        try {
          const note = snap.exists() ? (snap.data() as Note) : null;
          if (note) {
            if (note.uid !== user || typeof note.username !== "string")
              throw Error("Not okunamadı.");
            noteContent(note.text, note.songTitle, note.songUrl);
          }
          setNow(Date.now());
          setResult({
            user,
            retry,
            note,
            loading: false,
            error: "",
            denied: false,
          });
        } catch {
          setResult({
            user,
            retry,
            note: null,
            loading: false,
            error: "Not okunamadı.",
            denied: false,
          });
        }
      },
      (error) => {
        if (!current) return;
        const denied = error.code === "permission-denied";
        setResult({
          user,
          retry,
          note: null,
          loading: false,
          error: denied ? "" : friendly(error),
          denied,
        });
      },
    );
    return () => {
      current = false;
      stop();
    };
  }, [user, enabled, retry]);
  const ready = enabled && result.user === user && result.retry === retry;
  const record = ready ? result.note : null;
  useEffect(() => {
    const remaining = record ? noteExpiresAt(record) - Date.now() : 0;
    const timer =
      remaining > 0
        ? setTimeout(
            () => setNow(Date.now()),
            Math.min(remaining + 1, 2147483647),
          )
        : undefined;
    const listener = AppState.addEventListener("change", (state) => {
      if (state === "active") setNow(Date.now());
    });
    return () => {
      if (timer) clearTimeout(timer);
      listener.remove();
    };
  }, [record]);
  return {
    record,
    note: record && noteIsActive(record, now) ? record : null,
    loading: enabled && (!ready || result.loading),
    error: ready ? result.error : "",
    denied: ready && result.denied,
    refresh: () => setRetry((value) => value + 1),
  };
}
