import React, { useState } from "react";
import { collection, limit, query, where } from "firebase/firestore";
import { db } from "../firebase/client";
import { Button, Label, Page, State } from "../components/ui";
import { MusicNote } from "../components/MusicNote";
import { useNote } from "../hooks/useNote";
import { useRows } from "../hooks/useRows";
import { removeNote, saveNote } from "../services/notes";
import { useSession } from "../store/session";
import { NoteEditor } from "../components/NoteEditor";

export function FollowedNote({ user }: { user: string }) {
  const data = useNote(user);
  if (data.loading) return <Label muted>Not yükleniyor…</Label>;
  if (data.error) return <State error={data.error} retry={data.refresh} />;
  if (!data.note) return null;
  return (
    <MusicNote
      key={`${user}:${data.note.updatedAt?.seconds}:${data.note.updatedAt?.nanoseconds}`}
      note={data.note}
    />
  );
}

export function Notes() {
  const me = useSession((state) => state.profile)!.uid;
  const [pageSize, setPageSize] = useState(30);
  const own = useNote(me);
  const follows = useRows(
    query(
      collection(db, "follows"),
      where("followerUid", "==", me),
      where("status", "==", "accepted"),
      limit(pageSize),
    ),
  );
  const blocks = useRows(
    query(collection(db, "users", me, "blocks"), limit(200)),
  );
  const hidden = new Set(blocks.rows.map((row) => row.id));
  return (
    <Page title="Bir not, bir şarkı.">
      <State
        loading={own.loading}
        error={
          own.error ||
          (own.denied
            ? "Notlarına erişilemiyor. Bağlantını ve hesap izinlerini kontrol et."
            : "")
        }
        retry={own.refresh}
      />
      {!own.loading && !own.error && !own.denied && (
        <>
          <NoteEditor
            record={own.record}
            active={!!own.note}
            onSave={saveNote}
            onRemove={removeNote}
          />
          {!!own.note && <MusicNote note={own.note} own />}
        </>
      )}
      <Label>Takip ettiklerinin notları</Label>
      <Button
        secondary
        title="Notları yenile"
        onPress={() => {
          own.refresh();
          follows.refresh();
          blocks.refresh();
        }}
      />
      <Label muted>
        Takip ettiğin hesapların güncel notları burada görünür. Süresi dolan,
        silinen veya erişimine kapalı notlar gösterilmez.
      </Label>
      <State
        loading={follows.loading || blocks.loading}
        error={follows.error || blocks.error}
        empty={!follows.rows.length}
        retry={() => {
          follows.refresh();
          blocks.refresh();
        }}
      />
      {!follows.loading &&
        !follows.error &&
        !blocks.loading &&
        !blocks.error &&
        follows.rows
          .filter((row) => !hidden.has(row.followingUid))
          .map((row) => (
            <FollowedNote key={row.followingUid} user={row.followingUid} />
          ))}
      {!follows.loading &&
        !follows.error &&
        !blocks.loading &&
        !blocks.error &&
        follows.rows.length >= pageSize && (
          <Button
            secondary
            title="Daha fazla hesap göster"
            onPress={() => setPageSize((value) => value + 30)}
          />
        )}
    </Page>
  );
}
