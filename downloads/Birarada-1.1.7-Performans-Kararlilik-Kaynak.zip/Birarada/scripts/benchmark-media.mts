import { pathToFileURL, fileURLToPath } from "node:url";
import path from "node:path";
const project = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  "..",
);
import { readFile } from "node:fs/promises";
async function run(root: string) {
  const { harness } = await import(
    pathToFileURL(root + "/tests/free-harness.ts").href
  );
  const { Timestamp } = await import(
    pathToFileURL(root + "/supabase/functions/birarada/records.ts").href
  );
  const h = await harness();
  try {
    for (const uid of ["alice", "bob"])
      await h.db.doc("users/" + uid).set({
        uid,
        username: uid + "_user",
        isPrivate: false,
        deletionPending: false,
        createdAt: Timestamp.now(),
      });
    const id = "11111111-1111-4111-8111-111111111111",
      key = "private/alice/" + id,
      bytes = new Uint8Array(
        await readFile(path.join(project, "tests/free-photo.jpg")),
      );
    await h.db.doc("posts/image-post").set({
      uid: "alice",
      audience: "public",
      kind: "post",
      mediaIds: [id],
      createdAt: Timestamp.now(),
    });
    await h.db.doc("media/" + id).set({
      id,
      uid: "alice",
      status: "ready",
      kind: "image",
      purpose: "post",
      path: key,
      contentType: "image/jpeg",
      bytes: bytes.length,
      attachedTo: { collection: "posts", id: "image-post" },
    });
    h.objects.set(key, { bytes, type: "image/jpeg" });
    await h.call("bob", "connectionProbe");
    await h.db.doc("system/maintenance").set({ after: Date.now() + 600000 });
    const rpc = h.driver.rpc.bind(h.driver);
    let calls: Record<string, number> = {};
    h.driver.rpc = async (name: string, input: any) => {
      calls[name] = (calls[name] || 0) + 1;
      await new Promise((r) => setTimeout(r, 10));
      return rpc(name, input);
    };
    const samples = [];
    for (let i = 0; i < 5; i++) {
      calls = {};
      const at = performance.now();
      const response = await h.request(
        "bob",
        "mediaContent?id=" + id,
        undefined,
        "GET",
      );
      const body = await response.arrayBuffer();
      if (response.status !== 200 || body.byteLength !== bytes.length)
        throw Error("Image denied or wrong length");
      samples.push({
        milliseconds: Math.round(performance.now() - at),
        rpc: { ...calls },
        bytes: body.byteLength,
      });
    }
    return {
      samples,
      medianMs: samples.map((s) => s.milliseconds).sort((a, b) => a - b)[2],
    };
  } finally {
    await h.pg.close();
  }
}
(async () => {
  if (!process.argv[2])
    throw Error(
      "Usage: tsx scripts/benchmark-media.mts <extracted-baseline-project>",
    );
  const before = await run(path.resolve(process.argv[2]));
  const after = await run(project);
  console.log(
    JSON.stringify(
      {
        date: new Date().toISOString().slice(0, 10),
        scenario:
          "Same authenticated JPEG and two local accounts; PGlite, gateway, in-memory storage; artificial 10ms per database RPC; NOT phone or live network latency.",
        before,
        after,
      },
      null,
      2,
    ),
  );
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
