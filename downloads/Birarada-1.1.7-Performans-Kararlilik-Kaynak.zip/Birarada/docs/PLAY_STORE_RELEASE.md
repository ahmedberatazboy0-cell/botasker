# Android yayın adayı

Paket `com.birarada.app`, aday **1.1.7 / versionCode9**. Mevcut EAS `@ahmedberat/birarada` / `9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b` ve upload keystore korunur. Gerçek en yüksek versionCode bu oturumda Console'dan okunmadı; code9 kesin uygun kabul edilmemeli.

GUNCELLE_VE_AAB.bat; mevcut Supabase Edge'i `2026-11-08-media2` revizyonuna günceller, mevcut Hosting dosyalarını koruyarak gizlilik sayfasını yayımlar, test/canlı kontrolleri geçirir ve EAS üretim derlemesi başlatır. Migration/veri sıfırlama yoktur. Tam kaynak kullanılmalı; plugins/ klasörünü veya önceki hız düzeltmelerini tek dosya güncellemesiyle kaybetme.

Android Crashlytics eklendi. Veri gönderimi isteğe bağlı ve varsayılan kapalıdır. Firebase Android yapılandırması gerçek projeye ait olmalı. Yeni APK/AAB'de teknik hata paylaşımı açılıp deneme kaydının Firebase konsoluna geldiği ayrıca doğrulanmalı. SDK kabul yanıtı konsol teslimi değildir. Play Veri Güvenliği beyanında çökme kayıtları/teşhisler ve Firebase kurulum tanımlayıcılarının isteğe bağlı işlenmesi değerlendirilmelidir; bağımsız güvenlik değerlendirmesi yapıldığı iddia edilmez.

Son AAB'nin sürüm kodu, paket, imza, hedef API ve 16 KB native uyumluluğu Play Console'da doğrulanmalı. Gerçek Android düşük RAM/klavye/gezinme/arka plan/ağ koşulları ve FCM teslimi kaynak testlerinin yerine geçmez. Bu oturumda mağazaya yükleme veya imzalı üretim AAB teslimi yapılmadı.
