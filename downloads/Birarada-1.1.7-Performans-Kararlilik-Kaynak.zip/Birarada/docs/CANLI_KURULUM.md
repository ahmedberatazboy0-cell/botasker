# Ücretsiz Supabase kurulumu

Proje `qinevhhhdtslnzrtcanq`, URL `https://qinevhhhdtslnzrtcanq.supabase.co`. Firebase Auth projesi `birarada-5650c`; mevcut kullanıcı girişi bu sağlayıcıda kalır. Firebase'de Blaze açılmaz. Sosyal veriler ve medya yeni Supabase projesindedir; önceki Firestore verileri otomatik taşınmaz/silinmez.

CMD, package.json ile aynı klasörde:

```bat
npm run backend:deploy
```

Araç bağımlılıkları kurar, tip ve ücretsiz sunucu testlerini çalıştırır. Resmî Supabase CLI2.76.4 arşivi ve checksum listesi GitHub yayınından indirilir; SHA-256 doğrulanır. CLI hesabına tarayıcıdan giriş yap. `link` adımı gerekiyorsa veritabanı parolasını yalnız CLI'nin gizli istemine gir; sohbet veya kaynak dosyasına yazma. Sonra migration ve `birarada` Edge Function dağıtılır. Docker ve Firebase ücretli hizmeti gerekmez. Yanlış proje listelenirse durur; başka proje yaratmaz. Çıktıda UCRETSIZ_SUNUCU_HAZIR beklersin.

Migration uygulamaya ait `birarada_*` tabloları/RPC'leri ve private `birarada-media` bucket'ını oluşturur. Public/anon/authenticated rollere tablo/RPC erişimi verilmez. Service role anahtarı Edge ortamından gelir; uygulamaya veya ZIP'e kopyalanmaz. Edge JWT kapısındaki `verify_jwt=false`, özel Firebase doğrulaması kullanıldığı içindir: Google imzası/audience/issuer ve güncel Firebase hesap kaydı her istekte doğrulanır; anonim kullanıcıya erişim açmaz.

Güncel web yasal sayfalarını mevcut tam siteyle birleştir; adresler `/privacy`, `/delete-account`, `/terms`, `/child-safety`. Sonra `npm run build:no-github` ile test/önkontrol ve mevcut EAS projesi+keystore üzerinde yeni AAB oluştur. Canlı sağlık kontrolü depolama ve şema kurulumu/sürümünü denetler; gerçek cihaz veya native16KB kontrollerinin yerine geçmez.

Yerel tarayıcı denemesi için kurulumdan sonra `npm run web:local`. Bu mod gerçek Firebase/Supabase hesapları yerine yerel Auth emulator ve PostgreSQL uyumlu PGlite motoru kullanır. CMD açık kalsın. Yerel veriler `.birarada-local/` altındadır; ZIP/EAS yüklemesine dahil değildir.

Resmî hesap: kendi Firebase e-postanı doğrula; uygulamada resmî hesabı etkinleştir. Sunucu e-posta+UID kontrolü ve tek seferlik owner bağlantısı yapar. Role/verified-email istemci profil alanından kabul edilmez. Canlı owner kurulumu bu bulut ortamında yapılmadı.

## Mevcut sunucuyu güncelleme

Sunucu zaten kuruluysa `npm run backend:update` yeterli: yalnız Edge Function kodunu günceller, `link` ve `db push` çalıştırmaz; veritabanı parolası gerektirmez. Sağlık revizyonu `2026-11-08-public1` olur. `GUNCELLE_VE_AAB.bat` bu adımı ve testli üretim AAB derlemesini sırayla çalıştırır.

Telefon bildirimi için Firebase Android açık yapılandırması ve Expo FCM v1 kurulumu [HIZ_VE_BILDIRIM.md](HIZ_VE_BILDIRIM.md) içinde açıklanır. Operatör SMS hizmeti kullanılmaz.
