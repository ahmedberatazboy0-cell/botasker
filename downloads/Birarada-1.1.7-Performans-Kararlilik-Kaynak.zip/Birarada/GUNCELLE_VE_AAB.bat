@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title Birarada 1.1.7 - Sunucuyu Guncelle ve AAB Olustur
cd /d "%~dp0"
where.exe node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 veya 24 LTS kur: https://nodejs.org/
  pause
  exit /b 1
)
echo Mevcut Supabase projesindeki sosyal sunucu guncellenecek.
echo Veritabani, hesaplar, paket adi ve Android imzasi korunur.
call npm run backend:update
if errorlevel 1 goto failed
call npm run legal:deploy
if errorlevel 1 goto failed
call npm run build:no-github
if errorlevel 1 goto failed
echo AAB baglantisi yukaridaki Expo ciktisinda. Play Console'a otomatik gonderilmedi.
pause
exit /b 0
:failed
echo Islem tamamlanmadi. Yukaridaki son hatayi kontrol et; testler atlanmadi.
pause
exit /b 1
