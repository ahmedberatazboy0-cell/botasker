import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
async function metric(name: string, value: number) {
  const file = "artifacts/warm-navigation.json";
  let previous: any = {};
  try {
    previous = JSON.parse(await fs.readFile(file, "utf8"));
  } catch {}
  await fs.writeFile(
    file,
    JSON.stringify(
      {
        ...previous,
        version: "1.1.7",
        date: new Date().toISOString().slice(0, 10),
        environment:
          "Local Chromium, Firebase Auth emulator, PGlite and real gateway; not a physical device",
        [name]: value,
      },
      null,
      2,
    ) + "\n",
  );
}
const password = "Local-instant-ui-only-642!";
type Account = { uid: string; email: string; token: string; username: string };
let accounts: Record<string, Account>;
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  expect(r.status, await r.clone().text()).toBe(200);
  return r.json();
}
async function data(who: string, route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + accounts[who]!.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  expect(r.status, await r.clone().text()).toBe(200);
  return (await r.json()).data;
}
const api = (who: string, action: string, input: any = {}) =>
  data(who, "socialApi", { action, input });
async function privacy(who: string, value: boolean) {
  const path = "users/" + accounts[who]!.uid,
    old = (
      await data(who, "documents", { operation: "get", paths: [path] })
    )[0];
  await data(who, "documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ path, kind: "set", data: { ...old.data, isPrivate: value } }],
  });
}
async function login(page: Page, who: string) {
  await page.goto("/", { waitUntil: "commit" });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page.getByLabel("E-posta", { exact: true }).fill(accounts[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function closeBanner(page: Page) {
  const close = page.getByRole("button", {
    name: "Bildirimi kapat",
    exact: true,
  });
  if (await close.isVisible()) await close.click();
}
test.beforeEach(async () => {
  accounts = {};
  const profiles = [];
  const suffix = randomUUID().slice(0, 8);
  for (const who of ["alice", "bob"]) {
    const email = `instant-${who}-${suffix}@example.test`,
      created = await auth("accounts:signUp", {
        email,
        password,
        returnSecureToken: true,
      });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: created.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password,
      returnSecureToken: true,
    });
    accounts[who] = {
      uid: created.localId,
      email,
      token: signed.idToken,
      username: who + "_" + suffix,
    };
    profiles.push({
      uid: created.localId,
      email,
      username: accounts[who]!.username,
      displayName: who === "bob" ? "Bob Instant" : "Alice Instant",
    });
  }
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(r.status).toBe(200);
});
test("actual sign-up creates a public profile and its first post reaches another account without a follow", async ({
  page,
  browser,
}) => {
  const suffix = randomUUID().slice(0, 8),
    email = `signup-${suffix}@example.test`,
    username = "new_" + suffix;
  await page.goto("/", { waitUntil: "commit" });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page
    .getByRole("button", { name: "Yeni hesap oluştur", exact: true })
    .click();
  await page.getByLabel("E-posta", { exact: true }).fill(email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("checkbox").check();
  await page
    .getByRole("button", { name: "Hesap oluştur", exact: true })
    .click();
  await expect(page.getByPlaceholder("Görünen ad")).toBeVisible();
  await expect(
    page.getByText(/Hesabın herkese açık oluşturulur/),
  ).toBeVisible();
  await page.getByPlaceholder("Görünen ad").fill("Yeni Hesap");
  await page.getByPlaceholder("Kullanıcı adı").fill(username);
  await page.getByRole("checkbox").check();
  await page
    .getByRole("button", { name: "Birarada’ya katıl", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Takip ettiklerin", exact: true }),
  ).toHaveCount(0);
  const signed = await auth("accounts:signInWithPassword", {
    email,
    password,
    returnSecureToken: true,
  });
  accounts.new = {
    uid: signed.localId,
    email,
    token: signed.idToken,
    username,
  };
  const profile = (
    await data("new", "documents", {
      operation: "get",
      paths: ["users/" + signed.localId],
    })
  )[0].data;
  expect(profile.isPrivate).toBe(false);
  expect(profile.allowStrangerDM).toBe(false);
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  const caption = "İlk paylaşım " + suffix;
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  const saved = page.waitForResponse(
    (r) =>
      r.url().endsWith("/socialApi") &&
      r.request().postDataJSON()?.action === "publishContent",
  );
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  const id = (await (await saved).json()).data.id;
  const context = await browser.newContext();
  try {
    const viewer = await context.newPage();
    await login(viewer, "bob");
    await expect(viewer.getByTestId("post-" + id)).toBeVisible();
    await viewer.getByRole("tab", { name: "Keşfet", exact: true }).click();
    await expect(
      viewer.getByTestId("explore-grid").getByRole("button", {
        name: "@" + username + ": " + caption,
        exact: true,
      }),
    ).toBeVisible();
    await viewer.screenshot({ path: "artifacts/nov08-explore.png" });
  } finally {
    await context.close();
  }
});
test("home and Explore reuse the same fresh result, and manual refresh obtains a newly published post", async ({
  page,
}) => {
  const caption = "Fresh shared feed " + randomUUID();
  const first = await api("bob", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption,
    mediaIds: [],
  });
  await login(page, "alice");
  await expect(page.getByTestId("post-" + first.id)).toBeVisible();
  let publicReads = 0;
  page.on("request", (r) => {
    if (r.url().endsWith("/socialApi")) {
      const b = r.postDataJSON();
      if (
        b.action === "listContent" &&
        !b.input.uid &&
        b.input.kind === "post" &&
        !b.input.search
      )
        publicReads++;
    }
  });
  const started = Date.now();
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await expect(
    page.getByRole("button", {
      name: "@" + accounts.bob!.username + ": " + caption,
      exact: true,
    }),
  ).toBeVisible({ timeout: 1500 });
  await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
  await expect(page.getByTestId("post-" + first.id)).toBeVisible({
    timeout: 1500,
  });
  expect(publicReads).toBe(0);
  await metric("homeExploreRoundTripMs", Date.now() - started);
  const second = await api("bob", "publishContent", {
    requestId: randomUUID(),
    kind: "post",
    caption: "After manual refresh",
    mediaIds: [],
  });
  await page.getByRole("button", { name: "Akışı yenile", exact: true }).click();
  await expect(page.getByTestId("post-" + second.id)).toBeVisible();
  expect(publicReads).toBeGreaterThan(0);
  await page.screenshot({ path: "artifacts/nov08-feed.png" });
});
test("out-of-order account searches cannot restore results from the previous search", async ({
  page,
}) => {
  await login(page, "alice");
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  let held = 0;
  await page.route("**/socialApi", async (route) => {
    const b = route.request().postDataJSON();
    if (
      b.action === "searchUsers" &&
      b.input.search === accounts.alice!.username
    ) {
      held++;
      await gate;
    }
    await route.continue().catch(() => {});
  });
  try {
    const field = page.getByPlaceholder("Kullanıcı, kelime veya #etiket ara");
    await field.fill(accounts.alice!.username);
    await expect.poll(() => held).toBe(1);
    await field.fill(accounts.bob!.username);
    await expect(
      page.getByRole("button", {
        name: "@" + accounts.bob!.username + " hesabını aç",
        exact: true,
      }),
    ).toBeVisible();
    const completed = page.waitForResponse(
      (r) =>
        r.url().endsWith("/socialApi") &&
        r.request().postDataJSON()?.action === "searchUsers" &&
        r.request().postDataJSON()?.input.search === accounts.alice!.username,
    );
    release();
    await completed;
    await expect(
      page.getByRole("button", {
        name: "@" + accounts.alice!.username + " hesabını aç",
        exact: true,
      }),
    ).toHaveCount(0);
  } finally {
    release();
  }
});
