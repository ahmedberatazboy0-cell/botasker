import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
async function metric(name: string, value: number) {
  const file = "artifacts/warm-navigation.json";
  let previous: any = {};
  try {
    previous = JSON.parse(await fs.readFile(file, "utf8"));
  } catch {}
  await fs.writeFile(
    file,
    JSON.stringify(
      {
        ...previous,
        version: "1.1.7",
        date: new Date().toISOString().slice(0, 10),
        environment:
          "Local Chromium, Firebase Auth emulator, PGlite and real gateway; not a physical device",
        [name]: value,
      },
      null,
      2,
    ) + "\n",
  );
}
const password = "Local-instant-ui-only-642!";
type Account = { uid: string; email: string; token: string; username: string };
let accounts: Record<string, Account>;
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  expect(r.status, await r.clone().text()).toBe(200);
  return r.json();
}
async function data(who: string, route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + accounts[who]!.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  expect(r.status, await r.clone().text()).toBe(200);
  return (await r.json()).data;
}
const api = (who: string, action: string, input: any = {}) =>
  data(who, "socialApi", { action, input });
async function privacy(who: string, value: boolean) {
  const path = "users/" + accounts[who]!.uid,
    old = (
      await data(who, "documents", { operation: "get", paths: [path] })
    )[0];
  await data(who, "documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ path, kind: "set", data: { ...old.data, isPrivate: value } }],
  });
}
async function login(page: Page, who: string) {
  await page.goto("/", { waitUntil: "commit" });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page.getByLabel("E-posta", { exact: true }).fill(accounts[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function closeBanner(page: Page) {
  const close = page.getByRole("button", {
    name: "Bildirimi kapat",
    exact: true,
  });
  if (await close.isVisible()) await close.click();
}
test.beforeEach(async () => {
  accounts = {};
  const profiles = [];
  const suffix = randomUUID().slice(0, 8);
  for (const who of ["alice", "bob"]) {
    const email = `instant-${who}-${suffix}@example.test`,
      created = await auth("accounts:signUp", {
        email,
        password,
        returnSecureToken: true,
      });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: created.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password,
      returnSecureToken: true,
    });
    accounts[who] = {
      uid: created.localId,
      email,
      token: signed.idToken,
      username: who + "_" + suffix,
    };
    profiles.push({
      uid: created.localId,
      email,
      username: accounts[who]!.username,
      displayName: who === "bob" ? "Bob Instant" : "Alice Instant",
    });
  }
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(r.status).toBe(200);
});
async function publishPhoto(
  who: string,
  kind: "post" | "story" | "reel" = "post",
) {
  const bytes = await fs.readFile(
    kind === "reel" ? "tests/free-video.mp4" : "tests/free-photo.jpg",
  );
  const reserved = await api(who, "createUpload", {
    requestId: randomUUID(),
    kind: kind === "reel" ? "video" : "image",
    purpose: kind,
    bytes: bytes.byteLength,
  });
  const uploaded = await fetch(
    "http://127.0.0.1:5002/mediaUpload?id=" + reserved.id,
    {
      method: "PUT",
      headers: {
        Authorization: "Bearer " + accounts[who]!.token,
        "Content-Type": "application/octet-stream",
      },
      body: bytes,
    },
  );
  expect(uploaded.status, await uploaded.clone().text()).toBe(200);
  const post = await api(who, "publishContent", {
    requestId: randomUUID(),
    kind,
    caption: "Media phase " + randomUUID(),
    mediaIds: [reserved.id],
  });
  return { id: post.id, media: reserved.id };
}
test("composer stays inside a reduced viewport and sends the preserved draft to the actual other account", async ({
  page,
}) => {
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await login(page, "alice");
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
    .click();
  const input = page.getByPlaceholder("Mesaj yaz…"),
    text = "Small viewport message " + randomUUID();
  await input.fill(text);
  for (const height of [460, 380, 844]) {
    await page.setViewportSize({ width: 360, height });
    const box = await page.getByTestId("message-composer").boundingBox();
    expect(box).not.toBeNull();
    expect(box!.y + box!.height).toBeLessThanOrEqual(height + 1);
    await expect(
      page.getByRole("button", { name: "Gönder", exact: true }),
    ).toBeVisible();
    await expect(input).toHaveValue(text);
  }
  await page.getByRole("button", { name: "Gönder", exact: true }).click();
  await expect(input).toHaveValue("");
  const received = await data("bob", "documents", {
    operation: "query",
    spec: {
      path: `chats/${chat.id}/messages`,
      group: false,
      filters: [],
      orders: [],
      limit: 100,
    },
  });
  expect(received.filter((r: any) => r.data.text === text)).toHaveLength(1);
  await page.screenshot({ path: "artifacts/117-composer.png" });
});
test("a delayed photo has its own slow state, fails independently and a retry displays the real image", async ({
  page,
}) => {
  const photo = await publishPhoto("bob");
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  let attempts = 0;
  await page.route(
    new RegExp("/mediaContent\\?id=" + photo.media),
    async (route) => {
      if (attempts++ === 0) {
        await gate;
        await route.fulfill({
          status: 503,
          contentType: "application/json",
          body: JSON.stringify({
            error: { code: "unavailable", message: "Local media failure" },
          }),
        });
      } else await route.continue();
    },
  );
  try {
    await login(page, "alice");
    const card = page.getByTestId("post-" + photo.id),
      frame = card.getByTestId("image-frame-" + photo.media);
    await expect(card).toBeVisible();
    await expect(
      frame.getByTestId("image-loading-" + photo.media),
    ).toBeVisible();
    await expect(
      frame.getByText("Bağlantı yavaş, fotoğraf yükleniyor…", { exact: true }),
    ).toBeVisible({ timeout: 9000 });
    await page.screenshot({ path: "artifacts/117-slow-photo.png" });
    release();
    await expect(
      frame.getByRole("button", {
        name: "Fotoğrafı yeniden yükle",
        exact: true,
      }),
    ).toBeVisible();
    await frame
      .getByRole("button", { name: "Fotoğrafı yeniden yükle", exact: true })
      .click();
    await expect(
      frame.getByTestId("image-loading-" + photo.media),
    ).toBeHidden();
    await expect
      .poll(() =>
        frame
          .locator("img")
          .evaluateAll((images) =>
            images.some(
              (image) => (image as HTMLImageElement).naturalWidth > 0,
            ),
          ),
      )
      .toBe(true);
    expect(attempts).toBeGreaterThanOrEqual(2);
  } finally {
    release();
  }
});
test("an unresponsive photo stops loading at its deadline and exposes a retry instead of an indefinite gray tile", async ({
  page,
}) => {
  const photo = await publishPhoto("bob");
  let release!: () => void;
  const gate = new Promise<void>((r) => (release = r));
  await page.route(
    new RegExp("/mediaContent\\?id=" + photo.media),
    async (route) => {
      await gate;
      await route.continue().catch(() => {});
    },
  );
  try {
    await login(page, "alice");
    const frame = page
      .getByTestId("post-" + photo.id)
      .getByTestId("image-frame-" + photo.media);
    await expect(
      frame.getByTestId("image-loading-" + photo.media),
    ).toBeVisible();
    await expect(
      frame.getByRole("button", {
        name: "Fotoğrafı yeniden yükle",
        exact: true,
      }),
    ).toBeVisible({ timeout: 30000 });
    await expect(
      frame.getByTestId("image-loading-" + photo.media),
    ).toBeHidden();
  } finally {
    release();
  }
});
test("deleting a story invalidates the fresh story feed so it cannot reappear on immediate return", async ({
  page,
}) => {
  await publishPhoto("alice", "story");
  await login(page, "alice");
  const bubble = page.getByRole("button", {
    name: "@" + accounts.alice!.username + " hikâyesi",
    exact: true,
  });
  await expect(bubble).toBeVisible();
  await bubble.click();
  await page
    .getByRole("button", { name: "Hikâye seçenekleri", exact: true })
    .click();
  await page.getByRole("button", { name: "Hikâyeyi sil", exact: true }).click();
  await page.getByRole("button", { name: "Evet, sil", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await expect(bubble).toHaveCount(0);
  expect((await api("alice", "storyFeed")).rows).toHaveLength(0);
});

async function openSettings(page: Page) {
  await closeBanner(page);
  await page.getByRole("tab", { name: "Profil", exact: true }).click();
  await page
    .getByRole("button", { name: "Profil menüsü", exact: true })
    .click();
  await page.getByRole("button", { name: "Ayarlar", exact: true }).click();
}
test("persisted-session startup exposes separate measured milestones and web cannot pretend to enable Android Crashlytics", async ({
  page,
}) => {
  const photo = await publishPhoto("bob");
  await login(page, "alice");
  const samples = [];
  for (let i = 0; i < 3; i++) {
    const started = Date.now();
    await page.reload({ waitUntil: "commit" });
    await expect(
      page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
    ).toBeVisible();
    const shellMs = Date.now() - started;
    await expect(page.getByTestId("image-loading-" + photo.media)).toBeHidden();
    await expect
      .poll(() =>
        page
          .getByTestId("image-frame-" + photo.media)
          .locator("img")
          .evaluateAll((images) =>
            images.some(
              (image) => (image as HTMLImageElement).naturalWidth > 0,
            ),
          ),
      )
      .toBe(true);
    await expect(page.getByTestId("image-loading-" + photo.media)).toBeHidden();
    const imageMs = Date.now() - started;
    await openSettings(page);
    await page
      .getByRole("button", { name: "Bağlantı kontrolü", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Açılış aşamalarını göster", exact: true })
      .click();
    const stages: Record<string, number> = {};
    for (const name of [
      "firebase-initialization",
      "js-branding-visible",
      "auth-state-known",
      "profile-ready",
      "first-shell-layout",
      "feed-data-ready",
      "first-content-image-displayed",
    ]) {
      const text = await page
        .getByText(new RegExp("^" + name + ": [0-9]+ ms$"))
        .innerText();
      stages[name] = Number(text.match(/: ([0-9]+) ms/)![1]);
    }
    samples.push({ shellMs, imageMs, stages });
  }
  await fs.writeFile(
    "artifacts/117-browser-startup.json",
    JSON.stringify(
      {
        version: "1.1.7",
        date: new Date().toISOString().slice(0, 10),
        environment:
          "Local Chromium development bundle, persisted Firebase Auth emulator session, local PGlite gateway; reload includes browser/bundle work, not Android cold/warm launch",
        samples,
      },
      null,
      2,
    ) + "\n",
  );
  await page.getByRole("link", { name: /back/ }).click();
  await page
    .getByRole("button", { name: "Teknik hata raporları", exact: true })
    .click();
  await expect(
    page.getByRole("switch", {
      name: "Teknik hata raporlarını paylaş",
      exact: true,
    }),
  ).toBeDisabled();
  await expect(
    page.getByText(
      "Bu yapıda Android Crashlytics köprüsü yok. Yeni Android derlemesi gerekir.",
      { exact: true },
    ),
  ).toBeVisible();
});
test("a slow authenticated profile read shows an actionable startup state and recovers without changing accounts", async ({
  page,
}) => {
  await login(page, "alice");
  let release!: () => void;
  const gate = new Promise<void>((resolve) => (release = resolve));
  await page.route("**/documents", async (route) => {
    const body = route.request().postDataJSON();
    if (
      body.operation === "get" &&
      body.paths?.includes("users/" + accounts.alice!.uid)
    )
      await gate;
    await route.continue().catch(() => {});
  });
  try {
    await page.reload({ waitUntil: "commit" });
    await expect(
      page.getByText(
        "Bağlantı yavaş. Oturumun ve profilin güvenli biçimde kontrol ediliyor.",
        { exact: true },
      ),
    ).toBeVisible({ timeout: 10000 });
    await expect(
      page.getByRole("button", {
        name: "Bağlantıyı yeniden dene",
        exact: true,
      }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Bağlantıyı yeniden dene", exact: true })
      .click();
    await expect(
      page.getByRole("button", {
        name: "Bağlantıyı yeniden dene",
        exact: true,
      }),
    ).toBeVisible({ timeout: 10000 });
    release();
    await expect(
      page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
    ).toBeVisible();
    await page.getByRole("tab", { name: "Profil", exact: true }).click();
    await expect(
      page.getByText("Alice Instant", { exact: true }),
    ).toBeVisible();
  } finally {
    release();
  }
});
test("three reels fetch only the visible video on web and release the player when leaving the tab", async ({
  page,
}) => {
  const reels = [];
  for (let i = 0; i < 3; i++) reels.push(await publishPhoto("bob", "reel"));
  const media = new Set(reels.map((row) => row.media));
  const loaded = new Set<string>();
  page.on("request", (request) => {
    const url = new URL(request.url());
    if (
      url.pathname.endsWith("/mediaContent") &&
      media.has(url.searchParams.get("id")!)
    )
      loaded.add(url.searchParams.get("id")!);
  });
  await login(page, "alice");
  await page.getByRole("tab", { name: "Reels", exact: true }).click();
  const feed = page.getByTestId("reels-feed");
  await expect(feed.locator("video")).toHaveCount(1);
  await expect
    .poll(() =>
      feed
        .locator("video")
        .evaluateAll((videos) =>
          (videos as HTMLVideoElement[]).some(
            (v) => v.videoWidth === 160 && v.readyState >= 1,
          ),
        ),
    )
    .toBe(true);
  expect(loaded.size).toBe(1);
  await page.getByRole("tab", { name: "Ana Sayfa", exact: true }).click();
  await expect(page.locator("video")).toHaveCount(0);
  expect(loaded.size).toBe(1);
});
test("a browser taken fully offline keeps the conversation draft and one retry sends exactly one message after reconnection", async ({
  page,
  context,
}) => {
  const chat = await api("alice", "createChat", {
    members: [accounts.bob!.uid],
  });
  await login(page, "alice");
  await page.getByRole("button", { name: "Mesajlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Bob Instant sohbetini aç", exact: true })
    .click();
  const input = page.getByPlaceholder("Mesaj yaz…"),
    text = "Offline preserved draft " + randomUUID();
  await input.fill(text);
  try {
    await context.setOffline(true);
    await page.getByRole("button", { name: "Gönder", exact: true }).click();
    await expect(
      page.getByRole("button", { name: "Gönder", exact: true }),
    ).toBeEnabled();
    await expect(input).toHaveValue(text);
    const before = await data("bob", "documents", {
      operation: "query",
      spec: {
        path: `chats/${chat.id}/messages`,
        group: false,
        filters: [],
        orders: [],
        limit: 100,
      },
    });
    expect(before.filter((row: any) => row.data.text === text)).toHaveLength(0);
    await context.setOffline(false);
    await page.getByRole("button", { name: "Gönder", exact: true }).click();
    await expect(input).toHaveValue("");
    const after = await data("bob", "documents", {
      operation: "query",
      spec: {
        path: `chats/${chat.id}/messages`,
        group: false,
        filters: [],
        orders: [],
        limit: 100,
      },
    });
    expect(after.filter((row: any) => row.data.text === text)).toHaveLength(1);
  } finally {
    await context.setOffline(false);
  }
});
