import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";
async function metric(name: string, value: number) {
  const file = "artifacts/warm-navigation.json";
  let previous: any = {};
  try {
    previous = JSON.parse(await fs.readFile(file, "utf8"));
  } catch {}
  await fs.writeFile(
    file,
    JSON.stringify(
      {
        ...previous,
        version: "1.1.7",
        date: new Date().toISOString().slice(0, 10),
        environment:
          "Local Chromium, Firebase Auth emulator, PGlite and real gateway; not a physical device",
        [name]: value,
      },
      null,
      2,
    ) + "\n",
  );
}
const password = "Local-instant-ui-only-642!";
type Account = { uid: string; email: string; token: string; username: string };
let accounts: Record<string, Account>;
async function auth(action: string, input: any, admin = false) {
  const r = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  expect(r.status, await r.clone().text()).toBe(200);
  return r.json();
}
async function data(who: string, route: string, input: any) {
  const r = await fetch("http://127.0.0.1:5002/" + route, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + accounts[who]!.token,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(input),
  });
  expect(r.status, await r.clone().text()).toBe(200);
  return (await r.json()).data;
}
const api = (who: string, action: string, input: any = {}) =>
  data(who, "socialApi", { action, input });
async function privacy(who: string, value: boolean) {
  const path = "users/" + accounts[who]!.uid,
    old = (
      await data(who, "documents", { operation: "get", paths: [path] })
    )[0];
  await data(who, "documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ path, kind: "set", data: { ...old.data, isPrivate: value } }],
  });
}
async function login(page: Page, who: string) {
  await page.goto("/", { waitUntil: "commit" });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click({ timeout: 90000 });
  await page.getByLabel("E-posta", { exact: true }).fill(accounts[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function closeBanner(page: Page) {
  const close = page.getByRole("button", {
    name: "Bildirimi kapat",
    exact: true,
  });
  if (await close.isVisible()) await close.click();
}
test.beforeEach(async () => {
  accounts = {};
  const profiles = [];
  const suffix = randomUUID().slice(0, 8);
  for (const who of ["alice", "bob"]) {
    const email = `instant-${who}-${suffix}@example.test`,
      created = await auth("accounts:signUp", {
        email,
        password,
        returnSecureToken: true,
      });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: created.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password,
      returnSecureToken: true,
    });
    accounts[who] = {
      uid: created.localId,
      email,
      token: signed.idToken,
      username: who + "_" + suffix,
    };
    profiles.push({
      uid: created.localId,
      email,
      username: accounts[who]!.username,
      displayName: who === "bob" ? "Bob Instant" : "Alice Instant",
    });
  }
  const r = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(r.status).toBe(200);
});
async function publishPhoto(
  who: string,
  kind: "post" | "story" | "reel" = "post",
) {
  const bytes = await fs.readFile(
    kind === "reel" ? "tests/free-video.mp4" : "tests/free-photo.jpg",
  );
  const reserved = await api(who, "createUpload", {
    requestId: randomUUID(),
    kind: kind === "reel" ? "video" : "image",
    purpose: kind,
    bytes: bytes.byteLength,
  });
  const uploaded = await fetch(
    "http://127.0.0.1:5002/mediaUpload?id=" + reserved.id,
    {
      method: "PUT",
      headers: {
        Authorization: "Bearer " + accounts[who]!.token,
        "Content-Type": "application/octet-stream",
      },
      body: bytes,
    },
  );
  expect(uploaded.status, await uploaded.clone().text()).toBe(200);
  const post = await api(who, "publishContent", {
    requestId: randomUUID(),
    kind,
    caption: "Media phase " + randomUUID(),
    mediaIds: [reserved.id],
  });
  return { id: post.id, media: reserved.id };
}
test("compare persisted-session feed and first actual image with identical local accounts", async ({
  page,
}) => {
  const photo = await publishPhoto("bob");
  await login(page, "alice");
  const version = JSON.parse(await fs.readFile("app.json", "utf8")).expo
    .version;
  const samples = [];
  for (let i = 0; i < 5; i++) {
    const started = Date.now();
    await page.reload({ waitUntil: "commit" });
    await expect(
      page.getByRole("heading", { name: "Keşfet akışı", exact: true }),
    ).toBeVisible();
    const shellMs = Date.now() - started;
    await expect
      .poll(() =>
        page
          .getByTestId("post-" + photo.id)
          .locator("img")
          .evaluateAll((images) =>
            images.some(
              (image) => (image as HTMLImageElement).naturalWidth > 0,
            ),
          ),
      )
      .toBe(true);
    await expect(page.getByTestId("image-loading-" + photo.media)).toBeHidden();
    samples.push({ shellMs, firstImageMs: Date.now() - started });
  }
  const median = (key: "shellMs" | "firstImageMs") =>
    samples.map((row) => row[key]).sort((a, b) => a - b)[2];
  await fs.writeFile(
    `artifacts/startup-browser-${version}.json`,
    JSON.stringify(
      {
        version,
        date: new Date().toISOString().slice(0, 10),
        environment:
          "Local Chromium development bundle, same JPEG, Firebase Auth emulator and PGlite; five persisted-session page reloads include browser/bundle work. NOT Android startup.",
        samples,
        medianShellMs: median("shellMs"),
        medianFirstImageMs: median("firstImageMs"),
      },
      null,
      2,
    ) + "\n",
  );
});
