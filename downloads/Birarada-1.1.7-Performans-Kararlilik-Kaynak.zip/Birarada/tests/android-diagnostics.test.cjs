"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict");
const { transforms: t } = require("../plugins/withAndroidDiagnostics.cjs");
test("native diagnostic plugin is idempotent, defaults to opt-out and preserves unrelated application code", () => {
  const project = 'buildscript { dependencies { classpath("other") } }';
  const app = 'dependencies { implementation("other") }';
  assert.equal(
    t.projectGradle(t.projectGradle(project)),
    t.projectGradle(project),
  );
  assert.equal(t.appGradle(t.appGradle(app)), t.appGradle(app));
  assert.ok(t.projectGradle(project).includes('classpath("other")'));
  const source =
    "package com.birarada.app\nfun getPackages() = PackageList(this).packages.apply { add(ExistingPackage()) }\noverride fun onCreate() { super.onCreate() }";
  assert.equal(t.application(t.application(source)), t.application(source));
  assert.ok(t.application(source).includes("add(ExistingPackage())"));
  assert.throws(() => t.application("custom MainApplication"), /preserved/);
  const m = {
    manifest: {
      application: [
        {
          $: {},
          "meta-data": [
            { $: { "android:name": "existing", "android:value": "keep" } },
          ],
        },
      ],
    },
  };
  const out = t.manifest(m);
  assert.deepEqual(t.manifest(out), out);
  assert.equal(
    out.manifest.application[0]["meta-data"].find(
      (r) => r.$["android:name"] === "firebase_crashlytics_collection_enabled",
    ).$["android:value"],
    "false",
  );
  assert.match(t.MODULE, /enabled && !BuildConfig.DEBUG/);
  assert.ok(!t.MODULE.includes("setUserId"));
  assert.ok(!t.MODULE.includes("getDeviceId"));
});
