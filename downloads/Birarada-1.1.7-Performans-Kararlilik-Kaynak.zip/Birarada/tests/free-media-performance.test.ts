import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import { harness } from "./free-harness";
import { Timestamp } from "../supabase/functions/birarada/records";
test("authorized image reads batch permissions while the next blocked request is denied before storage", async () => {
  const h = await harness();
  try {
    for (const uid of ["alice", "bob"])
      await h.db
        .doc("users/" + uid)
        .set({
          uid,
          username: uid + "_user",
          isPrivate: false,
          deletionPending: false,
          createdAt: Timestamp.now(),
        });
    const id = randomUUID(),
      key = "private/alice/" + id,
      bytes = new Uint8Array(await readFile("tests/free-photo.jpg"));
    await h.db
      .doc("posts/image-post")
      .set({
        uid: "alice",
        audience: "public",
        kind: "post",
        mediaIds: [id],
        createdAt: Timestamp.now(),
      });
    await h.db
      .doc("media/" + id)
      .set({
        id,
        uid: "alice",
        status: "ready",
        kind: "image",
        purpose: "post",
        path: key,
        contentType: "image/jpeg",
        bytes: bytes.length,
        attachedTo: { collection: "posts", id: "image-post" },
      });
    h.objects.set(key, { bytes, type: "image/jpeg" });
    await h.call("bob", "connectionProbe");
    await h.db.doc("system/maintenance").set({ after: Date.now() + 600000 });
    const rpc = h.driver.rpc.bind(h.driver);
    let gets = 0,
      storageReads = 0;
    h.driver.rpc = async (name, input) => {
      if (name === "birarada_get") gets++;
      return rpc(name, input);
    };
    const read = h.deps.storage.read.bind(h.deps.storage);
    h.deps.storage.read = async (...args) => {
      storageReads++;
      return read(...args);
    };
    const response = await h.request(
      "bob",
      "mediaContent?id=" + id,
      undefined,
      "GET",
    );
    assert.equal(response.status, 200, await response.clone().text());
    assert.deepEqual(new Uint8Array(await response.arrayBuffer()), bytes);
    assert.match(
      response.headers.get("Server-Timing") || "",
      /media-authorization;dur=/,
    );
    assert.match(
      response.headers.get("Server-Timing") || "",
      /media-storage-headers;dur=/,
    );
    assert.ok(
      gets <= 5,
      `image must batch request-scoped authorization, got ${gets} database reads`,
    );
    await h.db
      .doc("users/alice/blocks/bob")
      .set({ uid: "bob", createdAt: Timestamp.now() });
    const forbidden = await h.request(
      "bob",
      "mediaContent?id=" + id,
      undefined,
      "GET",
    );
    assert.equal(forbidden.status, 403);
    assert.equal(storageReads, 1);
  } finally {
    await h.pg.close();
  }
});
