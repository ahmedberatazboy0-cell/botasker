import { test } from "node:test";
import assert from "node:assert/strict";
import { createMediaTokenStore } from "../src/utils/mediaTokenStore";
const tick = () => new Promise<void>((resolve) => setImmediate(resolve));
test("many mounted media share one auth listener/timer and release both after the last unsubscribe", async () => {
  let callback = () => {},
    timer = () => {},
    subscriptions = 0,
    stops = 0,
    timers = 0,
    cleared = 0,
    reads = 0;
  const user = {
    uid: "first",
    getIdToken: async () => {
      reads++;
      return "first-token";
    },
  };
  const store = createMediaTokenStore({
    currentUser: () => user,
    subscribe: (next) => {
      subscriptions++;
      callback = next;
      queueMicrotask(next);
      return () => {
        stops++;
      };
    },
    schedule: (next) => {
      timers++;
      timer = next;
      return () => {
        cleared++;
      };
    },
  });
  const off = Array.from({ length: 30 }, () => store.subscribe(() => {}));
  await tick();
  assert.equal(subscriptions, 1);
  assert.equal(timers, 1);
  assert.equal(reads, 1);
  assert.equal(store.snapshot(), "first-token");
  timer();
  await tick();
  assert.equal(reads, 2);
  assert.equal(store.snapshot(), "first-token");
  off.slice(0, -1).forEach((stop) => stop());
  assert.equal(stops, 0);
  off.at(-1)!();
  assert.equal(stops, 1);
  assert.equal(cleared, 1);
  assert.equal(store.snapshot(), "");
  callback();
  await tick();
  assert.equal(store.snapshot(), "");
});
test("delayed token results cannot cross account changes, sign-out or the final unsubscribe", async () => {
  let complete!: (token: string) => void,
    callback = () => {};
  const first = {
    uid: "first",
    getIdToken: () =>
      new Promise<string>((r) => {
        complete = r;
      }),
  };
  const second = { uid: "second", getIdToken: async () => "second-token" };
  let current: typeof first | null = first;
  const store = createMediaTokenStore({
    currentUser: () => current,
    subscribe: (next) => {
      callback = next;
      next();
      return () => {};
    },
    schedule: () => () => {},
  });
  const off = store.subscribe(() => {});
  current = second;
  callback();
  await tick();
  assert.equal(store.snapshot(), "second-token");
  complete("stale-private-token");
  await tick();
  assert.equal(store.snapshot(), "second-token");
  current = null;
  callback();
  assert.equal(store.snapshot(), "");
  off();
});
test("a failed token read can be retried without mounting a second Firebase subscription", async () => {
  let callback = () => {},
    calls = 0,
    complete!: (token: string) => void;
  const user = {
    uid: "first",
    getIdToken: () => {
      calls++;
      return calls === 1
        ? Promise.reject(Error("offline"))
        : new Promise<string>((resolve) => (complete = resolve));
    },
  };
  const store = createMediaTokenStore({
    currentUser: () => user,
    subscribe: (next) => {
      callback = next;
      next();
      return () => {};
    },
    schedule: () => () => {},
  });
  const off = store.subscribe(() => {});
  await tick();
  assert.equal(store.snapshot(), "");
  const first = store.refresh(),
    second = store.refresh();
  assert.equal(first, second);
  assert.equal(calls, 2);
  complete("recovered-token");
  await first;
  assert.equal(store.snapshot(), "recovered-token");
  off();
});
