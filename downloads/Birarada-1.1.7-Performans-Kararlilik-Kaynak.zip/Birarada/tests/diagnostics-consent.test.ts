import { test } from "node:test";
import assert from "node:assert/strict";
import { createDiagnosticsController } from "../src/utils/diagnosticsController";
function fixture(release = true) {
  let consent = false,
    failRead = false,
    failWrite = false,
    native = false,
    reporter: any = null;
  const calls: boolean[] = [],
    reports: string[][] = [];
  const controller = createDiagnosticsController({
    release,
    bridge: () => ({
      setEnabled: async (value) => {
        calls.push(value);
        native = value;
        return value;
      },
      recordTechnical: async (a, b) => {
        reports.push([a, b]);
        return true;
      },
    }),
    readConsent: async () => {
      if (failRead) throw Error("unreadable");
      return consent;
    },
    writeConsent: async (value) => {
      if (failWrite) throw Error("storage unavailable");
      consent = value;
    },
    reporter: (value) => {
      reporter = value;
    },
  });
  return {
    controller,
    calls,
    reports,
    setReadFailure: () => {
      failRead = true;
    },
    setWriteFailure: () => {
      failWrite = true;
    },
    native: () => native,
    reporter: () => reporter,
  };
}
test("Crashlytics defaults to disabled and only explicit persisted consent enables a sanitized self-test", async () => {
  const f = fixture();
  await f.controller.initialize();
  assert.equal(f.native(), false);
  assert.equal(f.reporter(), null);
  await assert.rejects(f.controller.check());
  await f.controller.setEnabled(true);
  assert.equal(f.native(), true);
  await f.controller.check();
  assert.deepEqual(f.reports, [["self-test", "self-test"]]);
  await f.controller.setEnabled(false);
  assert.equal(f.native(), false);
  assert.equal(f.reporter(), null);
});
test("unreadable consent and failed preference writes disable the native SDK instead of silently keeping collection enabled", async () => {
  const f = fixture();
  await f.controller.setEnabled(true);
  f.setReadFailure();
  await f.controller.initialize();
  assert.equal(f.native(), false);
  assert.equal((await f.controller.state()).enabled, false);
  const g = fixture();
  g.setWriteFailure();
  await assert.rejects(g.controller.setEnabled(true));
  assert.equal(g.native(), false);
  assert.equal(g.reporter(), null);
});
test("debug consent cannot enable reports and concurrent initialization/toggle actions preserve the explicit final preference", async () => {
  const debug = fixture(false);
  await debug.controller.initialize();
  await assert.rejects(debug.controller.setEnabled(true));
  assert.equal(debug.native(), false);
  assert.equal(debug.reports.length, 0);
  const f = fixture();
  await Promise.all([
    f.controller.initialize(),
    f.controller.setEnabled(true),
    f.controller.setEnabled(false),
  ]);
  assert.equal(f.native(), false);
  assert.equal((await f.controller.state()).enabled, false);
});
