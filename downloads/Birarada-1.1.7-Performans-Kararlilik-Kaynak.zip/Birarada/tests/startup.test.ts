import { test } from "node:test";
import assert from "node:assert/strict";
import { createStartupMeasurements } from "../src/utils/startup";
import { safeIssue } from "../src/utils/technicalIssues";
test("startup stages are measured once per run and warm resumes never inherit cold data", () => {
  let clock = 100;
  const tracker = createStartupMeasurements(() => clock);
  const finish = tracker.span("firebase-initialization");
  clock = 140;
  finish();
  finish();
  tracker.mark("auth-state-known");
  clock = 200;
  tracker.mark("auth-state-known");
  tracker.mark("unsafe-user-email");
  assert.equal(tracker.list()[0]!.stages["auth-state-known"], 40);
  assert.equal(tracker.list()[0]!.spans["firebase-initialization"], 40);
  assert.equal(tracker.list()[0]!.stages["unsafe-user-email"], undefined);
  tracker.resume();
  clock = 220;
  tracker.mark("resume-js-frame");
  assert.equal(tracker.list()[1]!.stages["resume-js-frame"], 20);
  assert.equal(tracker.list()[1]!.stages["auth-state-known"], undefined);
  for (let i = 0; i < 10; i++) tracker.resume();
  assert.equal(tracker.list().length, 5);
});
test("technical errors whitelist codes and discard messages, stacks, tokens and user fields", () => {
  const error = {
    code: "deadline-exceeded",
    message: "private message",
    stack: "Bearer SECRET",
    email: "private@example.invalid",
    token: "SECRET",
  };
  assert.deepEqual(safeIssue("network", error), {
    category: "network",
    code: "deadline-exceeded",
    fatal: false,
  });
  assert.deepEqual(
    safeIssue("ui-render", {
      code: "private@example.invalid",
      message: "secret",
    }),
    { category: "ui-render", code: "unknown", fatal: false },
  );
  assert.ok(
    !JSON.stringify(safeIssue("unhandled-js", error, true)).includes("SECRET"),
  );
});
test("broken error reporters never hide the original global error handler", async () => {
  const { setIssueReporter, installTechnicalErrorHandler } =
    await import("../src/utils/technicalIssues");
  const world = globalThis as any,
    before = world.ErrorUtils;
  const hostile = Object.defineProperty({}, "code", {
    get() {
      throw Error("getter failed");
    },
  });
  assert.equal(safeIssue("unhandled-js", hostile).code, "unknown");
  let originalCalls = 0;
  const original = () => {
    originalCalls++;
  };
  let handler = original;
  world.ErrorUtils = {
    getGlobalHandler: () => handler,
    setGlobalHandler: (next: any) => {
      handler = next;
    },
  };
  setIssueReporter(() => {
    throw Error("reporter failed");
  });
  const restore = installTechnicalErrorHandler();
  try {
    assert.doesNotThrow(() => (handler as any)(hostile, true));
    assert.equal(originalCalls, 1);
  } finally {
    restore();
    setIssueReporter(null);
    world.ErrorUtils = before;
  }
});
