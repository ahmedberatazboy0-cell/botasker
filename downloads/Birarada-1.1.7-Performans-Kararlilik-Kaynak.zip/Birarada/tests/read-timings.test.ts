import { test } from "node:test";
import assert from "node:assert/strict";
import { createReadTimings } from "../src/utils/readTimings";
test("timings are bounded, redacted, session scoped and record each completion once", () => {
  let clock = 100;
  const timings = createReadTimings(() => clock);
  const finish = timings.start(
    "private-input-token-message",
    "response-headers",
  );
  clock = 350;
  finish("error");
  finish();
  assert.deepEqual(timings.list(), [
    {
      operation: "other",
      stage: "response-headers",
      milliseconds: 250,
      status: "error",
    },
  ]);
  const old = timings.start("media", "image-load");
  timings.clear();
  old();
  assert.equal(timings.list().length, 0);
  for (let i = 0; i < 100; i++) timings.start("media", "image-display")();
  assert.equal(timings.list().length, 80);
  const copy = timings.list();
  copy[0]!.operation = "tampered";
  assert.equal(timings.list()[0]!.operation, "media");
});
