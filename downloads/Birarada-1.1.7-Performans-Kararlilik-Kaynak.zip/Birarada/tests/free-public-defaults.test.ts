import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { harness } from "./free-harness";
import { encode, Timestamp } from "../supabase/functions/birarada/records";
test("new public profiles publish without a privacy edit, legacy private profiles and user privacy choices remain enforced", async () => {
  const h = await harness();
  try {
    for (const [uid, isPrivate] of [
      ["alice", false],
      ["bob", true],
      ["eve", false],
    ] as const) {
      const fields = {
        uid,
        username: uid + "_user",
        displayName: uid,
        bio: "",
        website: "",
        avatarUrl: "",
        isPrivate,
        allowStrangerDM: false,
        createdAt: Timestamp.now(),
        deletionPending: false,
        termsVersion: "2026-10-21-free1",
        termsAcceptedAt: Timestamp.now(),
        followersCount: 0,
        followingCount: 0,
        postsCount: 0,
      };
      const r = await h.request(uid, "documents", {
        operation: "commit",
        reads: [],
        writes: [
          { kind: "set", path: "usernames/" + fields.username, data: { uid } },
          { kind: "set", path: "users/" + uid, data: encode(fields) },
        ],
      });
      assert.equal(r.status, 200, await r.text());
    }
    const published = await h.call("alice", "publishContent", {
      requestId: randomUUID(),
      kind: "post",
      caption: "Public without changing a setting",
      mediaIds: [],
    });
    assert.equal(published.status, 200);
    assert.ok(
      (await h.call("eve", "listContent", { kind: "post" })).data.rows.some(
        (r: any) => r.id === published.data.id,
      ),
    );
    assert.equal((await h.db.doc("users/bob").get()).get("isPrivate"), true);
    const old = await h.db.doc("users/alice").get();
    const change = await h.request("alice", "documents", {
      operation: "commit",
      reads: [{ path: old.raw.path, rev: old.raw.rev }],
      writes: [
        {
          kind: "set",
          path: old.raw.path,
          data: encode({ ...old.data(), isPrivate: true }),
        },
      ],
    });
    assert.equal(change.status, 200, await change.text());
    assert.equal(
      (await h.call("eve", "getContent", { id: published.data.id })).status,
      403,
    );
    assert.ok(
      !(await h.call("eve", "listContent", { kind: "post" })).data.rows.some(
        (r: any) => r.id === published.data.id,
      ),
    );
  } finally {
    await h.pg.close();
  }
});
