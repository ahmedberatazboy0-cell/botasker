"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const {
  RELEASE_IDENTITY,
  LEGAL_DEFAULTS,
  getReleaseProblems,
  getIdentityProblems,
  isPublicHttpsUrl,
  isSupportUrl,
} = require("../scripts/release-check.cjs");
const valid = () => ({
  EXPO_PUBLIC_USE_EMULATORS: "false",
  EXPO_PUBLIC_STORAGE_ENABLED: "false",
  EAS_PROJECT_ID: "00000000-0000-4000-8000-000000000001",
});

test("release identity matches the update without changing package identity", () => {
  assert.deepEqual(RELEASE_IDENTITY, {
    package: "com.birarada.app",
    version: "1.1.7",
    versionCode: 9,
    firebaseProjectId: "birarada-5650c",
  });
  const cfg = require("../app.json").expo;
  assert.equal(cfg.android.package, "com.birarada.app");
  assert.equal(cfg.ios.bundleIdentifier, "com.birarada.app");
  assert.equal(cfg.android.versionCode, 9);
  assert.equal(cfg.version, "1.1.7");
});
test("release cannot silently use test services or enabled unimplemented media", () => {
  for (const key of [
    "EXPO_PUBLIC_USE_EMULATORS",
    "EXPO_PUBLIC_STORAGE_ENABLED",
  ]) {
    const env = valid();
    delete env[key];
    assert.ok(getReleaseProblems(env).some((x) => x.includes(key)));
    assert.ok(
      getReleaseProblems({ ...valid(), [key]: "true" }).some((x) =>
        x.includes(key),
      ),
    );
  }
});
test("a syntactically valid public project ID is required, not invented by configuration", () => {
  const env = valid();
  delete env.EAS_PROJECT_ID;
  assert.ok(getReleaseProblems(env).some((x) => x.includes("EAS_PROJECT_ID")));
  assert.ok(
    getReleaseProblems({ ...valid(), EAS_PROJECT_ID: "replace-me" }).some((x) =>
      x.includes("EAS_PROJECT_ID"),
    ),
  );
  // Synthetic unit-test UUID only; this does not prove Expo account ownership.
  assert.deepEqual(getReleaseProblems(valid()), []);
});
test("conflicting package, Firebase project and update version code are rejected", () => {
  for (const env of [
    { EXPO_PUBLIC_ANDROID_PACKAGE: "wrong.app" },
    { ANDROID_PACKAGE: "other.app" },
    { ANDROID_VERSION_CODE: "5" },
    { EXPO_PUBLIC_FIREBASE_PROJECT_ID: "demo-birarada" },
  ])
    assert.ok(getIdentityProblems(env).length > 0);
  assert.deepEqual(
    getIdentityProblems({
      EXPO_PUBLIC_ANDROID_PACKAGE: "com.birarada.app",
      ANDROID_VERSION_CODE: "9",
    }),
    [],
  );
});
test("legal defaults are exact owner-approved locations and support contact", () => {
  assert.equal(
    LEGAL_DEFAULTS.EXPO_PUBLIC_PRIVACY_POLICY_URL,
    "https://birarada-5650c.web.app/privacy",
  );
  assert.equal(
    LEGAL_DEFAULTS.EXPO_PUBLIC_DELETE_ACCOUNT_URL,
    "https://birarada-5650c.web.app/delete-account",
  );
  assert.equal(
    LEGAL_DEFAULTS.EXPO_PUBLIC_TERMS_URL,
    "https://birarada-5650c.web.app/terms",
  );
  assert.equal(
    LEGAL_DEFAULTS.EXPO_PUBLIC_SUPPORT_URL,
    "mailto:ahmedberatazboy0@gmail.com",
  );
});
test("legal URL validation refuses unsafe and placeholder addresses", () => {
  for (const value of [
    "http://site.com/privacy",
    "https://localhost/privacy",
    "https://127.0.0.1/privacy",
    "https://10.0.0.1",
    "https://site.test",
    "https://example.com/privacy",
    "https://a:b@real.com/privacy",
    "javascript:alert(1)",
    "",
  ])
    assert.equal(isPublicHttpsUrl(value), false, value);
  assert.equal(
    isPublicHttpsUrl("https://birarada-5650c.web.app/privacy"),
    true,
  );
  assert.equal(isSupportUrl("mailto:ahmedberatazboy0@gmail.com"), true);
  assert.equal(isSupportUrl("mailto:fake@example.com"), false);
  assert.ok(
    getReleaseProblems({ ...valid(), EXPO_PUBLIC_PRIVACY_POLICY_URL: "" }).some(
      (x) => x.includes("PRIVACY"),
    ),
  );
});
