import React, { useEffect, useState } from "react";
import { Text, View, ActivityIndicator, AppState } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { onAuthStateChanged } from "firebase/auth";
import { doc, onSnapshot, clearClientSession } from "./src/database/client";
import { auth, db } from "./src/firebase/client";
import { useSession } from "./src/store/session";
import { AuthScreen, CompleteProfile } from "./src/screens/Auth";
import { Root } from "./src/navigation/Root";
import {
  Page,
  Label,
  Button,
  DeleteAccountForm,
  CommunityAgreement,
} from "./src/components/ui";
import { api } from "./src/services/api";
import { TERMS_VERSION } from "./src/constants/release";
import { friendly } from "./src/utils/errors";
import {
  logout,
  deleteOwnAccount,
  loadPendingDeletion,
} from "./src/services/social";
import type { Profile } from "./src/types";
import { startup } from "./src/utils/startup";
import { initializeDiagnostics } from "./src/services/diagnostics";
import {
  installTechnicalErrorHandler,
  recordTechnicalIssue,
} from "./src/utils/technicalIssues";
class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: unknown) {
    recordTechnicalIssue("ui-render", error);
  }
  render() {
    if (this.state.failed)
      return (
        <Page title="Bir sorun oluştu.">
          <Label>
            Uygulama bu ekranı açamadı. Yeniden deneyebilir veya uygulamayı
            kapatıp açabilirsin.
          </Label>
          <Button
            title="Yeniden dene"
            onPress={() => this.setState({ failed: false })}
          />
          <Button
            secondary
            title="Çıkış yap"
            onPress={async () => {
              await logout();
              this.setState({ failed: false });
            }}
          />
        </Page>
      );
    return this.props.children;
  }
}
function AppContent() {
  const {
      user,
      profile,
      ready,
      deleting,
      deletionPending,
      deletionError,
      set,
    } = useSession(),
    [error, setError] = useState(""),
    [syncError, setSyncError] = useState(""),
    [retry, setRetry] = useState(0);
  const [slowStartup, setSlowStartup] = useState(false);
  useEffect(() => {
    if (ready) {
      setSlowStartup(false);
      return;
    }
    const complete = startup.span("js-branding-visible");
    const timer = setTimeout(() => setSlowStartup(true), 5000);
    return () => {
      clearTimeout(timer);
      complete();
    };
  }, [ready, retry]);
  useEffect(() => {
    let stop: undefined | (() => void);
    let generation = 0;
    let active = true;
    startup.mark("auth-listener-attached");
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      startup.mark("auth-state-known");
      const current = ++generation;
      clearClientSession();
      stop?.();
      stop = undefined;
      setError("");
      setSyncError("");
      set({
        user: u,
        profile: null,
        ready: !u,
        deletionPending: false,
        deletionError: "",
      });
      if (u) {
        try {
          const pending = await loadPendingDeletion(u.uid);
          if (!active || current !== generation) return;
          set({ deletionPending: pending });
        } catch (e) {
          if (!active || current !== generation) return;
          setError(friendly(e));
          set({ ready: true });
          return;
        }
        let receivedProfile = false,
          lastRevision: unknown;
        stop = onSnapshot(
          doc(db, "users", u.uid),
          (snap) => {
            if (!active || current !== generation) return;
            const nextProfile = snap.exists() ? (snap.data() as Profile) : null;
            if (nextProfile) startup.mark("profile-ready");
            setError("");
            setSyncError("");
            const state = useSession.getState(),
              revision = snap.raw.rev;
            const changed =
              !receivedProfile || revision == null || lastRevision !== revision;
            if (
              changed ||
              !state.ready ||
              (nextProfile?.deletionPending === true && !state.deletionPending)
            )
              set({
                profile: changed ? nextProfile : state.profile,
                ...(nextProfile?.deletionPending === true
                  ? { deletionPending: true }
                  : {}),
                ready: true,
              });
            receivedProfile = true;
            lastRevision = revision;
          },
          (e) => {
            if (!active || current !== generation) return;
            const temporary =
              [
                "resource-exhausted",
                "unavailable",
                "deadline-exceeded",
              ].includes(e?.code) ||
              e instanceof TypeError ||
              e?.name === "AbortError";
            if (temporary && useSession.getState().profile) {
              setSyncError(friendly(e));
              return;
            }
            setError(friendly(e));
            set({ ready: true });
          },
        );
      }
    });
    return () => {
      active = false;
      generation += 1;
      unsubscribe();
      stop?.();
    };
  }, [retry]);
  return (
    <>
      {deleting ? (
        <Page title="Hesabın siliniyor…">
          <ActivityIndicator color="#ff925c" />
          <Label>
            Verilerin kaldırılıyor. İşlem tamamlanana kadar uygulamayı açık tut.
          </Label>
        </Page>
      ) : !ready ? (
        <View
          style={{
            flex: 1,
            backgroundColor: "#ffffff",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
          }}
        >
          <Text style={{ color: "#121212", fontSize: 44, fontWeight: "800" }}>
            birarada
          </Text>
          <Text style={{ color: "#737373" }}>
            Yeni insanlarla, daha güzel anlara.
          </Text>
          {slowStartup && (
            <View style={{ padding: 20, gap: 12 }}>
              <Label muted>
                Bağlantı yavaş. Oturumun ve profilin güvenli biçimde kontrol
                ediliyor.
              </Label>
              <Button
                secondary
                title="Bağlantıyı yeniden dene"
                onPress={() => {
                  setSlowStartup(false);
                  setRetry((r) => r + 1);
                }}
              />
            </View>
          )}
        </View>
      ) : user && deletionPending ? (
        <Page title="Hesap silmeyi tamamla.">
          <Label>
            Önceki silme işlemi tamamlanmadı. Hesabını kullanmaya devam etmeden
            önce kalan verileri kaldırmak için yeniden onayla.
          </Label>
          {!!deletionError && <Label>{deletionError}</Label>}
          <DeleteAccountForm
            onDelete={deleteOwnAccount}
            onCancel={logout}
            cancelTitle="Şimdilik çıkış yap"
          />
        </Page>
      ) : error ? (
        <Page title="Bağlantıyı yenileyelim.">
          <Label>{error}</Label>
          <Button title="Tekrar dene" onPress={() => setRetry((r) => r + 1)} />
          <Button secondary title="Çıkış yap" onPress={logout} />
        </Page>
      ) : !user ? (
        <AuthScreen />
      ) : !profile ? (
        <CompleteProfile />
      ) : profile.termsVersion !== TERMS_VERSION ? (
        <RenewConsent />
      ) : (
        <View style={{ flex: 1 }}>
          {!!syncError && (
            <Text
              accessibilityRole="alert"
              style={{
                padding: 8,
                color: "#737373",
                fontSize: 12,
                backgroundColor: "#fff",
              }}
            >
              {syncError}
            </Text>
          )}
          <Root />
        </View>
      )}
    </>
  );
}
function RenewConsent() {
  const [accepted, setAccepted] = useState(false);
  return (
    <Page title="Yeni paylaşım özellikleri">
      <Label>
        Fotoğraf/video, hikâyeler, sesli mesajlar ve telefon bildirimleri için
        güncel gizlilik politikasını ve topluluk kurallarını oku.
      </Label>
      <CommunityAgreement value={accepted} onChange={setAccepted} />
      <Button
        title="Onayla ve devam et"
        disabled={!accepted}
        onPress={() =>
          api("acceptTerms", { version: TERMS_VERSION, accepted: true })
        }
      />
      <Button secondary title="Çıkış yap" onPress={logout} />
    </Page>
  );
}
export default function App() {
  useEffect(() => {
    const restore = installTechnicalErrorHandler();
    const timer = setTimeout(() => {
      void initializeDiagnostics();
    }, 1000);
    let previous = AppState.currentState;
    const listener = AppState.addEventListener("change", (state) => {
      if (state === "active" && ["inactive", "background"].includes(previous)) {
        startup.resume();
        requestAnimationFrame(() =>
          requestAnimationFrame(() => startup.mark("resume-js-frame")),
        );
      }
      previous = state;
    });
    return () => {
      restore();
      clearTimeout(timer);
      listener.remove();
    };
  }, []);
  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <AppErrorBoundary>
        <View
          style={{ flex: 1 }}
          onLayout={() => startup.mark("first-app-layout")}
        >
          <AppContent />
        </View>
      </AppErrorBoundary>
    </SafeAreaProvider>
  );
}
