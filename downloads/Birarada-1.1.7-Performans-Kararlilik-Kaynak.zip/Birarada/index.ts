import { startup } from "./src/utils/startup";
import { registerRootComponent } from "expo";
import App from "./App";
startup.mark("root-registration");
registerRootComponent(App);
