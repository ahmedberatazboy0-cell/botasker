// Only authorized results from this running session; never written to disk.
export function stableKey(value: any): string {
  if (Array.isArray(value)) return `[${value.map(stableKey).join(",")}]`;
  if (value && typeof value === "object")
    return `{${Object.keys(value)
      .sort()
      .map((k) => JSON.stringify(k) + ":" + stableKey(value[k]))
      .join(",")}}`;
  return JSON.stringify(value);
}
export function createSessionReads({
  ttl = 60000,
  maximum = 80,
  now = Date.now,
} = {}) {
  const values = new Map<
    string,
    { scope: string; key: string; value: any; until: number }
  >();
  const pending = new Map<string, Promise<any>>();
  const revisions = new Map<string, number>();
  const listeners = new Set<(scope: string, keys: string[]) => void>();
  let generation = 0;
  const id = (scope: string, key: string) => `${scope}\u0000${key}`;
  const peek = <T>(
    scope: string,
    key: string,
    maxAgeMs = ttl,
  ): T | undefined => {
    const name = id(scope, key),
      saved = values.get(name);
    if (!saved || saved.until <= now()) {
      values.delete(name);
      return undefined;
    }
    if (now() - (saved.until - ttl) >= maxAgeMs) return undefined;
    return saved.value as T;
  };
  const remember = (scope: string, key: string, value: any) => {
    const name = id(scope, key);
    values.delete(name);
    values.set(name, { scope, key, value, until: now() + ttl });
    while (values.size > maximum) values.delete(values.keys().next().value!);
  };
  const load = <T>(
    scope: string,
    key: string,
    read: () => Promise<T>,
    maxAgeMs = 0,
  ): Promise<T> => {
    const name = id(scope, key);
    const saved = values.get(name);
    if (
      saved &&
      maxAgeMs > 0 &&
      saved.until > now() &&
      now() - (saved.until - ttl) < maxAgeMs
    )
      return Promise.resolve(saved.value as T);
    const existing = pending.get(name);
    if (existing) return existing;
    const revision = revisions.get(name) || 0,
      current = generation;
    const work = Promise.resolve()
      .then(read)
      .then((value) => {
        if (generation === current && revision === (revisions.get(name) || 0)) {
          values.delete(name);
          values.set(name, { scope, key, value, until: now() + ttl });
          while (values.size > maximum)
            values.delete(values.keys().next().value!);
        }
        return value;
      })
      .catch((error) => {
        if (["permission-denied", "unauthenticated"].includes(error?.code))
          values.delete(name);
        throw error;
      })
      .finally(() => {
        if (pending.get(name) === work) pending.delete(name);
      });
    pending.set(name, work);
    return work;
  };
  const invalidate = (
    scope: string,
    matches: (key: string) => boolean = () => true,
  ) => {
    const keys: string[] = [];
    for (const name of new Set([...values.keys(), ...pending.keys()])) {
      const split = name.indexOf("\u0000"),
        actor = name.slice(0, split),
        key = name.slice(split + 1);
      if (scope !== actor || !matches(key)) continue;
      values.delete(name);
      pending.delete(name);
      revisions.set(name, (revisions.get(name) || 0) + 1);
      keys.push(key);
    }
    // Notify only matched entries; unrelated writes do not restart readers.
    if (keys.length) for (const listen of listeners) listen(scope, keys);
  };
  return {
    peek,
    load,
    remember,
    invalidate,
    subscribe(listen: (scope: string, keys: string[]) => void) {
      listeners.add(listen);
      return () => {
        listeners.delete(listen);
      };
    },
    clear() {
      generation++;
      values.clear();
      pending.clear();
      revisions.clear();
      for (const listen of listeners) listen("", []);
    },
  };
}
export const sessionReads = createSessionReads();
export const apiReadKey = (action: string, input: unknown) =>
  "api:" + stableKey({ action, input });
export const documentReadKey = (input: unknown) =>
  "documents:" + stableKey(input);
export function documentChanged(input: any, paths: string[]) {
  if (input.operation === "get")
    return input.paths.some((path: string) =>
      paths.some(
        (p) =>
          path === p || p.startsWith(path + "/") || path.startsWith(p + "/"),
      ),
    );
  const target = input.spec?.path;
  return (
    !!target &&
    paths.some((p) =>
      input.spec.group
        ? p.split("/").includes(target)
        : p === target ||
          p.startsWith(target + "/") ||
          target.startsWith(p + "/"),
    )
  );
}
export function invalidateDocumentReads(scope: string, paths: string[]) {
  const security = paths.some(
    (p) => /^users\/[^/]+(?:$|\/blocks\/)/.test(p) || p.startsWith("follows/"),
  );
  const content =
    security ||
    paths.some((p) => /^posts\/[^/]+$/.test(p) || p.startsWith("stories/"));
  sessionReads.invalidate(scope, (key) => {
    if (key.startsWith("documents:"))
      return security || documentChanged(JSON.parse(key.slice(10)), paths);
    return content && key.startsWith("api:");
  });
}
