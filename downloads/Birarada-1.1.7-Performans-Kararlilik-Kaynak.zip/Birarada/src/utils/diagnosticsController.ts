import type { TechnicalIssue } from "./technicalIssues";
type Bridge = {
  setEnabled(value: boolean): Promise<boolean>;
  recordTechnical(category: string, code: string): Promise<boolean>;
};
export function createDiagnosticsController(deps: {
  bridge(): Bridge | null;
  release: boolean;
  readConsent(): Promise<boolean>;
  writeConsent(value: boolean): Promise<void>;
  reporter(value: ((issue: TechnicalIssue) => Promise<unknown>) | null): void;
}) {
  let enabled = false,
    queue: Promise<unknown> = Promise.resolve();
  const serial = <T>(work: () => Promise<T>): Promise<T> => {
    const next = queue.then(work);
    queue = next.catch(() => {});
    return next;
  };
  const applyReporter = () => {
    const bridge = deps.bridge();
    deps.reporter(
      enabled && bridge
        ? (issue) => bridge.recordTechnical(issue.category, issue.code)
        : null,
    );
  };
  const disable = async () => {
    enabled = false;
    deps.reporter(null);
    try {
      await deps.bridge()?.setEnabled(false);
    } catch {}
  };
  return {
    initialize: () =>
      serial(async () => {
        try {
          const bridge = deps.bridge();
          if (!bridge || !deps.release) {
            await disable();
            return;
          }
          const consent = await deps.readConsent();
          enabled = await bridge.setEnabled(consent);
          applyReporter();
        } catch {
          await disable();
        }
      }),
    state: async () => {
      await queue;
      return { supported: !!deps.bridge(), enabled, release: deps.release };
    },
    setEnabled: (value: boolean) =>
      serial(async () => {
        const bridge = deps.bridge();
        if (value && (!bridge || !deps.release))
          throw Error(
            "Crashlytics için üretim Android sürümü gerekli. Debug yapısında gönderim kapalıdır.",
          );
        try {
          const applied = bridge ? !!(await bridge.setEnabled(value)) : false;
          if (value && !applied)
            throw Error("Teknik hata raporlaması etkinleştirilemedi.");
          await deps.writeConsent(applied);
          enabled = applied;
          applyReporter();
        } catch (error) {
          await disable();
          try {
            await deps.writeConsent(false);
          } catch {}
          throw error;
        }
      }),
    check: () =>
      serial(async () => {
        const bridge = deps.bridge();
        if (!enabled || !bridge || !deps.release)
          throw Error(
            "Önce üretim Android uygulamasında teknik hata paylaşımını aç.",
          );
        if (!(await bridge.recordTechnical("self-test", "self-test")))
          throw Error("Deneme kaydı SDK'ya iletilemedi.");
      }),
  };
}
