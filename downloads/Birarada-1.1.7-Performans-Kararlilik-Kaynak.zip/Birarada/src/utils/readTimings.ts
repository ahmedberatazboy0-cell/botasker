// Bounded in-memory timings only: no URLs, IDs, tokens, messages or error text.
const operations = new Set([
  "documents:get",
  "documents:query",
  "documents:batch",
  "documents:commit",
  "listContent",
  "getContent",
  "profileStats",
  "storyFeed",
  "searchUsers",
  "sendMessage",
  "media",
]);
export type TimingRow = {
  operation: string;
  stage: string;
  milliseconds: number;
  status: "ok" | "error";
};
export function createReadTimings(now = () => Date.now()) {
  let generation = 0;
  const rows: TimingRow[] = [];
  return {
    start(
      operation: string,
      stage:
        | "auth-token"
        | "response-headers"
        | "response-json"
        | "image-load"
        | "image-display",
    ) {
      const at = now(),
        current = generation;
      let finished = false;
      return (status: "ok" | "error" = "ok") => {
        if (finished || current !== generation) return;
        finished = true;
        rows.push({
          operation: operations.has(operation) ? operation : "other",
          stage,
          milliseconds: Math.max(0, now() - at),
          status,
        });
        if (rows.length > 80) rows.splice(0, rows.length - 80);
      };
    },
    list: () => rows.map((row) => ({ ...row })),
    clear() {
      generation++;
      rows.length = 0;
    },
  };
}
export const readTimings = createReadTimings();
