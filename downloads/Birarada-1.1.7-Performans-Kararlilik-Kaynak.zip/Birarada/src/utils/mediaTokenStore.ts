type User = { uid: string; getIdToken(): Promise<string> };
// A single ref-counted Firebase subscription for mounted media. Tokens never leave memory.
export function createMediaTokenStore(deps: {
  currentUser(): User | null;
  subscribe(callback: () => void): () => void;
  schedule(callback: () => void): () => void;
}) {
  let value = "",
    generation = 0,
    stop: (() => void) | undefined,
    stopTimer: (() => void) | undefined;
  let pending: Promise<void> | undefined,
    owner: User | null = null;
  const listeners = new Set<() => void>();
  const publish = (token: string) => {
    if (value === token) return;
    value = token;
    listeners.forEach((callback) => callback());
  };
  const refresh = () => {
    const user = deps.currentUser(),
      request = ++generation;
    // Authentication changes must immediately remove the previous account's token.
    if (owner !== user) {
      owner = user;
      publish("");
    }
    pending = (async () => {
      try {
        const token = await user?.getIdToken();
        if (
          listeners.size &&
          generation === request &&
          deps.currentUser() === user
        )
          publish(token || "");
      } catch {
        if (generation === request) publish("");
      } finally {
        if (generation === request) pending = undefined;
      }
    })();
    return pending;
  };
  return {
    snapshot: () => value,
    refresh: () =>
      pending && owner === deps.currentUser() ? pending : refresh(),
    subscribe(callback: () => void) {
      listeners.add(callback);
      if (listeners.size === 1) {
        stop = deps.subscribe(() => {
          void refresh();
        });
        stopTimer = deps.schedule(() => {
          if (!pending) void refresh();
        });
      }
      return () => {
        listeners.delete(callback);
        if (!listeners.size) {
          ++generation;
          stop?.();
          stopTimer?.();
          stop = stopTimer = undefined;
          pending = undefined;
          owner = null;
          value = "";
        }
      };
    },
  };
}
