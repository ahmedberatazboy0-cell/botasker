export type TechnicalIssue = {
  category: "ui-render" | "unhandled-js" | "network" | "self-test";
  code:
    | "unavailable"
    | "deadline-exceeded"
    | "internal"
    | "unknown"
    | "self-test";
  fatal: boolean;
};
const codes = new Set([
  "unavailable",
  "deadline-exceeded",
  "internal",
  "self-test",
]);
export function safeIssue(
  category: TechnicalIssue["category"],
  error: unknown,
  fatal = false,
): TechnicalIssue {
  let code: string | undefined;
  try {
    code = (error as { code?: string } | null)?.code;
  } catch {}
  return {
    category,
    code: codes.has(code || "") ? (code as TechnicalIssue["code"]) : "unknown",
    fatal: !!fatal,
  };
}
const issues: TechnicalIssue[] = [];
let reporter: ((issue: TechnicalIssue) => Promise<unknown>) | null = null;
const recent = new Map<string, number>();
export function setIssueReporter(next: typeof reporter) {
  reporter = next;
}
export function recordTechnicalIssue(
  category: TechnicalIssue["category"],
  error?: unknown,
  fatal = false,
) {
  const issue = safeIssue(category, error, fatal),
    key = `${issue.category}:${issue.code}:${issue.fatal}`;
  if (Date.now() - (recent.get(key) || 0) < 30000) return;
  recent.set(key, Date.now());
  issues.push(issue);
  if (issues.length > 30) issues.shift();
  try {
    const sent = reporter?.(issue);
    if (sent) void Promise.resolve(sent).catch(() => {});
  } catch {}
}
export const recentTechnicalIssues = () =>
  issues.map((issue) => ({ ...issue }));
export function installTechnicalErrorHandler() {
  const utilities = (globalThis as any).ErrorUtils;
  if (!utilities?.getGlobalHandler || !utilities?.setGlobalHandler)
    return () => {};
  const previous = utilities.getGlobalHandler();
  const handler = (error: unknown, fatal?: boolean) => {
    try {
      recordTechnicalIssue("unhandled-js", error, !!fatal);
    } finally {
      previous?.(error, fatal);
    }
  };
  utilities.setGlobalHandler(handler);
  return () => {
    if (utilities.getGlobalHandler() === handler)
      utilities.setGlobalHandler(previous);
  };
}
