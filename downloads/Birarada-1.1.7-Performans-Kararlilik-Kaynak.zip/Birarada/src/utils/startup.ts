const STAGES = new Set([
  "root-registration",
  "firebase-initialized",
  "auth-listener-attached",
  "auth-state-known",
  "profile-ready",
  "first-app-layout",
  "first-shell-layout",
  "feed-data-ready",
  "first-content-image-displayed",
  "resume-js-frame",
]);
export function createStartupMeasurements(now = () => performance.now()) {
  let sequence = 0;
  const runs: {
    run: number;
    kind: "cold-js" | "resume-js";
    started: number;
    stages: Record<string, number>;
    spans: Record<string, number>;
  }[] = [];
  const begin = (kind: "cold-js" | "resume-js") => {
    runs.push({ run: ++sequence, kind, started: now(), stages: {}, spans: {} });
    if (runs.length > 5) runs.shift();
  };
  begin("cold-js");
  return {
    resume: () => begin("resume-js"),
    mark(stage: string) {
      const current = runs.at(-1)!;
      if (STAGES.has(stage) && current.stages[stage] === undefined)
        current.stages[stage] = Math.max(0, now() - current.started);
    },
    span(name: "firebase-initialization" | "js-branding-visible") {
      const run = runs.at(-1)!,
        at = now();
      let done = false;
      return () => {
        if (!done) {
          done = true;
          run.spans[name] = Math.max(0, now() - at);
        }
      };
    },
    list: () =>
      runs.map(({ started: _start, ...run }) => ({
        ...run,
        stages: { ...run.stages },
        spans: { ...run.spans },
      })),
  };
}
export const startup = createStartupMeasurements();
