// Browser has local sanitized observations only; no fake Crashlytics success.
export async function initializeDiagnostics() {}
export async function diagnosticsState() {
  return { supported: false, enabled: false, release: false };
}
export async function setDiagnosticsEnabled(_enabled: boolean) {
  throw Error(
    "Telefon hata raporlaması yalnız üretim Android yapısında kullanılabilir.",
  );
}
export async function sendDiagnosticsCheck() {
  throw Error("Bu yapıda Crashlytics bağlantısı yok.");
}
