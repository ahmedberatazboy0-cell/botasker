import { NativeModules, Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { setIssueReporter } from "../utils/technicalIssues";
import { createDiagnosticsController } from "../utils/diagnosticsController";
const KEY = "birarada:technical-diagnostics:consent:v1";
const controller = createDiagnosticsController({
  bridge: () =>
    Platform.OS === "android"
      ? NativeModules.BiraradaDiagnostics || null
      : null,
  release: !__DEV__,
  readConsent: async () => (await AsyncStorage.getItem(KEY)) === "yes",
  writeConsent: (value) => AsyncStorage.setItem(KEY, value ? "yes" : "no"),
  reporter: setIssueReporter,
});
export const initializeDiagnostics = controller.initialize;
export const diagnosticsState = controller.state;
export const setDiagnosticsEnabled = controller.setEnabled;
export const sendDiagnosticsCheck = controller.check;
