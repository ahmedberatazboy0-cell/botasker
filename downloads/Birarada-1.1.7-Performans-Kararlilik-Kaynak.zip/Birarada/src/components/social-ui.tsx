import React, { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  Text,
  View,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SafeAreaView } from "react-native-safe-area-context";
import { ProtectedImage } from "./ProtectedMedia";
import { colors as c } from "../constants/theme";
import { friendly } from "../utils/errors";
export type IconName = React.ComponentProps<typeof Ionicons>["name"];
export function Icon({
  name,
  size = 25,
  color = c.text,
}: {
  name: IconName;
  size?: number;
  color?: string;
}) {
  return <Ionicons name={name} size={size} color={color} accessible={false} />;
}
export function Action({
  name,
  label,
  onPress,
  color,
  size = 25,
  disabled = false,
  style,
}: {
  name: IconName;
  label: string;
  onPress: () => unknown | Promise<unknown>;
  color?: string;
  size?: number;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={label}
        accessibilityState={{ disabled: disabled || busy, busy }}
        disabled={disabled || busy}
        hitSlop={4}
        onPress={async () => {
          setBusy(true);
          setError("");
          try {
            await onPress();
          } catch (e) {
            setError(friendly(e));
          } finally {
            setBusy(false);
          }
        }}
        style={({ pressed }) => [
          {
            minWidth: 44,
            minHeight: 44,
            alignItems: "center",
            justifyContent: "center",
            opacity: disabled || busy ? 0.45 : pressed ? 0.55 : 1,
          },
          style,
        ]}
      >
        {busy ? (
          <ActivityIndicator size="small" color={color || c.text} />
        ) : (
          <Icon name={name} size={size} color={color} />
        )}
      </Pressable>
      {!!error && (
        <Text
          accessibilityRole="alert"
          style={{ fontSize: 12, color: c.danger, maxWidth: 220, padding: 4 }}
        >
          {error}
        </Text>
      )}
    </View>
  );
}
export function Avatar({
  name = "",
  mediaId,
  size = 42,
  ring = false,
  add = false,
}: {
  name?: string;
  mediaId?: string;
  size?: number;
  ring?: boolean;
  add?: boolean;
}) {
  const inner = size - (ring ? 8 : 0);
  return (
    <View
      style={{
        width: size,
        height: size,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: size / 2,
        ...(ring
          ? {
              borderWidth: 2,
              borderTopColor: "#d62976",
              borderRightColor: "#962fbf",
              borderBottomColor: "#fa7e1e",
              borderLeftColor: "#feda75",
            }
          : {}),
      }}
    >
      {mediaId ? (
        <ProtectedImage
          purpose="avatar"
          id={mediaId}
          label={`${name} profil fotoğrafı`}
          style={{ width: inner, height: inner, borderRadius: inner / 2 }}
        />
      ) : (
        <View
          style={{
            width: inner,
            height: inner,
            borderRadius: inner / 2,
            backgroundColor: "#f1efed",
            alignItems: "center",
            justifyContent: "center",
            overflow: "hidden",
          }}
        >
          {name ? (
            <Text
              style={{
                fontWeight: "600",
                color: "#6f6b68",
                fontSize: inner * 0.36,
              }}
            >
              {name.slice(0, 2).toLocaleUpperCase("tr-TR")}
            </Text>
          ) : (
            <Icon name="person" size={inner * 0.62} color="#c2c0bd" />
          )}
        </View>
      )}
      {add && (
        <View
          style={{
            position: "absolute",
            bottom: -1,
            right: -1,
            width: 23,
            height: 23,
            borderWidth: 2,
            borderColor: c.bg,
            borderRadius: 12,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: c.accent,
          }}
        >
          <Icon name="add" size={17} color="#fff" />
        </View>
      )}
    </View>
  );
}
export function TopBar({
  title,
  right,
  left,
  brand = false,
}: {
  title: string;
  right?: React.ReactNode;
  left?: React.ReactNode;
  brand?: boolean;
}) {
  return (
    <View
      style={{
        height: 58,
        paddingHorizontal: 12,
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottomWidth: 0.5,
        borderBottomColor: c.line,
        backgroundColor: c.bg,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          flex: 1,
          minWidth: 0,
        }}
      >
        {left}
        <Text
          numberOfLines={1}
          style={{
            color: c.text,
            fontSize: brand ? 30 : 21,
            fontWeight: "700",
            letterSpacing: brand ? -1.3 : -0.4,
            fontFamily: brand && Platform.OS === "ios" ? "Georgia" : undefined,
          }}
        >
          {title}
        </Text>
      </View>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 2 }}>
        {right}
      </View>
    </View>
  );
}
export function Sheet({
  visible,
  onClose,
  title,
  children,
}: {
  visible: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
}) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      <View
        style={{
          flex: 1,
          justifyContent: "flex-end",
          backgroundColor: "#00000065",
        }}
      >
        <Pressable
          style={{ flex: 1 }}
          onPress={onClose}
          accessibilityRole="button"
          accessibilityLabel="Pencereyi kapat"
        />
        <SafeAreaView
          edges={["bottom"]}
          style={{
            backgroundColor: c.bg,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            maxHeight: "85%",
            paddingHorizontal: 16,
          }}
        >
          <View
            style={{
              width: 36,
              height: 4,
              backgroundColor: "#c7c7c7",
              borderRadius: 4,
              alignSelf: "center",
              marginTop: 10,
              marginBottom: 8,
            }}
          />
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingBottom: 8,
            }}
          >
            <Text style={{ color: c.text, fontSize: 17, fontWeight: "700" }}>
              {title}
            </Text>
            <Action name="close" label="Kapat" onPress={onClose} />
          </View>
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={{ gap: 8, paddingBottom: 24 }}
          >
            {children}
          </ScrollView>
        </SafeAreaView>
      </View>
    </Modal>
  );
}
export function MenuRow({
  title,
  icon,
  onPress,
  danger = false,
  detail,
}: {
  title: string;
  icon: IconName;
  onPress: () => unknown | Promise<unknown>;
  danger?: boolean;
  detail?: string;
}) {
  const [error, setError] = useState("");
  return (
    <View>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={title}
        style={{
          flexDirection: "row",
          alignItems: "center",
          minHeight: 52,
          gap: 14,
          paddingHorizontal: 8,
        }}
        onPress={async () => {
          try {
            setError("");
            await onPress();
          } catch (e) {
            setError(friendly(e));
          }
        }}
      >
        <Icon name={icon} size={23} color={danger ? c.danger : c.text} />
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 15, color: danger ? c.danger : c.text }}>
            {title}
          </Text>
          {detail && (
            <Text style={{ fontSize: 12, color: c.muted, marginTop: 3 }}>
              {detail}
            </Text>
          )}
        </View>
        <Icon name="chevron-forward" color={c.muted} size={17} />
      </Pressable>
      {!!error && (
        <Text accessibilityRole="alert" style={{ color: c.danger }}>
          {error}
        </Text>
      )}
    </View>
  );
}
export function Segments({
  items,
  value,
  onChange,
}: {
  items: { value: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <View
      style={{
        flexDirection: "row",
        borderBottomWidth: 0.5,
        borderBottomColor: c.line,
      }}
    >
      {items.map((item) => (
        <Pressable
          key={item.value}
          accessibilityRole="tab"
          accessibilityLabel={item.label}
          accessibilityState={{ selected: value === item.value }}
          onPress={() => onChange(item.value)}
          style={{
            flex: 1,
            minHeight: 44,
            alignItems: "center",
            justifyContent: "center",
            borderBottomWidth: value === item.value ? 1.5 : 0,
            borderBottomColor: c.text,
          }}
        >
          <Text
            style={{
              color: value === item.value ? c.text : c.muted,
              fontWeight: value === item.value ? "700" : "500",
              fontSize: 14,
            }}
          >
            {item.label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
