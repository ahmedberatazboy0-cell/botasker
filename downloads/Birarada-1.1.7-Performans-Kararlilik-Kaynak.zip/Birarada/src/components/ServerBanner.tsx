import React, { useCallback, useState } from "react";
import { useFocusEffect } from "@react-navigation/native";
import { View } from "react-native";
import { api } from "../services/api";
import { Label, styles } from "./ui";
export function ServerBanner() {
  const [message, setMessage] = useState("");
  useFocusEffect(
    useCallback(() => {
      let alive = true;
      api("appConfig", {}, { maxAgeMs: 5000 })
        .then((r) => {
          if (alive)
            setMessage(
              r.maintenance
                ? "Bakım sürüyor. Biraz sonra yeniden dene."
                : r.announcement || "",
            );
        })
        .catch(() => {});
      return () => {
        alive = false;
      };
    }, []),
  );
  return message ? (
    <View style={styles.card}>
      <Label>{message}</Label>
    </View>
  ) : null;
}
