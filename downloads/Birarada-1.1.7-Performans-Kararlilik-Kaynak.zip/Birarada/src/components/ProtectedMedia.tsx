import React, { useEffect, useMemo, useState, useRef } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  Text,
  StyleSheet,
  type StyleProp,
  View,
  type ViewStyle,
} from "react-native";
import { Image } from "expo-image";
import { useVideoPlayer, VideoView } from "expo-video";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { auth } from "../firebase/client";
import { mediaEndpoint, type MediaItem } from "../services/api";
import { Button, Label } from "./ui";
import { readTimings } from "../utils/readTimings";
import { useIsFocused } from "@react-navigation/native";
import { useForeground } from "../hooks/useForeground";
import { startup } from "../utils/startup";
import { recordTechnicalIssue } from "../utils/technicalIssues";
import {
  useMediaToken as useToken,
  refreshMediaToken,
} from "../hooks/useMediaToken";
export function ProtectedImage({
  id,
  label,
  style,
  purpose = "content",
}: {
  id: string;
  label?: string;
  style: StyleProp<ViewStyle>;
  purpose?: "avatar" | "content";
}) {
  const uid = auth.currentUser?.uid || "";
  const [attempt, setAttempt] = useState(0);
  return (
    <ImageAttempt
      key={`${uid}:${id}:${attempt}`}
      id={id}
      label={label}
      style={style}
      purpose={purpose}
      retry={() => {
        void refreshMediaToken();
        setAttempt((a) => a + 1);
      }}
    />
  );
}
function ImageAttempt({
  id,
  label,
  style,
  retry,
  purpose,
}: {
  id: string;
  label?: string;
  style: StyleProp<ViewStyle>;
  retry: () => void;
  purpose: "avatar" | "content";
}) {
  const token = useToken(),
    [phase, setPhase] = useState<"loading" | "loaded" | "error">("loading"),
    [slow, setSlow] = useState(false);
  const alive = useRef(true),
    phaseRef = useRef(phase);
  phaseRef.current = phase;
  const finishLoad = useRef<ReturnType<typeof readTimings.start> | null>(null),
    finishDisplay = useRef<ReturnType<typeof readTimings.start> | null>(null);
  const source = useMemo(
    () => ({
      uri: mediaEndpoint("mediaContent", id),
      headers: { Authorization: `Bearer ${token}` },
    }),
    [id, token],
  );
  const frame = StyleSheet.flatten(style) || {},
    compact = typeof frame.width === "number" && frame.width < 80;
  useEffect(() => {
    alive.current = true;
    const slowTimer = setTimeout(() => {
      if (alive.current && phaseRef.current === "loading") setSlow(true);
    }, 5000);
    const deadline = setTimeout(() => {
      if (alive.current && phaseRef.current === "loading") {
        finishLoad.current?.("error");
        finishDisplay.current?.("error");
        phaseRef.current = "error";
        setPhase("error");
      }
    }, 25000);
    return () => {
      alive.current = false;
      clearTimeout(slowTimer);
      clearTimeout(deadline);
    };
  }, []);
  useEffect(() => {
    if (!token) return;
    finishLoad.current = readTimings.start("media", "image-load");
    finishDisplay.current = readTimings.start("media", "image-display");
  }, [token]);
  return (
    <View testID={`image-frame-${id}`} style={[style, { overflow: "hidden" }]}>
      {!!token && phase !== "error" && (
        <Image
          source={source}
          accessibilityLabel={label || "Paylaşılan fotoğraf"}
          cachePolicy="none"
          contentFit="cover"
          style={{ width: "100%", height: "100%" }}
          onLoad={() => {
            if (alive.current) finishLoad.current?.();
          }}
          onDisplay={() => {
            if (alive.current && phaseRef.current !== "error") {
              if (purpose === "content")
                startup.mark("first-content-image-displayed");
              finishDisplay.current?.();
              phaseRef.current = "loaded";
              setPhase("loaded");
            }
          }}
          onError={() => {
            if (alive.current) {
              finishLoad.current?.("error");
              finishDisplay.current?.("error");
              phaseRef.current = "error";
              setPhase("error");
            }
          }}
        />
      )}
      {phase === "loading" && (
        <View
          testID={`image-loading-${id}`}
          pointerEvents="none"
          style={{
            ...StyleSheet.absoluteFillObject,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#f5f5f5",
            padding: compact ? 0 : 8,
            gap: 6,
          }}
        >
          <ActivityIndicator
            accessibilityLabel="Fotoğraf yükleniyor"
            color="#0095f6"
          />
          {slow && !compact && (
            <Text
              style={{ textAlign: "center", color: "#737373", fontSize: 11 }}
            >
              Bağlantı yavaş, fotoğraf yükleniyor…
            </Text>
          )}
        </View>
      )}
      {phase === "error" && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Fotoğrafı yeniden yükle"
          onPress={retry}
          testID={`image-retry-${id}`}
          style={{
            ...StyleSheet.absoluteFillObject,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "#f5f5f5",
            padding: compact ? 0 : 8,
            gap: 6,
          }}
        >
          <Text
            style={{
              color: "#737373",
              fontSize: compact ? 20 : 12,
              textAlign: "center",
            }}
          >
            {compact ? "↻" : "Fotoğraf yüklenemedi."}
          </Text>
          {!compact && (
            <Text style={{ color: "#0095f6", fontSize: 12 }}>Yeniden dene</Text>
          )}
        </Pressable>
      )}
    </View>
  );
}
function Audio({
  uri,
  id,
  token,
  style,
}: {
  id: string;
  uri?: string;
  token: string;
  style: StyleProp<ViewStyle>;
}) {
  const source = useMemo(
    () => ({
      uri: uri || mediaEndpoint("mediaContent", id),
      ...(uri ? {} : { headers: { Authorization: `Bearer ${token}` } }),
    }),
    [id, token, uri],
  );
  const player = useAudioPlayer(source),
    status = useAudioPlayerStatus(player);
  const focused = useIsFocused(),
    foreground = useForeground();
  useEffect(() => {
    if (!focused || !foreground) player.pause();
  }, [focused, foreground, player]);
  return (
    <View style={style}>
      <Button
        secondary
        title={status.playing ? "Sesi duraklat" : "Sesli mesajı dinle"}
        onPress={() => {
          if (status.playing) player.pause();
          else {
            if (status.didJustFinish) void player.seekTo(0);
            player.play();
          }
        }}
      />
      <Label muted>
        {Math.floor(status.currentTime || 0)} /{" "}
        {Math.floor(status.duration || 0)} sn
      </Label>
    </View>
  );
}
function Player(props: {
  id: string;
  uri?: string;
  token: string;
  active: boolean;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
}) {
  const [attempt, setAttempt] = useState(0);
  return (
    <PlayerAttempt
      key={`${props.id}:${attempt}`}
      {...props}
      retry={() => setAttempt((value) => value + 1)}
    />
  );
}
function PlayerAttempt({
  uri,
  id,
  token,
  active,
  style,
  loop,
  onEnd,
  retry,
}: {
  id: string;
  uri?: string;
  token: string;
  active: boolean;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
  retry: () => void;
}) {
  const [failed, setFailed] = useState(false);
  const source = useMemo(
    () => ({
      uri: uri || mediaEndpoint("mediaContent", id),
      ...(uri ? {} : { headers: { Authorization: `Bearer ${token}` } }),
      contentType: "progressive" as const,
      useCaching: false,
    }),
    [id, token, uri],
  );
  const player = useVideoPlayer(source, (p) => {
    p.loop = loop;
    p.muted = true;
    p.bufferOptions = {
      preferredForwardBufferDuration: 3,
      minBufferForPlayback: 0.5,
      maxBufferBytes: 2 * 1024 * 1024,
    };
  });
  const focused = useIsFocused(),
    foreground = useForeground();
  useEffect(() => {
    try {
      if (active && focused && foreground && !failed) player.play();
      else player.pause();
    } catch {
      setFailed(true);
    }
  }, [player, active, focused, foreground, failed]);
  useEffect(() => {
    if (!onEnd) return;
    const subscription = player.addListener("playToEnd", onEnd);
    return () => subscription.remove();
  }, [player, onEnd]);
  useEffect(() => {
    const listener = player.addListener("statusChange", ({ status }) => {
      if (status === "error") {
        setFailed(true);
        recordTechnicalIssue("network", { code: "unavailable" });
      }
    });
    return () => listener.remove();
  }, [player]);
  if (failed)
    return (
      <View
        style={[
          style,
          { justifyContent: "center", padding: 12, backgroundColor: "#f5f5f5" },
        ]}
      >
        <Label>Video şu an yüklenemedi.</Label>
        <Button secondary title="Videoyu yeniden yükle" onPress={retry} />
      </View>
    );
  return (
    <VideoView
      player={player}
      style={style}
      nativeControls
      contentFit="contain"
      allowsPictureInPicture={false}
    />
  );
}
// HTML media elements cannot set Authorization headers. Fetch private bytes first;
// object URLs stay in this component and are revoked on stop/unmount/session change.
function WebPrivateMedia({
  item,
  token,
  active,
  style,
  loop,
  onEnd,
}: {
  item: MediaItem;
  token: string;
  active: boolean;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
}) {
  const [requested, setRequested] = useState(false),
    [uri, setUri] = useState(""),
    [error, setError] = useState(""),
    [attempt, setAttempt] = useState(0);
  const enabled = requested || active;
  useEffect(() => {
    setUri("");
    setError("");
    if (!enabled) return;
    let alive = true,
      objectUrl = "";
    const controller = new AbortController(),
      timer = setTimeout(() => controller.abort(), 90000);
    void (async () => {
      try {
        const response = await fetch(mediaEndpoint("mediaContent", item.id), {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
          signal: controller.signal,
        });
        if (!response.ok) {
          throw Error(
            "Medya şu an açılamıyor. Erişim iznini veya bağlantını kontrol et.",
          );
        }
        const blob = await response.blob();
        if (blob.size > 20 * 1024 ** 2) {
          throw Error("Medya boyutu desteklenmiyor.");
        }
        if (alive) {
          objectUrl = URL.createObjectURL(blob);
          setUri(objectUrl);
        }
      } catch (e) {
        if (alive) {
          setError(e instanceof Error ? e.message : "Medya açılamadı.");
        }
      } finally {
        clearTimeout(timer);
      }
    })();
    return () => {
      alive = false;
      clearTimeout(timer);
      controller.abort();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [item.id, token, enabled, attempt]);
  if (!enabled) {
    return (
      <View style={style}>
        <Button
          secondary
          title={item.kind === "audio" ? "Sesli mesajı yükle" : "Videoyu yükle"}
          onPress={() => setRequested(true)}
        />
      </View>
    );
  }
  if (error) {
    return (
      <View style={style}>
        <Label>{error}</Label>
        <Button
          secondary
          title="Yeniden dene"
          onPress={() => setAttempt((value) => value + 1)}
        />
      </View>
    );
  }
  if (!uri) {
    return (
      <View style={style}>
        <ActivityIndicator />
      </View>
    );
  }
  return item.kind === "audio" ? (
    <Audio id={item.id} token={token} uri={uri} style={style} />
  ) : (
    <Player
      id={item.id}
      token={token}
      uri={uri}
      active={active}
      style={style}
      loop={loop}
      onEnd={onEnd}
    />
  );
}
export function ProtectedMedia({
  item,
  active = false,
  style,
  loop = true,
  onEnd,
  deferLoading = false,
  preload = false,
  tapToLoad = false,
}: {
  item: MediaItem;
  active?: boolean;
  style?: StyleProp<ViewStyle>;
  loop?: boolean;
  onEnd?: () => void;
  deferLoading?: boolean;
  preload?: boolean;
  tapToLoad?: boolean;
}) {
  const frame = style || {
    width: "100%" as const,
    aspectRatio: item.kind === "audio" ? 4 : 1,
    backgroundColor: "#17191d",
    borderRadius: 14,
  };
  if (item.kind === "image")
    return <ProtectedImage id={item.id} style={frame} />;
  if (deferLoading && !active && !preload) return <View style={frame} />;
  if (Platform.OS !== "web" && tapToLoad)
    return (
      <NativeTapMedia item={item} style={frame} loop={loop} onEnd={onEnd} />
    );
  return (
    <AuthorizedPlayer
      item={item}
      active={active}
      style={frame}
      loop={loop}
      onEnd={onEnd}
    />
  );
}
function NativeTapMedia({
  item,
  style,
  loop,
  onEnd,
}: {
  item: MediaItem;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
}) {
  const [requested, setRequested] = useState(false),
    focused = useIsFocused(),
    foreground = useForeground();
  useEffect(() => {
    if (!focused || !foreground) setRequested(false);
  }, [focused, foreground]);
  if (!requested || !focused || !foreground)
    return (
      <View style={style}>
        <Button
          secondary
          title={item.kind === "audio" ? "Sesli mesajı yükle" : "Videoyu yükle"}
          onPress={() => setRequested(true)}
        />
      </View>
    );
  return (
    <AuthorizedPlayer
      item={item}
      active
      style={style}
      loop={loop}
      onEnd={onEnd}
    />
  );
}
function AuthorizedPlayer({
  item,
  active,
  style: frame,
  loop,
  onEnd,
}: {
  item: MediaItem;
  active: boolean;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
}) {
  const token = useToken();
  const [tokenError, setTokenError] = useState(false),
    [tokenAttempt, setTokenAttempt] = useState(0);
  useEffect(() => {
    setTokenError(false);
    if (token) return;
    const timer = setTimeout(() => setTokenError(true), 15000);
    return () => clearTimeout(timer);
  }, [token, tokenAttempt]);
  if (!token) {
    return (
      <View style={frame}>
        {tokenError ? (
          <>
            <Label>Medya oturumu şu an doğrulanamadı.</Label>
            <Button
              secondary
              title="Medya bağlantısını yeniden dene"
              onPress={() => {
                setTokenAttempt((a) => a + 1);
                void refreshMediaToken();
              }}
            />
          </>
        ) : (
          <ActivityIndicator />
        )}
      </View>
    );
  }
  if (Platform.OS === "web") {
    return (
      <WebPrivateMedia
        item={item}
        token={token}
        active={active}
        style={frame}
        loop={loop}
        onEnd={onEnd}
      />
    );
  }
  if (item.kind === "audio") {
    return <Audio id={item.id} token={token} style={frame} />;
  }
  return (
    <Player
      id={item.id}
      token={token}
      active={active}
      style={frame}
      loop={loop}
      onEnd={onEnd}
    />
  );
}
