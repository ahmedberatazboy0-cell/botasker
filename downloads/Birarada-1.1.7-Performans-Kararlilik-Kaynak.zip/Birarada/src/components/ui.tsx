import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Keyboard,
  Platform,
  ScrollView,
  Linking,
} from "react-native";
import { releaseLinks } from "../constants/release";
import {
  HeaderShownContext,
  HeaderHeightContext,
} from "@react-navigation/elements";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors as c } from "../constants/theme";
import { friendly } from "../utils/errors";
import { useSession } from "../store/session";
export const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: c.bg },
  pad: { padding: 16, gap: 14 },
  title: {
    fontSize: 23,
    fontWeight: "700",
    color: c.text,
    letterSpacing: -0.6,
  },
  text: { color: c.text, fontSize: 15, lineHeight: 22 },
  muted: { color: c.muted, fontSize: 13, lineHeight: 20 },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  card: {
    backgroundColor: c.bg,
    borderWidth: 1,
    borderColor: c.line,
    borderRadius: 12,
    padding: 14,
    gap: 10,
  },
  input: {
    backgroundColor: c.surface,
    color: c.text,
    borderWidth: 1,
    borderColor: c.line,
    borderRadius: 8,
    padding: 12,
    fontSize: 15,
  },
  button: {
    backgroundColor: c.accent,
    paddingVertical: 11,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignItems: "center",
  },
  buttonText: { color: "#ffffff", fontWeight: "700", fontSize: 14 },
  error: { color: c.danger, lineHeight: 21 },
  divider: { height: 1, backgroundColor: c.line },
});
export function Label({
  children,
  muted = false,
}: {
  children: React.ReactNode;
  muted?: boolean;
}) {
  return <Text style={muted ? styles.muted : styles.text}>{children}</Text>;
}
export function Field(props: React.ComponentProps<typeof TextInput>) {
  return (
    <TextInput
      placeholderTextColor={c.muted}
      autoCapitalize="none"
      {...props}
      accessibilityLabel={props.accessibilityLabel || props.placeholder}
      style={[styles.input, props.style]}
    />
  );
}
export function Button({
  title,
  onPress,
  disabled = false,
  secondary = false,
}: {
  title: string;
  onPress: () => void | Promise<unknown>;
  disabled?: boolean;
  secondary?: boolean;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <View style={{ gap: 6 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: disabled || busy, busy }}
        disabled={disabled || busy}
        onPress={async () => {
          setBusy(true);
          setError("");
          try {
            await onPress();
          } catch (e) {
            setError(friendly(e));
          } finally {
            setBusy(false);
          }
        }}
        style={[
          styles.button,
          secondary && {
            backgroundColor: "#efefef",
            borderWidth: 1,
            borderColor: c.line,
          },
          (disabled || busy) && { opacity: 0.45 },
        ]}
      >
        {busy ? (
          <ActivityIndicator color={c.text} />
        ) : (
          <Text style={[styles.buttonText, secondary && { color: c.text }]}>
            {title}
          </Text>
        )}
      </Pressable>
      {!!error && (
        <Text
          accessibilityRole="alert"
          accessibilityLiveRegion="polite"
          style={styles.error}
        >
          {error}
        </Text>
      )}
    </View>
  );
}

export function LegalLinks({
  includeDeletion = false,
}: {
  includeDeletion?: boolean;
}) {
  const links = [
    { title: "Gizlilik politikası", value: releaseLinks.privacyPolicy },
    { title: "Kullanım koşulları", value: releaseLinks.terms },
    { title: "Destek", value: releaseLinks.support },
    ...(includeDeletion
      ? [
          {
            title: "Hesap ve veri silme bilgileri",
            value: releaseLinks.accountDeletion,
          },
        ]
      : []),
  ].filter(
    (item) =>
      typeof item.value === "string" &&
      (/^https:\/\//.test(item.value) ||
        (item.title === "Destek" &&
          /^mailto:[^\s@]+@[^\s@]+\.[^\s@]+$/.test(item.value))),
  );
  const [error, setError] = useState("");
  return (
    <View style={{ gap: 6 }}>
      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 14,
          justifyContent: "center",
        }}
      >
        {links.map((item) => (
          <Pressable
            key={item.title}
            accessibilityRole="button"
            accessibilityLabel={item.title}
            onPress={async () => {
              try {
                setError("");
                await Linking.openURL(item.value);
              } catch (e) {
                setError(friendly(e));
              }
            }}
            style={{ paddingVertical: 8 }}
          >
            <Text style={{ color: c.muted, fontSize: 12 }}>{item.title}</Text>
          </Pressable>
        ))}
      </View>
      {!!error && (
        <Text accessibilityRole="alert" style={styles.error}>
          {error}
        </Text>
      )}
    </View>
  );
}

export function CommunityAgreement({
  value,
  onChange,
}: {
  value: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <View style={[styles.card, { gap: 12 }]}>
      <Text style={[styles.text, { fontWeight: "700" }]}>
        Birarada topluluk kuralları
      </Text>
      <Label muted>
        Taciz, nefret söylemi, tehdit, cinsel istismar, yasa dışı içerik,
        kişisel bilgileri izinsiz paylaşma ve spam yasaktır. Yalnızca paylaşma
        hakkına sahip olduğun içerikleri yayınla. Uygunsuz içerikleri şikâyet
        edebilir, hesapları engelleyebilirsin. İhlal eden içerikler
        kaldırılabilir ve hesaplar kapatılabilir.
      </Label>
      <LegalLinks />
      <Pressable
        accessibilityRole="checkbox"
        accessibilityState={{ checked: value }}
        aria-checked={value}
        accessibilityLabel="Kullanım koşullarını ve topluluk kurallarını kabul ediyorum, gizlilik politikasını okudum"
        onPress={() => onChange(!value)}
        style={[styles.row, { alignItems: "flex-start", paddingVertical: 10 }]}
      >
        <Text style={{ color: "#ff925c", fontSize: 24 }}>
          {value ? "☑" : "☐"}
        </Text>
        <Text style={[styles.text, { flex: 1 }]}>
          Kullanım koşullarını ve topluluk kurallarını kabul ediyorum, gizlilik
          politikasını okudum.
        </Text>
      </Pressable>
    </View>
  );
}

export function ReportForm({
  onSubmit,
  onCancel,
}: {
  onSubmit: (reason: string) => Promise<unknown>;
  onCancel: () => void;
}) {
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");
  const [sent, setSent] = useState(false);
  return (
    <View style={styles.card}>
      <Text style={[styles.text, { fontWeight: "700" }]}>
        {sent ? "Şikâyetin iletildi" : "Şikâyet nedeni"}
      </Text>
      {sent ? (
        <Label muted>
          İnceleme için kaydedildi. Bu hesabı engelleyerek içeriklerini
          gizleyebilirsin.
        </Label>
      ) : (
        <>
          {[
            "Taciz veya tehdit",
            "Nefret söylemi",
            "Cinsel içerik veya çocuk güvenliği",
            "Şiddet veya yasa dışı içerik",
            "Spam veya dolandırıcılık",
            "Diğer",
          ].map((item) => (
            <Pressable
              key={item}
              accessibilityRole="radio"
              accessibilityState={{ checked: reason === item }}
              accessibilityLabel={item}
              onPress={() => setReason(item)}
              style={[styles.row, { paddingVertical: 6 }]}
            >
              <Text style={{ color: "#ff925c", fontSize: 20 }}>
                {reason === item ? "◉" : "○"}
              </Text>
              <Text style={[styles.text, { flex: 1 }]}>{item}</Text>
            </Pressable>
          ))}
          <Field
            placeholder="Ek açıklama (isteğe bağlı)"
            multiline
            maxLength={400}
            value={details}
            onChangeText={setDetails}
          />
          <Label muted>
            Şikâyetine şifre veya başka hassas bilgiler ekleme.
          </Label>
          <Button
            title="Şikâyeti gönder"
            disabled={!reason}
            onPress={async () => {
              await onSubmit(
                `${reason}${details.trim() ? `: ${details.trim()}` : ""}`,
              );
              setSent(true);
            }}
          />
        </>
      )}
      <Button secondary title={sent ? "Kapat" : "Vazgeç"} onPress={onCancel} />
    </View>
  );
}

export function DeleteAccountForm({
  onDelete,
  onCancel,
  cancelTitle = "Vazgeç",
}: {
  onDelete: (password: string) => Promise<void>;
  onCancel: () => void;
  cancelTitle?: string;
}) {
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const requiresPassword =
    useSession((state) => state.user)?.providerData.some(
      (provider) => provider.providerId === "password",
    ) ?? true;
  return (
    <View style={styles.card}>
      <Text style={[styles.text, { color: c.danger, fontWeight: "700" }]}>
        Hesabını kalıcı olarak sil
      </Text>
      <Label>
        Bu işlem geri alınamaz. Hesabın, profilin, gönderilerin ve sana ait
        içerikler silinir. Diğer kişilerin sohbet içerikleri kalabilir.
      </Label>
      <Label muted>
        Güvenliğin için {requiresPassword ? "mevcut şifreni gir ve " : ""}onay
        alanına SİL yaz. İşlem tamamlanana kadar uygulamayı açık tut. İşlem
        yarıda kalırsa tekrar deneyebilirsin.
      </Label>
      {requiresPassword ? (
        <Field
          placeholder="Mevcut şifren"
          secureTextEntry
          autoComplete="current-password"
          value={password}
          onChangeText={setPassword}
        />
      ) : (
        <Label muted>
          Silmeden önce Google hesabını açılan pencerede yeniden doğrulaman
          gerekir.
        </Label>
      )}
      <Field
        placeholder="Onaylamak için SİL yaz"
        value={confirmation}
        onChangeText={setConfirmation}
        autoCapitalize="characters"
      />
      <Button
        title="Hesabımı ve verilerimi kalıcı sil"
        disabled={
          (requiresPassword && !password) ||
          confirmation.trim().toLocaleUpperCase("tr-TR").replace("İ", "I") !==
            "SIL"
        }
        onPress={() => onDelete(password)}
      />
      <Button secondary title={cancelTitle} onPress={onCancel} />
    </View>
  );
}
export function Page({
  children,
  title,
  scroll = true,
  safeBottom = false,
  keyboardAware = false,
}: {
  children: React.ReactNode;
  title?: string;
  scroll?: boolean;
  safeBottom?: boolean;
  keyboardAware?: boolean;
}) {
  const headerShown = React.useContext(HeaderShownContext);
  const headerHeight = React.useContext(HeaderHeightContext) || 0;
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  React.useEffect(() => {
    if (!safeBottom && !keyboardAware) return;
    const shown = Keyboard.addListener("keyboardDidShow", () =>
      setKeyboardVisible(true),
    );
    const hidden = Keyboard.addListener("keyboardDidHide", () =>
      setKeyboardVisible(false),
    );
    return () => {
      shown.remove();
      hidden.remove();
    };
  }, [safeBottom, keyboardAware]);
  return (
    <SafeAreaView
      edges={[
        ...(headerShown ? [] : ["top" as const]),
        "left",
        "right",
        ...(safeBottom && !keyboardVisible ? ["bottom" as const] : []),
      ]}
      style={[
        styles.page,
        Platform.OS === "web" && {
          width: "100%",
          maxWidth: 680,
          alignSelf: "center",
        },
      ]}
    >
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={
          Platform.OS === "ios"
            ? "padding"
            : Platform.OS === "android" && keyboardAware
              ? "height"
              : undefined
        }
        keyboardVerticalOffset={headerShown ? headerHeight : 0}
      >
        {scroll ? (
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.pad}
          >
            {title && <Text style={styles.title}>{title}</Text>}
            {children}
          </ScrollView>
        ) : (
          <View style={{ flex: 1 }}>
            {title && (
              <Text style={[styles.title, { padding: 22 }]}>{title}</Text>
            )}
            {children}
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
export function State({
  loading,
  error,
  empty,
  retry,
}: {
  loading?: boolean;
  error?: string;
  empty?: boolean;
  retry: () => void;
}) {
  if (!loading && !error && !empty) return null;
  return (
    <View style={{ padding: 20, gap: 12 }}>
      {loading ? (
        <>
          <View
            style={{
              height: 20,
              width: "45%",
              backgroundColor: c.surface,
              borderRadius: 10,
            }}
          />
          <View
            style={{
              height: 160,
              backgroundColor: c.surface,
              borderRadius: 20,
            }}
          />
          <ActivityIndicator color={c.accent} />
        </>
      ) : error ? (
        <>
          <Text style={styles.error}>{error}</Text>
          <Button title="Tekrar dene" onPress={retry} />
        </>
      ) : empty ? (
        <Label muted>Burada henüz bir şey yok. İlk adımı sen at.</Label>
      ) : null}
    </View>
  );
}
