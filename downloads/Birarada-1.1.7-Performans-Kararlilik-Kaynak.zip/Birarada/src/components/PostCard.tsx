import React, { memo, useRef, useState } from "react";
import {
  View,
  Text,
  Pressable,
  Share,
  ScrollView,
  useWindowDimensions,
} from "react-native";
import { Image } from "expo-image";
import {
  collection,
  doc,
  query,
  orderBy,
  limit,
  onSnapshot,
} from "../database/client";
import { db } from "../firebase/client";
import { api } from "../services/api";
import { friendly } from "../utils/errors";
import { useRows } from "../hooks/useRows";
import { usePerson } from "../hooks/usePerson";
import { useSession } from "../store/session";
import {
  toggleLike,
  toggleSaved,
  comment,
  report,
  deleteOwnPost,
} from "../services/social";
import { Button, Label, Field, State, ReportForm, styles } from "./ui";
import { Action, Avatar, MenuRow, Sheet } from "./social-ui";
import { colors as c } from "../constants/theme";
import { timeAgo } from "../utils/time";
import type { Post } from "../types";
import { ProtectedMedia } from "./ProtectedMedia";
export const PostCard = memo(function PostCard({
  post,
  openProfile,
  blockedUids,
  hideMedia = false,
  commentsOnly = false,
  onCommentsClose,
}: {
  post: Post;
  openProfile: (id: string) => void;
  blockedUids?: ReadonlySet<string>;
  hideMedia?: boolean;
  commentsOnly?: boolean;
  onCommentsClose?: () => void;
}) {
  const window = useWindowDimensions(),
    profile = useSession((s) => s.profile)!,
    author = usePerson(post.uid);
  const [width, setWidth] = useState(Math.min(window.width, 680)),
    [page, setPage] = useState(0);
  const [comments, setComments] = useState(commentsOnly),
    [text, setText] = useState(""),
    [menu, setMenu] = useState(false),
    [reporting, setReporting] = useState(false),
    [saved, setSaved] = useState(false),
    [confirm, setConfirm] = useState(false),
    [confirmPublic, setConfirmPublic] = useState(false),
    [madePublic, setMadePublic] = useState(false),
    [error, setError] = useState("");
  const [commentReport, setCommentReport] = useState<{
    uid: string;
    id: string;
  } | null>(null);
  const lastTap = useRef(0),
    likeBusy = useRef(false),
    [optimisticLike, setOptimisticLike] = useState<boolean | null>(null);
  React.useEffect(
    () =>
      onSnapshot(
        doc(db, "saved", profile.uid, "posts", post.id),
        (s) => setSaved(s.exists()),
        (e) => setError(friendly(e)),
      ),
    [profile.uid, post.id],
  );
  const likes = useRows(
    query(collection(db, "posts", post.id, "likes"), limit(500)),
  );
  const replies = useRows(
    comments
      ? query(
          collection(db, "posts", post.id, "comments"),
          orderBy("createdAt", "asc"),
          limit(50),
        )
      : null,
  );
  const serverLiked = likes.rows.some((r) => r.id === profile.uid),
    liked = optimisticLike ?? serverLiked;
  React.useEffect(() => {
    setOptimisticLike(null);
  }, [serverLiked]);
  async function like() {
    if (likeBusy.current) return;
    likeBusy.current = true;
    setOptimisticLike(!liked);
    try {
      await toggleLike(post);
    } catch (e) {
      setOptimisticLike(null);
      throw e;
    } finally {
      likeBusy.current = false;
    }
  }
  const count =
    likes.rows.length +
    (optimisticLike === null
      ? 0
      : Number(optimisticLike) - Number(serverLiked));
  return (
    <View
      testID={`post-${post.id}`}
      onLayout={(e) => setWidth(Math.round(e.nativeEvent.layout.width))}
      style={{
        width: "100%",
        backgroundColor: c.bg,
        marginBottom: 12,
        borderBottomWidth: 0.5,
        borderBottomColor: c.line,
      }}
    >
      {!commentsOnly && (
        <>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 10,
              paddingLeft: 12,
              paddingRight: 4,
              gap: 10,
            }}
          >
            <Pressable
              onPress={() => openProfile(post.uid)}
              accessibilityRole="button"
              accessibilityLabel={`@${post.username} profilini aç`}
            >
              <Avatar
                name={author?.displayName || post.username}
                mediaId={author?.avatarMediaId}
                size={34}
              />
            </Pressable>
            <Pressable
              onPress={() => openProfile(post.uid)}
              style={{ flex: 1 }}
            >
              <Text style={{ fontSize: 13, fontWeight: "700", color: c.text }}>
                {post.username}
                {author?.official ? "  ✓" : ""}
              </Text>
              <Text style={{ fontSize: 11, color: c.muted, marginTop: 2 }}>
                {timeAgo(post.createdAt)}
              </Text>
            </Pressable>
            <Action
              name="ellipsis-horizontal"
              label="Gönderi seçenekleri"
              onPress={() => setMenu(true)}
              size={23}
            />
          </View>
          {!hideMedia && !!post.mediaItems?.length && (
            <View>
              <ScrollView
                testID={`media-carousel-${post.id}`}
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onScroll={(e) =>
                  setPage(
                    Math.round(
                      e.nativeEvent.contentOffset.x / Math.max(width, 1),
                    ),
                  )
                }
                scrollEventThrottle={80}
              >
                {post.mediaItems.map((item) => (
                  <Pressable
                    key={item.id}
                    accessibilityLabel={post.caption || "Paylaşılan medya"}
                    onPress={
                      item.kind === "image"
                        ? () => {
                            const now = Date.now();
                            if (now - lastTap.current < 300 && !liked)
                              void like().catch((e) => setError(friendly(e)));
                            lastTap.current = now;
                          }
                        : undefined
                    }
                  >
                    <ProtectedMedia
                      item={item}
                      tapToLoad
                      style={{
                        width,
                        height: width,
                        backgroundColor: c.surface,
                      }}
                    />
                  </Pressable>
                ))}
              </ScrollView>
              {post.mediaItems.length > 1 && (
                <>
                  <View
                    style={{
                      position: "absolute",
                      right: 12,
                      top: 12,
                      backgroundColor: "#0008",
                      borderRadius: 20,
                      paddingHorizontal: 10,
                      paddingVertical: 5,
                    }}
                  >
                    <Text style={{ color: "#fff", fontSize: 12 }}>
                      {page + 1}/{post.mediaItems.length}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "center",
                      gap: 4,
                      paddingTop: 8,
                    }}
                  >
                    {post.mediaItems.map((m, i) => (
                      <View
                        key={m.id}
                        style={{
                          width: 5,
                          height: 5,
                          borderRadius: 3,
                          backgroundColor: i === page ? c.accent : "#d0d0d0",
                        }}
                      />
                    ))}
                  </View>
                </>
              )}
            </View>
          )}
          {!hideMedia &&
            !post.mediaItems?.length &&
            !!post.mediaUrl &&
            post.mediaType === "image" && (
              <Image
                source={post.mediaUrl}
                style={{ width: "100%", aspectRatio: 1 }}
                contentFit="cover"
                accessibilityLabel={post.caption}
              />
            )}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingHorizontal: 4,
            }}
          >
            <Action
              name={liked ? "heart" : "heart-outline"}
              label={liked ? "Beğeniyi geri al" : "Beğen"}
              color={liked ? c.danger : c.text}
              onPress={like}
              size={28}
            />
            {post.commentsEnabled && (
              <Action
                name="chatbubble-outline"
                label="Yorumlar"
                onPress={() => setComments(true)}
                size={25}
              />
            )}
            <Action
              name="paper-plane-outline"
              label="Paylaş"
              onPress={() =>
                Share.share({ message: `@${post.username}: ${post.caption}` })
              }
              size={26}
            />
            <View style={{ flex: 1 }} />
            <Action
              name={saved ? "bookmark" : "bookmark-outline"}
              label={saved ? "Kaydedildi" : "Kaydet"}
              onPress={async () => {
                await toggleSaved(post.id);
                setSaved(!saved);
              }}
              size={25}
            />
          </View>
          <View style={{ paddingHorizontal: 14, gap: 5, paddingBottom: 12 }}>
            <Text style={{ fontWeight: "700", fontSize: 13, color: c.text }}>
              {count > 0
                ? `${count >= 500 ? "500+" : count.toLocaleString("tr-TR")} beğenme`
                : "İlk beğenen sen ol"}
            </Text>
            {!!post.caption && (
              <Text style={{ fontSize: 14, lineHeight: 20, color: c.text }}>
                <Text
                  onPress={() => openProfile(post.uid)}
                  style={{ fontWeight: "700" }}
                >
                  {post.username}{" "}
                </Text>
                <Text>{post.caption}</Text>
              </Text>
            )}
            {post.commentsEnabled && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Yorumları görüntüle"
                onPress={() => setComments(true)}
                style={{ paddingVertical: 4 }}
              >
                <Text style={{ fontSize: 13, color: c.muted }}>
                  Yorumları görüntüle
                </Text>
              </Pressable>
            )}
            {!!(error || likes.error) && (
              <Text accessibilityRole="alert" style={styles.error}>
                {error || likes.error}
              </Text>
            )}
          </View>
        </>
      )}
      <Sheet
        visible={menu}
        title="Gönderi seçenekleri"
        onClose={() => {
          setMenu(false);
          setConfirm(false);
          setConfirmPublic(false);
        }}
      >
        <MenuRow
          title={saved ? "Kaydedilenlerden çıkar" : "Kaydet"}
          icon="bookmark-outline"
          onPress={async () => {
            await toggleSaved(post.id);
            setSaved(!saved);
            setMenu(false);
          }}
        />
        <MenuRow
          title="Profili görüntüle"
          icon="person-outline"
          onPress={() => {
            setMenu(false);
            openProfile(post.uid);
          }}
        />
        {post.uid === profile.uid ? (
          <MenuRow
            title="Gönderiyi sil"
            icon="trash-outline"
            danger
            onPress={() => setConfirm(true)}
          />
        ) : (
          <MenuRow
            title="Gönderiyi şikâyet et"
            icon="flag-outline"
            danger
            onPress={() => {
              setMenu(false);
              setReporting(true);
            }}
          />
        )}
        {post.uid === profile.uid &&
          post.audience === "private" &&
          !madePublic && (
            <MenuRow
              title="Herkese açık paylaş"
              icon="globe-outline"
              onPress={() => setConfirmPublic(true)}
            />
          )}
        {confirmPublic && (
          <View style={styles.card}>
            <Label>
              Bu gönderi ve eklediğin medya tüm uygulama kullanıcılarına
              açılacak ve Keşfet'te görünebilecek.
            </Label>
            {profile.isPrivate && (
              <Label>
                Önce profil ayarlarından hesabını herkese açık yapmalısın.
                Önceki gizli gönderilerin otomatik açılmaz.
              </Label>
            )}
            <Button
              title="Evet, herkese açık paylaş"
              disabled={profile.isPrivate}
              onPress={async () => {
                await api("publishToExplore", {
                  id: post.id,
                  confirmPublic: true,
                });
                setMadePublic(true);
                setConfirmPublic(false);
                setMenu(false);
              }}
            />
            <Button
              secondary
              title="Vazgeç"
              onPress={() => setConfirmPublic(false)}
            />
          </View>
        )}
        {confirm && (
          <View style={styles.card}>
            <Label>Bu gönderiyi kalıcı olarak silmek istiyor musun?</Label>
            <Button
              title="Evet, gönderiyi sil"
              onPress={async () => {
                await deleteOwnPost(post.id);
                setMenu(false);
              }}
            />
            <Button
              secondary
              title="Vazgeç"
              onPress={() => setConfirm(false)}
            />
          </View>
        )}
      </Sheet>
      <Sheet
        visible={comments}
        title="Yorumlar"
        onClose={() => {
          setComments(false);
          setCommentReport(null);
          onCommentsClose?.();
        }}
      >
        <State
          {...replies}
          empty={!replies.rows.some((r) => !blockedUids?.has(r.uid))}
          retry={replies.refresh}
        />
        {replies.rows
          .filter((r) => !blockedUids?.has(r.uid))
          .map((r) => (
            <View
              key={r.id}
              style={{
                flexDirection: "row",
                alignItems: "flex-start",
                gap: 10,
                paddingVertical: 8,
              }}
            >
              <Avatar name={r.username} size={32} />
              <View style={{ flex: 1 }}>
                <Pressable onPress={() => openProfile(r.uid)}>
                  <Text style={{ color: c.text, fontSize: 14, lineHeight: 20 }}>
                    <Text style={{ fontWeight: "700" }}>{r.username} </Text>
                    {r.text}
                  </Text>
                </Pressable>
                <Text style={{ fontSize: 11, color: c.muted, marginTop: 4 }}>
                  {timeAgo(r.createdAt)}
                </Text>
              </View>
              {r.uid !== profile.uid && (
                <Action
                  name="ellipsis-horizontal"
                  size={18}
                  label="Yorumu şikâyet et"
                  onPress={() => setCommentReport({ uid: r.uid, id: r.id })}
                />
              )}
            </View>
          ))}
        {commentReport && (
          <ReportForm
            onSubmit={(reason) =>
              report(
                commentReport.uid,
                `Yorum ${post.id}/${commentReport.id}: ${reason}`.slice(0, 500),
              )
            }
            onCancel={() => setCommentReport(null)}
          />
        )}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
            borderTopWidth: 1,
            borderTopColor: c.line,
            paddingTop: 12,
          }}
        >
          <Avatar
            name={profile.username}
            mediaId={profile.avatarMediaId}
            size={32}
          />
          <View style={{ flex: 1 }}>
            <Field
              placeholder="Bir şey söyle…"
              value={text}
              onChangeText={setText}
              maxLength={1000}
            />
          </View>
          <Action
            name="arrow-up-circle"
            label="Yorum gönder"
            color={c.accent}
            disabled={!text.trim()}
            onPress={async () => {
              await comment(post, text, profile);
              setText("");
              replies.refresh();
            }}
          />
        </View>
      </Sheet>
      <Sheet
        visible={reporting}
        title="Şikâyet et"
        onClose={() => setReporting(false)}
      >
        <ReportForm
          onSubmit={(reason) => report(post.uid, reason, post.id)}
          onCancel={() => setReporting(false)}
        />
      </Sheet>
    </View>
  );
});
