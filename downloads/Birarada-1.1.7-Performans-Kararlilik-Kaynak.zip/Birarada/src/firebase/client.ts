import { initializeApp } from "firebase/app";
import { connectAuthEmulator, initializeAuth } from "firebase/auth";
import { persistence } from "./persistence";
import { startup } from "../utils/startup";
const firebaseReady = startup.span("firebase-initialization");
export const app = initializeApp({
  apiKey: "AIzaSyC2TYgUREM8QWSg_RcunLQfnb_GXGboHT8",
  authDomain: "birarada-5650c.firebaseapp.com",
  projectId: process.env.EXPO_PUBLIC_USE_EMULATORS === "true"
    ? "demo-birarada"
    : "birarada-5650c",
  storageBucket: "birarada-5650c.firebasestorage.app",
  messagingSenderId: "510479812993",
  appId: "1:510479812993:web:3276197b364a784414c080",
});
export const auth = initializeAuth(app, { persistence });
firebaseReady();
startup.mark("firebase-initialized");
export const db = {};
export const storage = null;
if (process.env.EXPO_PUBLIC_USE_EMULATORS === "true") {
  const host = process.env.EXPO_PUBLIC_EMULATOR_HOST || "127.0.0.1";
  connectAuthEmulator(auth, `http://${host}:9099`, { disableWarnings: true });
}
