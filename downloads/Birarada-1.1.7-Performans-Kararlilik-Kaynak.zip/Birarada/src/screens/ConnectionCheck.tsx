import React, { useState } from "react";
import { Text, View, Platform } from "react-native";
import app from "../../app.json";
import Constants from "expo-constants";
import { Page, Button, Label } from "../components/ui";
import { api } from "../services/api";
import { apiBase } from "../database/client";
import { withDeadline } from "../utils/deadline";
import { startup } from "../utils/startup";
import { readTimings, type TimingRow } from "../utils/readTimings";
export function ConnectionCheck() {
  const [launches, setLaunches] = useState<ReturnType<typeof startup.list>>([]);
  const [timings, setTimings] = useState<TimingRow[]>([]);
  const [rows, setRows] = useState<
    { label: string; ms?: number; detail: string }[]
  >([]);
  return (
    <Page title="Bağlantı kontrolü">
      <Label>
        Uygulama:{" "}
        {Platform.OS === "web"
          ? app.expo.version
          : Constants.nativeAppVersion || app.expo.version}{" "}
        · kod{" "}
        {Platform.OS === "web"
          ? app.expo.android.versionCode
          : Constants.nativeBuildVersion || app.expo.android.versionCode}
      </Label>
      <Label muted>
        Bu ölçüm telefondaki gerçek bağlantıyı kontrol eder. Mesaj, şifre veya
        cihaz anahtarı kaydetmez.
      </Label>
      <Button
        title="Bağlantıyı ölç"
        onPress={async () => {
          setRows([]);
          for (const [label, work] of [
            [
              "Sunucu",
              () =>
                withDeadline(async (signal) => {
                  const r = await fetch(apiBase + "/health", { signal });
                  const v = await r.json();
                  if (!r.ok) throw Error("Sunucu hazır değil.");
                  return String(v.revision || "Sürüm okunamadı.");
                }, 15000),
            ],
            [
              "Oturumlu okuma",
              async () => {
                await api("connectionProbe");
                return "Oturum doğrulandı.";
              },
            ],
          ] as [string, () => Promise<string>][]) {
            const started = Date.now();
            try {
              const detail = await work();
              setRows((old) => [
                ...old,
                { label, ms: Date.now() - started, detail },
              ]);
            } catch (e) {
              setRows((old) => [
                ...old,
                {
                  label,
                  detail:
                    e instanceof Error ? e.message : "Bağlantı kurulamadı.",
                },
              ]);
            }
          }
        }}
      />
      {rows.map((row) => (
        <View key={row.label} style={{ paddingVertical: 10 }}>
          <Text>
            {row.label}: {row.ms === undefined ? "Başarısız" : `${row.ms} ms`}
          </Text>
          <Label muted>{row.detail}</Label>
        </View>
      ))}
      <Button
        secondary
        title="Son yükleme aşamalarını göster"
        onPress={() => setTimings(readTimings.list().slice(-30))}
      />
      {!!timings.length && (
        <Label muted>
          Bu oturumdaki gerçek istemci ölçümleri. Görsel süresi indirme ve çizim
          yolunu kapsar; sunucu yetkilendirmesinin tek başına süresi değildir.
        </Label>
      )}
      {timings.map((row, index) => (
        <Label key={index} muted>
          {row.operation} · {row.stage}: {row.milliseconds} ms ·{" "}
          {row.status === "ok" ? "tamamlandı" : "başarısız"}
        </Label>
      ))}
      <Button
        secondary
        title="Açılış aşamalarını göster"
        onPress={() => setLaunches(startup.list())}
      />
      {!!launches.length && (
        <Label muted>
          Bu değerler JavaScript ölçümünden başlar. Android Activity ve sistem
          Splash süresi bu kayıttan ölçülmüş sayılmaz. 2 saniye hedefi gerçek
          cihazda ayrıca doğrulanmalıdır.
        </Label>
      )}
      {launches.map((run) => (
        <View key={run.run} style={{ gap: 4 }}>
          <Label>
            {run.kind === "cold-js"
              ? "JavaScript başlangıcı"
              : "Arka plandan dönüş"}{" "}
            · {run.run}
          </Label>
          {Object.entries(run.stages).map(([key, ms]) => (
            <Label key={key} muted>
              {key}: {Math.round(ms)} ms
            </Label>
          ))}
          {Object.entries(run.spans).map(([key, ms]) => (
            <Label key={key} muted>
              {key}: {Math.round(ms)} ms
            </Label>
          ))}
        </View>
      ))}
    </Page>
  );
}
