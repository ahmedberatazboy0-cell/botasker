import React, { useEffect, useState } from "react";
import { Switch, View } from "react-native";
import { Page, Label, Button } from "../components/ui";
import {
  diagnosticsState,
  setDiagnosticsEnabled,
  sendDiagnosticsCheck,
} from "../services/diagnostics";
export function Diagnostics() {
  const [state, setState] = useState({
      supported: false,
      enabled: false,
      release: false,
    }),
    [notice, setNotice] = useState("");
  useEffect(() => {
    void diagnosticsState().then(setState);
  }, []);
  return (
    <Page title="Teknik hata raporları">
      <Label>
        İstersen uygulamanın çökme ve teknik hata raporlarını Google Firebase
        Crashlytics ile paylaşabilirsin. Bu tercih isteğe bağlıdır.
      </Label>
      <Label muted>
        Uygulama sürümü, Android sürümü, cihaz modeli, teknik çökme ayrıntıları
        ve SDK kurulum tanımlayıcıları işlenebilir. Mesajların, e-posta adresin,
        şifren ve erişim anahtarların uygulamanın hata kayıtlarına eklenmez. Bu
        raporlar anonim olduğu iddiasıyla sunulmaz.
      </Label>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
        <Label>Teknik hata raporlarını paylaş</Label>
        <Switch
          accessibilityLabel="Teknik hata raporlarını paylaş"
          value={state.enabled}
          disabled={!state.supported || !state.release}
          onValueChange={(value) => {
            void setDiagnosticsEnabled(value)
              .then(() => diagnosticsState())
              .then(setState)
              .catch((error) => setNotice(error.message));
          }}
        />
      </View>
      {!state.supported && (
        <Label muted>
          Bu yapıda Android Crashlytics köprüsü yok. Yeni Android derlemesi
          gerekir.
        </Label>
      )}
      {state.supported && !state.release && (
        <Label muted>Debug yapısında uzak hata gönderimi kapalıdır.</Label>
      )}
      {state.enabled && (
        <Button
          secondary
          title="Tanılama bağlantısını dene"
          onPress={async () => {
            await sendDiagnosticsCheck();
            setNotice(
              "Deneme kaydı cihaz SDK'sına verildi. Firebase konsoluna ulaştığı ayrıca doğrulanmalı.",
            );
          }}
        />
      )}
      {!!notice && <Label>{notice}</Label>}
    </Page>
  );
}
