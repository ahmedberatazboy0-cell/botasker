import { useCallback, useEffect, useRef, useState } from "react";
import { useIsFocused } from "@react-navigation/native";
import { api, cachedApi, type Cursor } from "../services/api";
import { useSession } from "../store/session";
import { friendly } from "../utils/errors";
import { useForeground } from "./useForeground";
import { sessionReads, apiReadKey } from "../utils/sessionReads";
import type { Row } from "../types";
import { startup } from "../utils/startup";
export function useApiList(
  action: string,
  input: Record<string, unknown>,
  { pollInterval = 0, enabled = true } = {},
) {
  const account = useSession((s) => s.user?.uid || s.profile?.uid || ""),
    key = JSON.stringify(input),
    identity = `${account}:${action}:${key}`,
    focused = useIsFocused(),
    foreground = useForeground(),
    generation = useRef(0),
    busy = useRef(false),
    manualRefresh = useRef(false),
    paged = useRef(false),
    latest = useRef(identity);
  latest.current = identity;
  const cached = cachedApi<{ rows: Row[]; cursor: Cursor }>(action, input);
  const [state, setState] = useState({
      identity,
      rows: cached?.rows || ([] as Row[]),
      cursor: cached?.cursor || (null as Cursor),
      loaded: !!cached,
      loading: !cached,
      refreshing: false,
      paging: false,
      error: "",
      failedPage: false,
    }),
    [version, setVersion] = useState(0);
  const refresh = useCallback(() => {
    manualRefresh.current = true;
    setVersion((v) => v + 1);
  }, []);
  useEffect(
    () =>
      sessionReads.subscribe((scope, keys) => {
        if (
          scope === account &&
          keys.includes(apiReadKey(action, JSON.parse(key)))
        )
          setVersion((v) => v + 1);
      }),
    [account, action, key, refresh],
  );
  useEffect(() => {
    if (!focused || !foreground || !enabled) return;
    const current = ++generation.current;
    busy.current = false;
    paged.current = false;
    const load = async (silent = false, reuseFresh = false) => {
      if (
        busy.current ||
        current !== generation.current ||
        (silent && paged.current)
      )
        return;
      busy.current = true;
      const warm = cachedApi<{ rows: Row[]; cursor: Cursor }>(
        action,
        JSON.parse(key),
      );
      setState((old) =>
        old.identity === identity
          ? {
              ...old,
              rows: old.loaded ? old.rows : warm?.rows || [],
              cursor: old.loaded ? old.cursor : warm?.cursor || null,
              loaded: old.loaded || !!warm,
              loading: !old.loaded && !warm,
              refreshing: old.loaded && !silent,
              paging: false,
              error: "",
              failedPage: false,
            }
          : {
              identity,
              rows: warm?.rows || [],
              cursor: warm?.cursor || null,
              loaded: !!warm,
              loading: !warm,
              refreshing: false,
              paging: false,
              error: "",
              failedPage: false,
            },
      );
      try {
        const result = await api<{ rows: Row[]; cursor: Cursor }>(
          action,
          JSON.parse(key),
          { maxAgeMs: reuseFresh ? 5000 : 0 },
        );
        if (current !== generation.current || latest.current !== identity)
          return;
        if (
          action === "listContent" &&
          input.kind === "post" &&
          !input.uid &&
          !input.search
        )
          startup.mark("feed-data-ready");
        setState({
          identity,
          rows: result.rows,
          cursor: result.cursor || null,
          loaded: true,
          loading: false,
          refreshing: false,
          paging: false,
          error: "",
          failedPage: false,
        });
      } catch (e) {
        if (current === generation.current && latest.current === identity)
          setState((old) => ({
            ...old,
            loading: false,
            refreshing: false,
            error: friendly(e),
            ...(["permission-denied", "unauthenticated"].includes(
              (e as any)?.code,
            )
              ? { rows: [], cursor: null, loaded: false }
              : {}),
          }));
      } finally {
        if (current === generation.current) busy.current = false;
      }
    };
    void load(!manualRefresh.current, !manualRefresh.current);
    manualRefresh.current = false;
    const timer = pollInterval
      ? setInterval(() => {
          void load(true);
        }, pollInterval)
      : undefined;
    return () => {
      generation.current++;
      if (timer) clearInterval(timer);
    };
  }, [
    action,
    key,
    identity,
    version,
    focused,
    foreground,
    enabled,
    pollInterval,
  ]);
  const loadMore = useCallback(async () => {
    if (
      busy.current ||
      state.loading ||
      !state.cursor ||
      state.identity !== identity ||
      !focused ||
      !foreground ||
      !enabled
    )
      return;
    const current = generation.current;
    busy.current = true;
    paged.current = true;
    setState((old) => ({ ...old, paging: true, error: "", failedPage: false }));
    try {
      const next = await api<{ rows: Row[]; cursor: Cursor }>(action, {
        ...JSON.parse(key),
        cursor: state.cursor,
      });
      if (current !== generation.current || latest.current !== identity) return;
      setState((old) => ({
        ...old,
        rows: [
          ...new Map(
            [...old.rows, ...next.rows].map((r) => [r.id, r]),
          ).values(),
        ],
        cursor: next.cursor || null,
        paging: false,
      }));
    } catch (e) {
      if (current === generation.current && latest.current === identity)
        setState((old) => ({
          ...old,
          error: friendly(e),
          paging: false,
          failedPage: true,
        }));
    } finally {
      if (current === generation.current) busy.current = false;
    }
  }, [
    action,
    key,
    identity,
    state.cursor,
    state.loading,
    state.identity,
    focused,
    foreground,
    enabled,
  ]);
  const matches = state.identity === identity;
  return {
    rows: matches ? state.rows : [],
    loading: enabled && (!matches || state.loading),
    refreshing: matches && state.refreshing,
    paging: matches && state.paging,
    error: matches ? state.error : "",
    hasMore: matches && !!state.cursor,
    loadMore,
    refresh,
    retry: state.failedPage ? loadMore : refresh,
  };
}
