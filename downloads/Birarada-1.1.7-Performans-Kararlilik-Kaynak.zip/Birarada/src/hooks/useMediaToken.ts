import { useSyncExternalStore } from "react";
import { onIdTokenChanged } from "firebase/auth";
import { auth } from "../firebase/client";
import { createMediaTokenStore } from "../utils/mediaTokenStore";
const store = createMediaTokenStore({
  currentUser: () => auth.currentUser,
  subscribe: (callback) => onIdTokenChanged(auth, callback),
  schedule: (callback) => {
    const timer = setInterval(callback, 40 * 60000);
    return () => clearInterval(timer);
  },
});
const empty = () => "";
export const useMediaToken = () =>
  useSyncExternalStore(store.subscribe, store.snapshot, empty);
export const refreshMediaToken = store.refresh;
