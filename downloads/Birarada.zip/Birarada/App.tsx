import React, { useEffect, useState } from "react";
import { Text, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { onAuthStateChanged } from "firebase/auth";
import { doc, onSnapshot } from "firebase/firestore";
import { auth, db } from "./src/firebase/client";
import { useSession } from "./src/store/session";
import { AuthScreen, CompleteProfile } from "./src/screens/Auth";
import { Root } from "./src/navigation/Root";
import { Page, Label, Button } from "./src/components/ui";
import { friendly } from "./src/utils/errors";
import { logout } from "./src/services/social";
import type { Profile } from "./src/types";
export default function App() {
  const { user, profile, ready, set } = useSession(),
    [splash, setSplash] = useState(true),
    [error, setError] = useState(""),
    [retry, setRetry] = useState(0);
  useEffect(() => {
    const timer = setTimeout(() => setSplash(false), 1400);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => {
    let stop: undefined | (() => void);
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      stop?.();
      setError("");
      set({ user: u, profile: null, ready: !u });
      if (u)
        stop = onSnapshot(
          doc(db, "users", u.uid),
          (snap) =>
            set({
              profile: snap.exists() ? (snap.data() as Profile) : null,
              ready: true,
            }),
          (e) => {
            setError(friendly(e));
            set({ ready: true });
          },
        );
    });
    return () => {
      unsubscribe();
      stop?.();
    };
  }, [retry]);
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      {splash || !ready ? (
        <View
          style={{
            flex: 1,
            backgroundColor: "#101112",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
          }}
        >
          <Text style={{ color: "#ff925c", fontSize: 44, fontWeight: "800" }}>
            birarada
          </Text>
          <Text style={{ color: "#a8a6a3" }}>
            Yeni insanlarla, daha güzel anlara.
          </Text>
        </View>
      ) : error ? (
        <Page title="Bağlantıyı yenileyelim.">
          <Label>{error}</Label>
          <Button title="Tekrar dene" onPress={() => setRetry((r) => r + 1)} />
          <Button secondary title="Çıkış yap" onPress={logout} />
        </Page>
      ) : !user ? (
        <AuthScreen />
      ) : !profile ? (
        <CompleteProfile />
      ) : (
        <Root />
      )}
    </SafeAreaProvider>
  );
}
