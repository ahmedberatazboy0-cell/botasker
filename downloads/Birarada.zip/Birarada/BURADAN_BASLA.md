# Birarada 1.0.0 kaynak paketi

Android/iOS kimliği: com.birarada.app
İlk Android versionCode: 1
Firebase: birarada-5650c
Destek: ahmedberatazboy0@gmail.com

Bu ZIP kaynak kodudur. İmzalı Play Store AAB'si değildir.

Hızlı yerel demo: Birarada.html dosyasını tarayıcıda aç.
Bu bağımsız HTML demosu cihazında çalışır; Firebase hesabı veya ortak sosyal ağ oluşturmaz.

Mobil projeyi Windows'ta test: ZIP'in tamamını çıkart, Node.js LTS ve Java21 kur;
mobile klasöründeki başlat.bat veya baslat.bat dosyasına çift tıkla.
İlk kurulum internet ve Firebase emulator indirmesi gerektirir.

Mobil kaynak: mobile/
Test edilenler ve açık engeller: mobile/TEST_REPORT.md
Kurulum: mobile/README.md
Yeni Expo/EAS projesi ve imzalı AAB: mobile/docs/PLAY_STORE_RELEASE.md
Yasal sayfalar ve mevcut siteyi koruyan yayın adımları: mobile/docs/HOSTING.md

Son adayda hesap silme/kurtarma, topluluk kuralları onayı, gerekçeli şikâyet,
engelleme filtreleri, yayın yapılandırması ve gerçek Türkçe yasal sayfalar eklendi.
Yerel kontroller geçti; 34 Firestore güvenlik testi ağ engeli nedeniyle çalışmadı.
Gerçek Android cihaz/Firebase uçtan uca testi, Expo/EAS ve Firebase yetkili oturumları,
canlı yasal sayfalar ve üretim imzalı AAB hâlâ gereklidir.

Şifre, service account, private key veya imzalama anahtarı sohbete/koda koyma.
