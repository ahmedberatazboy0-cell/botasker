import { test, before, after, beforeEach } from "node:test";
import { readFileSync } from "node:fs";
import {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
  RulesTestEnvironment,
} from "@firebase/rules-unit-testing";
import {
  doc,
  setDoc,
  getDoc,
  updateDoc,
  deleteDoc,
  collection,
  query,
  where,
  getDocs,
  writeBatch,
  serverTimestamp,
} from "firebase/firestore";
let env: RulesTestEnvironment;
before(async () => {
  env = await initializeTestEnvironment({
    projectId: "demo-birarada",
    firestore: {
      rules: readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8080,
    },
  });
});
after(async () => {
  await env?.cleanup();
});
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    for (const uid of ["alice", "bob", "eve"])
      await setDoc(doc(db, "users", uid), {
        uid,
        username: uid,
        displayName: uid,
        bio: "",
        website: "",
        avatarUrl: "",
        isPrivate: uid === "bob",
        allowStrangerDM: false,
        followersCount: 0,
        followingCount: 0,
        postsCount: 0,
      });
    await setDoc(doc(db, "posts", "private"), {
      uid: "bob",
      audience: "private",
      commentsEnabled: true,
    });
    await setDoc(doc(db, "posts", "public"), {
      uid: "alice",
      audience: "public",
      commentsEnabled: true,
    });
    await setDoc(doc(db, "chats", "alice:bob"), {
      memberIds: ["alice", "bob"],
      lastMessage: "",
    });
  });
});
const db = (uid: string) => env.authenticatedContext(uid).firestore();
test("only profile owner edits; counters and username are immutable", async () => {
  await assertSucceeds(
    updateDoc(doc(db("alice"), "users", "alice"), { bio: "Merhaba" }),
  );
  await assertFails(
    updateDoc(doc(db("bob"), "users", "alice"), { bio: "Hijacked" }),
  );
  await assertFails(
    updateDoc(doc(db("alice"), "users", "alice"), { followersCount: 100 }),
  );
  await assertFails(
    updateDoc(doc(db("alice"), "users", "alice"), { username: "taken" }),
  );
});
test("private content requires accepted follow and blocks override acceptance", async () => {
  await assertFails(getDoc(doc(db("alice"), "posts", "private")));
  await env.withSecurityRulesDisabled((c) =>
    setDoc(doc(c.firestore(), "follows", "alice_bob"), {
      followerUid: "alice",
      followingUid: "bob",
      status: "accepted",
    }),
  );
  await assertSucceeds(getDoc(doc(db("alice"), "posts", "private")));
  await assertSucceeds(
    setDoc(doc(db("bob"), "users", "bob", "blocks", "alice"), {
      uid: "alice",
      createdAt: serverTimestamp(),
    }),
  );
  await assertFails(getDoc(doc(db("alice"), "posts", "private")));
});
test("post owner alone may delete; public feed query works", async () => {
  await assertSucceeds(
    getDocs(
      query(collection(db("bob"), "posts"), where("audience", "==", "public")),
    ),
  );
  await assertFails(deleteDoc(doc(db("bob"), "posts", "public")));
  await assertSucceeds(deleteDoc(doc(db("alice"), "posts", "public")));
});
test("private follow requires request; target accepts and follower cannot self-accept", async () => {
  const f = doc(db("alice"), "follows", "alice_bob");
  await assertSucceeds(getDoc(f));
  await assertFails(
    setDoc(f, {
      followerUid: "alice",
      followingUid: "bob",
      status: "accepted",
      createdAt: serverTimestamp(),
    }),
  );
  await assertSucceeds(
    setDoc(f, {
      followerUid: "alice",
      followingUid: "bob",
      status: "pending",
      createdAt: serverTimestamp(),
    }),
  );
  await assertFails(updateDoc(f, { status: "accepted" }));
  await assertSucceeds(
    updateDoc(doc(db("bob"), "follows", "alice_bob"), { status: "accepted" }),
  );
});
test("only chat members read messages; outsider cannot inject messages", async () => {
  await assertSucceeds(getDoc(doc(db("alice"), "chats", "alice:bob")));
  await assertFails(getDoc(doc(db("eve"), "chats", "alice:bob")));
  await assertFails(
    setDoc(doc(db("eve"), "chats", "alice:bob", "messages", "attack"), {
      senderUid: "eve",
      text: "Hi",
      type: "text",
      seenBy: ["eve"],
      createdAt: serverTimestamp(),
    }),
  );
});
test("new DM honors recipient preference; accepted follower may send", async () => {
  const d = db("alice");
  await assertSucceeds(getDoc(doc(d, "chats", "alice:eve")));
  const chat = {
    memberIds: ["alice", "eve"],
    lastMessage: "",
    lastMessageAt: serverTimestamp(),
  };
  await assertFails(setDoc(doc(d, "chats", "alice:eve"), chat));
  await env.withSecurityRulesDisabled((c) =>
    setDoc(doc(c.firestore(), "follows", "eve_alice"), {
      followerUid: "eve",
      followingUid: "alice",
      status: "accepted",
    }),
  );
  await assertSucceeds(setDoc(doc(d, "chats", "alice:eve"), chat));
  await assertSucceeds(
    setDoc(doc(d, "chats", "alice:eve", "messages", "one"), {
      senderUid: "alice",
      text: "Merhaba",
      type: "text",
      seenBy: ["alice"],
      createdAt: serverTimestamp(),
    }),
  );
  await assertSucceeds(
    updateDoc(doc(db("eve"), "chats", "alice:eve", "messages", "one"), {
      seenBy: ["alice", "eve"],
    }),
  );
  await assertSucceeds(
    updateDoc(doc(d, "chats", "alice:eve", "messages", "one"), {
      text: "Düzenlenmiş mesaj",
      editedAt: serverTimestamp(),
    }),
  );
  await assertFails(
    updateDoc(doc(db("eve"), "chats", "alice:eve", "messages", "one"), {
      text: "Changed",
    }),
  );
});
test("profile and unique username created atomically", async () => {
  const d = db("newuser"),
    batch = writeBatch(d);
  batch.set(doc(d, "usernames", "newuser"), { uid: "newuser" });
  batch.set(doc(d, "users", "newuser"), {
    uid: "newuser",
    username: "newuser",
    displayName: "New User",
    bio: "",
    website: "",
    avatarUrl: "",
    isPrivate: true,
    allowStrangerDM: false,
    followersCount: 0,
    followingCount: 0,
    postsCount: 0,
    createdAt: serverTimestamp(),
  });
  await assertSucceeds(batch.commit());
  await assertFails(
    setDoc(doc(db("eve"), "usernames", "newuser"), { uid: "eve" }),
  );
});
