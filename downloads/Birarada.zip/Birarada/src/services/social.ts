import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";
import {
  collection,
  doc,
  setDoc,
  getDoc,
  runTransaction,
  serverTimestamp,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  addDoc,
  deleteDoc,
  updateDoc,
  writeBatch,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { Platform } from "react-native";
import { auth, db, storage } from "../firebase/client";
import { usernameValid } from "../utils/errors";
import { useSession } from "../store/session";
import type { Profile, Post } from "../types";
export const uid = () => {
  if (!auth.currentUser) throw Error("Devam etmek için giriş yap.");
  return auth.currentUser.uid;
};
export async function createProfile(username: string, displayName: string) {
  if (!usernameValid(username))
    throw Error(
      "Kullanıcı adı 3–24 küçük harf, rakam veya alt çizgi içermeli.",
    );
  const id = uid();
  await runTransaction(db, async (tx) => {
    const name = doc(db, "usernames", username),
      user = doc(db, "users", id);
    if ((await tx.get(user)).exists()) return;
    if ((await tx.get(name)).exists()) throw Error("Bu kullanıcı adı alınmış.");
    tx.set(name, { uid: id });
    tx.set(user, {
      uid: id,
      username,
      displayName,
      bio: "",
      avatarUrl: "",
      website: "",
      isPrivate: true,
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
      allowStrangerDM: false,
      createdAt: serverTimestamp(),
    });
  });
}
export async function register(email: string, password: string) {
  if (password.length < 8) throw Error("En az 8 karakterli şifre seç.");
  await createUserWithEmailAndPassword(auth, email.trim(), password);
}
export const login = (email: string, password: string) =>
  signInWithEmailAndPassword(auth, email.trim(), password);
export const logout = () => signOut(auth);
export const resetPassword = (email: string) =>
  sendPasswordResetEmail(auth, email.trim());
export async function googleLogin() {
  if (Platform.OS !== "web")
    throw Error(
      "Google girişi bu sürümde yalnızca web üzerinden kullanılabilir.",
    );
  await signInWithPopup(auth, new GoogleAuthProvider());
}
export const feedQuery = () =>
  query(
    collection(db, "posts"),
    where("audience", "==", "public"),
    orderBy("createdAt", "desc"),
    limit(4),
  );
export const ownPostsQuery = (id: string, publicOnly = false) =>
  query(
    collection(db, "posts"),
    where("uid", "==", id),
    ...(publicOnly ? [where("audience", "==", "public")] : []),
    orderBy("createdAt", "desc"),
    limit(50),
  );
export async function editProfile(
  data: Pick<
    Profile,
    "displayName" | "bio" | "website" | "isPrivate" | "allowStrangerDM"
  >,
) {
  await updateDoc(doc(db, "users", uid()), data);
}
export async function upload(uri: string) {
  if (!storage)
    throw Error(
      "Medya yükleme kapalı. Firebase Storage etkinleştirildikten sonra kullanılabilir.",
    );
  const response = await fetch(uri),
    blob = await response.blob();
  if (blob.size > 20 * 1024 * 1024)
    throw Error("Medya en fazla 20 MB olabilir.");
  const target = ref(storage, `media/${uid()}/${Date.now()}`);
  await uploadBytes(target, blob);
  return getDownloadURL(target);
}
export async function publish(
  profile: Profile,
  caption: string,
  mediaUrl: string,
  mediaType: "image" | "video",
  commentsEnabled: boolean,
) {
  if (!caption.trim() && !mediaUrl)
    throw Error("Bir açıklama veya medya ekle.");
  await addDoc(collection(db, "posts"), {
    uid: uid(),
    username: profile.username,
    caption: caption.trim(),
    mediaUrl,
    mediaType,
    commentsEnabled,
    audience: profile.isPrivate ? "private" : "public",
    createdAt: serverTimestamp(),
  });
}
export async function toggleLike(post: Post) {
  const target = doc(db, "posts", post.id, "likes", uid());
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(target);
    if (snap.exists()) tx.delete(target);
    else tx.set(target, { uid: uid(), createdAt: serverTimestamp() });
  });
}
export async function toggleSaved(id: string) {
  const target = doc(db, "saved", uid(), "posts", id);
  await runTransaction(db, async (tx) =>
    (await tx.get(target)).exists()
      ? tx.delete(target)
      : tx.set(target, { postId: id, createdAt: serverTimestamp() }),
  );
}
export async function comment(post: Post, text: string, profile: Profile) {
  if (!text.trim()) return;
  await addDoc(collection(db, "posts", post.id, "comments"), {
    uid: uid(),
    username: profile.username,
    text: text.trim().slice(0, 1000),
    createdAt: serverTimestamp(),
  });
}
export async function follow(profile: Profile) {
  const target = doc(db, "follows", `${uid()}_${profile.uid}`);
  await runTransaction(db, async (tx) => {
    if ((await tx.get(target)).exists()) tx.delete(target);
    else {
      tx.set(target, {
        followerUid: uid(),
        followingUid: profile.uid,
        status: profile.isPrivate ? "pending" : "accepted",
        createdAt: serverTimestamp(),
      });
      tx.set(doc(collection(db, "notifications")), {
        sourceUid: uid(),
        targetUid: profile.uid,
        type: "follow",
        text:
          "@" +
          useSession.getState().profile!.username +
          " seninle bağlantı kurmak istiyor.",
        read: false,
        createdAt: serverTimestamp(),
      });
    }
  });
}
export async function acceptFollow(id: string, accept: boolean) {
  const target = doc(db, "follows", id);
  if (accept) await updateDoc(target, { status: "accepted" });
  else await deleteDoc(target);
}
export async function chatWith(other: Profile) {
  if (other.uid === uid()) throw Error("Kendine mesaj gönderemezsin.");
  const id = [uid(), other.uid].sort().join(":"),
    target = doc(db, "chats", id);
  if (!(await getDoc(target)).exists())
    await setDoc(target, {
      memberIds: [uid(), other.uid],
      lastMessage: "",
      lastMessageAt: serverTimestamp(),
    });
  return id;
}
export async function sendMessage(chatId: string, text: string) {
  if (!text.trim()) return;
  const batch = writeBatch(db);
  batch.set(doc(collection(db, "chats", chatId, "messages")), {
    senderUid: uid(),
    text: text.trim().slice(0, 2000),
    type: "text",
    createdAt: serverTimestamp(),
    seenBy: [uid()],
  });
  batch.update(doc(db, "chats", chatId), {
    lastMessage: text.trim().slice(0, 100),
    lastMessageAt: serverTimestamp(),
  });
  await batch.commit();
}
export const report = (targetUid: string) =>
  addDoc(collection(db, "reports"), {
    reporterUid: uid(),
    targetUid,
    reason: "Uygunsuz içerik veya hesap",
    createdAt: serverTimestamp(),
  });
export async function block(targetUid: string) {
  await setDoc(doc(db, "users", uid(), "blocks", targetUid), {
    uid: targetUid,
    createdAt: serverTimestamp(),
  });
}
