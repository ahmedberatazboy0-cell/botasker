import React from "react";
import { Pressable, View, Text } from "react-native";
import {
  collection,
  doc,
  getDoc,
  query,
  where,
  limit,
} from "firebase/firestore";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useRows } from "../hooks/useRows";
import { Page, Label, State, styles } from "../components/ui";
import { PostCard } from "../components/PostCard";
import type { Post, Profile } from "../types";
import { friendly } from "../utils/errors";
function Person({ id, open }: { id: string; open: (id: string) => void }) {
  const [p, setP] = React.useState<Profile | null>(null);
  React.useEffect(() => {
    let alive = true;
    getDoc(doc(db, "users", id))
      .then((s) => {
        if (alive && s.exists()) setP(s.data() as Profile);
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [id]);
  return p ? (
    <Pressable onPress={() => open(id)} style={styles.card}>
      <Text style={styles.text}>{p.displayName}</Text>
      <Label muted>@{p.username}</Label>
    </Pressable>
  ) : null;
}
export function Connections({ route, navigation }: any) {
  const current = useSession((s) => s.profile)!.uid,
    isFollowing = route.params?.kind === "following",
    data = useRows(
      query(
        collection(db, "follows"),
        where(isFollowing ? "followerUid" : "followingUid", "==", current),
        where("status", "==", "accepted"),
        limit(100),
      ),
    );
  return (
    <Page title={isFollowing ? "Takip ettiklerin" : "Takipçilerin"}>
      <State {...data} empty={!data.rows.length} retry={data.refresh} />
      {data.rows.map((r) => (
        <Person
          key={r.id}
          id={isFollowing ? r.followingUid : r.followerUid}
          open={(uid) => navigation.push("User", { uid })}
        />
      ))}
    </Page>
  );
}
export function Saved({ navigation }: any) {
  const id = useSession((s) => s.profile)!.uid,
    data = useRows(query(collection(db, "saved", id, "posts"), limit(100))),
    [posts, setPosts] = React.useState<Post[]>([]),
    [error, setError] = React.useState("");
  React.useEffect(() => {
    let active = true;
    setError("");
    Promise.all(
      data.rows.map(async (row) => {
        try {
          const snap = await getDoc(doc(db, "posts", row.id));
          return snap.exists()
            ? ({ id: snap.id, ...snap.data() } as Post)
            : null;
        } catch {
          return null;
        }
      }),
    )
      .then((rows) => {
        if (active) setPosts(rows.filter((p): p is Post => p !== null));
      })
      .catch((e) => {
        if (active) setError(friendly(e));
      });
    return () => {
      active = false;
    };
  }, [data.rows]);
  return (
    <Page title="Sana kalsın.">
      <Label muted>
        Silinen veya erişimin kaldırıldığı gönderiler gösterilmez.
      </Label>
      <State
        loading={data.loading}
        error={error || data.error}
        empty={!posts.length}
        retry={data.refresh}
      />
      {posts.map((p) => (
        <PostCard
          key={p.id}
          post={p}
          openProfile={(uid) => navigation.push("User", { uid })}
        />
      ))}
    </Page>
  );
}
