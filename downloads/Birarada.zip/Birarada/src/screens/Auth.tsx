import React, { useState } from "react";
import { Text, View, Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Page, Label, Field, Button, styles } from "../components/ui";
import {
  register,
  login,
  resetPassword,
  googleLogin,
  createProfile,
} from "../services/social";
export function AuthScreen() {
  const [step, setStep] = useState(0),
    [onboard, setOnboard] = useState(false),
    [mode, setMode] = useState<"login" | "register" | "reset">("login"),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [notice, setNotice] = useState("");
  React.useEffect(() => {
    AsyncStorage.getItem("onboarded").then((v) => setOnboard(v === "yes"));
  }, []);
  if (!onboard) {
    const copy = [
      [
        "Arkadaşlarını bul",
        "Aynı şehirde, aynı heyecanda. Kendi çevrene bir adım daha yaklaş.",
      ],
      [
        "Anlarını paylaş",
        "Büyük olayları bekleme. Güzel bir gün, küçük bir anla başlar.",
      ],
      ["Birlikte daha fazlasını yaşa", "Yeni insanlarla, daha güzel anlara."],
    ][step]!;
    return (
      <Page>
        <Text style={{ color: "#ff925c", fontWeight: "800", fontSize: 22 }}>
          birarada
        </Text>
        <View style={{ height: 180, justifyContent: "center" }}>
          <Text style={{ fontSize: 80, color: "#ff925c" }}>◌</Text>
        </View>
        <Text style={styles.title}>{copy[0]}</Text>
        <Label muted>{copy[1]}</Label>
        <Label muted>{step + 1} / 3</Label>
        <Button
          title={step < 2 ? "Devam et" : "Giriş yap"}
          onPress={async () => {
            if (step < 2) setStep(step + 1);
            else {
              await AsyncStorage.setItem("onboarded", "yes");
              setOnboard(true);
            }
          }}
        />
        {step === 2 && (
          <Button
            secondary
            title="Hesap oluştur"
            onPress={async () => {
              await AsyncStorage.setItem("onboarded", "yes");
              setMode("register");
              setOnboard(true);
            }}
          />
        )}
      </Page>
    );
  }
  return (
    <Page>
      <Text style={{ color: "#ff925c", fontSize: 26, fontWeight: "800" }}>
        birarada
      </Text>
      <View style={{ height: 40 }} />
      <Text style={styles.title}>
        {mode === "register"
          ? "Aramıza katıl."
          : mode === "reset"
            ? "Yeniden bağlan."
            : "İyi ki geldin."}
      </Text>
      <Label muted>Yeni insanlarla, daha güzel anlara.</Label>
      <Field
        placeholder="E-posta"
        keyboardType="email-address"
        autoComplete="email"
        value={email}
        onChangeText={setEmail}
      />
      {mode !== "reset" && (
        <Field
          placeholder="Şifre"
          secureTextEntry
          autoComplete={
            mode === "register" ? "new-password" : "current-password"
          }
          value={password}
          onChangeText={setPassword}
        />
      )}
      <Button
        title={
          mode === "register"
            ? "Hesap oluştur"
            : mode === "reset"
              ? "Sıfırlama bağlantısı gönder"
              : "Giriş yap"
        }
        disabled={!email || (mode !== "reset" && !password)}
        onPress={async () => {
          setNotice("");
          if (mode === "register") await register(email, password);
          else if (mode === "reset") {
            await resetPassword(email);
            setNotice("E-posta kutunu kontrol et.");
          } else await login(email, password);
        }}
      />
      {!!notice && <Label>{notice}</Label>}
      <Button
        secondary
        title="Google ile devam et"
        disabled={Platform.OS !== "web"}
        onPress={googleLogin}
      />
      {Platform.OS !== "web" && (
        <Label muted>
          Google girişi web sürümünde kullanılabilir; cihaz için OAuth istemcisi
          yapılandırılmalıdır.
        </Label>
      )}
      <Button
        secondary
        title={mode === "register" ? "Zaten hesabım var" : "Yeni hesap oluştur"}
        onPress={() => {
          setNotice("");
          setMode(mode === "register" ? "login" : "register");
        }}
      />
      {mode !== "reset" && (
        <Button
          secondary
          title="Şifremi unuttum"
          onPress={() => setMode("reset")}
        />
      )}
      <Label muted>Hesabın varsayılan olarak gizli. Konumun paylaşılmaz.</Label>
    </Page>
  );
}
export function CompleteProfile() {
  const [name, setName] = useState(""),
    [username, setUsername] = useState("");
  return (
    <Page title="Seni tanıyalım.">
      <Label muted>Görünen adını ve benzersiz kullanıcı adını seç.</Label>
      <Field
        placeholder="Görünen ad"
        value={name}
        onChangeText={setName}
        maxLength={60}
      />
      <Field
        placeholder="Kullanıcı adı"
        value={username}
        onChangeText={(v) => setUsername(v.toLowerCase())}
        maxLength={24}
      />
      <Button
        title="Birarada’ya katıl"
        disabled={name.trim().length < 2 || username.length < 3}
        onPress={() => createProfile(username, name.trim())}
      />
    </Page>
  );
}
