import { useCallback, useEffect, useState, useRef } from "react";
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  getDocs,
  startAfter,
  QueryDocumentSnapshot,
  DocumentData,
} from "firebase/firestore";
import { db } from "../firebase/client";
import { friendly } from "../utils/errors";
import type { Post } from "../types";
const base = () =>
  [where("audience", "==", "public"), orderBy("createdAt", "desc")] as const;
export function useFeed() {
  const [first, setFirst] = useState<Post[]>([]),
    [more, setMore] = useState<Post[]>([]),
    [loading, setLoading] = useState(true),
    [paging, setPaging] = useState(false),
    [hasMore, setHasMore] = useState(false),
    [error, setError] = useState(""),
    [offline, setOffline] = useState(false),
    [version, setVersion] = useState(0),
    cursor = useRef<QueryDocumentSnapshot<DocumentData> | undefined>(undefined),
    busy = useRef(false);
  useEffect(() => {
    setMore([]);
    setLoading(true);
    setError("");
    cursor.current = undefined;
    return onSnapshot(
      query(collection(db, "posts"), ...base(), limit(20)),
      { includeMetadataChanges: true },
      (snap) => {
        setFirst(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Post));
        if (!cursor.current) cursor.current = snap.docs[snap.docs.length - 1];
        setHasMore(snap.size === 20);
        setLoading(false);
        setOffline(snap.metadata.fromCache);
      },
      (e) => {
        setError(friendly(e));
        setLoading(false);
      },
    );
  }, [version]);
  const loadMore = useCallback(async () => {
    if (!cursor.current || busy.current || !hasMore) return;
    busy.current = true;
    setPaging(true);
    try {
      const snap = await getDocs(
        query(
          collection(db, "posts"),
          ...base(),
          startAfter(cursor.current),
          limit(20),
        ),
      );
      setMore((rows) => [
        ...rows,
        ...snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Post),
      ]);
      cursor.current = snap.docs[snap.docs.length - 1];
      setHasMore(snap.size === 20);
      setError("");
    } catch (e) {
      setError(friendly(e));
    } finally {
      busy.current = false;
      setPaging(false);
    }
  }, [hasMore]);
  const rows = Array.from(
    new Map([...first, ...more].map((p) => [p.id, p])).values(),
  );
  return {
    rows,
    loading,
    error,
    offline,
    paging,
    hasMore,
    loadMore,
    refresh: () => setVersion((v) => v + 1),
  };
}
