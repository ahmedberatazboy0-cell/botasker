import { create } from "zustand";
import type { User } from "firebase/auth";
import type { Profile } from "../types";
export const useSession = create<{
  user: User | null;
  profile: Profile | null;
  ready: boolean;
  set: (
    v: Partial<{ user: User | null; profile: Profile | null; ready: boolean }>,
  ) => void;
}>((set) => ({ user: null, profile: null, ready: false, set: (v) => set(v) }));
