import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors as c } from "../constants/theme";
import { friendly } from "../utils/errors";
export const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: c.bg },
  pad: { padding: 22, gap: 18 },
  title: { fontSize: 32, fontWeight: "700", color: c.text, letterSpacing: -1 },
  text: { color: c.text, fontSize: 15, lineHeight: 22 },
  muted: { color: c.muted, fontSize: 13, lineHeight: 20 },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  card: { backgroundColor: c.surface, borderRadius: 24, padding: 18, gap: 14 },
  input: {
    backgroundColor: c.surface,
    color: c.text,
    borderWidth: 1,
    borderColor: c.line,
    borderRadius: 16,
    padding: 16,
    fontSize: 15,
  },
  button: {
    backgroundColor: c.accent,
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderRadius: 16,
    alignItems: "center",
  },
  buttonText: { color: "#20150f", fontWeight: "700", fontSize: 14 },
  error: { color: c.danger, lineHeight: 21 },
  divider: { height: 1, backgroundColor: c.line },
});
export function Label({
  children,
  muted = false,
}: {
  children: React.ReactNode;
  muted?: boolean;
}) {
  return <Text style={muted ? styles.muted : styles.text}>{children}</Text>;
}
export function Field(props: React.ComponentProps<typeof TextInput>) {
  return (
    <TextInput
      placeholderTextColor={c.muted}
      autoCapitalize="none"
      {...props}
      accessibilityLabel={props.accessibilityLabel || props.placeholder}
      style={[styles.input, props.style]}
    />
  );
}
export function Button({
  title,
  onPress,
  disabled = false,
  secondary = false,
}: {
  title: string;
  onPress: () => void | Promise<unknown>;
  disabled?: boolean;
  secondary?: boolean;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  return (
    <View style={{ gap: 6 }}>
      <Pressable
        accessibilityRole="button"
        accessibilityState={{ disabled: disabled || busy }}
        disabled={disabled || busy}
        onPress={async () => {
          setBusy(true);
          setError("");
          try {
            await onPress();
          } catch (e) {
            setError(friendly(e));
          } finally {
            setBusy(false);
          }
        }}
        style={[
          styles.button,
          secondary && {
            backgroundColor: c.surface,
            borderWidth: 1,
            borderColor: c.line,
          },
          (disabled || busy) && { opacity: 0.45 },
        ]}
      >
        {busy ? (
          <ActivityIndicator color={c.text} />
        ) : (
          <Text style={[styles.buttonText, secondary && { color: c.text }]}>
            {title}
          </Text>
        )}
      </Pressable>
      {!!error && (
        <Text accessibilityRole="alert" style={styles.error}>
          {error}
        </Text>
      )}
    </View>
  );
}
export function Page({
  children,
  title,
  scroll = true,
}: {
  children: React.ReactNode;
  title?: string;
  scroll?: boolean;
}) {
  return (
    <SafeAreaView edges={["top", "left", "right"]} style={styles.page}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        {scroll ? (
          <ScrollView
            keyboardShouldPersistTaps="handled"
            contentContainerStyle={styles.pad}
          >
            {title && <Text style={styles.title}>{title}</Text>}
            {children}
          </ScrollView>
        ) : (
          <View style={{ flex: 1 }}>
            {title && (
              <Text style={[styles.title, { padding: 22 }]}>{title}</Text>
            )}
            {children}
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
export function State({
  loading,
  error,
  empty,
  retry,
}: {
  loading?: boolean;
  error?: string;
  empty?: boolean;
  retry: () => void;
}) {
  return (
    <View style={{ padding: 22, gap: 12 }}>
      {loading ? (
        <>
          <View
            style={{
              height: 20,
              width: "45%",
              backgroundColor: c.surface,
              borderRadius: 10,
            }}
          />
          <View
            style={{
              height: 160,
              backgroundColor: c.surface,
              borderRadius: 20,
            }}
          />
          <ActivityIndicator color={c.accent} />
        </>
      ) : error ? (
        <>
          <Text style={styles.error}>{error}</Text>
          <Button title="Tekrar dene" onPress={retry} />
        </>
      ) : empty ? (
        <Label muted>Burada henüz bir şey yok. İlk adımı sen at.</Label>
      ) : null}
    </View>
  );
}
