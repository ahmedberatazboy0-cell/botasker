import { test, expect } from "@playwright/test";
test("first render, onboarding, login/reset navigation and onboarding persistence", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(
    page.getByText("Arkadaşlarını bul", { exact: true }),
  ).toBeVisible({ timeout: 60000 });
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await expect(
    page.getByText("Anlarını paylaş", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await expect(
    page.getByText("Birlikte daha fazlasını yaşa", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(page.getByText("İyi ki geldin.", { exact: true })).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Giriş yap", exact: true }),
  ).toBeDisabled();
  await page.screenshot({ path: "artifacts/auth-mobile.png", fullPage: true });
  await page
    .getByRole("button", { name: "Şifremi unuttum", exact: true })
    .click();
  await expect(
    page.getByText("Yeniden bağlan.", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByText("İyi ki geldin.", { exact: true })).toBeVisible();
  expect(errors).toEqual([]);
});
