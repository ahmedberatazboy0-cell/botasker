# Birarada mobil

React Native + Expo SDK 54, TypeScript, React Navigation 7, Zustand ve Firebase JS SDK. Koyu antrasit yüzeyler, gün batımı turuncusu, Türkçe arayüz. Bu ZIP, kaynak depodaki eski Express web uygulamasından bağımsız mobil projeyi içerir.

## Kurulum ve çalıştırma

Node.js 20.19+ (bu ortamda 24.19), npm ve Expo Go SDK 54 ile uyumlu cihaz veya development build kullanın.

```sh
cd Birarada
npm ci
npx expo start
# Ağ kısıtlı bulut ortamında:
npx expo start --offline
# Web:
npm run web -- --offline
# Android SDK/emulator bulunan makinede:
npm run android
# macOS + Xcode üzerinde:
npm run ios
```

**ZIP’i çıkardıktan sonra komutları `Birarada` klasöründe çalıştırın.** Kaynak GitHub deposunda mobil uygulama `mobile/` altındadır. Kaynak deponun kökündeki `npm install`, eski web sunucusunu ve verileri değiştiren bir preinstall içerir; bu ZIP’teki mobil kurulum o adıma ihtiyaç duymaz.

## Firebase kurulumu

Kullanıcının verdiği `birarada-5650c` public istemci yapılandırması `src/firebase/client.ts` içindedir. Bu bir Admin SDK anahtarı değildir. Projede service account veya özel anahtar yoktur.

1. Firebase Console → Authentication → Sign-in method: Email/Password etkinleştirin. Web Google girişi için Google sağlayıcısını da etkinleştirin; yetkili alan adlarına gerçek web alan adınızı ekleyin. Google popup yalnız web sürümünde açıktır. Native OAuth istemcisi/development build entegrasyonu bu teslimatta yoktur; native Google düğmesi disabled görünür.
2. Cloud Firestore oluşturun. Varsayılan açık/test kurallarını kullanmayın. Kuralları ve indeksleri inceleyin, emulator testleri geçtikten sonra yetkili hesabınızla yayımlayın:

```sh
npx firebase login
npx firebase deploy --project birarada-5650c --only firestore:rules,firestore:indexes
```

Bu teslimatta canlı Firebase projesine kural, kullanıcı, veri veya altyapı dağıtılmadı. Bileşik indeksler oluşturulmadan ilgili sorgular hata gösterebilir.

3. Varsayılan gizlilik açık, yabancı DM izni kapalı. Yeni kullanıcı Auth kaydından sonra benzersiz kullanıcı adı ve profil oluşturur; kullanıcı adı rezervasyonu ile profil tek transaction içinde yazılır. Profil oluşturma başarısızsa aynı oturumda tekrar denenebilir.
4. Storage **varsayılan kapalıdır**. Spark üzerinde Storage erişimi/faturalandırması varsayılmaz. Galeri ve kamera butonları kapalı görünür; metin paylaşımı kullanılabilir. `storage.rules` tüm erişimi reddeder. Gizli medya için yetkilendirilmiş sunucu erişimi kurulmadan `EXPO_PUBLIC_STORAGE_ENABLED=true` yapmayın: Firebase indirme tokenları paylaşıldığında profil gizliliği sağlamaz. Storage sözleşmesi `src/services/social.ts` içinde ayrıdır.

## Yerel emulator

Java 21+ gerekir. Emulator testleri canlı projenizi kullanmaz.

```sh
npm run test:rules
# Ayrı terminalde backend:
npx firebase emulators:start --project demo-birarada --only auth,firestore
# Uygulama:
EXPO_PUBLIC_USE_EMULATORS=true npx expo start --web --offline
```

Android emulator için `EXPO_PUBLIC_EMULATOR_HOST=10.0.2.2`, fiziksel cihaz için geliştirici makinesinin LAN IP adresini kullanın. Production build'de emulator bayrağını açmayın.

Bu bulut ortamında yazılabilir önbellek seçenekleri:

```sh
FIREBASE_EMULATORS_PATH=/workspace/.cache/firebase/emulators \
XDG_CONFIG_HOME=/workspace/.config \
XDG_CACHE_HOME=/workspace/.cache npm run test:rules
```

## Doğrulama

```sh
npm run typecheck
npm test
npm run test:rules
npx playwright test
npm run export:web
npx expo export --platform android --platform ios --output-dir dist-native
```

Playwright testi sistemde `/usr/bin/chromium` kullanır; başka makinede `CHROMIUM_PATH` ile kurulu Chromium yolunu verin. İlk açılış testi gerçek kullanıcı oluşturmaz ve Firebase akışlarını test ettiği anlamına gelmez. Detaylar [TEST_REPORT.md](TEST_REPORT.md).

## Build

```sh
# JS + asset paketleri; APK/IPA değildir:
npx expo export --platform android --platform ios
# Mağaza binary'si: Expo hesabı, EAS projesi ve imzalama gerekir
npx eas-cli build:configure
npx eas-cli build --platform android --profile preview
npx eas-cli build --platform ios --profile production
```

EAS yapılandırmasını kendi Expo hesabınızda oluşturun. Bu ortamda Android/iOS native binary derlenmedi veya imzalanmadı. iOS cihaz dağıtımı için Apple geliştirici hesabı gerekir.

## Veri ve erişim modeli

- `users/{uid}`: herkese açık profil; e-posta Firebase Auth'ta kalır. Kullanıcı yalnız kendi profilini düzenleyebilir. Kimlik, kullanıcı adı ve sayaç alanları client güncellemelerine kapalıdır. Sayaçlar şu anda arayüzde gösterilmez; güvenilir sunucu agregasyonu henüz yoktur.
- `usernames/{name}`: transaction içinde benzersiz kullanıcı adı rezervasyonu.
- `posts/{id}`: içerik ve oluşturulurken sabitlenen `audience`. Gizli gönderiler onaylı takipçilere açıktır. Ana akış herkese açık gönderileri sayfalı getirir; gizli gönderiler yazarın profilinden okunur. Hesap gizliliği eski gönderilerin erişimini değiştirmez; arayüz bunu açıklar.
- `posts/{id}/likes/{uid}` ve `comments/{id}`: erişim üst gönderinin görünürlüğüne bağlıdır. Client beğeni/yorum sayacı değiştiremez. Beğeni ekranı 500 kayıtta `500+` gösterir.
- `follows/{followerUid}_{followingUid}`: gizli hesap için pending, yalnız hedef kullanıcı accepted yapabilir. Takip değiştirme transaction ile yapılır.
- `chats/{id}` ve `messages/{id}`: yalnız üyeler okur. Yeni sohbet ve mesaj yazma, alıcının yabancı DM tercihini ve engellemeleri kontrol eder. Metin mesajı, düzenleme, silme ve görüldü desteklenir.
- `notifications/{id}`: takip bildirimleri transaction içinde üretilir; yalnız alıcı okur/okundu yapar. Diğer bildirim türleri henüz üretilmez.
- `saved/{uid}/posts/{id}`: yalnız sahibi erişebilir.
- `users/{uid}/blocks/{targetUid}` ve `reports/{id}`: engelleme ve raporlama. Raporlar istemciden okunamaz; moderasyon yönetim sistemi henüz yoktur.

Engelleme gizli gönderi ve yeni DM yazımını sınırlar; herkese açık gönderiler güvenlik açısından herkese açık kalır, kendi engellediğiniz hesaplar ana akışta gizlenir. Mevcut sohbet geçmişi üyelerce okunmaya devam eder.

## Offline ve performans

Web Firestore IndexedDB persistence, native Auth AsyncStorage persistence kullanır. Native Firestore JS SDK kalıcı disk önbelleği sağlamaz; native offline kalıcılık tamamlanmış değildir. Cache yanıtı arayüzde belirtilir. FlatList, memoized gönderi kartları, sayfalama ve expo-image cache kullanılır. Kısa videolarda yalnız görünür ve odaklanmış öğe oynar. Kullanıcı listesindeki arama kullanıcı adı önekiyle çalışır.

## Üretim öncesi

Bu sürüm tam ürün kapsamını bitirmiş değildir. Anlar/Yakınlar, grup sohbeti, ses/medya DM, mesaj cevap/reaksiyon, hashtag/içerik arama, push, yaş bazlı denetimler, kullanıcı adı değiştirme, öne çıkanlar, repostlar ve native Google OAuth yoktur. Bunlar için işlevsiz butonlar gösterilmez. Akış testleri ve kurallar doğrulanmadan gerçek kullanıcılarla yayınlamayın. Sunucu tabanlı spam/rate limiting, App Check, moderasyon, veri silme/alt koleksiyon temizliği, medya yetkilendirmesi ve hukuki metinler ayrıca tamamlanmalıdır.
