# Birarada test raporu

Tarih: 19 Ekim 2026. Ortam: Linux, Node.js 24.19.0, Expo SDK 54. Bu rapor `mobile/` uygulamasına aittir; eski kök Express uygulamasının test sonuçları ayrı bir iş akışıdır.

## Gerçekten doğrulananlar

### Windows başlatıcı eklemesi

`başlat.bat` ve ASCII isimli `baslat.bat`, `scripts/start-local.cjs` üzerinden yerel Firebase + Expo test ortamını açar. Başlatıcı için Node.js yerleşik test runner'ıyla 10 test geçti: sürüm sınırları, Java sürümü çözümleme, test ortamı ayarları, dolu portta mevcut servisi koruma, HTTP hazır olma/timeout/bağlantı hatası, beklenmedik süreç çıkışı ve yalnızca başlatılan süreç ağacını temizleme. Boşluk ve Türkçe karakter içeren dizin de test edildi. BAT dosyalarının CRLF satır sonları ve paket içindeki yardımcı dosya kontrol edildi. Bunlar Linux üzerinde yapılan testlerdir; Windows'ta gerçek çift tıklama ve tam Firebase + Expo açılışı henüz doğrulanmadı. Windows'ta üst süreç beklenmedik biçimde çökerse Java alt süreçlerinin temizliği garanti edilmez; normal Ctrl+C kapatması kendi süreç ağacını hedefler. Aşağıdaki Firestore emulator indirme engeli tam açılış testini de sınırlayabilir.

Gerçek başlatıcı `--no-open` ile de çalıştırıldı: Node/Java kontrolü, `npm ci --include=dev` kurulumu ve Firebase başlatma adımı gerçekleşti. Firestore jar indirmesi aynı ağ engeline takıldı; başlatıcı hatayı gösterip 1 koduyla çıktı. Expo adımına ulaşılmadı. Sonrasında test portlarının boş kaldığı kontrol edildi.

| Kontrol | Sonuç | Kapsam |
| --- | --- | --- |
| TypeScript `tsc --noEmit` | Geçti | strict kontrol, uygulama ve test dosyaları |
| `npm test` | 2 test geçti | Türkçe Firebase hata eşlemeleri, hata ayrıntısı sızdırmama, kullanıcı adı validasyonu |
| `npm run test:auth` | 1 test geçti | Gerçek Firebase Authentication Emulator üzerinde kayıt, çıkış, yanlış şifre reddi, tekrar giriş, şifre sıfırlama isteği; demo hesap test sonunda silindi |
| `npx playwright test` | 1 test geçti | 390×844 Chromium: ilk render, 3 onboarding ekranı, login ekranı, boş formda disabled giriş, şifre sıfırlama ekranına geçiş, onboarding tercihinin reload sonrası korunması, sıfır pageerror |
| `expo export --platform all` | Geçti | Web, Android ve iOS JS/asset paketleri; native Hermes paketleri üretildi |
| Expo bağımlılık uyumu | Offline kontrol geçti | SDK'nın yerel önerileriyle uyumlu; çevrimiçi sürüm sorgusu yapılmadı |

Ekran görüntüsü: [artifacts/auth-mobile.png](artifacts/auth-mobile.png).

## Çalıştırılamayan kontroller

`npm run test:rules` başlatıldı ancak Firestore Emulator jar dosyası indirilemedi. `storage.googleapis.com` CONNECT isteği ortam proxy'sinden HTTP 403 aldı. Test runner aşamasına ulaşılmadı: **7 güvenlik testi çalışmadı; sıfırının geçtiği iddia edilmiyor.**

Hazır testler: profil sahipliği ve sayaç değişikliği reddi; gizli içerik + onaylı takip + engelleme; gönderi silme yetkisi ve public feed sorgusu; takip isteğinin yalnız hedef tarafından kabulü; sohbet üyeliği; yabancı DM tercihi/görüldü/mesaj düzenleme; atomik kullanıcı adı/profil oluşturma. Bu testler ve rules derlemesi, ağ erişimi sağlanınca mutlaka çalıştırılmalı.

Firestore CRUD, profil oluşturma/düzenleme, gönderi oluşturma/beğeni/yorum, takip/takipten çıkma, DM ve bildirimlerin uygulama üzerinden uçtan uca testi **yapılmadı**. Servis çağrıları gerçek Firebase SDK'sına bağlıdır; mock veri yoktur. Auth emulator testi SDK akışını doğrular; uygulama + Firestore entegrasyon testinin yerine geçmez.

Canlı `birarada-5650c` projesinde Auth sağlayıcılarının/Firestore veritabanının etkinliği, mevcut kurallar, indeksler ve OAuth yetkili alan adları doğrulanmadı. Canlı projeye dağıtım veya test kullanıcısı ekleme yapılmadı. Android/iOS cihazında çalıştırma, imzalı APK/IPA, Google OAuth, gerçek medya, video oynatma, push ve gerçek çevrimdışı senaryolar test edilmedi.

## Uygulanan işlevler

- Firebase email/şifre kayıt/giriş/çıkış/sıfırlama; native Auth kalıcılığı; web Google popup entegrasyonu.
- Ayrı profil tamamlama adımı, atomik kullanıcı adı rezervasyonu, profil düzenleme, varsayılan gizli hesap.
- Public feed, cursor sayfalama, yenileme, boş/hata/loading ekranları; profil gönderileri; beğeni, çift dokunma, yorum, paylaşım, kaydetme ve kaydedilenler ekranı; sahibi için gönderi silme.
- Takip/istek/geri çekme/kabul/ret; kendi takipçi ve takip listeleri.
- Kullanıcı adı önekiyle keşfet; profil açma, engelleme/engeli kaldırma ve raporlama.
- Üye sohbetleri, metin mesajı gönderme/düzenleme/silme, görüldü; yabancı DM tercihi ve blok kontrolü kuralları.
- Takip bildirimleri ve okundu işaretleme; bekleyen takip istekleri.
- Metin paylaşma, cihazda açıklama taslağı; isteğe bağlı medya adapteri (kapalı); public video listesinde görünür/odaktaki video oynatma.
- 5 sekmeli gezinme; koyu tema ve Türkçe; ayarlar.

Bu liste **kod kapsamını** anlatır. Yukarıda ayrıca doğrulanmayan işlevlerin canlı ortamda çalıştığı iddia edilmez.

## Bilinen sınırlar ve kapsam eksikleri

- İstenen ürün kapsamı tamamlanmış değildir: Anlar/Yakınlar, öne çıkanlar, grup/medya/ses DM, yazıyor bilgisi, mesaj cevabı/reaksiyonu, hashtag/içerik araması, repost/etiketlenenler, native Google OAuth, push ve yaş bazlı güvenlik yoktur; işlevsiz düğmeler gösterilmez.
- Storage erişimi ve güvenli özel medya yetkilendirmesi yoktur. Galeri/kamera disabled. `storage.rules` tamamen kapalı tutulur. Public indirme tokenları gizli içerik garantisi sağlamaz.
- Profil alanları signed-in kullanıcılara açıktır; e-posta Auth'ta kalır. Sayaçlar istemcide değiştirilemez fakat sunucu hesaplaması yoktur, UI'da gösterilmez.
- Hesap gizliliği önceki gönderilerin audience alanını dönüştürmez. Public içerik public kalır; kendi engellediğiniz hesaplar feed'de filtrelenir. Eski sohbetler üyelerce okunabilir, yeni mesajlar engel/DM tercihine tabidir.
- Feed yalnız public gönderileri listeler; takipçiye özel gönderiler yazar profilinden görülür. Kullanıcı araması önek aramasıdır. Profil, sohbet ve yorum listeleri ilk sayfa limitlerine sahiptir; ana feed cursor ile devam eder.
- Takip bildirimleri dışında beğeni/yorum/mention bildirimleri ve push üretilmez. Metin bildirimleri client transaction ile yazılır; sunucu spam koruması henüz yoktur.
- Native Firestore disk kalıcılığı yoktur. Web IndexedDB cache vardır; cache yanıtı kesin internet kesintisi göstergesi değildir.
- Gönderi silme alt koleksiyonları otomatik temizlemez. Moderasyon kuyruğu için yalnız rapor kaydı vardır; yönetim/işleme sistemi yoktur.

## Üretim öncesi zorunlu işler

1. Ortam ayarlarındaki ağ taslağını uygulayın: emulator için `storage.googleapis.com`; istemci erişimi için `identitytoolkit.googleapis.com`, `securetoken.googleapis.com`, `firestore.googleapis.com`, `birarada-5650c.firebaseapp.com`, `accounts.google.com`, `www.googleapis.com`. Kayıtlı ağ değişiklikleri mevcut runtime'a otomatik uygulanmış sayılmaz.
2. Firestore emulator testlerini çalıştırın ve tüm kritik akışlar için gerçek uygulama + emulator E2E testleri ekleyip geçirin; keşfedilen rules/indeks sorunlarını düzeltin. Sonrasında kendi Firebase projenizde sağlayıcıları etkinleştirin, kuralları ve indeksleri inceleyerek yayımlayın.
3. Gerçek iOS/Android cihaz testi ve native imzalı build; OAuth redirect/client yapılandırması, erişilebilirlik, klavye/safe area, ağ kesintisi ve video performansı doğrulaması yapın.
4. App Check, güvenilir rate limiting, bildirim/counter altyapısı, kötüye kullanım denetimi, hesap/veri silme, alt koleksiyon temizliği, yaşa uygun politikalar ve hukuki metinler tamamlanmalı.

Bu teslimat, tam ürünün veya production hazırlığının tamamlandığı anlamına gelmez.
