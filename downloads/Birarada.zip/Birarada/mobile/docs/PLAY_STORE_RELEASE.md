# Birarada — ilk Play Store AAB adayı

Bu mobil proje, kullanıcının belirlediği sabit kimlikle ilk Android App Bundle adayını hazırlamak içindir. `Birarada.html` tarayıcı demosudur; kaynak ZIP'i, HTML ve `expo export` çıktısı Play Store'a yüklenen imzalı `.aab` dosyası değildir.

## Sabit uygulama kimliği

| Alan | Bu adayın değeri |
| --- | --- |
| Uygulama adı | Birarada |
| Android applicationId | `com.birarada.app` |
| iOS bundle identifier | `com.birarada.app` |
| Sürüm adı / versionName | `1.0.0` |
| Android versionCode | `1` |
| Firebase projesi | `birarada-5650c` |
| Gizlilik politikası | `https://birarada-5650c.web.app/privacy` |
| Hesap silme sayfası | `https://birarada-5650c.web.app/delete-account` |
| Kullanım ve topluluk kuralları | `https://birarada-5650c.web.app/terms` |
| Destek | `ahmedberatazboy0@gmail.com` |

Android ve iOS kimlikleri `app.json` ile `app.config.ts` içinde ayarlıdır. İlk adayın sürüm adı ve kodu sabittir. Paket adını veya bu adayın kodunu farklı bir değere çevirmeye çalışan ortam değişkenleri reddedilir; paket adı değişkeni girmeniz gerekmez. İlerideki Android sürümlerinde `versionCode` önceki yüklemelerden büyük olmalıdır. Bunun için `app.json` ve `scripts/release-check.cjs` içindeki sürüm değerlerini yeni sürüme göre birlikte güncelleyin. EAS bu yapılandırmada sürüm kodunu kendiliğinden artırmaz.

Verilen hukuki URL'ler uygulama ve EAS yapılandırmasına işlendi. URL'nin yapılandırmada bulunması sayfanın yayımlandığını veya metnin onaylandığını kanıtlamaz. Yayından önce üç sayfa da oturum gerektirmeden, gerçek içerikle açılmalı; hesap silme talebi ve destek süreci gerçekten işlemelidir.

## Bu hazırlıkta ne doğrulandı?

- `eas.json` içindeki `production` profili mağaza için AAB, `preview` profili cihaz testi için APK üretmek üzere ayarlı.
- Üretim yapılandırması emulator bağlantısını ve Storage'ın açılmasını reddeder; gerçek EAS proje UUID'si gerektirir. Demo/test Firebase projesine yönlendiren çelişkili proje ayarları kabul edilmez.
- 1024×1024 uygulama simgesi, Android adaptive ve monochrome simgeleri eklendi. Android yedekleme kapalı. Kullanılmayan kamera, mikrofon, medya/depolama, ekran üstü pencere ve titreşim izinleri engellendi.
- İzole Android prebuild, native proje ve simge kaynakları üretme kontrolüdür; imzalı AAB veya gerçek cihaz testi değildir. Nihai birleştirilmiş manifest ayrıca derlenen AAB üzerinde kontrol edilmelidir.
- Bu hazırlıkta kimliği doğrulanmış Expo/EAS oturumu veya yeni EAS projesinin gerçek UUID'si sağlanmadı. İmzalı EAS mağaza AAB'sinin hazır olduğu iddia edilmiyor. Yerel native derleme dahil güncel test sonuçları ve açık engeller [TEST_REPORT.md](../TEST_REPORT.md) dosyasındadır.

## Yeni Expo/EAS projesini oluşturma

Bu uygulamaya ait bir EAS projesi henüz yok. Kendi Expo hesabınızda yeni proje oluşturun. Komutları kökteki eski web uygulamasında değil, `mobile` klasöründe çalıştırın:

```sh
npm ci
npx eas-cli login
npx eas-cli init
```

`init` akışında kendi hesabınızı veya yetkili olduğunuz organizasyonu ve Birarada için **yeni proje oluşturmayı** seçin. EAS'in döndürdüğü gerçek proje UUID'sini alın. Dinamik `app.config.ts` kullanıldığı için CLI yapılandırmaya otomatik yazamıyorsa dosyaya sahte bir UUID eklemeyin: yerel, Git'e eklenmeyen `.env.local` dosyanızda `EAS_PROJECT_ID` değişkenine bu gerçek UUID'yi yazın. Gerekirse `EXPO_ACCOUNT_OWNER` değişkenine seçtiğiniz hesap/organizasyon adını ekleyin.

Giriş ve proje oluşturma işlemleri Expo hesabınızın kimlik doğrulamasını gerektirir. Parola, erişim tokenı, keystore veya servis hesabı anahtarını sohbete ya da kaynak ZIP'ine koymayın. EAS'in güvenli oturum ve credential yönetimini kullanın. Üretilmemiş proje kimliği veya imza bilgisi uydurulmaz.

Ardından doğru projeye bağlandığınızı kontrol edin:

```sh
npx eas-cli project:info
```

`EAS_PROJECT_ID` gerçek yeni projenizle eşleşmelidir. Bu UUID herkese açık proje kimliğidir; imzalama anahtarı değildir. Dinamik yapılandırma bunu `extra.eas.projectId` alanına taşır.

## Yerel ve EAS üretim değişkenleri

`production` ve `preview` EAS profillerinde aşağıdaki gerçek, herkese açık uygulama değerleri hazırdır. Yerel `release-check` komutu için `.env.local` dosyanıza şu iki güvenli bayrağı ve oluşturduğunuz projenin **gerçek** `EAS_PROJECT_ID` değerini ekleyin:

```env
EXPO_PUBLIC_USE_EMULATORS=false
EXPO_PUBLIC_STORAGE_ENABLED=false
```

`EAS_PROJECT_ID` için burada yer tutucu değer verilmez; `init` sonucundaki UUID kullanılmalıdır. Üç hukuki URL ve destek e-postası varsayılan olarak yukarıdaki gerçek adreslerdir. Açıkça verilen URL değişkenleri bunları geçersiz kılabilir; boş, HTTP, localhost, test veya örnek alan adlı değerler üretim kontrolünde reddedilir.

| Değişken | Kullanım |
| --- | --- |
| `EAS_PROJECT_ID` | Yeni oluşturduğunuz Expo/EAS projesinin gerçek UUID'si; zorunlu |
| `EXPO_ACCOUNT_OWNER` | Gerekirse Expo hesap/organizasyon adı |
| `EXPO_PUBLIC_USE_EMULATORS` | Üretimde tam olarak `false` |
| `EXPO_PUBLIC_STORAGE_ENABLED` | Bu sürümde tam olarak `false` |
| `EXPO_PUBLIC_FIREBASE_PROJECT_ID` | Verilirse yalnız `birarada-5650c`; EAS profillerinde ayarlı |
| `EXPO_PUBLIC_PRIVACY_POLICY_URL` | Varsayılan `https://birarada-5650c.web.app/privacy` |
| `EXPO_PUBLIC_DELETE_ACCOUNT_URL` | Varsayılan `https://birarada-5650c.web.app/delete-account` |
| `EXPO_PUBLIC_TERMS_URL` | Varsayılan `https://birarada-5650c.web.app/terms` |
| `EXPO_PUBLIC_SUPPORT_URL` | Varsayılan `mailto:ahmedberatazboy0@gmail.com` |

Bu `EXPO_PUBLIC_*` değerleri uygulama paketine girer; gizli anahtar saklamak için kullanılmaz. EAS `production` ve `preview` ortamlarına proje UUID'sini gerektiği şekilde ekleyin; EAS CLI'nin yerelde proje çözümlemesi için de aynı UUID erişilebilir olmalıdır.

## Kontroller ve cihaz APK'sı

```sh
npm run typecheck
npm test
npm run test:auth
npm run test:rules
node scripts/release-check.cjs
```

Emulator testleri canlı Firebase'i kullanmaz. Üretimde ise `birarada-5650c` projesinde Authentication sağlayıcıları, Firestore kuralları ve indeksleri kurulmuş olmalıdır. Test edilen kuralların canlıya kendiliğinden dağıtıldığını varsaymayın. Storage ve medya yükleme bu adayda kapalı kalır.

EAS'e giriş ve gerçek proje bağlantısı tamamlandıktan sonra:

```sh
npx eas-cli build --platform android --profile preview
```

EAS'in APK çıktısını gerçek Android telefona kurun. `preview` profili emulator kullanmaz; varsayılan istemci `birarada-5650c` projesine bağlanır. Test hesapları kullanın; test verisi gerçek Firebase'e yazılabilir. Gerçek cihazda aşağıdaki akışları doğrulayın:

1. Kayıt, giriş, çıkış, parola sıfırlama, profil düzenleme ve uygulamayı kapatıp yeniden açma.
2. İki hesapla takip isteği/kabul, gizli gönderilere erişim, metin paylaşımı, beğeni ve yorum.
3. DM, engelleme, raporlama ve engellenen kullanıcıya yeni mesaj yazılamaması.
4. Ağ kesintisi ve başarısız işlem mesajları; hata durumunu başarı olarak göstermemesi.
5. Hesap silme, silinen hesapla yeniden girişin başarısız olması ve kişisel veri kalıntılarının incelenmesi. Web silme talebi ve destek süreci de test edilmeli.

## İmzalı ilk AAB

Testler ve canlı altyapı kontrolleri tamamlanınca:

```sh
node scripts/release-check.cjs
npx eas-cli build --platform android --profile production
```

Yeni proje ve ilk uygulama için EAS'in Android imzalama anahtarı oluşturma/yönetme akışını kullanın. Anahtarları ve parolaları güvenli şekilde yedekleyin; kaynak koduna veya sohbete koymayın. Sonraki sürümlerde aynı uygulama kimliğini ve geçerli yükleme imzasını koruyun. Play App Signing etkinleştirilirse EAS yükleme anahtarı ile Play'in dağıtım anahtarının farklı rolleri olduğunu dikkate alın.

EAS build sayfasından indirilen **imzalı `.aab`** Play Console'a yüklenecek dosyadır. Geçici `expo prebuild` projesindeki debug imzasıyla yerel `bundleRelease` çalıştırmak mağaza teslimatı sayılmaz. Nihai AAB üzerinde paket adı `com.birarada.app`, versionName `1.0.0`, versionCode `1`, yükleme imzası ve izinleri doğrulayın.

Bu dosyadaki komutlar çalıştırılıp başarıyla sonuçlanmadan bir üretim AAB'sinin hazır olduğunu varsaymayın. Bu hazırlık sırasında Play Store'a uygulama yükleme veya yayımlama yapıldığı iddia edilmiyor.

## Play Console'a geçmeden önce

- Gizlilik, kullanım/topluluk kuralları ve hesap silme sayfalarının herkese açık olduğunu ve gerçek veri işlemeyi anlattığını doğrulayın. Raporları inceleyecek moderasyon ve destek sorumlusunu belirleyin; yalnız rapor düğmesi yeterli değildir.
- App content, Data safety, içerik derecelendirmesi, hedef yaş grubu, reklam beyanı ve gerekiyorsa inceleme hesabını uygulamanın gerçek davranışına göre tamamlayın. Hesap, kullanıcı içeriği ve mesaj verilerinin Firebase'e gönderilmesini doğru beyan edin.
- İlk AAB'yi internal testing kanalına yükleyin. Pre-launch report ve gerçek Android cihaz sonuçlarını inceleyin; hesabınıza özel üretim erişimi/test koşullarını yerine getirin.
- Yayımlayacağınız tarihte güncel target API gereksinimini ve diğer politikaları resmi kaynaklardan ve Play Console'un AAB doğrulamasından kontrol edin. Kurulu Expo/RN 0.81 şablonunun yerel varsayılan target/compile SDK değeri **36** olarak incelendi; resmi politika sayfalarına ağ erişimi proxy 403 nedeniyle doğrulanamadı. Bu değer tek başına mağaza kabul garantisi değildir.

Resmi kaynaklar:

- [Android target API gereksinimleri](https://support.google.com/googleplay/android-developer/answer/11926878)
- [Play hesap silme gereksinimleri](https://support.google.com/googleplay/android-developer/answer/13327111)
- [Kullanıcıların oluşturduğu içerik politikası](https://support.google.com/googleplay/android-developer/answer/9876937)
- [Android uygulama imzalama](https://developer.android.com/studio/publish/app-signing)
- [EAS Android build](https://docs.expo.dev/build-reference/android-builds/)
- [EAS uygulama sürümleri](https://docs.expo.dev/build-reference/app-versions/)
