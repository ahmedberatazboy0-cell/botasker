import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  use: {
    baseURL: "http://127.0.0.1:8081",
    viewport: { width: 390, height: 844 },
    launchOptions: {
      executablePath: process.env.CHROMIUM_PATH || "/usr/bin/chromium",
      args: ["--no-sandbox"],
    },
  },
  webServer: {
    command:
      "CI=1 EXPO_NO_TELEMETRY=1 EXPO_PUBLIC_USE_EMULATORS=true npm run web -- --offline --port 8081",
    port: 8081,
    reuseExistingServer: true,
    timeout: 120000,
  },
});
