import { initializeApp } from "firebase/app";
import { initializeAuth, connectAuthEmulator } from "firebase/auth";
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  connectFirestoreEmulator,
} from "firebase/firestore";
import { persistence } from "./persistence";
import { Platform } from "react-native";
import { getStorage } from "firebase/storage";
const app = initializeApp({
  apiKey: "AIzaSyC2TYgUREM8QWSg_RcunLQfnb_GXGboHT8",
  authDomain: "birarada-5650c.firebaseapp.com",
  projectId:
    process.env.EXPO_PUBLIC_USE_EMULATORS === "true"
      ? "demo-birarada"
      : "birarada-5650c",
  storageBucket: "birarada-5650c.firebasestorage.app",
  messagingSenderId: "510479812993",
  appId: "1:510479812993:web:3276197b364a784414c080",
});
export const auth = initializeAuth(app, { persistence });
export const db = initializeFirestore(
  app,
  Platform.OS === "web"
    ? {
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
      }
    : {},
);
export const storage =
  process.env.EXPO_PUBLIC_STORAGE_ENABLED === "true" ? getStorage(app) : null;

if (process.env.EXPO_PUBLIC_USE_EMULATORS === "true") {
  const host = process.env.EXPO_PUBLIC_EMULATOR_HOST || "127.0.0.1";
  connectAuthEmulator(auth, `http://${host}:9099`, { disableWarnings: true });
  connectFirestoreEmulator(db, host, 8080);
}
