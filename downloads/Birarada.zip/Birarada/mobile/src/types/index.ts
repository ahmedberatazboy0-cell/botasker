export type Profile = {
  uid: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  website: string;
  isPrivate: boolean;
  followersCount: number;
  followingCount: number;
  postsCount: number;
  allowStrangerDM: boolean;
  deletionPending?: boolean;
};
export type Post = {
  id: string;
  uid: string;
  username: string;
  caption: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  createdAt?: { seconds: number };
  commentsEnabled: boolean;
};
export type Row = { id: string; [key: string]: any };
