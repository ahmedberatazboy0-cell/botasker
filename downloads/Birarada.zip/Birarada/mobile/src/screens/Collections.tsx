import React from "react";
import { Pressable, View, Text } from "react-native";
import {
  collection,
  doc,
  getDoc,
  query,
  where,
  limit,
} from "firebase/firestore";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useRows } from "../hooks/useRows";
import { Page, Label, State, styles } from "../components/ui";
import { PostCard } from "../components/PostCard";
import type { Post, Profile } from "../types";
import { friendly } from "../utils/errors";
function Person({ id, open }: { id: string; open: (id: string) => void }) {
  const [p, setP] = React.useState<Profile | null>(null),
    [error, setError] = React.useState("");
  React.useEffect(() => {
    let alive = true;
    setP(null);
    setError("");
    getDoc(doc(db, "users", id))
      .then((s) => {
        if (alive && s.exists()) setP(s.data() as Profile);
      })
      .catch((e) => {
        if (alive) setError(friendly(e));
      });
    return () => {
      alive = false;
    };
  }, [id]);
  return error ? (
    <View style={styles.card}>
      <Label muted>{error}</Label>
    </View>
  ) : p ? (
    <Pressable onPress={() => open(id)} style={styles.card}>
      <Text style={styles.text}>{p.displayName}</Text>
      <Label muted>@{p.username}</Label>
    </Pressable>
  ) : null;
}
export function Connections({ route, navigation }: any) {
  const current = useSession((s) => s.profile)!.uid,
    blocks = useRows(
      query(collection(db, "users", current, "blocks"), limit(200)),
    ),
    hidden = new Set(blocks.rows.map((row) => row.id)),
    isFollowing = route.params?.kind === "following",
    data = useRows(
      query(
        collection(db, "follows"),
        where(isFollowing ? "followerUid" : "followingUid", "==", current),
        where("status", "==", "accepted"),
        limit(100),
      ),
    );
  return (
    <Page title={isFollowing ? "Takip ettiklerin" : "Takipçilerin"}>
      <State
        loading={data.loading || blocks.loading}
        error={data.error || blocks.error}
        empty={
          !data.rows.some(
            (r) => !hidden.has(isFollowing ? r.followingUid : r.followerUid),
          )
        }
        retry={() => {
          data.refresh();
          blocks.refresh();
        }}
      />
      {!blocks.loading &&
        !blocks.error &&
        data.rows
          .filter(
            (r) => !hidden.has(isFollowing ? r.followingUid : r.followerUid),
          )
          .map((r) => (
            <Person
              key={r.id}
              id={isFollowing ? r.followingUid : r.followerUid}
              open={(uid) => navigation.push("User", { uid })}
            />
          ))}
    </Page>
  );
}
export function Saved({ navigation }: any) {
  const id = useSession((s) => s.profile)!.uid,
    blocks = useRows(query(collection(db, "users", id, "blocks"), limit(200))),
    hidden = new Set(blocks.rows.map((row) => row.id)),
    data = useRows(query(collection(db, "saved", id, "posts"), limit(100))),
    [posts, setPosts] = React.useState<Post[]>([]),
    [hydrating, setHydrating] = React.useState(false),
    [error, setError] = React.useState("");
  React.useEffect(() => {
    let active = true;
    setError("");
    setPosts([]);
    setHydrating(true);
    Promise.all(
      data.rows.map(async (row) => {
        try {
          const snap = await getDoc(doc(db, "posts", row.id));
          return snap.exists()
            ? ({ id: snap.id, ...snap.data() } as Post)
            : null;
        } catch (e) {
          if ((e as { code?: string })?.code === "permission-denied")
            return null;
          throw e;
        }
      }),
    )
      .then((rows) => {
        if (active) setPosts(rows.filter((p): p is Post => p !== null));
      })
      .catch((e) => {
        if (active) setError(friendly(e));
      })
      .finally(() => {
        if (active) setHydrating(false);
      });
    return () => {
      active = false;
    };
  }, [data.rows]);
  return (
    <Page title="Sana kalsın.">
      <Label muted>
        Silinen veya erişimin kaldırıldığı gönderiler gösterilmez.
      </Label>
      <State
        loading={data.loading || blocks.loading || hydrating}
        error={error || data.error || blocks.error}
        empty={!posts.some((p) => !hidden.has(p.uid))}
        retry={() => {
          data.refresh();
          blocks.refresh();
        }}
      />
      {!blocks.loading &&
        !blocks.error &&
        posts
          .filter((p) => !hidden.has(p.uid))
          .map((p) => (
            <PostCard
              key={p.id}
              post={p}
              blockedUids={hidden}
              openProfile={(uid) => navigation.push("User", { uid })}
            />
          ))}
    </Page>
  );
}
