import React, { useState, useRef } from "react";
import {
  View,
  Text,
  Switch,
  FlatList,
  useWindowDimensions,
  ViewToken,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Picker from "expo-image-picker";
import { Image } from "expo-image";
import { useIsFocused } from "@react-navigation/native";
import { useVideoPlayer, VideoView } from "expo-video";
import { collection, query, where, orderBy, limit } from "firebase/firestore";
import { db, storage } from "../firebase/client";
import { useSession } from "../store/session";
import { publish, upload, toggleLike, toggleSaved } from "../services/social";
import { useRows } from "../hooks/useRows";
import { Page, Label, Field, Button, State, styles } from "../components/ui";
import { friendly } from "../utils/errors";
import type { Post } from "../types";
export function Create() {
  const p = useSession((s) => s.profile)!,
    [caption, setCaption] = useState(""),
    [asset, setAsset] = useState<Picker.ImagePickerAsset | null>(null),
    [comments, setComments] = useState(true),
    [notice, setNotice] = useState("");
  React.useEffect(() => {
    AsyncStorage.getItem(`draft:${p.uid}`)
      .then((v) => {
        if (v) setCaption(v);
      })
      .catch((e) => setNotice(friendly(e)));
  }, [p.uid]);
  async function pick(camera = false) {
    const permission = camera
      ? await Picker.requestCameraPermissionsAsync()
      : await Picker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) throw Error("Medya erişim izni gerekli.");
    const result = camera
      ? await Picker.launchCameraAsync({ allowsEditing: true, quality: 0.8 })
      : await Picker.launchImageLibraryAsync({
          mediaTypes: ["images", "videos"],
          allowsEditing: true,
          quality: 0.8,
        });
    if (!result.canceled) setAsset(result.assets[0] || null);
  }
  return (
    <Page title="Bir an bırak.">
      <Label muted>
        {p.isPrivate
          ? "Gönderin yalnızca onaylı takipçilerine görünür."
          : "Gönderin herkese açık akışta görünür."}
      </Label>
      <Field
        placeholder="Aklında ne var?"
        multiline
        value={caption}
        onChangeText={setCaption}
        maxLength={2200}
        style={{ minHeight: 140 }}
      />
      {asset && (
        <>
          <Label>{asset.fileName || "Seçilen medya"}</Label>
          {asset.type === "image" && (
            <Image
              source={asset.uri}
              style={{ width: "100%", height: 220, borderRadius: 20 }}
            />
          )}
          <Button
            secondary
            title="Medyayı kaldır"
            onPress={() => setAsset(null)}
          />
        </>
      )}
      {storage && (
        <View style={styles.row}>
          <Button secondary title="Galeriden seç" onPress={() => pick()} />
          <Button secondary title="Kamera" onPress={() => pick(true)} />
        </View>
      )}
      {!storage && <Label muted>Bu sürümde metin paylaşabilirsin.</Label>}
      <View style={styles.row}>
        <Label>Yorumlara izin ver</Label>
        <Switch value={comments} onValueChange={setComments} />
      </View>
      <Button
        secondary
        title="Taslağı kaydet"
        onPress={async () => {
          await AsyncStorage.setItem(`draft:${p.uid}`, caption);
          setNotice(
            "Açıklaman bu cihazda taslağa kaydedildi. Medya yeniden seçilmeli.",
          );
        }}
      />
      <Button
        title="Paylaş"
        disabled={!caption.trim() && !asset}
        onPress={async () => {
          setNotice("");
          const url = asset ? await upload(asset.uri) : "";
          await publish(
            p,
            caption,
            url,
            asset?.type === "video" ? "video" : "image",
            comments,
          );
          setCaption("");
          setAsset(null);
          await AsyncStorage.removeItem(`draft:${p.uid}`);
          setNotice("Gönderin paylaşıldı.");
        }}
      />
      {!!notice && <Label>{notice}</Label>}
    </Page>
  );
}
function Video({
  post,
  active,
  height,
}: {
  post: Post;
  active: boolean;
  height: number;
}) {
  const focused = useIsFocused(),
    player = useVideoPlayer(post.mediaUrl, (p) => {
      p.loop = true;
      p.muted = true;
    });
  React.useEffect(() => {
    if (active && focused) player.play();
    else player.pause();
  }, [active, focused, player]);
  return (
    <View style={{ height, backgroundColor: "#000" }}>
      <VideoView
        player={player}
        style={{ flex: 1 }}
        contentFit="cover"
        nativeControls
      />
      <View
        style={[
          styles.pad,
          {
            position: "absolute",
            bottom: 25,
            left: 0,
            right: 0,
            backgroundColor: "#101112d9",
          },
        ]}
      >
        <Text style={[styles.text, { fontWeight: "700" }]}>
          @{post.username}
        </Text>
        <Label>{post.caption}</Label>
        <View style={styles.row}>
          <Button title="Beğen / geri al" onPress={() => toggleLike(post)} />
          <Button
            secondary
            title="Kaydet / geri al"
            onPress={() => toggleSaved(post.id)}
          />
        </View>
      </View>
    </View>
  );
}
export function ShortVideos() {
  const me = useSession((s) => s.profile)!.uid,
    blocks = useRows(query(collection(db, "users", me, "blocks"), limit(200))),
    hidden = new Set(blocks.rows.map((row) => row.id)),
    data = useRows(
      query(
        collection(db, "posts"),
        where("audience", "==", "public"),
        where("mediaType", "==", "video"),
        orderBy("createdAt", "desc"),
        limit(4),
      ),
    ),
    [active, setActive] = useState(""),
    height = Math.max(300, useWindowDimensions().height - 160),
    visible = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) =>
      setActive(viewableItems[0]?.item.id || ""),
    );
  return (
    <Page scroll={false} title="Kısa Videolar">
      <FlatList
        pagingEnabled
        data={
          blocks.loading || blocks.error
            ? []
            : data.rows.filter((post) => !hidden.has(post.uid))
        }
        keyExtractor={(r) => r.id}
        onViewableItemsChanged={visible.current}
        viewabilityConfig={{ itemVisiblePercentThreshold: 70 }}
        getItemLayout={(_, i) => ({
          length: height,
          offset: height * i,
          index: i,
        })}
        ListEmptyComponent={
          <State
            loading={data.loading || blocks.loading}
            error={data.error || blocks.error}
            empty
            retry={() => {
              data.refresh();
              blocks.refresh();
            }}
          />
        }
        renderItem={({ item }) => (
          <Video
            post={item as Post}
            active={active === item.id}
            height={height}
          />
        )}
      />
    </Page>
  );
}
