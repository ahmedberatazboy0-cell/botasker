import React from "react";
import { Text } from "react-native";
import { NavigationContainer, DarkTheme } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import {
  Feed,
  Explore,
  ProfileScreen,
  EditProfile,
  Settings,
  Notifications,
  Chats,
  Conversation,
} from "../screens/Social";
import { Create, ShortVideos } from "../screens/Media";
import { Saved, Connections } from "../screens/Collections";
import { storage } from "../firebase/client";
const Stack = createNativeStackNavigator(),
  Tab = createBottomTabNavigator();
const icons: Record<string, string> = {
  "Ana Sayfa": "◉",
  Keşfet: "⌕",
  Oluştur: "+",
  "Kısa Videolar": "▷",
  Profil: "◎",
};
function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: "#ff925c",
        tabBarInactiveTintColor: "#a8a6a3",
        tabBarStyle: {
          backgroundColor: "#101112",
          borderTopColor: "#303237",
          height: 78,
          paddingBottom: 14,
          paddingTop: 8,
        },
        tabBarLabelStyle: { fontSize: 10 },
        tabBarIcon: ({ color }) => (
          <Text style={{ color, fontSize: 25 }}>{icons[route.name]}</Text>
        ),
      })}
    >
      <Tab.Screen name="Ana Sayfa" component={Feed} />
      <Tab.Screen name="Keşfet" component={Explore} />
      <Tab.Screen name="Oluştur" component={Create} />
      {storage && <Tab.Screen name="Kısa Videolar" component={ShortVideos} />}
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
export function Root() {
  return (
    <NavigationContainer
      theme={{
        ...DarkTheme,
        colors: {
          ...DarkTheme.colors,
          primary: "#ff925c",
          background: "#101112",
          card: "#101112",
          border: "#303237",
          text: "#f7f2eb",
        },
      }}
    >
      <Stack.Navigator
        screenOptions={{ headerTintColor: "#ff925c", headerBackTitle: "Geri" }}
      >
        <Stack.Screen
          name="Main"
          component={Tabs}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Saved"
          component={Saved}
          options={{ title: "Kaydedilenler" }}
        />
        <Stack.Screen
          name="Connections"
          component={Connections}
          options={{ title: "Bağlantıların" }}
        />
        <Stack.Screen
          name="User"
          component={ProfileScreen}
          options={{ title: "Profil" }}
        />
        <Stack.Screen
          name="EditProfile"
          component={EditProfile}
          options={{ title: "Profili düzenle" }}
        />
        <Stack.Screen
          name="Settings"
          component={Settings}
          options={{ title: "Ayarlar" }}
        />
        <Stack.Screen
          name="Notifications"
          component={Notifications}
          options={{ title: "Bildirimler" }}
        />
        <Stack.Screen
          name="Chats"
          component={Chats}
          options={{ title: "Mesajlar" }}
        />
        <Stack.Screen
          name="Conversation"
          component={Conversation}
          options={{ title: "Sohbet" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
