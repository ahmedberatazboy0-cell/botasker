// Public publication metadata. Values are supplied by the existing app owner.
export const releaseLinks = {
  privacyPolicy:
    process.env.EXPO_PUBLIC_PRIVACY_POLICY_URL ||
    "https://birarada-5650c.web.app/privacy",
  terms:
    process.env.EXPO_PUBLIC_TERMS_URL || "https://birarada-5650c.web.app/terms",
  accountDeletion:
    process.env.EXPO_PUBLIC_DELETE_ACCOUNT_URL ||
    "https://birarada-5650c.web.app/delete-account",
  support:
    process.env.EXPO_PUBLIC_SUPPORT_URL || "mailto:ahmedberatazboy0@gmail.com",
};

export const TERMS_VERSION = "2026-10-19";
