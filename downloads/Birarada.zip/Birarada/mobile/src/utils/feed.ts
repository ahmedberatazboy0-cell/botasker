import type {Post} from '../types';
// The live first page always wins over older copies in paginated results.
export function mergeFeedPages(first:Post[],more:Post[]):Post[]{
 const seen=new Set<string>();
 return [...first,...more].filter(post=>{if(seen.has(post.id))return false;seen.add(post.id);return true});
}
