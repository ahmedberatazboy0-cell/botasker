import React, { memo, useState, useRef } from "react";
import { View, Text, Pressable, Share } from "react-native";
import { Image } from "expo-image";
import {
  collection,
  doc,
  query,
  orderBy,
  limit,
  deleteDoc,
  onSnapshot,
} from "firebase/firestore";
import { db } from "../firebase/client";
import { friendly } from "../utils/errors";
import { useRows } from "../hooks/useRows";
import { useSession } from "../store/session";
import {
  toggleLike,
  toggleSaved,
  comment,
  report,
  deleteOwnPost,
} from "../services/social";
import { Button, Label, Field, State, ReportForm, styles } from "./ui";
import type { Post } from "../types";
export const PostCard = memo(function PostCard({
  post,
  openProfile,
  blockedUids,
}: {
  post: Post;
  openProfile: (id: string) => void;
  blockedUids?: ReadonlySet<string>;
}) {
  const profile = useSession((s) => s.profile)!,
    [comments, setComments] = useState(false),
    [text, setText] = useState(""),
    lastTap = useRef(0),
    [tapError, setTapError] = useState(""),
    [isSaved, setSaved] = useState(false),
    [reporting, setReporting] = useState(false),
    [commentReport, setCommentReport] = useState<{
      uid: string;
      id: string;
    } | null>(null),
    [confirmDelete, setConfirmDelete] = useState(false);
  React.useEffect(
    () =>
      onSnapshot(
        doc(db, "saved", profile.uid, "posts", post.id),
        (s) => setSaved(s.exists()),
        (e) => setTapError(friendly(e)),
      ),
    [profile.uid, post.id],
  );
  const likes = useRows(
      query(collection(db, "posts", post.id, "likes"), limit(500)),
    ),
    replies = useRows(
      comments
        ? query(
            collection(db, "posts", post.id, "comments"),
            orderBy("createdAt", "asc"),
            limit(50),
          )
        : null,
    );
  const liked = likes.rows.some((r) => r.id === profile.uid);
  return (
    <View style={[styles.card, { marginHorizontal: 18, marginBottom: 16 }]}>
      <Pressable onPress={() => openProfile(post.uid)}>
        <Text style={[styles.text, { fontWeight: "700" }]}>
          @{post.username}
        </Text>
        <Label muted>
          {post.createdAt
            ? new Date(post.createdAt.seconds * 1000).toLocaleDateString(
                "tr-TR",
              )
            : "Gönderiliyor"}
        </Label>
      </Pressable>
      {!!post.mediaUrl && post.mediaType === "image" && (
        <Pressable
          onPress={() => {
            const now = Date.now();
            if (now - lastTap.current < 300 && !liked)
              toggleLike(post).catch((e) => setTapError(friendly(e)));
            lastTap.current = now;
          }}
        >
          <Image
            source={post.mediaUrl}
            style={{ width: "100%", aspectRatio: 1, borderRadius: 16 }}
            contentFit="cover"
            cachePolicy="memory-disk"
            accessibilityLabel={post.caption}
          />
        </Pressable>
      )}
      {post.mediaType === "video" && (
        <Label muted>Videoyu Kısa Videolar sekmesinde izle.</Label>
      )}
      <Label>{post.caption}</Label>
      {!!tapError && <Text style={styles.error}>{tapError}</Text>}
      {!!likes.error && <Text style={styles.error}>{likes.error}</Text>}
      <View style={[styles.row, { flexWrap: "wrap" }]}>
        <Button
          secondary
          title={`${liked ? "♥" : "♡"} ${likes.rows.length >= 500 ? "500+" : likes.rows.length}`}
          onPress={() => toggleLike(post)}
        />
        <Button
          secondary
          title={isSaved ? "Kaydedildi" : "Kaydet"}
          onPress={() => toggleSaved(post.id)}
        />
        <Button
          secondary
          title="Paylaş"
          onPress={() =>
            Share.share({ message: `@${post.username}: ${post.caption}` })
          }
        />
      </View>
      {post.commentsEnabled && (
        <Button
          secondary
          title={comments ? "Yorumları gizle" : "Yorumlar"}
          onPress={() => setComments(!comments)}
        />
      )}
      {comments && (
        <View style={{ gap: 12 }}>
          <State
            {...replies}
            empty={!replies.rows.some((r) => !blockedUids?.has(r.uid))}
            retry={replies.refresh}
          />
          {replies.rows
            .filter((r) => !blockedUids?.has(r.uid))
            .map((r) => (
              <View key={r.id} style={{ gap: 6 }}>
                <Pressable
                  onPress={() => openProfile(r.uid)}
                  accessibilityRole="button"
                  accessibilityLabel={`@${r.username} profilini aç`}
                >
                  <Label>
                    @{r.username} · {r.text}
                  </Label>
                </Pressable>
                {r.uid !== profile.uid && (
                  <Button
                    secondary
                    title="Yorumu şikâyet et"
                    onPress={() => setCommentReport({ uid: r.uid, id: r.id })}
                  />
                )}
              </View>
            ))}
          {commentReport && (
            <ReportForm
              key={commentReport.id}
              onSubmit={(reason) =>
                report(
                  commentReport.uid,
                  `Yorum ${post.id}/${commentReport.id}: ${reason}`.slice(
                    0,
                    500,
                  ),
                )
              }
              onCancel={() => setCommentReport(null)}
            />
          )}
          <Field
            placeholder="Bir şey söyle…"
            value={text}
            onChangeText={setText}
            maxLength={1000}
          />
          <Button
            title="Yorum gönder"
            disabled={!text.trim()}
            onPress={async () => {
              await comment(post, text, profile);
              setText("");
            }}
          />
        </View>
      )}
      {post.uid === profile.uid && (
        <Button
          secondary
          title="Gönderiyi sil"
          onPress={() => setConfirmDelete(!confirmDelete)}
        />
      )}
      {confirmDelete && (
        <View style={styles.card}>
          <Label>Bu gönderiyi kalıcı olarak silmek istiyor musun?</Label>
          <Button
            title="Evet, gönderiyi sil"
            onPress={() => deleteOwnPost(post.id)}
          />
          <Button
            secondary
            title="Vazgeç"
            onPress={() => setConfirmDelete(false)}
          />
        </View>
      )}
      {post.uid !== profile.uid && (
        <Button
          secondary
          title="Gönderiyi şikâyet et"
          onPress={() => setReporting(!reporting)}
        />
      )}
      {reporting && (
        <ReportForm
          onSubmit={(reason) => report(post.uid, reason, post.id)}
          onCancel={() => setReporting(false)}
        />
      )}
    </View>
  );
});
