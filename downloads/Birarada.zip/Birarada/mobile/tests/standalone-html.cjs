const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const http = require('node:http');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium, expect } = require('playwright/test');

// Run directly with Node. Prefer actual file:// navigation. Managed Chromium
// can forbid local-file navigation; in that case explicitly skip that check
// and serve the same bytes over loopback for functional validation only.
const htmlPath = path.resolve(__dirname, '../../downloads/Birarada.html');
const screenshotPath = '/workspace/exports/birarada-html-mobile.png';
const localNotice = /yerel|demo|örnek|çevrimdışı|offline/iu;
const attribute = (value) => JSON.stringify(value);
const navigation = (page, name) => page.locator(`[data-page=${attribute(name)}]`).filter({ visible: true }).first();

async function assertNoOverflow(page) {
  const dimensions = await page.evaluate(() => ({
    viewport: window.innerWidth,
    page: document.documentElement.scrollWidth,
    body: document.body.scrollWidth,
  }));
  assert.ok(dimensions.page <= dimensions.viewport + 1, JSON.stringify(dimensions));
  assert.ok(dimensions.body <= dimensions.viewport + 1, JSON.stringify(dimensions));
}

async function createPost(page, caption) {
  await navigation(page, 'create').click();
  const form = page.locator('#create-form');
  await expect(form).toBeVisible();
  await form.locator('[name="caption"]').fill(caption);
  await form.locator('[type="submit"]').click();
  await navigation(page, 'feed').click();
  await expect(page.getByText(caption, { exact: true })).toBeVisible();
}

async function openChat(page, id) {
  await navigation(page, 'feed').click();
  await page.locator('[data-action="open-messages"]').filter({ visible: true }).first().click();
  const chat = id
    ? page.locator(`[data-action="open-chat"][data-id=${attribute(id)}]`).filter({ visible: true }).first()
    : page.locator('[data-action="open-chat"][data-id]').filter({ visible: true }).first();
  await expect(chat).toBeVisible();
  const conversationId = await chat.getAttribute('data-id');
  assert.ok(conversationId, 'Every local conversation needs a stable identifier');
  await chat.click();
  await expect(page.locator('#message-form')).toBeVisible();
  return conversationId;
}

test('standalone HTML interactions need no external services', { timeout: 120_000 }, async (t) => {
  await fs.access(htmlPath);
  const html = await fs.readFile(htmlPath);
  const browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
    headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage'],
  });
  let server;
  try {
  const pageErrors = [];
  const remoteRequests = [];
  const fileDependencies = [];
  const dialogs = [];
  const fileUrl = pathToFileURL(htmlPath).href;
  let url = fileUrl;
  let fileBlocked;
  const probeContext = await newContext();
  try {
    const probe = await probeContext.newPage();
    try {
      await probe.goto(fileUrl);
      await expect(probe.locator('#demo-login')).toBeVisible();
    } catch (error) {
      if (!String(error.message).includes('ERR_BLOCKED_BY_ADMINISTRATOR')) throw error;
      fileBlocked = 'Managed Chromium policy: net::ERR_BLOCKED_BY_ADMINISTRATOR';
      t.diagnostic(`${fileBlocked}; functional checks use exact HTML bytes over loopback. Direct-file behavior is unverified.`);
    }
  } finally {
    await probeContext.close();
  }
  await t.test('direct file:// opening', { skip: fileBlocked || false }, () => {
    assert.equal(fileBlocked, undefined);
  });
  if (fileBlocked) {
    server = http.createServer((request, response) => {
      if (request.url !== '/Birarada.html') {
        response.writeHead(404).end('This test serves only the standalone HTML.');
        return;
      }
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      response.end(html);
    });
    await new Promise((resolve, reject) => {
      server.once('error', reject);
      server.listen(0, '127.0.0.1', resolve);
    });
    url = `http://127.0.0.1:${server.address().port}/Birarada.html`;
  }
  async function newContext(viewport = { width: 390, height: 844 }) {
    const context = await browser.newContext({ viewport, offline: !server, serviceWorkers: 'block' });
    const allowedDocument = (request) => request.url() === url
      && request.isNavigationRequest() && request.resourceType() === 'document'
      && request.method() === 'GET';
    await context.route('**/*', (route) => {
      if (/^https?:/i.test(route.request().url()) && !allowedDocument(route.request())) return route.abort();
      return route.continue();
    });
    await context.routeWebSocket('**', (socket) => {
      remoteRequests.push(socket.url());
      socket.close();
    });
    context.on('request', (request) => {
      if (/^(?:https?|wss?):/i.test(request.url()) && !allowedDocument(request)) remoteRequests.push(request.url());
      if (request.url().startsWith('file:') && request.url() !== url) fileDependencies.push(request.url());
    });
    context.on('page', (page) => {
      page.on('pageerror', (error) => pageErrors.push(error.message));
      page.on('crash', () => pageErrors.push('Page crashed'));
      page.on('websocket', (socket) => remoteRequests.push(socket.url()));
      page.on('dialog', async (dialog) => {
        dialogs.push(dialog.message());
        await dialog.accept();
      });
      page.setDefaultTimeout(7000);
    });
    return context;
  }

  const context = await newContext();
  const page = await context.newPage();

  await t.test('welcome is readable at phone and desktop widths', async () => {
    await page.goto(url);
    assert.equal(page.url(), url);
    await expect(page.locator('#demo-login')).toBeVisible();
    assert.match(await page.locator('body').innerText(), localNotice);
    await assertNoOverflow(page);
    await page.setViewportSize({ width: 1440, height: 1000 });
    await expect(page.locator('#demo-login')).toBeVisible();
    await assertNoOverflow(page);
    await page.setViewportSize({ width: 390, height: 844 });
  });

  await t.test('demo sign-in and all five main pages work on mobile', async () => {
    await page.locator('#demo-login').click();
    for (const name of ['feed', 'explore', 'create', 'videos', 'profile']) {
      const tab = navigation(page, name);
      await expect(tab).toBeVisible();
      await tab.click();
      await expect(navigation(page, name)).toHaveClass(/(?:^|\s)active(?:\s|$)/);
      await expect(page.locator('#view')).toBeVisible();
      await assertNoOverflow(page);
    }
    assert.match(await page.locator('body').innerText(), localNotice, 'Profile must identify the local/demo account');
    await navigation(page, 'feed').click();
    await fs.mkdir(path.dirname(screenshotPath), { recursive: true });
    await page.screenshot({ path: screenshotPath, fullPage: false });
  });

  const caption = `Yerel HTML gönderisi ${Date.now()}`;
  const message = `Yerel mesaj ${Date.now()}`;
  let messageConversationId;
  await t.test('text posts persist across reload', async () => {
    await createPost(page, caption);
    await page.reload();
    await navigation(page, 'feed').click();
    await expect(page.getByText(caption, { exact: true })).toBeVisible();
  });

  await t.test('likes toggle and persist across reloads', async () => {
    const firstLike = page.locator('[data-action="like"][data-id]').filter({ visible: true }).first();
    const id = await firstLike.getAttribute('data-id');
    assert.ok(id);
    const selector = `[data-action="like"][data-id=${attribute(id)}]`;
    const like = page.locator(selector).filter({ visible: true }).first();
    const before = await like.getAttribute('aria-pressed');
    assert.ok(before === 'true' || before === 'false', 'Like must expose its state with aria-pressed');
    const after = before === 'true' ? 'false' : 'true';
    await like.click();
    await expect(like).toHaveAttribute('aria-pressed', after);
    await page.reload();
    await navigation(page, 'feed').click();
    await expect(like).toHaveAttribute('aria-pressed', after);
    await like.click();
    await expect(like).toHaveAttribute('aria-pressed', before);
  });

  await t.test('HTML-shaped captions render as literal text', async () => {
    const hostileCaption = '<img src=x onerror="window.__captionExecuted=true"> Yerel <script>window.__captionExecuted=true</script>';
    await createPost(page, hostileCaption);
    await expect(page.getByText(hostileCaption, { exact: true })).toBeVisible();
    assert.equal(await page.evaluate(() => window.__captionExecuted), undefined);
    assert.equal(await page.locator('img[src="x"]').count(), 0);
    await page.reload();
    await navigation(page, 'feed').click();
    await expect(page.getByText(hostileCaption, { exact: true })).toBeVisible();
    assert.equal(await page.evaluate(() => window.__captionExecuted), undefined);
  });

  await t.test('local direct messages send and persist without a backend', async () => {
    const id = await openChat(page);
    messageConversationId = id;
    assert.match(await page.locator('body').innerText(), localNotice, 'Messages must identify the local/offline mode');
    await page.locator('#message-text').fill(message);
    await page.locator('#message-form [type="submit"]').click();
    await expect(page.locator('.bubble').filter({ hasText: message })).toBeVisible();
    await page.reload();
    await openChat(page, id);
    await expect(page.locator('.bubble').filter({ hasText: message })).toBeVisible();
  });

  await t.test('sharing and reports explain their local limitations', async () => {
    await page.reload();
    await navigation(page, 'feed').click();
    await page.locator('[data-action="share"]').first().click();
    const modal = page.locator('dialog[open]');
    await expect(modal).toBeVisible();
    assert.match(await modal.innerText(), /yerel/iu);
    assert.match(await modal.innerText(), /açık bir bağlantısı yok/iu);
    await modal.locator('[data-action="close-modal"]').click();
    // The last seeded feed card belongs to another account and can be reported.
    await page.locator('[data-action="post-menu"]').last().click();
    await modal.locator('[data-action="report"]').click();
    await expect(modal.locator('#report-form')).toBeVisible();
    assert.match(await modal.innerText(), /yalnızca bu cihazda/iu);
    assert.match(await modal.innerText(), /gerçek bir moderasyon ekibine iletilmez/iu);
    await modal.locator('[data-action="close-modal"]').click();
  });

  await t.test('switching demo personas is clearly labeled and keeps local state', async () => {
    await navigation(page, 'profile').click();
    await page.locator('[data-action="switch-account"]').filter({ visible: true }).first().click();
    const modal = page.locator('dialog[open]');
    assert.match(await modal.innerText(), /bu cihazdaki örnek/iu);
    await modal.locator('[data-action="switch-to"][data-id="demo-lina"]').click();
    await navigation(page, 'profile').click();
    await expect(page.locator('.profile-overview')).toContainText(/örnek hesap/iu);
    await expect(page.locator('.profile-overview')).toContainText(/lina/iu);
    assert.ok(messageConversationId, 'The demo recipient must read the existing local conversation');
    await openChat(page, messageConversationId);
    await expect(page.locator('.bubble').filter({ hasText: message })).toBeVisible();
    await navigation(page, 'profile').click();
    await page.locator('[data-action="switch-account"]').filter({ visible: true }).first().click();
    await modal.locator('[data-action="switch-to"][data-id="demo-me"]').click();
    await navigation(page, 'feed').click();
    await expect(page.getByText(caption, { exact: true })).toBeVisible();
  });

  await t.test('registration creates and retains a clearly local account', async () => {
    const registrationContext = await newContext();
    try {
      const registrationPage = await registrationContext.newPage();
      await registrationPage.goto(url);
      await expect(registrationPage.locator('#demo-login')).toBeVisible();
      await registrationPage.locator('[data-action="show-register"]').click();
      const form = registrationPage.locator('#register-form');
      await expect(form).toBeVisible();
      const suffix = Date.now().toString(36);
      const name = `Yerel Test ${suffix}`;
      const username = `yerel_${suffix}`;
      await form.locator('[name="displayName"]').fill(name);
      await form.locator('[name="username"]').fill(username);
      await form.locator('[name="email"]').fill(`${username}@example.test`);
      await form.locator('[name="password"]').fill('LocalDemo2026!');
      assert.match(await registrationPage.locator('body').innerText(), localNotice);
      await form.locator('[type="submit"]').click();
      await navigation(registrationPage, 'profile').click();
      await expect(registrationPage.locator('.profile-overview').getByText(name, { exact: true })).toBeVisible();
      assert.match(await registrationPage.locator('body').innerText(), localNotice);
      await registrationPage.reload();
      await navigation(registrationPage, 'profile').click();
      await expect(registrationPage.locator('.profile-overview').getByText(name, { exact: true })).toBeVisible();
      await assertNoOverflow(registrationPage);
    } finally {
      await registrationContext.close();
    }
  });

  await t.test('no tested flow triggers remote requests or JavaScript errors', async () => {
    assert.deepEqual(remoteRequests, [], 'The double-click download must be entirely self contained');
    assert.deepEqual(fileDependencies, [], 'The download must not depend on neighboring files');
    assert.deepEqual(pageErrors, [], 'The offline app must not emit uncaught page errors');
    assert.deepEqual(dialogs, [], 'The tested flows should not trigger unexpected JavaScript dialogs');
  });
  } finally {
    try {
      await browser.close();
    } finally {
      if (server) await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
    }
  }
});
