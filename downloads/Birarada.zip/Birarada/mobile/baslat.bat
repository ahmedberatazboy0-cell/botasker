@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
title Birarada - Yerel Test
pushd "%~dp0"
if errorlevel 1 goto folder_error
if not exist "scripts\start-local.cjs" (
    popd
    goto folder_error
)
where.exe node >nul 2>nul
if errorlevel 1 goto node_missing
node "scripts\start-local.cjs"
set "BIRARADA_EXIT=%errorlevel%"
popd
if not "%BIRARADA_EXIT%"=="0" pause
exit /b %BIRARADA_EXIT%

:node_missing
echo Node.js bulunamadi. https://nodejs.org/ adresinden guncel LTS surumunu kur.
echo Kurulumdan sonra bu dosyaya yeniden cift tikla.
popd
pause
exit /b 1

:folder_error
echo ZIP dosyasinin tamamini bir klasore cikart ve tekrar dene.
pause
exit /b 1
