> **10 Kasım devam snapshot'ı:** Önce DEVIR_NOTU_10_KASIM.md oku. Yeni medya düzeltmesinde yalnız istemci TS ve tek yeni regresyon testi geçti; tam paket/native/telefon yeniden doğrulanmadı. AAB değildir.

# Birarada 1.1.7 — performans ve kararlılık

Bu kaynak, önceki **1.1.6** teslimi üzerine geliştirilmiştir. Çalışan giriş/kayıt, tek Keşfet akışı, açık hesap varsayılanı, profil, mesajlaşma, notlar, fotoğraf/video, hikâyeler, beğeni ve yorumlar korunur. Coin/Kapışma veya yeni sosyal özellik geliştirilmedi. Güncel sonuçlar ve sınırlar: [TEST_REPORT.md](TEST_REPORT.md).

## Düzeltilenler

- Özel fotoğraf erişimindeki izin okumaları aynı HTTP isteğinde toplandı. Her yeni istekte oturum, engel, gizlilik ve hesap durumu yeniden denetlenir. Medya herkese açılmadı; disk görüntü önbelleği etkinleştirilmedi.
- Medya bileşenleri tek Firebase token aboneliğini paylaşır. Hesap değişiminden kalan token sonuçları kullanılmaz; son bileşen kapandığında dinleyici/zamanlayıcı temizlenir.
- Fotoğraf yüklenmesi veri listesinden ayrı gösterilir. Yavaş bağlantı bilgisi, 25 saniyelik sınır ve yeniden deneme vardır. Profil/oturum başlangıcı 5 saniye uzarsa yeniden deneme sunulur.
- Değişmeyen profil revizyonu bütün uygulamayı yeniden çizmez. Kritik olmayan profil/gelen kutusu hazırlığı ilk ekran çiziminden sonraya ertelenir; eski oturumun geciken işi iptal edilir.
- Android Reels yalnız etkin video ve sıradaki tek video için oynatıcı hazırlar; küçük ileri tampon kullanır. Web yalnız görünür videoyu indirir. Gönderi/mesaj videoları Android'de dokunarak yüklenir. Sekme/arka plan değişiminde oynatma durur; Reels ve isteğe bağlı oynatıcılar kaldırılır.
- Sohbet yazma alanı esnek yükseklik ve sistem alt boşluğunu hesaba katar. Android klavye yeniden boyutlandırması yapılandırılmıştır. Fiziksel klavye/sistem gezinme doğrulaması ayrıca gerekir.
- Açılış ve istek aşamaları Ayarlar → Bağlantı kontrolü içinde ölçülür. Bu bellek kayıtlarında URL, hesap kimliği, mesaj veya token tutulmaz. JavaScript başlangıcı Android Activity/sistem Splash süresinin tamamı değildir.

## İsteğe bağlı Android Crashlytics

`plugins/withAndroidDiagnostics.cjs`, Android yerel Crashlytics SDK'sını ekler; Firebase JS Authentication değiştirilmez. Yeni JavaScript bağımlılığı eklenmedi. Varsayılan veri gönderimi kapalıdır. Üretim Android uygulamasında Ayarlar → Teknik hata raporları bölümünden açık onay gerekir. Debug gönderimi engellenir; web/iOS bu Android köprüsünü kullanmaz.

SDK sürüm/Android/model ve kurulum tanımlayıcılarını işleyebilir; anonim rapor iddiası yoktur. Uygulama JS hatalarını yalnız izin verilen kategori/kodlarla aktarır; ham mesaj, yığın, e-posta, token veya sohbet içeriği eklemez. Yerel Java çökme raporları teknik yığın içerebilir. NDK/C++ sembol yüklemesi ve fiziksel Crashlytics konsol teslimi doğrulanmış değildir. Güncellenen gizlilik sayfası yayımlanmalı; Play Veri Güvenliği beyanında isteğe bağlı çökme/teşhis ve SDK tanımlayıcıları değerlendirilmelidir.

## Kimlik ve güncelleme

Aday **1.1.7 / versionCode 9**, paket **com.birarada.app**. Code9 Play Console'dan doğrulanmış en yüksek kod değildir; gerçek derleme öncesi bütün kanallarla karşılaştırılmalıdır. Mevcut EAS **@ahmedberat/birarada / 9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b** ve upload imzası korunur. Firebase Authentication/Hosting **birarada-5650c**, Supabase **qinevhhhdtslnzrtcanq** korunur. Yeni Edge revizyonu **2026-11-08-media2** gerekir; şema migration'ı, kullanıcı verisi değişikliği veya Blaze planı gerekmez.

Kaynağın tamamını yeni klasöre çıkar. **GUNCELLE_VE_AAB.bat** mevcut sunucuyu günceller, site dosyalarını koruyarak yasal sayfaları yayımlar ve kontroller geçerse mevcut EAS projesinde AAB başlatır. Aynı klasörde iki kurulum çalıştırma. Komut karşılıkları:

```bat
npm run backend:update
npm run legal:deploy
npm run build:no-github
```

Node.js 22/24 LTS ve Chrome/Edge gerekir. Gerçek Firebase Android açık yapılandırmasını yardımcı resmî CLI üzerinden alır; parola/servis hesabı/imza dosyası ZIP'e eklenmez. FCM v1 yetkisi ve fiziksel teslim ayrıca kontrol edilir. Bildirimler push türündedir; SMS hizmeti bağlı değildir.

**WEB_TEST.bat** veya `npm run web:local` yerel hesaplarla http://localhost:8081 açar. Test hesapları ve paylaşımlar canlı kullanıcılara gönderilmez.

**Bu teslim kaynak kodudur; imzalı AAB, canlı dağıtım, telefona kurulum veya 2 saniye altı Android açılış garantisi değildir.** Bu sohbette Remote Desktop Commander kumanda aracı sunulmadı. Yerel tarayıcı/derleme sonuçları ile fiziksel telefon sonuçları raporda ayrı belirtilir.
