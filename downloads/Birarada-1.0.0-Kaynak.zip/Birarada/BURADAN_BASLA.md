# Birarada — Windows derleme paketi

Git/GitHub bağlantısı ve Codex ortam ayarı gerektirmez.
Kaynaklar yerel bilgisayarından Expo EAS Build'e gönderilir.

1. ZIP'in tamamını bir klasöre çıkar.
2. Node.js LTS, Java21 ve Chrome/Edge kurulu olsun.
3. Bu klasördeki AAB_OLUSTUR.bat dosyasına çift tıkla.
4. Testler geçerse resmi Expo tarayıcı girişini tamamla ve Birarada projesini oluşturmayı onayla.
5. EAS AAB derlemesi tamamlanınca terminaldeki bağlantıdan dosyayı indir.

Proje kimliği uydurulmaz veya Codex ekranına elle girilmez.
Uygulama kimliği com.birarada.app, sürüm1.0.0, versionCode1.
Bu ZIP kaynak ve derleme başlatıcısıdır; önceden üretilmiş AAB içermez.

Ayrıntılar: mobile/docs/GITHUB_GEREKTIRMEYEN_DERLEME.md
Test edilenler ve engeller: mobile/TEST_REPORT.md
Firebase/yasal sayfalar: mobile/docs/HOSTING.md
PlayStore adımları: mobile/docs/PLAY_STORE_RELEASE.md

Birarada.html bağımsız yerel gösterimdir; canlı Firebase hesabı oluşturmaz.
