# Birarada mobil

React Native + Expo SDK 54, TypeScript, React Navigation 7, Zustand ve Firebase JS SDK. Koyu antrasit yüzeyler, gün batımı turuncusu, Türkçe arayüz. Bu dizin, kökteki eski Express web uygulamasından bağımsızdır.

Bu adayın kimliği: **Birarada · `com.birarada.app` · `1.0.0` · Android versionCode `1`**. iOS kimliği de `com.birarada.app` olarak sabittir. Kaynak ZIP'i ve HTML demosu Play Store'a yüklenebilecek imzalı AAB değildir. Yeni Expo/EAS projesi ve ilk AAB adımları [PLAY_STORE_RELEASE.md](docs/PLAY_STORE_RELEASE.md) içinde; doğrulananlar ve açık engeller [TEST_REPORT.md](TEST_REPORT.md) içinde kayıtlıdır.

## Kurulum ve çalıştırma

### GitHub ve Codex ayar ekranı olmadan AAB

Windows'ta `AAB_OLUSTUR.bat` dosyasını çalıştırın. Node.js LTS, Java 21 ve Chrome/Edge gerekir. Testler geçerse resmi Expo girişi açılır, gerçek EAS projesi bağlanır ve imzalı AAB için EAS Build başlatılır. Kaynaklar yerel dosyalardan Expo'ya gider; Git/GitHub gerekmez. Yardımcıda hata veren kontroller atlanmaz. Kullanım ve doğrulanmış sınırlar: [GitHub gerektirmeyen derleme](docs/GITHUB_GEREKTIRMEYEN_DERLEME.md).

### Windows'ta çift tıklayarak test

1. ZIP'in tamamını bir klasöre çıkartın.
2. [Node.js LTS](https://nodejs.org/) ve [Java 21 veya üzerini](https://adoptium.net/) kurun.
3. `başlat.bat` dosyasına çift tıklayın. Aynı işi yapan `baslat.bat` da bulunur.

Başlatıcı gerekli bağımlılıkları ilk açılışta kurar; lockfile değiştiğinde kurulumu yeniler. İlk kurulum ve Firebase emulator indirmesi için internet gerekir. Auth ve Firestore emulatorlerini `demo-birarada` projesiyle başlatır; Expo web uygulamasının paketi hazır olunca tarayıcıyı açar. `.env.local` dosyası hazırlamanız veya iki terminal açmanız gerekmez. Yerel test bağlantıları kullanılır; Storage kapalı tutulur. Mevcut `.env` dosyaları değiştirilmez.

Pencere açık kalsın; durdurmak için **Ctrl+C** kullanın. Test hesapları geçicidir, emulatorler durunca silinir. Node/Java eksikse, portlar doluysa veya indirme başarısızsa açıklama gösterilir; hata penceresi açık kalır. `8080`, `9099`, `8081`, `4400`, `4500` portları boş olmalıdır. Başka uygulamaların süreçleri kapatılmaz.

Başlatıcının süreç yönetimi Linux üzerinde test edildi; Windows'ta gerçek çift tıklama testi bu ortamda yapılamadı.

### Komut satırından

Node.js 20.19.4+ (bu ortamda 24.19), npm ve Expo Go SDK 54 ile uyumlu cihaz veya development build kullanın.

```sh
cd /workspace/botasker/mobile
npm ci
npx expo start
# Ağ kısıtlı bulut ortamında:
npx expo start --offline
# Web:
npm run web -- --offline
# Android SDK/emulator bulunan makinede:
npm run android
# macOS + Xcode üzerinde:
npm run ios
```

**Komutları mobile dizininde çalıştırın.** Kökteki `npm install` mevcut web sunucusunu ve verileri değiştiren bir preinstall içerir. Mobil kurulum bu adıma ihtiyaç duymaz.

## Firebase kurulumu

Kullanıcının verdiği `birarada-5650c` public istemci yapılandırması `src/firebase/client.ts` içindedir. Bu bir Admin SDK anahtarı değildir. Projede service account veya özel anahtar yoktur.

1. Firebase Console → Authentication → Sign-in method: Email/Password etkinleştirin. Web Google girişi için Google sağlayıcısını da etkinleştirin; yetkili alan adlarına gerçek web alan adınızı ekleyin. Google popup yalnız web sürümünde açıktır. Native OAuth entegrasyonu yoktur; native Google düğmesi gizlidir. Kayıt ve profil tamamlama, kullanım/topluluk kurallarının kabulünü gerektirir.
2. Cloud Firestore oluşturun. Varsayılan açık/test kurallarını kullanmayın. Kuralları ve indeksleri inceleyin, emulator testleri geçtikten sonra yetkili hesabınızla yayımlayın:

```sh
npx firebase login
npx firebase deploy --project birarada-5650c --only firestore:rules,firestore:indexes
```

Bu teslimatta canlı Firebase projesine kural, kullanıcı, veri veya altyapı dağıtılmadı. Bileşik indeksler oluşturulmadan ilgili sorgular hata gösterebilir.

3. Varsayılan gizlilik açık, yabancı DM izni kapalı. Yeni kullanıcı Auth kaydından sonra benzersiz kullanıcı adı ve profil oluşturur; kullanıcı adı rezervasyonu ile profil tek transaction içinde yazılır. Profil oluşturma başarısızsa aynı oturumda tekrar denenebilir.
4. Storage **varsayılan kapalıdır**. Spark üzerinde Storage erişimi/faturalandırması varsayılmaz. Galeri, kamera ve kısa video sekmesi gizlidir; metin paylaşımı kullanılabilir. `storage.rules` tüm erişimi reddeder, Firestore kuralları medya URL'lerini reddeder. Güvenli medya yetkilendirmesi uygulanmadan Storage bayrağını açmayın. Üretim kontrolü bu adayda Storage'ın açılmasını engeller. Storage sözleşmesi `src/services/social.ts` içinde ayrıdır.

## Destek ve yasal sayfalar

Destek: `ahmedberatazboy0@gmail.com`. Mobil uyumlu Türkçe sayfalar `hosting/public/` altındadır: `/privacy`, `/delete-account`, `/terms`, `/child-safety`. Tam adresler `https://birarada-5650c.web.app` altındadır. Sayfalar yerel olarak hazırlanmıştır; canlıda yayımlandıkları iddia edilmez. Yayın adımları [HOSTING.md](docs/HOSTING.md) içindedir. Firebase Hosting tüm site sürümünü değiştirdiğinden, mevcut sitenin tam çıktısıyla birleştirmeden yalnız bu klasörü dağıtmayın.

Hesap silme, Profil → Ayarlar üzerinden veya eksik profil ekranından başlatılır. Yeniden kimlik doğrulama ve SİL onayı gerekir. Profilde silme durumu işaretlenir; gönderiler, alt kayıtlar, kendi yorum/beğeni/mesajları, bağlantılar, kayıtlılar, engellemeler, bildirimler ve kendi şikâyetleri temizlenir. Profil/kullanıcı adı atomik kaldırılır, Auth hesabı son adımda silinir. Yarıda kalan işlem tekrar denenebilir. Başkalarının mesajları, sohbet üyelik geçmişi ve başkalarının raporları otomatik silinmez. Tam temizliğin gerçek emulator/cihaz doğrulaması hâlâ gereklidir; bu işlem sunucu tarafında atomik bir silme garantisi vermez.

## Yerel emulator

Java 21+ gerekir. Emulator testleri canlı projenizi kullanmaz.

```sh
npm run test:rules
# Ayrı terminalde backend:
npx firebase emulators:start --project demo-birarada --only auth,firestore
# Uygulama:
EXPO_PUBLIC_USE_EMULATORS=true npx expo start --web --offline
```

Android emulator için `EXPO_PUBLIC_EMULATOR_HOST=10.0.2.2`, fiziksel cihaz için geliştirici makinesinin LAN IP adresini kullanın. Production build'de emulator bayrağını açmayın.

Bu bulut ortamında yazılabilir önbellek seçenekleri:

```sh
FIREBASE_EMULATORS_PATH=/workspace/.cache/firebase/emulators \
XDG_CONFIG_HOME=/workspace/.config \
XDG_CACHE_HOME=/workspace/.cache npm run test:rules
```

## Doğrulama

```sh
npm run typecheck
npm test
npm run test:release
npm run test:launcher
npm run test:auth
npm run test:rules
npm run test:ui
npm run export:web
npx expo export --platform android --platform ios --output-dir dist-native
```

Playwright testi sistemde `/usr/bin/chromium` kullanır; başka makinede `CHROMIUM_PATH` ile kurulu Chromium yolunu verin. İlk açılış testi gerçek kullanıcı oluşturmaz ve Firebase akışlarını test ettiği anlamına gelmez. Detaylar [TEST_REPORT.md](TEST_REPORT.md).

## Build

```sh
# JS + asset paketleri; APK/IPA değildir:
npx expo export --platform android --platform ios
# Yeni EAS projesi: kendi hesabınızda güvenli giriş ve init gerekir
npx eas-cli login
npx eas-cli init
# Gerçek proje UUID'sini bağladıktan sonra:
npm run release:check
npx eas-cli build --platform android --profile preview
npx eas-cli build --platform android --profile production
```

Dinamik Expo yapılandırması gerçek `EAS_PROJECT_ID` değerini kullanır; sahte kimlik eklemeyin. `.env.example` yalnız herkese açık varsayılanları içerir. Şifre, token ve imzalama anahtarı sohbete veya ZIP'e konmaz. Native derlemenin güncel sonucu test raporundadır; iOS cihaz dağıtımı için ayrıca macOS/Xcode ve Apple geliştirici hesabı gerekir.

## Veri ve erişim modeli

- `users/{uid}`: herkese açık profil; e-posta Firebase Auth'ta kalır. Kullanıcı yalnız kendi profilini düzenleyebilir. Kimlik, kullanıcı adı ve sayaç alanları client güncellemelerine kapalıdır. Sayaçlar şu anda arayüzde gösterilmez; güvenilir sunucu agregasyonu henüz yoktur.
- `usernames/{name}`: transaction içinde benzersiz kullanıcı adı rezervasyonu.
- `posts/{id}`: içerik ve oluşturulurken sabitlenen `audience`. Gizli gönderiler onaylı takipçilere açıktır. Ana akış herkese açık gönderileri sayfalı getirir; gizli gönderiler yazarın profilinden okunur. Hesap gizliliği eski gönderilerin erişimini değiştirmez; arayüz bunu açıklar.
- `posts/{id}/likes/{uid}` ve `comments/{id}`: erişim üst gönderinin görünürlüğüne bağlıdır. Client beğeni/yorum sayacı değiştiremez. Beğeni ekranı 500 kayıtta `500+` gösterir.
- `follows/{followerUid}_{followingUid}`: gizli hesap için pending, yalnız hedef kullanıcı accepted yapabilir. Takip değiştirme transaction ile yapılır.
- `chats/{id}` ve `messages/{id}`: yalnız üyeler okur. Yeni sohbet ve mesaj yazma, alıcının yabancı DM tercihini ve engellemeleri kontrol eder. Metin mesajı, düzenleme, silme ve görüldü desteklenir.
- `notifications/{followerUid}_{followingUid}`: yeni takip ilişkisiyle aynı transaction içinde üretilir. Kaynak/hedef okuyup silebilir, yalnız hedef okundu yapar. Diğer bildirim türleri henüz üretilmez.
- `saved/{uid}/posts/{id}`: yalnız sahibi erişebilir.
- `users/{uid}/blocks/{targetUid}` ve `reports/{id}`: engelleme ve gerekçeli raporlama. Kullanıcı yalnız kendi raporunu okuyup silebilir; moderasyon yönetim sistemi henüz yoktur.

Engelleme gizli gönderi ve yeni DM yazımını sınırlar; herkese açık gönderiler güvenlik açısından herkese açık kalır, kendi engellediğiniz hesaplar ana akışta gizlenir. Mevcut sohbet geçmişi üyelerce okunmaya devam eder.

## Offline ve performans

Web Firestore IndexedDB persistence, native Auth AsyncStorage persistence kullanır. Native Firestore JS SDK kalıcı disk önbelleği sağlamaz; native offline kalıcılık tamamlanmış değildir. Cache yanıtı arayüzde belirtilir. FlatList, memoized gönderi kartları, sayfalama ve expo-image cache kullanılır. Kısa videolarda yalnız görünür ve odaklanmış öğe oynar. Kullanıcı listesindeki arama kullanıcı adı önekiyle çalışır.

## Üretim öncesi

Bu sürüm tam ürün kapsamını bitirmiş değildir. Anlar/Yakınlar, grup sohbeti, ses/medya DM, mesaj cevap/reaksiyon, hashtag/içerik arama, push, yaş bazlı denetimler, kullanıcı adı değiştirme, öne çıkanlar, repostlar ve native Google OAuth yoktur. Bunlar için işlevsiz butonlar gösterilmez. Firestore kuralları ve kritik akışlar emulator/gerçek cihazda doğrulanmadan yayın hazırlığı tamamlanmış sayılmaz. Sunucu tabanlı spam/rate limiting, App Check, işleyen moderasyon, sunucudan silme denetimi, güvenli medya yetkilendirmesi ve yasal sayfaların canlı yayını açık işlerdir.
