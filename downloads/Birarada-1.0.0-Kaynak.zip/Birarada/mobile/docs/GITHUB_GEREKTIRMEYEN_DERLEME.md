# Windows'ta Git/GitHub olmadan Android derleme

Bu yol kaynaklarını bilgisayarından Expo EAS Build'e gönderir. Git ve GitHub bağlantısı kurmaz; Codex ortamının takılmış ayar ekranını kullanmaz. Yeni EAS projesi gerçek Expo hesabında oluşturulur ve gerçek proje kimliği yardımcı tarafından alınır. Kutuya rastgele proje kimliği yazılmaz.

## Çalıştırma

1. Kaynak ZIP'inin tamamını bir klasöre çıkar. Node.js LTS, Java 21 ve Chrome veya Edge kurulu olsun; ilk kurulum ve emulator araçları için internet gerekir. Android Studio veya yerel Android SDK bu EAS yolu için gerekmez.
2. `AAB_OLUSTUR.bat` dosyasına çift tıkla. Dosya doğrudan `mobile` klasöründe veya `mobile` klasörünü içeren üst klasörde bulunabilir. Pencereyi açık tut.
3. Tip kontrolü, birim/yayın testleri, Auth/Firestore emulator testleri ve arayüz testi çalışır. Bir adım hata verirse süreç durur; başarısız test atlanmaz.
4. Expo oturumun yoksa resmi EAS CLI tarayıcı girişini açar. Kendi hesabınla giriş yap; gerekiyorsa Birarada projesinin sahibi olacak hesabı seç ve proje oluşturmayı onayla. Şifre veya token bu yardımcıya kaydedilmez.
5. Kontroller geçince EAS, `com.birarada.app`, `1.0.0`, `versionCode 1` için üretim AAB derlemesini başlatır. İlk uygulamanın Android imzasını EAS'in güvenli credential yönetimi üzerinden oluştur/yönet. Terminaldeki EAS bağlantısından sonucu indir.

Komut satırı seçenekleri (`mobile` klasöründe):

```sh
# Yalnız yerel araçların ve kimliğin önkontrolü:
node scripts/build-no-github.cjs --check
# Test APK'sı için:
node scripts/build-no-github.cjs --preview
# AAB için:
node scripts/build-no-github.cjs
```

`AAB_OLUSTUR.bat` Node yardımcısını içinde taşır; daha önce alınmış kaynak paketine yalnız bu BAT eklenerek de kullanılabilir. `scripts/start-local.cjs`, `scripts/release-check.cjs`, testler ve diğer uygulama dosyaları yine kaynak pakette bulunmalıdır. Gerçek Expo kimliğini elle bir ortam ayarı ekranına yazmak gerekmez.

## Dosyalar ve hesap erişimi

Asıl `app.json`/`app.config.ts` değiştirilmez. Yardımcı kendi `.birarada-release` klasöründe statik bir ilk bağlantı projesi ve ayrı bir derleme kopyası oluşturur. Yalnız kendi işaretlediği çalışma klasörlerini yeniler; aynı anda ikinci derlemeye izin vermez. Gerçek, herkese açık proje kimliği `.birarada-release/project.json` içinde tutulur ve tekrar denemelerde korunur.

Kaynak seçimi açık bir izin listesine dayanır. `.git`, `.env` dosyaları, credentials dosyaları ve imzalama anahtarları kaynak kopyasına alınmaz. `EAS_NO_VCS=1` ve mutlak `EAS_PROJECT_ROOT` ile Git kökü araması da kullanılmaz. Özel anahtar veya parola sohbete ya da ZIP'e konmaz.

Bu yardımcı Firebase Hosting'i ve Play Console'u otomatik değiştirmez. Firebase/yasal sayfa yayını için [HOSTING.md](HOSTING.md), mağaza süreci için [PLAY_STORE_RELEASE.md](PLAY_STORE_RELEASE.md) geçerlidir. Mevcut web sitesini yalnız yasal sayfalarla değiştiren bir dağıtım yapılmaz.

## Doğrulanmış kapsam

20 Ekim 2026: Yardımcının 10 testi geçti. Hatalı testte durma, ağ hatasını giriş eksikliği saymama, resmi tarayıcı girişini seçme, eksik/yanlış proje kimliğini reddetme, tekrar denemede proje kimliğini koruma, dosya koruması, eşzamanlı çalışmayı engelleme ve başarısız build'i başarı göstermeme testleri kullanıldı. CLI yanıtları bu testlerde modellenmiştir; gerçek Expo hesabına bağlanıldığı anlamına gelmez. Ayrı bir test gerçek Expo config aracıyla izole edilmiş üretim yapılandırmasını çözdü; test UUID'si yalnız geçici test klasöründedir.

Node/Java/tarayıcı/kimlik önkontrolü gerçek BAT dosyası Node ile çalıştırılarak geçti. Windows çift tıklaması bu Linux ortamında doğrulanmadı. Arayüz testi taşınabilir Node başlatıcısıyla tekrar geçti. Firestore testleri ve gerçek Expo oturumu/AAB bu bulut oturumundaki ağ engeli nedeniyle hâlâ tamamlanmadı. Yardımcının hazır olması imzalı AAB'nin üretildiği veya uygulamanın yayın onayı aldığı anlamına gelmez.

Tek BAT ayrıca önceki kaynak ZIP'inin açılmış kopyasına eklendi: hem üst klasörden hem `mobile` klasöründen, boşluk ve Türkçe karakter içeren dizin yolunda Node önkontrolü geçti. Eski pakette `build-no-github.cjs` bulunmadan denendi; yardımcı kodu BAT'ın içindedir.
