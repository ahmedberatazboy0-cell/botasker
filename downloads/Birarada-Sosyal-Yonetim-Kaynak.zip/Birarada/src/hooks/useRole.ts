import { useEffect, useState } from "react";
import { onIdTokenChanged } from "firebase/auth";
import { auth } from "../firebase/client";
export function useRole() {
  const [role, setRole] = useState("member");
  useEffect(() => {
    let active = true,
      generation = 0;
    const stop = onIdTokenChanged(auth, async (user) => {
      const current = ++generation;
      setRole("member");
      if (!user) return;
      try {
        const token = await user.getIdTokenResult();
        if (active && current === generation)
          setRole(
            token.claims.email_verified === true &&
              ["owner", "admin", "moderator"].includes(
                String(token.claims.biraradaRole),
              )
              ? String(token.claims.biraradaRole)
              : "member",
          );
      } catch {
        if (active && current === generation) setRole("member");
      }
    });
    return () => {
      active = false;
      stop();
    };
  }, []);
  return role;
}
