import { useCallback, useEffect, useState, useRef } from "react";
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  getDocs,
  startAfter,
  QueryDocumentSnapshot,
  DocumentData,
} from "firebase/firestore";
import { db } from "../firebase/client";
import { friendly } from "../utils/errors";
import type { Post } from "../types";
import { mergeFeedPages } from "../utils/feed";
const base = () =>
  [where("audience", "==", "public"), orderBy("createdAt", "desc")] as const;
export function useFeed() {
  const [first, setFirst] = useState<Post[]>([]),
    [more, setMore] = useState<Post[]>([]),
    [loading, setLoading] = useState(true),
    [paging, setPaging] = useState(false),
    [hasMore, setHasMore] = useState(false),
    [error, setError] = useState(""),
    [offline, setOffline] = useState(false),
    [version, setVersion] = useState(0),
    cursor = useRef<QueryDocumentSnapshot<DocumentData> | undefined>(undefined),
    busy = useRef(false),
    generation = useRef(0),
    paged = useRef(false);
  useEffect(() => {
    const current = ++generation.current;
    paged.current = false;
    busy.current = false;
    setPaging(false);
    setMore([]);
    setLoading(true);
    setError("");
    cursor.current = undefined;
    const stop = onSnapshot(
      query(collection(db, "posts"), ...base(), limit(20)),
      { includeMetadataChanges: true },
      (snap) => {
        if (current !== generation.current) return;
        setFirst(snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Post));
        if (!paged.current) {
          cursor.current = snap.docs[snap.docs.length - 1];
          setHasMore(snap.size === 20);
        }
        setLoading(false);
        setOffline(snap.metadata.fromCache);
      },
      (e) => {
        if (current !== generation.current) return;
        setError(friendly(e));
        setLoading(false);
      },
    );
    return () => {
      stop();
      generation.current += 1;
    };
  }, [version]);
  const loadMore = useCallback(async () => {
    if (!cursor.current || busy.current || !hasMore) return;
    const current = generation.current;
    busy.current = true;
    paged.current = true;
    setPaging(true);
    try {
      const snap = await getDocs(
        query(
          collection(db, "posts"),
          ...base(),
          startAfter(cursor.current),
          limit(20),
        ),
      );
      if (current !== generation.current) return;
      setMore((rows) => [
        ...rows,
        ...snap.docs.map((d) => ({ id: d.id, ...d.data() }) as Post),
      ]);
      cursor.current = snap.docs[snap.docs.length - 1];
      setHasMore(snap.size === 20);
      setError("");
    } catch (e) {
      if (current !== generation.current) return;
      setError(friendly(e));
    } finally {
      if (current === generation.current) {
        busy.current = false;
        setPaging(false);
      }
    }
  }, [hasMore]);
  const rows = mergeFeedPages(first, more);
  return {
    rows,
    loading,
    error,
    offline,
    paging,
    hasMore,
    loadMore,
    refresh: () => setVersion((v) => v + 1),
  };
}
