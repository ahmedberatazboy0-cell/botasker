import { httpsCallable } from "firebase/functions";
import { randomUUID } from "expo-crypto";
import { auth, functions } from "../firebase/client";
import { readMediaBytes } from "./mediaBytes";
export const newId = () => randomUUID();
export type MediaKind = "image" | "video" | "audio";
export type MediaItem = {
  id: string;
  kind: MediaKind;
  width?: number;
  height?: number;
  duration?: number;
};
export type Cursor = {
  seconds: number;
  nanoseconds: number;
  id: string;
} | null;
const call = httpsCallable<
  { action: string; input: Record<string, unknown> },
  unknown
>(functions, "socialApi", { timeout: 45000 });
export async function api<T = any>(
  action: string,
  input: Record<string, unknown> = {},
): Promise<T> {
  try {
    return (await call({ action, input })).data as T;
  } catch (error) {
    const e = error as { code?: string; message?: string };
    if (
      [
        "functions/invalid-argument",
        "functions/failed-precondition",
        "functions/resource-exhausted",
      ].includes(e.code || "")
    )
      throw Error(e.message || "İşlem tamamlanamadı.");
    const messages: Record<string, string> = {
      "functions/unauthenticated":
        "Oturumunu yenilemek için yeniden giriş yap.",
      "functions/permission-denied":
        "Bu işlem veya içerik için erişim iznin yok.",
      "functions/not-found": "İçerik bulunamadı veya sunucu henüz kurulmadı.",
      "functions/unavailable":
        "Sunucuya bağlanılamadı. İnternetini kontrol edip yeniden dene.",
      "functions/deadline-exceeded":
        "İşlem zaman aşımına uğradı. Taslağın korunuyor; yeniden deneyebilirsin.",
    };
    throw Error(
      messages[e.code || ""] || "İşlem tamamlanamadı. Lütfen yeniden dene.",
    );
  }
}
export const mediaEndpoint = (
  name: "mediaContent" | "mediaUpload",
  id: string,
) => {
  if (!/^[a-z0-9-]{36}$/i.test(id)) throw Error("Geçersiz medya kimliği.");
  const emulator = process.env.EXPO_PUBLIC_USE_EMULATORS === "true";
  const base = emulator
    ? `http://${process.env.EXPO_PUBLIC_EMULATOR_HOST || "127.0.0.1"}:5001/demo-birarada/europe-west1`
    : "https://europe-west1-birarada-5650c.cloudfunctions.net";
  return `${base}/${name}?id=${encodeURIComponent(id)}`;
};
export async function uploadMedia(
  uri: string,
  kind: MediaKind,
  purpose: "post" | "story" | "reel" | "message" | "avatar",
  requestId = newId(),
): Promise<MediaItem> {
  const account = auth.currentUser;
  if (!account) throw Error("Önce giriş yap.");
  const bytes = await readMediaBytes(uri);
  const max = kind === "image" ? 10 : kind === "audio" ? 8 : 20;
  if (!bytes.byteLength || bytes.byteLength > max * 1024 ** 2)
    throw Error(`Dosya en fazla ${max} MB olabilir.`);
  const reserved = await api("createUpload", {
    requestId,
    kind,
    purpose,
    bytes: bytes.byteLength,
  });
  if (reserved.status === "ready") return { id: reserved.id, kind };
  const controller = new AbortController(),
    timer = setTimeout(() => controller.abort(), 125000);
  try {
    const response = await fetch(mediaEndpoint("mediaUpload", reserved.id), {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${await account.getIdToken()}`,
        "Content-Type": "application/octet-stream",
      },
      body: bytes,
      signal: controller.signal,
    });
    if (!response.ok) {
      const failure = await response.json().catch(() => ({}));
      throw Error(
        typeof failure.error === "string"
          ? failure.error
          : "Medya yüklenemedi. Taslağın korunuyor.",
      );
    }
    return { id: reserved.id, kind };
  } finally {
    clearTimeout(timer);
  }
}
