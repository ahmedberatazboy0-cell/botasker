import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
  reauthenticateWithCredential,
  reauthenticateWithPopup,
  EmailAuthProvider,
  deleteUser,
} from "firebase/auth";
import {
  collection,
  doc,
  setDoc,
  getDoc,
  runTransaction,
  serverTimestamp,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  addDoc,
  deleteDoc,
  updateDoc,
  writeBatch,
  collectionGroup,
  Query,
  DocumentData,
} from "firebase/firestore";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { api } from "./api";
import { disablePush } from "./push";
import { Platform } from "react-native";
import { auth, db, storage } from "../firebase/client";
import { usernameValid } from "../utils/errors";
import { useSession } from "../store/session";
import type { Profile, Post } from "../types";
import { TERMS_VERSION } from "../constants/release";
import { friendly } from "../utils/errors";
import { runDeletionPlan } from "./deletionPlan";
export const uid = () => {
  if (!auth.currentUser) throw Error("Devam etmek için giriş yap.");
  return auth.currentUser.uid;
};
export async function createProfile(username: string, displayName: string) {
  displayName = displayName.trim();
  if (displayName.length < 2 || displayName.length > 60) {
    throw Error("Görünen adın 2–60 karakter olmalı.");
  }
  if (!usernameValid(username))
    throw Error(
      "Kullanıcı adı 3–24 küçük harf, rakam veya alt çizgi içermeli.",
    );
  const id = uid();
  await runTransaction(db, async (tx) => {
    const name = doc(db, "usernames", username),
      user = doc(db, "users", id);
    if ((await tx.get(user)).exists()) return;
    if ((await tx.get(name)).exists()) throw Error("Bu kullanıcı adı alınmış.");
    tx.set(name, { uid: id });
    tx.set(user, {
      uid: id,
      username,
      displayName,
      bio: "",
      avatarUrl: "",
      website: "",
      isPrivate: true,
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
      allowStrangerDM: false,
      createdAt: serverTimestamp(),
      deletionPending: false,
      termsAcceptedAt: serverTimestamp(),
      termsVersion: TERMS_VERSION,
    });
  });
}
export async function register(email: string, password: string) {
  if (password.length < 8) throw Error("En az 8 karakterli şifre seç.");
  await createUserWithEmailAndPassword(auth, email.trim(), password);
}
export const login = (email: string, password: string) =>
  signInWithEmailAndPassword(auth, email.trim(), password);
export async function logout() {
  await disablePush();
  await signOut(auth);
}
export const resetPassword = (email: string) =>
  sendPasswordResetEmail(auth, email.trim());
export async function googleLogin() {
  if (Platform.OS !== "web")
    throw Error(
      "Google girişi bu sürümde yalnızca web üzerinden kullanılabilir.",
    );
  await signInWithPopup(auth, new GoogleAuthProvider());
}
export const feedQuery = () =>
  query(
    collection(db, "posts"),
    where("audience", "==", "public"),
    where("protocol", "==", 1),
    orderBy("createdAt", "desc"),
    limit(4),
  );
export const ownPostsQuery = (id: string, publicOnly = false) =>
  query(
    collection(db, "posts"),
    where("uid", "==", id),
    ...(publicOnly ? [where("audience", "==", "public")] : []),
    orderBy("createdAt", "desc"),
    limit(50),
  );
export async function editProfile(
  data: Pick<
    Profile,
    "displayName" | "bio" | "website" | "isPrivate" | "allowStrangerDM"
  >,
) {
  await updateDoc(doc(db, "users", uid()), data);
}
export async function publish(
  profile: Profile,
  caption: string,
  mediaUrl: string,
  mediaType: "image" | "video",
  commentsEnabled: boolean,
) {
  if (!caption.trim() && !mediaUrl)
    throw Error("Bir açıklama veya medya ekle.");
  await addDoc(collection(db, "posts"), {
    uid: uid(),
    username: profile.username,
    caption: caption.trim(),
    mediaUrl,
    mediaType,
    commentsEnabled,
    audience: profile.isPrivate ? "private" : "public",
    createdAt: serverTimestamp(),
  });
}
export async function toggleLike(post: Post) {
  const target = doc(db, "posts", post.id, "likes", uid());
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(target);
    if (snap.exists()) tx.delete(target);
    else tx.set(target, { uid: uid(), createdAt: serverTimestamp() });
  });
}
export async function toggleSaved(id: string) {
  const target = doc(db, "saved", uid(), "posts", id);
  await runTransaction(db, async (tx) =>
    (await tx.get(target)).exists()
      ? tx.delete(target)
      : tx.set(target, { postId: id, createdAt: serverTimestamp() }),
  );
}
export async function comment(post: Post, text: string, profile: Profile) {
  if (!text.trim()) return;
  await addDoc(collection(db, "posts", post.id, "comments"), {
    uid: uid(),
    username: profile.username,
    text: text.trim().slice(0, 1000),
    createdAt: serverTimestamp(),
  });
}
export async function follow(profile: Profile) {
  const target = doc(db, "follows", `${uid()}_${profile.uid}`);
  const notification = doc(db, "notifications", `${uid()}_${profile.uid}`);
  await runTransaction(db, async (tx) => {
    const existing = await tx.get(target);
    // All reads precede writes, including cleanup of a previous notification.
    const previousNotification = await tx.get(notification);
    if (existing.exists()) {
      tx.delete(target);
      if (previousNotification.exists()) tx.delete(notification);
    } else {
      tx.set(target, {
        followerUid: uid(),
        followingUid: profile.uid,
        status: profile.isPrivate ? "pending" : "accepted",
        createdAt: serverTimestamp(),
      });
      tx.set(notification, {
        sourceUid: uid(),
        targetUid: profile.uid,
        type: "follow",
        text:
          "@" +
          useSession.getState().profile!.username +
          " seninle bağlantı kurmak istiyor.",
        read: false,
        createdAt: serverTimestamp(),
      });
    }
  });
}
export async function acceptFollow(id: string, accept: boolean) {
  const target = doc(db, "follows", id);
  if (accept) await updateDoc(target, { status: "accepted" });
  else await deleteDoc(target);
}
export async function chatWith(other: Profile) {
  return (await api("createChat", { members: [other.uid] })).id as string;
}
export async function sendMessage(chatId: string, text: string) {
  if (!text.trim()) return;
  const batch = writeBatch(db);
  batch.set(doc(collection(db, "chats", chatId, "messages")), {
    senderUid: uid(),
    text: text.trim().slice(0, 2000),
    type: "text",
    createdAt: serverTimestamp(),
    seenBy: [uid()],
  });
  batch.update(doc(db, "chats", chatId), {
    lastMessage: text.trim().slice(0, 100),
    lastMessageAt: serverTimestamp(),
  });
  await batch.commit();
}
export async function report(
  targetUid: string,
  reason = "Uygunsuz içerik veya hesap",
  postId?: string,
) {
  const text = reason.trim();
  if (!text || text.length > 500)
    throw Error("Şikâyet nedeni 1–500 karakter olmalı.");
  if (targetUid === uid()) throw Error("Kendi hesabını şikâyet edemezsin.");
  return addDoc(collection(db, "reports"), {
    reporterUid: uid(),
    targetUid,
    reason: text,
    ...(postId ? { postId } : {}),
    createdAt: serverTimestamp(),
  });
}
export async function block(targetUid: string) {
  await setDoc(doc(db, "users", uid(), "blocks", targetUid), {
    uid: targetUid,
    createdAt: serverTimestamp(),
  });
}

async function deleteQuery(target: Query<DocumentData>): Promise<void> {
  while (true) {
    const rows = await getDocs(query(target, limit(100)));
    if (rows.empty) return;
    const batch = writeBatch(db);
    rows.docs.forEach((row) => batch.delete(row.ref));
    await batch.commit();
  }
}

export async function deleteOwnPost(postId: string): Promise<void> {
  const target = doc(db, "posts", postId);
  const post = await getDoc(target);
  if (!post.exists()) return;
  if (post.data().uid !== uid())
    throw Error("Yalnızca kendi gönderini silebilirsin.");
  await deleteQuery(collection(db, "posts", postId, "likes"));
  await deleteQuery(collection(db, "posts", postId, "comments"));
  await deleteDoc(target);
}

const deletionKey = (id: string) => `birarada:account-deletion:${id}`;
type PendingDeletion = { uid: string; username: string; startedAt: number };

export async function loadPendingDeletion(id: string): Promise<boolean> {
  const value = await AsyncStorage.getItem(deletionKey(id));
  if (!value) return false;
  try {
    return (JSON.parse(value) as PendingDeletion).uid === id;
  } catch {
    return false;
  }
}

export async function deleteOwnAccount(password: string): Promise<void> {
  const account = auth.currentUser;
  if (!account) throw Error("Hesabını silmek için giriş yap.");
  if (useSession.getState().deleting)
    throw Error("Hesap silme işlemi zaten sürüyor.");
  const id = account.uid;
  let marker: PendingDeletion | null = null;
  const stored = await AsyncStorage.getItem(deletionKey(id));
  if (stored) {
    try {
      marker = JSON.parse(stored) as PendingDeletion;
    } catch {}
  }
  const isPasswordAccount = account.providerData.some(
    (provider) => provider.providerId === "password",
  );
  try {
    await runDeletionPlan({
      async confirmIdentity() {
        if (isPasswordAccount) {
          if (!account.email || !password)
            throw Error("Hesabını silmek için mevcut şifreni yaz.");
          await reauthenticateWithCredential(
            account,
            EmailAuthProvider.credential(account.email, password),
          );
        } else if (Platform.OS === "web") {
          await reauthenticateWithPopup(account, new GoogleAuthProvider());
        } else {
          throw Error(
            "Bu giriş sağlayıcısı için güvenli yeniden doğrulama henüz desteklenmiyor.",
          );
        }
        if (auth.currentUser?.uid !== id)
          throw Error("Oturum değişti; silme işlemi iptal edildi.");
        useSession.getState().set({ deleting: true, deletionError: "" });
      },
      async markPending() {
        const profile = await getDoc(doc(db, "users", id));
        marker = {
          uid: id,
          username: profile.data()?.username || marker?.username || "",
          startedAt: marker?.startedAt || Date.now(),
        };
        await AsyncStorage.setItem(deletionKey(id), JSON.stringify(marker));
        useSession.getState().set({ deletionPending: true });
        if (profile.exists() && profile.data().deletionPending !== true) {
          await updateDoc(profile.ref, { deletionPending: true });
        }
        return { profileExists: profile.exists() };
      },
      async removeOwnedPosts() {
        await api("cleanupSocialData");
        while (true) {
          const posts = await getDocs(
            query(
              collection(db, "posts"),
              where("uid", "==", id),
              where("protocol", "==", 1),
              limit(25),
            ),
          );
          if (posts.empty) return;
          for (const post of posts.docs) await deleteOwnPost(post.id);
        }
      },
      async removeAuthoredActivity() {
        for (const kind of ["likes", "comments"]) {
          await deleteQuery(
            query(collectionGroup(db, kind), where("uid", "==", id)),
          );
        }
        await deleteQuery(
          query(collectionGroup(db, "messages"), where("senderUid", "==", id)),
        );
      },
      async clearChatPreviews() {
        const chats = await getDocs(
          query(
            collection(db, "chats"),
            where("memberIds", "array-contains", id),
          ),
        );
        // Remove previews which could contain text from the deleted account.
        // Other participants' messages and membership history are retained.
        for (const chat of chats.docs) {
          await updateDoc(chat.ref, {
            lastMessage: "",
            lastMessageAt: serverTimestamp(),
          });
        }
      },
      async removeConnections() {
        await deleteQuery(
          query(collection(db, "follows"), where("followerUid", "==", id)),
        );
        await deleteQuery(
          query(collection(db, "follows"), where("followingUid", "==", id)),
        );
      },
      async removePrivateData() {
        await deleteDoc(doc(db, "notes", id));
        await deleteQuery(collection(db, "saved", id, "posts"));
        await deleteQuery(collection(db, "users", id, "blocks"));
        await deleteQuery(
          query(collection(db, "notifications"), where("targetUid", "==", id)),
        );
        await deleteQuery(
          query(collection(db, "notifications"), where("sourceUid", "==", id)),
        );
        await deleteQuery(
          query(collection(db, "reports"), where("reporterUid", "==", id)),
        );
        await AsyncStorage.removeItem(`draft:${id}`);
      },
      async removeProfileAndUsername() {
        await runTransaction(db, async (tx) => {
          const profile = await tx.get(doc(db, "users", id));
          const username = profile.data()?.username || marker?.username;
          const name = username
            ? await tx.get(doc(db, "usernames", username))
            : null;
          if (name?.exists() && name.data().uid === id) tx.delete(name.ref);
          if (profile.exists()) tx.delete(profile.ref);
        });
      },
      async removeAuthentication() {
        await deleteUser(account);
        await AsyncStorage.removeItem(deletionKey(id));
        useSession
          .getState()
          .set({ deletionPending: false, deletionError: "" });
      },
    });
  } catch (error) {
    useSession.getState().set({ deletionError: friendly(error) });
    throw error;
  } finally {
    useSession.getState().set({ deleting: false });
  }
}
