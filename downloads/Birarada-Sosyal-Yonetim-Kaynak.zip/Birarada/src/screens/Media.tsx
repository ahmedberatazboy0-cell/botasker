import React, { useEffect, useRef, useState } from "react";
import {
  FlatList,
  Pressable,
  ScrollView,
  Switch,
  Text,
  View,
  Share,
  useWindowDimensions,
  type ViewToken,
} from "react-native";
import { Image } from "expo-image";
import { useIsFocused, useFocusEffect } from "@react-navigation/native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { ImagePickerAsset } from "expo-image-picker";
import { api, newId, uploadMedia, type MediaItem } from "../services/api";
import { selectMedia } from "../services/picker";
import { useApiList } from "../hooks/useApiList";
import { useSession } from "../store/session";
import {
  Page,
  Label,
  Field,
  Button,
  State,
  ReportForm,
  styles,
} from "../components/ui";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { PostCard } from "../components/PostCard";
import type { Post } from "../types";
import { toggleLike, toggleSaved } from "../services/social";

export function Create({ route, navigation }: any) {
  const profile = useSession((s) => s.profile)!,
    initial = route?.params?.kind || "post";
  const [kind, setKind] = useState<"post" | "story" | "reel">(initial),
    [caption, setCaption] = useState(""),
    [assets, setAssets] = useState<ImagePickerAsset[]>([]),
    [comments, setComments] = useState(true),
    [notice, setNotice] = useState(""),
    [busy, setBusy] = useState(false);
  const request = useRef(newId()),
    uploads = useRef(new Map<string, MediaItem>());
  useEffect(() => {
    if (route?.params?.kind) setKind(route.params.kind);
  }, [route?.params?.kind]);
  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(`draft:${profile.uid}`).then((value) => {
      if (alive && value) setCaption(value);
    });
    return () => {
      alive = false;
    };
  }, [profile.uid]);
  async function choose(camera = false) {
    const selected = await selectMedia({
      camera,
      multiple: kind === "post",
      videoOnly: kind === "reel",
    });
    if (selected.length) {
      setAssets(selected);
      uploads.current.clear();
      request.current = newId();
      setNotice("");
    }
  }
  async function submit() {
    setBusy(true);
    setNotice("");
    try {
      const ids: string[] = [];
      for (let i = 0; i < assets.length; i++) {
        const asset = assets[i]!;
        setNotice(`Medya yükleniyor ve işleniyor: ${i + 1}/${assets.length}`);
        let item = uploads.current.get(asset.uri);
        if (!item) {
          item = await uploadMedia(
            asset.uri,
            asset.type === "video" ? "video" : "image",
            kind,
          );
          uploads.current.set(asset.uri, item);
        }
        ids.push(item.id);
      }
      await api("publishContent", {
        requestId: request.current,
        kind,
        caption,
        mediaIds: ids,
        commentsEnabled: comments,
      });
      setAssets([]);
      setCaption("");
      uploads.current.clear();
      request.current = newId();
      await AsyncStorage.removeItem(`draft:${profile.uid}`);
      setNotice("Paylaşımın yayınlandı.");
      if (kind === "story") navigation.goBack();
      else navigation.navigate("Ana Sayfa");
    } finally {
      setBusy(false);
    }
  }
  return (
    <Page title="Yeni paylaşım">
      <View style={[styles.row, { flexWrap: "wrap" }]}>
        {(
          [
            ["post", "Gönderi"],
            ["story", "Hikâye"],
            ["reel", "Reels"],
          ] as const
        ).map(([value, label]) => (
          <Button
            key={value}
            title={label}
            secondary={kind !== value}
            disabled={busy}
            onPress={() => {
              setKind(value);
              setAssets([]);
              uploads.current.clear();
              request.current = newId();
            }}
          />
        ))}
      </View>
      <Label muted>
        {profile.isPrivate
          ? "Yalnız onaylı takipçilerin görebilir."
          : "Herkese açık paylaşım."}{" "}
        {kind === "story"
          ? "Hikâyen 24 saat görünür; öne çıkanlara ekleyebilirsin."
          : kind === "reel"
            ? "En fazla 90 saniyelik dikey video."
            : "En fazla 10 fotoğraf/video. #etiket ve @kullanıcı ekleyebilirsin."}
      </Label>
      <Field
        placeholder="Açıklama, #etiket, @kullanıcı…"
        multiline
        maxLength={2200}
        value={caption}
        editable={!busy}
        onChangeText={setCaption}
        style={{ minHeight: 100 }}
      />
      <ScrollView horizontal>
        {assets.map((asset, index) => (
          <View key={asset.uri} style={{ marginRight: 10, gap: 6 }}>
            <Image
              source={asset.uri}
              style={{ width: 180, height: 230, borderRadius: 14 }}
              contentFit="cover"
            />
            <Label>
              {index + 1}. {asset.type === "video" ? "Video" : "Fotoğraf"}
            </Label>
            <Button
              title="Kaldır"
              secondary
              disabled={busy}
              onPress={() => {
                setAssets((old) => old.filter((_, i) => i !== index));
                request.current = newId();
              }}
            />
          </View>
        ))}
      </ScrollView>
      <View style={[styles.row, { flexWrap: "wrap" }]}>
        <Button
          title="Galeriden seç"
          secondary
          disabled={busy}
          onPress={() => choose()}
        />
        <Button
          title="Kamera / kırp"
          secondary
          disabled={busy}
          onPress={() => choose(true)}
        />
      </View>
      {kind !== "story" && (
        <View style={styles.row}>
          <Label>Yorumlara izin ver</Label>
          <Switch
            disabled={busy}
            value={comments}
            onValueChange={setComments}
          />
        </View>
      )}
      <Button
        title="Açıklamayı taslak kaydet"
        secondary
        disabled={busy}
        onPress={async () => {
          await AsyncStorage.setItem(`draft:${profile.uid}`, caption);
          setNotice(
            "Açıklama bu cihaza kaydedildi. Medyayı yeniden seçmelisin.",
          );
        }}
      />
      <Button
        title={busy ? "Paylaşılıyor…" : "Paylaş"}
        disabled={
          busy || (!assets.length && (kind !== "post" || !caption.trim()))
        }
        onPress={submit}
      />
      {!!notice && <Label>{notice}</Label>}
    </Page>
  );
}
function Reel({
  post,
  active,
  height,
  navigation,
}: {
  post: Post;
  active: boolean;
  height: number;
  navigation: any;
}) {
  const focused = useIsFocused(),
    [comments, setComments] = useState(false),
    [report, setReport] = useState(false),
    item = post.mediaItems?.[0];
  return (
    <View style={{ height, backgroundColor: "#000" }}>
      {item && (
        <ProtectedMedia
          item={item}
          active={active && focused && !comments && !report}
          style={{ width: "100%", height }}
        />
      )}
      <View
        style={{
          position: "absolute",
          bottom: 12,
          left: 14,
          right: 14,
          backgroundColor: "#101112c9",
          padding: 12,
          gap: 8,
          borderRadius: 12,
        }}
      >
        <Pressable
          onPress={() => navigation.navigate("User", { uid: post.uid })}
        >
          <Text style={[styles.text, { fontWeight: "700" }]}>
            @{post.username}
          </Text>
        </Pressable>
        <Label>{post.caption}</Label>
        <View style={[styles.row, { flexWrap: "wrap" }]}>
          <Button secondary title="♡ Beğen" onPress={() => toggleLike(post)} />
          <Button
            secondary
            title="Kaydet"
            onPress={() => toggleSaved(post.id)}
          />
          <Button
            secondary
            title="Paylaş"
            onPress={() =>
              Share.share({
                message: `Birarada · @${post.username}\n${post.caption}`,
              })
            }
          />
          <Button
            secondary
            title="Yorumlar"
            onPress={() => setComments(!comments)}
          />
          <Button
            secondary
            title="Şikâyet"
            onPress={() => setReport(!report)}
          />
        </View>
        {comments && (
          <View style={{ maxHeight: height * 0.5 }}>
            <ScrollView>
              <PostCard
                post={post}
                hideMedia
                openProfile={(uid) => navigation.navigate("User", { uid })}
              />
            </ScrollView>
          </View>
        )}
        {report && (
          <ReportForm
            onSubmit={async (reason) => {
              await api("reportContent", { kind: "reel", id: post.id, reason });
              setReport(false);
            }}
            onCancel={() => setReport(false)}
          />
        )}
      </View>
    </View>
  );
}
export function ShortVideos({ navigation }: any) {
  const data = useApiList("listContent", { kind: "reel" }),
    [active, setActive] = useState("");
  const height = Math.max(360, useWindowDimensions().height - 130),
    change = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) =>
      setActive(viewableItems[0]?.item.id || ""),
    );
  useFocusEffect(
    React.useCallback(() => {
      data.refresh();
    }, [data.refresh]),
  );
  return (
    <Page scroll={false}>
      <FlatList
        data={data.rows}
        pagingEnabled
        keyExtractor={(r) => r.id}
        initialNumToRender={2}
        maxToRenderPerBatch={2}
        windowSize={3}
        onViewableItemsChanged={change.current}
        viewabilityConfig={{ itemVisiblePercentThreshold: 70 }}
        onEndReached={data.loadMore}
        onEndReachedThreshold={0.7}
        refreshing={data.loading}
        onRefresh={data.refresh}
        getItemLayout={(_, i) => ({
          length: height,
          offset: height * i,
          index: i,
        })}
        ListEmptyComponent={<State {...data} empty retry={data.refresh} />}
        renderItem={({ item }) => (
          <Reel
            post={item as Post}
            height={height}
            active={active === item.id}
            navigation={navigation}
          />
        )}
      />
    </Page>
  );
}
