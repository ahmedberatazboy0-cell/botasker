import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  View,
  type StyleProp,
  type ViewStyle,
} from "react-native";
import { Image } from "expo-image";
import { useVideoPlayer, VideoView } from "expo-video";
import { useAudioPlayer, useAudioPlayerStatus } from "expo-audio";
import { onIdTokenChanged } from "firebase/auth";
import { auth } from "../firebase/client";
import { mediaEndpoint, type MediaItem } from "../services/api";
import { Button, Label } from "./ui";
function useToken() {
  const [token, setToken] = useState("");
  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const t = await auth.currentUser?.getIdToken();
        if (alive) setToken(t || "");
      } catch {
        if (alive) setToken("");
      }
    };
    const stop = onIdTokenChanged(auth, () => {
        void load();
      }),
      timer = setInterval(() => {
        void load();
      }, 40 * 60000);
    return () => {
      alive = false;
      stop();
      clearInterval(timer);
    };
  }, []);
  return token;
}
export function ProtectedImage({
  id,
  label,
  style,
}: {
  id: string;
  label?: string;
  style: StyleProp<ViewStyle>;
}) {
  const token = useToken(),
    [error, setError] = useState(false);
  useEffect(() => setError(false), [id, token]);
  if (!token)
    return (
      <View style={style}>
        <ActivityIndicator />
      </View>
    );
  if (error)
    return (
      <View style={style}>
        <Label>Fotoğraf şu an açılamıyor.</Label>
      </View>
    );
  return (
    <Image
      source={{
        uri: mediaEndpoint("mediaContent", id),
        headers: { Authorization: `Bearer ${token}` },
      }}
      accessibilityLabel={label || "Paylaşılan fotoğraf"}
      cachePolicy="none"
      contentFit="cover"
      style={style as any}
      onError={() => setError(true)}
    />
  );
}
function Audio({
  id,
  token,
  style,
}: {
  id: string;
  token: string;
  style: StyleProp<ViewStyle>;
}) {
  const source = useMemo(
    () => ({
      uri: mediaEndpoint("mediaContent", id),
      headers: { Authorization: `Bearer ${token}` },
    }),
    [id, token],
  );
  const player = useAudioPlayer(source),
    status = useAudioPlayerStatus(player);
  return (
    <View style={style}>
      <Button
        secondary
        title={status.playing ? "Sesi duraklat" : "Sesli mesajı dinle"}
        onPress={() => {
          if (status.playing) player.pause();
          else {
            if (status.didJustFinish) void player.seekTo(0);
            player.play();
          }
        }}
      />
      <Label muted>
        {Math.floor(status.currentTime || 0)} /{" "}
        {Math.floor(status.duration || 0)} sn
      </Label>
    </View>
  );
}
function Player({
  id,
  token,
  active,
  style,
  loop,
  onEnd,
}: {
  id: string;
  token: string;
  active: boolean;
  style: StyleProp<ViewStyle>;
  loop: boolean;
  onEnd?: () => void;
}) {
  const source = useMemo(
    () => ({
      uri: mediaEndpoint("mediaContent", id),
      headers: { Authorization: `Bearer ${token}` },
      contentType: "progressive" as const,
      useCaching: false,
    }),
    [id, token],
  );
  const player = useVideoPlayer(source, (p) => {
    p.loop = loop;
    p.muted = true;
  });
  useEffect(() => {
    if (active) player.play();
    else player.pause();
  }, [player, active]);
  useEffect(() => {
    if (!onEnd) return;
    const subscription = player.addListener("playToEnd", onEnd);
    return () => subscription.remove();
  }, [player, onEnd]);
  return (
    <VideoView
      player={player}
      style={style}
      nativeControls
      contentFit="contain"
      allowsPictureInPicture={false}
    />
  );
}
export function ProtectedMedia({
  item,
  active = false,
  style,
  loop = true,
  onEnd,
}: {
  item: MediaItem;
  active?: boolean;
  style?: StyleProp<ViewStyle>;
  loop?: boolean;
  onEnd?: () => void;
}) {
  const token = useToken(),
    frame = style || {
      width: "100%" as const,
      aspectRatio: item.kind === "audio" ? 4 : 1,
      backgroundColor: "#17191d",
      borderRadius: 14,
    };
  if (item.kind === "image")
    return <ProtectedImage id={item.id} style={frame} />;
  if (!token)
    return (
      <View style={frame}>
        <ActivityIndicator />
      </View>
    );
  if (item.kind === "audio")
    return <Audio id={item.id} token={token} style={frame} />;
  return (
    <Player
      id={item.id}
      token={token}
      active={active}
      style={frame}
      loop={loop}
      onEnd={onEnd}
    />
  );
}
