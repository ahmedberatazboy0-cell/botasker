# Birarada

Expo SDK 54 / React Native uygulaması ve Firebase Functions sunucusu. Android/iOS kimliği **com.birarada.app**, sürüm **1.0.0**, ilk Android versionCode **1**. Mevcut Expo projesi **@ahmedberat/birarada**, projectId **9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b**. Mevcut EAS imzalama anahtarını kullan; yeni proje veya anahtar oluşturma.

**Bu teslim kaynak ZIP'idir. Yeni imzalı AAB içermez; canlı sunucu dağıtımı ve gerçek cihaz doğrulaması tamamlanmadı.** Önceden ürettiğin AAB bu yeni özellikleri içermez. Son doğrulama ve kalan işler: [TEST_REPORT.md](TEST_REPORT.md).

## Eklenen akışlar

- Fotoğraf/video gönderileri, en fazla 10 öğeli kaydırılabilir paylaşım, kamera/sistem galeri seçicisi, açıklama taslağı ve yorum tercihi.
- Takip edilenler/keşfet akışı, üç sütunlu profil, gerçek gönderi/takipçi sayıları, kullanıcı/kelime/etiket araması.
- 24 saatlik hikâyeler, görüntüleyenler, yanıt, öne çıkanlar ve sahibine 30 günlük arşiv.
- Dikey Reels akışı, görünür videonun otomatik oynatılması, beğeni/yorum/kaydetme ve metin paylaşımı.
- Bireysel/grup sohbetleri, fotoğraf/video/ses mesajı, yanıt, emoji tepkisi, düzenleme/silme ve görüldü bilgisi.
- Şarkı adı + Spotify/YouTube bağlantılı notlar korunur; şarkı ilgili serviste açılır.
- Yetkiye göre yönetim paneli: şikâyet inceleme, sınırlı kanıt erişimi, içerik kaldırma, hesap kısıtlama, rol yönetimi, duyuru/bakım ve yeni paylaşım açıklamalarında kelime filtresi. Hassas işlemler açık onay ve gerekçe ister.
- İsteğe bağlı cihaz bildirimi kaydı ve sunucu gönderim kodu. Gerçek Android bildirim teslimi ayrıca Firebase/Expo FCM yapılandırması gerektirir ve henüz sınanmadı.

Sunucu her medya isteğinde oturumu ve erişim hakkını kontrol eder; herkese açık Firebase download-token URL'si üretilmez. Storage istemci SDK'sı kapalı kalır. Yeni medya HTTP sunucu kapısından geçer; `EXPO_PUBLIC_STORAGE_ENABLED=false` bunu kapatmaz. Eski metin gönderileriyle uyumluluk korunur; yeni gönderiler mevcut hesap gizliliğine de uyar.

## Kurulum ve AAB

Node.js **22 veya 24 LTS**, Java **21+**, Chrome/Edge gerekir. ZIP'i çıkarıp `Birarada` klasörünü aç.

1. **FIREBASE_KUR.bat**: bağımlılıkları ve sunucu kontrollerini çalıştırır, resmî Google girişini açar, yalnız `birarada-5650c` sunucusunu/kurallarını/indekslerini dağıtır. Blaze planını kendiliğinden açmaz; Hosting sitesini değiştirmez.
2. Güncel yasal sayfaları mevcut sitenin tam çıktısına [Hosting rehberine](docs/HOSTING.md) göre birleştir. Firebase Console'da Email/Password, Firestore ve mevcut Storage bucket kurulmuş olmalı. [Canlı kurulum](docs/CANLI_KURULUM.md).
3. **AAB_OLUSTUR.bat**: uygulama, sunucu, güvenlik ve arayüz kontrollerini çalıştırır; canlı sunucu sürümünü/yasal sayfaları kontrol eder. Başarılıysa mevcut Expo projesi ve keystore ile üretim AAB derlemesini başlatır. GitHub kurulumu gerekmez. Son `.aab` bağlantısını EAS verir.

Kontroller başarısız olursa üretim derlemesi durur. Bu araçlar Play Console'a otomatik göndermez. Fiziksel telefonda kamera, video, mikrofon, iki hesapla erişim/silme ve gerçek bildirimleri doğrula; son AAB'de 16 KB native uyumluluğunu ve Play ön kontrollerini tamamla. Google inceleme/yayın süresini bu kod belirlemez.

## Resmî hesap ve yönetim

`ahmedberatazboy0@gmail.com` adresiyle uygulamada kendi hesabını oluştur, gelen doğrulama e-postasını onayla. Profil kurulumunda veya Ayarlar'da **Resmî hesabı etkinleştir** işlemini kullan. Sunucu doğrulanmış oturumu kendi yapılandırmasıyla karşılaştırıp `birarada` profilini ve tek seferlik sahip UID bağlantısını oluşturur; owner custom claim'i yalnız sunucu yazar. Sonra Ayarlar → **Yönetim paneli** açılır.

Bu işlem canlıda henüz yapılmadı. E-posta veya istemci profil alanı tek başına yönetici yetkisi sağlamaz. Paylaşılan parola kaynaklara eklenmedi; bu parola yerine yeni ve yalnız bu hesaba ait bir parola kullan.

## Geliştirme

`npm ci`, `npm run backend:install`, `npm run typecheck`, `npm test`, `npm run test:backend`, `npm run test:rules`, `npm run test:auth`, `npm run test:ui`, `npm run test:social`.

Sosyal entegrasyon testleri yalnız `demo-birarada` yerel Auth/Firestore/Functions ortamını kullanır. Medya baytları testte geçici dosya sisteminde saklanır; gerçek Cloud Storage ve haricî push teslimi doğrulaması sayılmaz. Sunucu için `functions/.env.example`, istemci için `.env.example` yalnız açık yapılandırma örnekleridir. Parola, token, service account ve imzalama anahtarını kaynaklara ekleme.

Destek: **ahmedberatazboy0@gmail.com**.
