"use strict";
const { test } = require("node:test"),
  assert = require("node:assert/strict"),
  { createRequire } = require("node:module"),
  path = require("node:path"),
  { randomUUID } = require("node:crypto");
const serverRequire = createRequire(
  path.resolve(__dirname, "../functions/package.json"),
);
test("Firestore handlers: timelines, idempotent notifications, push transport and expiration", async (t) => {
  assert.equal(process.env.GCLOUD_PROJECT, "demo-birarada");
  assert.equal(process.env.FIRESTORE_EMULATOR_HOST, "127.0.0.1:8080");
  process.env.FUNCTIONS_EMULATOR = "true";
  const handlers = require("../functions/lib/index.js"),
    { getFirestore, Timestamp } = serverRequire("firebase-admin/firestore"),
    db = getFirestore();
  const author = "qa-trigger-author",
    follower = "qa-trigger-follower",
    stamp = Timestamp.now(),
    postId = randomUUID();
  await db
    .doc("users/" + author)
    .set({
      uid: author,
      username: "trigger_author",
      isPrivate: false,
      deletionPending: false,
    });
  await db
    .doc("users/" + follower)
    .set({
      uid: follower,
      username: "trigger_follower",
      isPrivate: false,
      deletionPending: false,
    });
  await db
    .doc(`follows/${follower}_${author}`)
    .set({ followerUid: follower, followingUid: author, status: "accepted" });
  const postRef = db.doc("posts/" + postId);
  await postRef.set({
    uid: author,
    createdAt: stamp,
    mediaIds: [],
    caption: "trigger fixture",
  });
  const post = await postRef.get();
  await t.test(
    "post fanout writes reference-only timelines and follow acceptance seeds recent posts",
    async () => {
      await handlers.fanoutPost.run({
        id: "fanout-" + postId,
        params: { postId },
        data: post,
      });
      assert.deepEqual(
        Object.keys(
          (await db.doc(`timelines/${follower}/posts/${postId}`).get()).data(),
        ),
        ["createdAt"],
      );
      await db.doc(`timelines/${follower}/posts/${postId}`).delete();
      const follow = await db.doc(`follows/${follower}_${author}`).get();
      await handlers.seedTimeline.run({
        params: { id: follow.id },
        data: {
          before: { data: () => ({ status: "pending" }) },
          after: follow,
        },
      });
      assert.equal(
        (await db.doc(`timelines/${follower}/posts/${postId}`).get()).exists,
        true,
      );
    },
  );
  let notification;
  await t.test("retried like events create only one notification", async () => {
    const event = { id: "like-" + postId, params: { postId, uid: follower } };
    await handlers.onLike.run(event);
    await handlers.onLike.run(event);
    const rows = await db
      .collection("notifications")
      .where("targetUid", "==", author)
      .get();
    const matching = rows.docs.filter(
      (r) => r.get("target")?.postId === postId,
    );
    assert.equal(matching.length, 1);
    notification = matching[0];
  });
  await t.test(
    "push payload hides message text and invalid device tickets remove tokens",
    async () => {
      const device = db.doc("pushDevices/" + randomUUID());
      await device.set({
        uid: author,
        enabled: true,
        token: "ExponentPushToken[local-fixture-only]",
      });
      const original = global.fetch;
      let sent;
      global.fetch = async (url, opts) => {
        assert.equal(url, "https://exp.host/--/api/v2/push/send");
        sent = JSON.parse(opts.body);
        return {
          ok: true,
          json: async () => ({
            data: sent.map(() => ({
              details: { error: "DeviceNotRegistered" },
            })),
          }),
        };
      };
      try {
        await handlers.sendPush.run({
          id: "send-" + postId,
          params: { id: notification.id },
          data: notification,
        });
      } finally {
        global.fetch = original;
      }
      assert.equal(sent[0].body, "Yeni bir bildirimin var.");
      assert.equal(sent[0].data.targetUid, author);
      assert.equal((await device.get()).exists, false);
    },
  );
  await t.test(
    "expired upload metadata and unhighlighted 30-day stories are removed",
    async () => {
      const media = db.doc("media/" + randomUUID()),
        story = db.doc("stories/" + randomUUID()),
        highlight = db.doc("stories/" + randomUUID());
      await media.set({
        uid: author,
        status: "pending",
        expiresAt: Timestamp.fromMillis(1),
      });
      await story.set({
        uid: author,
        highlighted: false,
        expiresAt: Timestamp.fromMillis(1),
        mediaIds: [],
      });
      await highlight.set({
        uid: author,
        highlighted: true,
        expiresAt: Timestamp.fromMillis(1),
        mediaIds: [],
      });
      await handlers.purgeExpired.run({});
      assert.equal((await media.get()).exists, false);
      assert.equal((await story.get()).exists, false);
      assert.equal((await highlight.get()).exists, true);
    },
  );
});
