"use strict";
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { randomUUID } = require("node:crypto");
const { createRequire } = require("node:module");
const path = require("node:path");
const fs = require("node:fs/promises");
const os = require("node:os");
const { promisify } = require("node:util");
const { execFile } = require("node:child_process");
const serverRequire = createRequire(
  path.join(__dirname, "../functions/package.json"),
);
const { initializeApp: initializeAdmin, deleteApp: deleteAdmin } =
  serverRequire("firebase-admin/app");
const { getAuth: adminAuth } = serverRequire("firebase-admin/auth");
const { getFirestore: adminDb, Timestamp } = serverRequire(
  "firebase-admin/firestore",
);
const sharp = serverRequire("sharp"),
  ffmpeg = serverRequire("ffmpeg-for-homebridge");
const { initializeApp, deleteApp } = require("firebase/app");
const {
  initializeAuth,
  inMemoryPersistence,
  connectAuthEmulator,
  signInWithEmailAndPassword,
} = require("firebase/auth");
const BASE = "http://127.0.0.1:5001/demo-birarada/europe-west1";

test(
  "real Auth + Firestore + Functions: ownership, private media, stories, chats and moderation",
  { timeout: 150000 },
  async (t) => {
    assert.equal(process.env.FIRESTORE_EMULATOR_HOST, "127.0.0.1:8080");
    assert.equal(process.env.FIREBASE_AUTH_EMULATOR_HOST, "127.0.0.1:9099");
    const admin = initializeAdmin(
        { projectId: "demo-birarada" },
        "social-integration",
      ),
      db = adminDb(admin),
      auth = adminAuth(admin),
      apps = [],
      people = {};
    const fixture = await fs.mkdtemp(
      path.join(os.tmpdir(), "birarada-api-test-"),
    );
    async function invoke(person, action, input = {}) {
      const response = await fetch(BASE + "/socialApi", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(person
            ? { Authorization: `Bearer ${await person.getIdToken()}` }
            : {}),
        },
        body: JSON.stringify({ data: { action, input } }),
        signal: AbortSignal.timeout(45000),
      });
      const result = await response.json();
      return {
        status: response.status,
        data: result.result ?? result.data,
        error: result.error,
      };
    }
    async function ok(person, action, input = {}) {
      const r = await invoke(person, action, input);
      assert.equal(r.status, 200, `${action}: ${JSON.stringify(r.error)}`);
      return r.data;
    }
    async function denied(person, action, input = {}) {
      const r = await invoke(person, action, input);
      assert.ok(r.status >= 400, `${action} must be denied`);
      return r;
    }
    async function media(person, id, options = {}) {
      return fetch(BASE + "/mediaContent?id=" + id, {
        headers: {
          ...(person
            ? { Authorization: `Bearer ${await person.getIdToken()}` }
            : {}),
        },
        ...options,
        signal: AbortSignal.timeout(15000),
      });
    }
    const image = await sharp({
      create: { width: 64, height: 48, channels: 3, background: "#f09060" },
    })
      .png()
      .toBuffer();
    async function upload(person, purpose, bytes = image, kind = "image") {
      const requestId = randomUUID();
      await ok(person, "createUpload", {
        requestId,
        kind,
        purpose,
        bytes: bytes.length,
      });
      const response = await fetch(BASE + "/mediaUpload?id=" + requestId, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${await person.getIdToken()}`,
          "Content-Type": "application/octet-stream",
        },
        body: bytes,
        signal: AbortSignal.timeout(120000),
      });
      assert.equal(response.status, 200, await response.text());
      return requestId;
    }
    try {
      for (const name of [
        "alice",
        "bob",
        "charlie",
        "eve",
        "official",
        "moderator",
      ]) {
        const uid = "qa-" + name,
          email =
            name === "official"
              ? "official@example.test"
              : name + "@example.test";
        try {
          await auth.deleteUser(uid);
        } catch {}
        await auth.createUser({
          uid,
          email,
          password: "Local-emulator-only-942!",
          emailVerified: true,
        });
        if (name === "moderator")
          await auth.setCustomUserClaims(uid, { biraradaRole: "moderator" });
        const app = initializeApp(
          { apiKey: "demo-key", projectId: "demo-birarada" },
          "backend-" + name,
        );
        apps.push(app);
        const client = initializeAuth(app, {
          persistence: inMemoryPersistence,
        });
        connectAuthEmulator(client, "http://127.0.0.1:9099", {
          disableWarnings: true,
        });
        people[name] = (
          await signInWithEmailAndPassword(
            client,
            email,
            "Local-emulator-only-942!",
          )
        ).user;
        if (name !== "official")
          await db
            .doc("users/" + uid)
            .set({
              uid,
              username: name,
              displayName: name,
              bio: "",
              avatarUrl: "",
              website: "",
              isPrivate: name === "alice",
              allowStrangerDM: name !== "eve",
              deletionPending: false,
              createdAt: Timestamp.now(),
              termsAcceptedAt: Timestamp.now(),
              termsVersion: "2026-10-21",
            });
      }
      const { alice, bob, charlie, eve, official, moderator } = people;
      await t.test(
        "anonymous calls and body-supplied admin roles are denied",
        async () => {
          await denied(null, "capabilities");
          await denied(alice, "dashboard", {
            role: "owner",
            email: "official@example.test",
          });
          await denied(alice, "activateOwner", { acceptTerms: true });
        },
      );
      await t.test(
        "verified official owner activation creates a UID-pinned account and server role",
        async () => {
          await db.doc("system/owner").delete();
          await db.doc("usernames/birarada").delete();
          await ok(official, "activateOwner", { acceptTerms: true });
          await official.getIdToken(true);
          assert.equal(
            (await db.doc("system/owner").get()).get("uid"),
            official.uid,
          );
          assert.equal(
            (await db.doc("users/" + official.uid).get()).get("official"),
            true,
          );
          assert.equal((await ok(official, "capabilities")).role, "owner");
          const wrong = await db.doc("system/owner").get();
          await wrong.ref.set({ uid: "previous-owner" });
          await denied(official, "activateOwner", { acceptTerms: true });
          await wrong.ref.set({ uid: official.uid });
        },
      );
      let privatePost, privateMedia;
      await t.test(
        "upload reservations cannot be filled by another user; malformed images are rejected",
        async () => {
          const key = randomUUID();
          await ok(alice, "createUpload", {
            requestId: key,
            kind: "image",
            purpose: "post",
            bytes: image.length,
          });
          const response = await fetch(BASE + "/mediaUpload?id=" + key, {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${await eve.getIdToken()}`,
              "Content-Type": "application/octet-stream",
            },
            body: image,
          });
          assert.equal(response.status, 403);
          const bad = Buffer.from("<svg>not a trusted image</svg>"),
            badKey = randomUUID();
          await ok(alice, "createUpload", {
            requestId: badKey,
            kind: "image",
            purpose: "post",
            bytes: bad.length,
          });
          const badResponse = await fetch(BASE + "/mediaUpload?id=" + badKey, {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${await alice.getIdToken()}`,
              "Content-Type": "application/octet-stream",
            },
            body: bad,
          });
          assert.equal(badResponse.status, 400);
        },
      );
      await t.test(
        "private image access requires a current accepted follow and disappears after removal/blocking",
        async () => {
          privateMedia = await upload(alice, "post");
          privatePost = randomUUID();
          await ok(alice, "publishContent", {
            requestId: privatePost,
            kind: "post",
            caption: "Gizli fotoğraf",
            mediaIds: [privateMedia],
          });
          await ok(alice, "publishContent", {
            requestId: privatePost,
            kind: "post",
            caption: "Gizli fotoğraf",
            mediaIds: [privateMedia],
          });
          assert.equal((await media(null, privateMedia)).status, 401);
          assert.equal((await media(eve, privateMedia)).status, 403);
          await db
            .doc("follows/" + bob.uid + "_" + alice.uid)
            .set({
              followerUid: bob.uid,
              followingUid: alice.uid,
              status: "pending",
              createdAt: Timestamp.now(),
            });
          assert.equal((await media(bob, privateMedia)).status, 403);
          await db
            .doc("follows/" + bob.uid + "_" + alice.uid)
            .update({ status: "accepted" });
          const response = await media(bob, privateMedia);
          assert.equal(response.status, 200);
          assert.equal(
            response.headers.get("cache-control"),
            "private, no-store",
          );
          assert.equal(response.headers.get("content-type"), "image/jpeg");
          assert.ok((await response.arrayBuffer()).byteLength > 100);
          const range = await fetch(BASE + "/mediaContent?id=" + privateMedia, {
            headers: {
              Authorization: `Bearer ${await bob.getIdToken()}`,
              Range: "bytes=0-15",
            },
          });
          assert.equal(range.status, 206);
          assert.equal((await range.arrayBuffer()).byteLength, 16);
          await db.doc("follows/" + bob.uid + "_" + alice.uid).delete();
          assert.equal((await media(bob, privateMedia)).status, 403);
          await db
            .doc("follows/" + bob.uid + "_" + alice.uid)
            .set({
              followerUid: bob.uid,
              followingUid: alice.uid,
              status: "accepted",
              createdAt: Timestamp.now(),
            });
          await db
            .doc("users/" + alice.uid + "/blocks/" + bob.uid)
            .set({ uid: bob.uid });
          assert.equal((await media(bob, privateMedia)).status, 403);
          await db.doc("users/" + alice.uid + "/blocks/" + bob.uid).delete();
        },
      );
      await t.test(
        "real Reels upload/transcoding appears in discovery and is searchable by tag",
        async () => {
          await db.doc("users/" + alice.uid).update({ isPrivate: false });
          const file = path.join(fixture, "reel.mp4");
          await promisify(execFile)(ffmpeg, [
            "-v",
            "error",
            "-f",
            "lavfi",
            "-i",
            "color=c=orange:s=128x128:d=1",
            "-c:v",
            "libx264",
            "-y",
            file,
          ]);
          const mediaId = await upload(
              alice,
              "reel",
              await fs.readFile(file),
              "video",
            ),
            key = randomUUID();
          await ok(alice, "publishContent", {
            requestId: key,
            kind: "reel",
            caption: "#Müzik güzel bir gün",
            mediaIds: [mediaId],
          });
          const result = await ok(eve, "listContent", {
            kind: "reel",
            search: "müzik",
          });
          assert.ok(result.rows.some((row) => row.id === key));
          assert.equal((await media(eve, mediaId)).status, 200);
        },
      );
      let story, storyMedia;
      await t.test(
        "stories expire on the server; viewers are owner-only and highlights retain explicit access",
        async () => {
          storyMedia = await upload(alice, "story");
          story = randomUUID();
          await ok(alice, "publishContent", {
            requestId: story,
            kind: "story",
            caption: "Bir an",
            mediaIds: [storyMedia],
          });
          await ok(eve, "storyView", { id: story });
          await denied(eve, "storyViewers", { id: story });
          assert.ok(
            (await ok(alice, "storyViewers", { id: story })).rows.some(
              (row) => row.id === eve.uid,
            ),
          );
          await db
            .doc("stories/" + story)
            .update({ expiresAt: Timestamp.fromMillis(Date.now() - 1000) });
          assert.equal((await media(eve, storyMedia)).status, 403);
          await ok(alice, "highlightStory", {
            id: story,
            enabled: true,
            title: "Anılar",
          });
          assert.equal((await media(eve, storyMedia)).status, 200);
          await ok(alice, "highlightStory", {
            id: story,
            enabled: false,
            title: "Anılar",
          });
          assert.equal((await media(eve, storyMedia)).status, 403);
          assert.ok(
            (
              await ok(alice, "listContent", {
                kind: "story",
                uid: alice.uid,
                archived: true,
              })
            ).rows.some((row) => row.id === story),
          );
        },
      );
      let chat, messageMedia, messageId;
      await t.test(
        "recipient permissions, chat membership, replies, reactions and read receipts are enforced",
        async () => {
          await denied(alice, "createChat", { members: [eve.uid] });
          chat = (await ok(alice, "createChat", { members: [bob.uid] })).id;
          messageMedia = await upload(alice, "message");
          messageId = randomUUID();
          await ok(alice, "sendMessage", {
            chatId: chat,
            requestId: messageId,
            text: "Fotoğraf",
            mediaIds: [messageMedia],
          });
          assert.equal((await media(eve, messageMedia)).status, 403);
          assert.equal((await media(bob, messageMedia)).status, 200);
          await denied(eve, "editMessage", {
            chatId: chat,
            id: messageId,
            text: "sahte",
          });
          await denied(bob, "editMessage", {
            chatId: chat,
            id: messageId,
            text: "sahte",
          });
          await ok(bob, "reactMessage", {
            chatId: chat,
            id: messageId,
            reaction: "❤️",
          });
          await ok(bob, "markSeen", { chatId: chat, ids: [messageId] });
          const record = (
            await db.doc(`chats/${chat}/messages/${messageId}`).get()
          ).data();
          assert.equal(record.reactions[bob.uid], "❤️");
          assert.ok(record.seenBy.includes(bob.uid));
          await ok(bob, "sendMessage", {
            chatId: chat,
            requestId: randomUUID(),
            text: "Yanıt",
            replyTo: messageId,
          });
        },
      );
      await t.test(
        "group members cannot bypass blocks and leaving revokes further actions",
        async () => {
          await db
            .doc("users/" + charlie.uid + "/blocks/" + bob.uid)
            .set({ uid: bob.uid });
          await denied(alice, "createChat", {
            requestId: randomUUID(),
            group: true,
            title: "Grup",
            members: [bob.uid, charlie.uid],
          });
          await db.doc("users/" + charlie.uid + "/blocks/" + bob.uid).delete();
          const group = await ok(alice, "createChat", {
            requestId: randomUUID(),
            group: true,
            title: "Arkadaşlar",
            members: [bob.uid, charlie.uid],
          });
          await ok(bob, "leaveGroup", { chatId: group.id });
          await denied(bob, "sendMessage", {
            chatId: group.id,
            requestId: randomUUID(),
            text: "Artık üye değilim",
          });
        },
      );
      await t.test(
        "moderation evidence requires a report, creates an audit and never grants global message access",
        async () => {
          await ok(bob, "reportChat", {
            chatId: chat,
            messageId,
            reason: "Şikâyet kanıtı",
          });
          const reports = await ok(moderator, "adminList", {
              collection: "reports",
            }),
            report = reports.rows.find((row) => row.messageId === messageId);
          assert.ok(report);
          assert.equal((await media(moderator, messageMedia)).status, 403);
          const evidence = await ok(moderator, "reviewReport", {
            id: report.id,
          });
          assert.equal(evidence.mediaItems[0].id, messageMedia);
          assert.equal((await media(moderator, messageMedia)).status, 200);
          await denied(moderator, "setUserStatus", {
            uid: bob.uid,
            suspended: true,
            reason: "Yetkim yok",
          });
          await denied(moderator, "setRole", {
            uid: charlie.uid,
            role: "admin",
          });
          await ok(official, "resolveReport", {
            id: report.id,
            status: "closed",
            reason: "İncelendi",
          });
        },
      );
      await t.test(
        "suspension closes existing tokens and owner accounts cannot be suspended",
        async () => {
          await denied(official, "setUserStatus", {
            uid: official.uid,
            suspended: true,
            reason: "Kendi hesabı",
          });
          await ok(official, "setUserStatus", {
            uid: charlie.uid,
            suspended: true,
            reason: "Test kısıtlaması",
          });
          await denied(charlie, "listContent", { kind: "post" });
          assert.equal(
            (await db.doc("users/" + charlie.uid).get()).get("suspended"),
            true,
          );
          await ok(official, "setUserStatus", {
            uid: charlie.uid,
            suspended: false,
            reason: "Kısıtlama kaldırıldı",
          });
        },
      );
      await t.test(
        "server cleanup removes advanced account data before Authentication can be deleted",
        async () => {
          await denied(alice, "cleanupSocialData");
          await db.doc("users/" + alice.uid).update({ deletionPending: true });
          await ok(alice, "cleanupSocialData");
          assert.equal(
            (await db.collection("media").where("uid", "==", alice.uid).get())
              .size,
            0,
          );
          assert.equal((await media(bob, messageMedia)).status, 403);
        },
      );
    } finally {
      await Promise.all(apps.map(deleteApp));
      await deleteAdmin(admin);
      await fs.rm(fixture, { recursive: true, force: true });
    }
  },
);
