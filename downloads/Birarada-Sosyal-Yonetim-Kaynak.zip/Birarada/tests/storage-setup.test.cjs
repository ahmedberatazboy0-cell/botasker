"use strict";
const {test}=require('node:test'),assert=require('node:assert/strict');
const {setupStorage}=require('../STORAGE_KUR.cjs');
const correct={bucket:{name:'projects/test/buckets/birarada-5650c.firebasestorage.app'}};
function fixture(overrides={}){let reads=0;const calls=[];return {calls,io:{billingEnabled:async()=>true,getDefault:async()=>++reads>1?correct:null,create:async body=>calls.push(['create',body]),wait:async()=>{},deployRules:async()=>calls.push(['rules']),log:()=>{},...overrides}};}
test('disabled billing never creates Storage or deploys rules',async()=>{const f=fixture({billingEnabled:async()=>false});await assert.rejects(setupStorage(f.io),/BLAZE_KAPALI/);assert.deepEqual(f.calls,[]);});
test('creation uses the expected location and waits for authoritative bucket before private rules',async()=>{const f=fixture();await setupStorage(f.io);assert.deepEqual(f.calls,[['create',{location:'europe-west1',storageClass:'STANDARD'}],['rules']]);});
test('an existing expected bucket is preserved and only private rules are deployed',async()=>{const f=fixture({getDefault:async()=>correct});await setupStorage(f.io);assert.deepEqual(f.calls,[['rules']]);});
test('a different default bucket cannot be renamed, replaced or deleted',async()=>{const f=fixture({getDefault:async()=>({bucket:{name:'other.appspot.com'}})});await assert.rejects(setupStorage(f.io),/Baska/);assert.deepEqual(f.calls,[]);});
test('a concurrent successful creation is resolved by re-reading the expected bucket',async()=>{const f=fixture({create:async()=>{throw Object.assign(new Error('conflict'),{status:409})}});await setupStorage(f.io);assert.deepEqual(f.calls,[['rules']]);});
test('read permission failures cannot trigger creation and rules failures cannot claim completion',async()=>{const f=fixture({getDefault:async()=>{throw Object.assign(new Error('denied'),{status:403})}});await assert.rejects(setupStorage(f.io),/denied/);assert.deepEqual(f.calls,[]);const g=fixture({getDefault:async()=>correct,deployRules:async()=>{throw Error('rules failed')}});await assert.rejects(setupStorage(g.io),/rules failed/);});
