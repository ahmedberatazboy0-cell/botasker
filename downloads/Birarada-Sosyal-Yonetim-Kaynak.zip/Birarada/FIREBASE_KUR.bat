@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
node scripts\deploy-backend.cjs
set "BIRARADA_SETUP_EXIT=%errorlevel%"
pause
exit /b %BIRARADA_SETUP_EXIT%
