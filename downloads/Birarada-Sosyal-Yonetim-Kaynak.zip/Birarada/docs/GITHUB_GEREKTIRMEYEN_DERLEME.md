# GitHub gerektirmeyen derleme

Güncel başlangıç: [CANLI_KURULUM.md](CANLI_KURULUM.md). Node22/24, Java21+ ve Chrome/Edge kurulu olmalı. `FIREBASE_KUR.bat` canlı sunucuyu dağıtır; `AAB_OLUSTUR.bat` yerel testleri, canlı sürüm/yasal sayfa kontrolünü ve EAS üretim derlemesini çalıştırır. Başarısız kontroller atlanmaz.

Mevcut gerçek EAS projectId `9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b` ve owner `ahmedberat` sabit kaynakta bulunur. Yardımcı `.birarada-release/` altında yalnız kendi oluşturduğu iş klasörünü kullanır; kaynak app.json dosyasını, `.env.local` veya kullanıcının `.git` dizinini değiştirmez. Üretim kopyası yalnız izin verilen uygulama dosyalarını içerir; server credentials veya özel env dosyaları EAS'e kopyalanmaz.

Expo giriş oturumu yoksa resmî tarayıcı girişi açılır. Tarayıcı oturumu terminale dönmezse terminalde Ctrl+C ile durdur, `npx --yes eas-cli@25.2.0 login --no-browser` komutuyla resmî CLI girişini yapıp tekrar BAT'ı çalıştır. Şifreni sohbetten paylaşma. Mevcut proje erişimi yoksa başka proje/keystore oluşturma; doğru owner hesabıyla giriş yap.

EAS build `--freeze-credentials --non-interactive` kullanır. Eksik imza otomatik üretilmez. Başarıda EAS yeni `.aab` indirme bağlantısı verir; ZIP, HTML veya APK dosyası Play üretim AAB'si yerine geçmez. Canlı doğrulama gerçek cihaz/Cloud Storage/FCM/16 KB testinin yerine geçmez.
