# Canlı kurulum — 21 Ekim 2026

Bu kaynaklar yeni özellikleri içerir; canlı Firebase hesabına dağıtılmadan ve yeni AAB üretilmeden eski AAB'ye eklenmez. Aşağıdaki Google/Expo girişleri sahibinin bilgisayarında resmî sağlayıcı pencerelerinde gerçekleşir. Parola/token/service account sohbetten istenmez veya projeye gömülmez.

## Firebase

`FIREBASE_KUR.bat` Node.js 22/24 ile kök ve `functions/` bağımlılıklarını kurar, gerçek medya işleyiciyi test eder, Google girişini açar, yetkili proje listesinde `birarada-5650c` kontrolünü yapar. Yalnız `functions:social,firestore,storage` dağıtır; mevcut Hosting'i değiştirmez. Başka projeye dağıtım seçeneği yoktur. Sunucu bölgesi `europe-west1`, Node22; yükleme en fazla 3 eşzamanlı sunucu örneğiyle sınırlandırılmıştır. Blaze kullanımı ücret doğurabilir; araç ücretli planı açmaz.

Console'da kontrol edilmesi gerekenler: projenin Blaze planı, Email/Password sağlayıcısı, `(default)` Firestore veritabanı ve `birarada-5650c.firebasestorage.app` Storage bucket. Bu kaynaklar mevcut bölgeyi veya bucket'ı yeniden oluşturmaz. Gerekli Google API/IAM izinleri dağıtım hesabında bulunmalı. İndekslerin hazır duruma gelmesi beklenmeli; emulator indeks gerekliliklerini doğrulamaz.

`functions/.env.birarada-5650c` yalnız açık owner e-postası/bootstrap/bucket ayarlarıyla ilk çalıştırmada oluşturulur. Var olan farklı dosya otomatik ezilmez. Firebase/Expo erişim anahtarları eklenmez. `functions/.env.example` örnektir; örnek dosya dağıtımda kendiliğinden etkinleşmez.

## Resmî hesap

Uygulamada `ahmedberatazboy0@gmail.com` için kendi Auth hesabını oluştur ve e-postayı doğrula. Profil tamamlama veya Ayarlar'da **Resmî hesabı etkinleştir** seç. Sunucu, gerçek doğrulanmış oturumu kontrol eder ve `system/owner` içinde UID'yi bir kez sabitler; `birarada` profilini ve owner custom claim'ini oluşturur. Kaynaklarda bu hesaba ait parola veya otomatik sabit parola yoktur. Canlı hesap/claim bu çalışma ortamında oluşturulmadı.

Yönetim paneli Ayarlar'da yalnız sunucunun verdiği role görünür. Owner, doğrulanmış diğer hesaplara admin/moderator rolü verebilir. Moderatör tüm DM'leri okuyamaz; belirli bir şikâyet için 15 dakikalık medya inceleme izni alır. Kısıtlama/kaldırma gerekçe ve açık onay ister; sunucu denetim kaydı tutar. Duyuru/bakım ayarları sunucudan gelir. Kelime filtresi yeni sunucu paylaşım açıklamalarını kapsar; her eski yorum kanalını otomatik denetlediği iddia edilmez.

## Web ve bildirimler

Dört yasal sayfa `hosting/public/` içinde günceldir. Bunları mevcut sitenin tam çıktısına [HOSTING.md](HOSTING.md) ile birleştir; tek başına bu klasörü dağıtma. Geçerli adresler `/privacy`, `/delete-account`, `/terms`, `/child-safety`.

Gerçek Android push için aynı Firebase projesinde `com.birarada.app` Android uygulaması ve EAS'in güvenli credentials akışında FCM V1 bağlantısı gerekir. Android Firebase istemci yapılandırması mevcut EAS build sürecine güvenle bağlanmalı. Service account/private key ZIP'e konmaz ve sohbetten paylaşılmaz. Sunucu kodu Expo push gönderimini ve geçersiz cihaz temizliğini içerir; gerçek cihaza teslim henüz doğrulanmadı. Push izni isteğe bağlıdır.

## Üretim derlemesi

`AAB_OLUSTUR.bat` önce yerel testleri, ardından canlı sağlık/yasal sayfa sürüm kontrolünü çalıştırır. Başarısız önkoşul atlanmaz. Sonra mevcut EAS projesi `9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b` ile derler. `--freeze-credentials --non-interactive` mevcut imzayı kullanır; eksik credentials durumunda yeni keystore üretmek yerine durur. Önceki AAB henüz Play'e yüklenmediği için versionCode1 korunmuştur; sonradan yüklediysen mevcut en yüksek kodu dikkate alarak bir sonraki sürümü hazırlamalısın.

Canlı sağlık kontrolü sunucu sürümü, çalışabilir FFmpeg ve yasal sayfa içeriğini doğrular. Depolama yetkileri, telefon davranışı, gerçek push teslimi, son AAB native 16 KB uyumluluğu ve Play politika onayı yerine geçmez. Son AAB'yi en az iki gerçek hesapla cihazda test et; Play Console ön kontrolleri ve hesabına özel test koşulları tamamlanmadan üretim yayını garanti edilemez.
