# Güncel devir

21 Ekim 2026 sosyal özellik çalışması için ana belgeler: `README.md`, `TEST_REPORT.md`, `docs/CANLI_KURULUM.md`. Eski onboarding düzeltmesi ve eski metin-only AAB geçmişi yeni özelliklerin canlı olduğu anlamına gelmez.

Yeni kaynakta Firebase Functions özel medya/sosyal API/yönetim altyapısı ve gerçek ekranlar var. Uygulama kimliği `com.birarada.app`, ilk versionCode1; gerçek EAS UUID `9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b`, owner `ahmedberat`. Yeni EAS projesi/keystore oluşturma. Kullanıcının parolasını kaynaklara yazma veya isteme. Owner yetkisi yalnız doğrulanmış Firebase oturumu ve sunucu bootstrap işlemiyle verilir; canlı hesap henüz etkinleştirilmedi.

Canlı dağıtım ve yeni imzalı AAB eksik. Testleri atlayarak veya eski AAB'yi yeniden adlandırarak tamamlandı deme. Yerel API testleri gerçek Auth/Firestore/Functions emulatörleriyle çalışır; Cloud Storage yerine açıkça sınırlandırılmış geçici dosya fixture'ı kullanılır. Push haricî taşıma testi sahte sağlayıcı yanıtıyla yapılır; gerçek cihaz teslimi değildir. Otomatik bulut tetikleyici/FCM/Storage/IAM/16 KB binary kontrolleri ayrıca gerekir.
