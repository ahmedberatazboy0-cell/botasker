import { test, expect, type Page } from "@playwright/test";
import { createRequire } from "node:module";
import path from "node:path";
const backendRequire = createRequire(
  path.resolve(__dirname, "../functions/package.json"),
);
const { initializeApp } = backendRequire("firebase-admin/app"),
  { getAuth } = backendRequire("firebase-admin/auth"),
  { getFirestore, Timestamp } = backendRequire("firebase-admin/firestore"),
  sharp = backendRequire("sharp");
let database: any, accounts: any, image: Buffer;
const PASSWORD = "Local-UI-emulator-only-942!";
test.beforeAll(async () => {
  if (
    process.env.FIRESTORE_EMULATOR_HOST !== "127.0.0.1:8080" ||
    process.env.FIREBASE_AUTH_EMULATOR_HOST !== "127.0.0.1:9099"
  )
    throw Error("Only local demo emulators may run these checks.");
  const app = initializeApp({ projectId: "demo-birarada" }, "ui-integration");
  database = getFirestore(app);
  accounts = getAuth(app);
  image = await sharp({
    create: { width: 200, height: 180, channels: 3, background: "#ff925c" },
  })
    .png()
    .toBuffer();
  for (const name of ["ui", "ui-admin", "ui-victim"]) {
    const uid = "qa-" + name;
    try {
      await accounts.deleteUser(uid);
    } catch {}
    await accounts.createUser({
      uid,
      email: name + "@example.test",
      password: PASSWORD,
      emailVerified: true,
    });
    if (name === "ui-admin")
      await accounts.setCustomUserClaims(uid, { biraradaRole: "admin" });
    await database.doc("accountStatus/" + uid).delete();
    for (const collection of ["posts", "stories", "media"]) {
      const rows = await database
        .collection(collection)
        .where("uid", "==", uid)
        .get();
      for (const row of rows.docs) await database.recursiveDelete(row.ref);
    }
    await database
      .doc("users/" + uid)
      .set({
        uid,
        username: name.replaceAll("-", "_"),
        displayName: name,
        bio: "",
        website: "",
        avatarUrl: "",
        isPrivate: false,
        allowStrangerDM: true,
        createdAt: Timestamp.now(),
        deletionPending: false,
        termsAcceptedAt: Timestamp.now(),
        termsVersion: "2026-10-21",
      });
  }
});
async function login(page: Page, name = "ui") {
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await expect(
    page.getByText("Arkadaşlarını bul", { exact: true }),
  ).toBeVisible({ timeout: 90000 });
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await page.getByRole("button", { name: "Devam et", exact: true }).click();
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await page
    .getByLabel("E-posta", { exact: true })
    .fill(name + "@example.test");
  await page.getByLabel("Şifre", { exact: true }).fill(PASSWORD);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function attachImage(page: Page) {
  const chooser = page.waitForEvent("filechooser");
  await page
    .getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  await (
    await chooser
  ).setFiles({ name: "moment.png", mimeType: "image/png", buffer: image });
  await expect(page.getByText("1. Fotoğraf", { exact: true })).toBeVisible();
}
test("real signed-in app uploads an image, preserves a failed draft and publishes once after retry", async ({
  page,
}) => {
  await login(page);
  await page.getByText("Oluştur", { exact: true }).click();
  const caption = "#gece Birarada gerçek fotoğraf";
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  await attachImage(page);
  let fail = true;
  await page.route("**/socialApi", async (route) => {
    const input = route.request().postDataJSON();
    if (fail && input?.data?.action === "publishContent") {
      fail = false;
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          error: { status: "UNAVAILABLE", message: "Temporary test failure" },
        }),
      });
    } else await route.continue();
  });
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect(
    page.getByText(
      "Sunucuya bağlanılamadı. İnternetini kontrol edip yeniden dene.",
      { exact: true },
    ),
  ).toBeVisible();
  await expect(
    page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…"),
  ).toHaveValue(caption);
  await expect(page.getByText("1. Fotoğraf", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await expect
    .poll(
      async () =>
        (
          await database
            .collection("posts")
            .where("uid", "==", "qa-ui")
            .where("caption", "==", caption)
            .get()
        ).size,
    )
    .toBe(1);
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  await expect(page.getByText(caption, { exact: true })).toBeVisible();
  await page.screenshot({
    path: "artifacts/social-feed-mobile.png",
    fullPage: true,
  });
});
test("real story photo appears in the rail and can become a highlight", async ({
  page,
}) => {
  await login(page);
  await page.getByRole("button", { name: "Hikâye ekle", exact: true }).click();
  await attachImage(page);
  await page
    .getByPlaceholder("Açıklama, #etiket, @kullanıcı…")
    .fill("Bugünden bir an");
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  await page.getByRole("button", { name: "@ui hikâyesi", exact: true }).click();
  await expect(
    page.getByText("Bugünden bir an", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Öne çıkanlara ekle", exact: true })
    .click();
  await expect
    .poll(
      async () =>
        (
          await database
            .collection("stories")
            .where("uid", "==", "qa-ui")
            .where("highlighted", "==", true)
            .get()
        ).size,
    )
    .toBeGreaterThan(0);
});
test("real admin panel requires an explicit confirmation before restricting an account", async ({
  page,
}) => {
  await login(page, "ui-admin");
  await page.getByText("Profil", { exact: true }).click();
  await page.getByRole("button", { name: "Ayarlar", exact: true }).click();
  await page
    .getByRole("button", { name: "Yönetim paneli", exact: true })
    .click();
  await expect(
    page.getByText("Yetkin: Yönetici", { exact: true }),
  ).toBeVisible();
  await page
    .getByPlaceholder("İşlem gerekçesi / inceleme notu")
    .fill("UI security check");
  await page.getByPlaceholder("Firebase kullanıcı UID").fill("qa-ui-victim");
  await page
    .getByRole("button", { name: "Hesabı kısıtla", exact: true })
    .click();
  expect((await database.doc("accountStatus/qa-ui-victim").get()).exists).toBe(
    false,
  );
  await page
    .getByRole("button", { name: "Onayla ve uygula", exact: true })
    .click();
  await expect
    .poll(async () =>
      (await database.doc("accountStatus/qa-ui-victim").get()).get("suspended"),
    )
    .toBe(true);
  await page.screenshot({ path: "artifacts/admin-mobile.png", fullPage: true });
});
