import { defineConfig } from "@playwright/test";
import base from "./playwright.config";
export default defineConfig({
  ...base,
  testDir: "./integration-ui",
  workers: 1,
  timeout: 120000,
  expect: { timeout: 15000 },
});
