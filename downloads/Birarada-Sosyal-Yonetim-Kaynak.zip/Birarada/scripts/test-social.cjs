"use strict";
const fs = require("node:fs"),
  os = require("node:os"),
  path = require("node:path"),
  { spawnSync } = require("node:child_process");
const fixture = fs.mkdtempSync(
  path.join(os.tmpdir(), "birarada-social-fixture-"),
);
try {
  const cli = path.join(
    path.dirname(require.resolve("firebase-tools/package.json")),
    "lib/bin/firebase.js",
  );
  const result = spawnSync(
    process.execPath,
    [
      cli,
      "emulators:exec",
      "--project",
      "demo-birarada",
      "--only",
      "auth,firestore,functions",
      "node scripts/check-social-suite.cjs",
    ],
    {
      cwd: path.resolve(__dirname, ".."),
      stdio: "inherit",
      env: {
        ...process.env,
        MEDIA_TEST_STORAGE_DIR: fixture,
        OWNER_EMAIL: "official@example.test",
        ENABLE_OWNER_BOOTSTRAP: "true",
      },
    },
  );
  if (result.error) throw result.error;
  process.exitCode = result.status ?? 1;
} finally {
  fs.rmSync(fixture, { recursive: true, force: true });
}
