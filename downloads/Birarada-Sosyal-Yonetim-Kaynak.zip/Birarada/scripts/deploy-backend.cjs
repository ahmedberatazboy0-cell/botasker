"use strict";
const fs = require("node:fs"),
  path = require("node:path"),
  { spawnSync } = require("node:child_process");
const { commandSpec } = require("./build-no-github.cjs");
const root = path.resolve(__dirname, ".."),
  project = "birarada-5650c";
function run(command, args, capture = false) {
  const [binary, argv] = commandSpec(command, args);
  const result = spawnSync(binary, argv, {
    cwd: root,
    env: process.env,
    stdio: capture ? "pipe" : "inherit",
    encoding: "utf8",
  });
  if (result.error || result.status !== 0)
    throw Error(
      "Kurulum durdu. Yukarıdaki Google/Firebase hatasını kontrol et; Blaze planı ve proje erişimi gerekiyor.",
    );
  return result.stdout || "";
}
try {
  console.log(
    "Birarada canlı sunucu kurulumu. Mevcut Hosting sitesi ve Android imzası değiştirilmez. Blaze planı gereklidir; araç ücretli planı etkinleştirmez.",
  );
  run("npm", ["ci", "--include=dev", "--no-audit", "--no-fund"]);
  run("npm", ["run", "backend:install"]);
  run("npm", ["run", "test:backend"]);
  const cli = path.join(
    path.dirname(require.resolve("firebase-tools/package.json")),
    "lib/bin/firebase.js",
  );
  run(process.execPath, [cli, "login", "--no-localhost"]);
  const list = JSON.parse(
    run(process.execPath, [cli, "projects:list", "--json"], true),
  );
  if (
    list.status !== "success" ||
    !list.result?.some((p) => p.projectId === project)
  )
    throw Error(
      "Giriş yapılan Google hesabının birarada-5650c projesine erişimi yok.",
    );
  const env = path.join(root, "functions", ".env." + project),
    expected =
      "OWNER_EMAIL=ahmedberatazboy0@gmail.com\nENABLE_OWNER_BOOTSTRAP=true\nMEDIA_BUCKET=birarada-5650c.firebasestorage.app\n";
  if (!fs.existsSync(env)) fs.writeFileSync(env, expected, { flag: "wx" });
  else if (fs.readFileSync(env, "utf8") !== expected)
    throw Error(
      "Mevcut sunucu ortam dosyan farklı; özel ayarların korunarak duruldu. docs/CANLI_KURULUM.md dosyasını kontrol et.",
    );
  run(process.execPath, [
    cli,
    "deploy",
    "--project",
    project,
    "--only",
    "functions:social,firestore,storage",
  ]);
  console.log(
    "Firebase dağıtımı tamamlandı. Resmî hesabı uygulamada kendi e-postanla oluşturup e-posta doğrulamasını tamamla; Ayarlar > Resmî hesabı etkinleştir. Parola veya yönetici anahtarı kaynaklara yazılmaz.",
  );
  console.log(
    "Yasal sayfaları mevcut siteye docs/HOSTING.md ile birleştir. Sonra AAB_OLUSTUR.bat çalıştır.",
  );
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
