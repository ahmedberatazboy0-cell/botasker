"use strict";
const https = require("node:https");
const PROJECT = "birarada-5650c",
  DATE = "2026-10-21";
function get(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      {
        timeout: 20000,
        headers: { "User-Agent": "Birarada-Release-Check/1.0" },
      },
      (res) => {
        let body = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => {
          body += chunk;
          if (body.length > 1000000) res.destroy(Error("Response too large"));
        });
        res.on("error", reject);
        res.on("end", () => resolve({ status: res.statusCode, body }));
      },
    );
    req.on("timeout", () => req.destroy(Error("Connection timed out")));
    req.on("error", reject);
  });
}
async function checkLive() {
  const health = await get(
    `https://europe-west1-${PROJECT}.cloudfunctions.net/health`,
  );
  if (health.status !== 200)
    throw Error(
      "Canlı Birarada sunucusu hazır değil. Önce FIREBASE_KUR.bat ile kurulumu tamamla.",
    );
  let value;
  try {
    value = JSON.parse(health.body);
  } catch {
    throw Error("Sunucu sağlık yanıtı geçersiz.");
  }
  if (
    value.service !== "birarada-social" ||
    value.protocol !== 2 ||
    value.projectId !== PROJECT ||
    value.termsVersion !== DATE ||
    value.mediaProcessorReady !== true
  )
    throw Error(
      "Canlı sunucu bu kaynak sürümüyle eşleşmiyor veya medya işleyici eksik.",
    );
  for (const route of ["privacy", "delete-account", "terms", "child-safety"]) {
    const page = await get(`https://${PROJECT}.web.app/${route}`);
    if (
      page.status !== 200 ||
      !page.body.includes("<html") ||
      !page.body.includes("com.birarada.app") ||
      !page.body.includes("ahmedberatazboy0@gmail.com") ||
      !page.body.includes(DATE)
    )
      throw Error(
        `Güncel yasal sayfa yayımlanmamış: /${route}. docs/HOSTING.md adımlarını uygula.`,
      );
  }
  console.log(
    "Canlı sunucu sürümü/medya işleyici ve dört yasal sayfa doğrulandı. Bu kontrol cihaz, gerçek depolama, push, imza veya Play onayı yerine geçmez.",
  );
}
module.exports = { checkLive };
if (require.main === module)
  checkLive().catch(() => {
    console.error(
      "Canlı yayın doğrulaması tamamlanamadı. Firebase sunucusu ve güncel yasal sayfalar yayımlanmadan üretim derlemesi durduruldu. docs/CANLI_KURULUM.md dosyasına bak.",
    );
    process.exitCode = 1;
  });
