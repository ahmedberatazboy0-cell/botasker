"use strict";
const { spawnSync } = require("node:child_process");
if (
  process.env.FIRESTORE_EMULATOR_HOST !== "127.0.0.1:8080" ||
  process.env.FIREBASE_AUTH_EMULATOR_HOST !== "127.0.0.1:9099"
)
  throw Error("Only local demo emulators may run this suite.");
for (const args of [
  ["--test", "tests/backend.test.cjs", "tests/triggers.test.cjs"],
  [
    require.resolve("@playwright/test/cli"),
    "test",
    "--config",
    "playwright.social.config.ts",
  ],
]) {
  const r = spawnSync(process.execPath, args, {
    stdio: "inherit",
    env: { ...process.env, GCLOUD_PROJECT: "demo-birarada" },
  });
  if (r.error) throw r.error;
  if (r.status !== 0) {
    process.exitCode = r.status ?? 1;
    break;
  }
}
