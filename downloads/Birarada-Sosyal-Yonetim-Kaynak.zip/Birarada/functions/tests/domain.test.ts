import { test } from "node:test";
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import {
  canView,
  canMessage,
  roleFromToken,
  requireRole,
  parseUpload,
  id,
  uuid,
  rangeHeader,
  safeMembers,
  searchTokens,
} from "../src/domain";
test("a matching owner email, profile badge or unverified admin claim cannot grant administration", () => {
  assert.equal(
    roleFromToken({
      email: "owner@example.test",
      email_verified: true,
      official: true,
    }),
    "member",
  );
  assert.equal(
    roleFromToken({ biraradaRole: "owner", email_verified: false }),
    "member",
  );
  assert.equal(
    roleFromToken({ biraradaRole: "root", email_verified: true }),
    "member",
  );
  for (const role of ["member", "moderator"] as const)
    assert.throws(() =>
      requireRole({ uid: "alice", role, emailVerified: true }, "admin"),
    );
  assert.throws(() =>
    requireRole(
      { uid: "alice", role: "owner", emailVerified: false },
      "moderator",
    ),
  );
  assert.doesNotThrow(() =>
    requireRole({ uid: "alice", role: "owner", emailVerified: true }, "owner"),
  );
});
const facts = {
  self: false,
  blocked: false,
  ownerActive: true,
  viewerActive: true,
  isPrivate: true,
  follows: true,
};
test("private media access is revoked immediately by either a block, lost follow, deletion, suspension or expiry", () => {
  assert.equal(canView(facts), true);
  for (const patch of [
    { blocked: true },
    { follows: false },
    { ownerActive: false },
    { viewerActive: false },
    { expired: true },
  ])
    assert.equal(canView({ ...facts, ...patch }), false);
  assert.equal(canView({ ...facts, self: true, follows: false }), true);
  assert.equal(canView({ ...facts, self: true, ownerActive: false }), false);
  assert.equal(canView({ ...facts, isPrivate: false, blocked: true }), false);
});
test("direct/group invitations require recipient consent even for a public account", () => {
  const state = {
    ...facts,
    isPrivate: false,
    strangerAllowed: false,
    followsViewer: false,
  };
  assert.equal(canMessage(state), false);
  assert.equal(canMessage({ ...state, strangerAllowed: true }), true);
  assert.equal(canMessage({ ...state, followsViewer: true }), true);
  assert.equal(
    canMessage({ ...state, strangerAllowed: true, blocked: true }),
    false,
  );
});
test("uploads reject forged kinds, incompatible purposes, zero/fractional and excessive sizes", () => {
  const base = {
    requestId: randomUUID(),
    kind: "image",
    purpose: "post",
    bytes: 100,
  };
  for (const patch of [
    { kind: "toString" },
    { kind: "__proto__" },
    { kind: "executable" },
    { purpose: "admin" },
    { bytes: 0 },
    { bytes: 1.5 },
    { bytes: 10 * 1024 ** 2 + 1 },
    { kind: "audio" },
    { kind: "video", purpose: "avatar" },
    { purpose: "reel" },
  ])
    assert.throws(() => parseUpload({ ...base, ...patch }));
  assert.equal(
    parseUpload({ ...base, bytes: 10 * 1024 ** 2 }).bytes,
    10 * 1024 ** 2,
  );
});
test("object paths and operation IDs cannot select another path or an arbitrary deterministic key", () => {
  for (const value of ["../owner", "a/b", "a?b", "a#b", "", {}, null])
    assert.throws(() => id(value));
  for (const value of [
    "chosen-key",
    "00000000-0000-0000-0000-000000000000",
    "../x",
  ])
    assert.throws(() => uuid(value));
  assert.equal(uuid(randomUUID()).length, 36);
});
test("video byte ranges are bounded and reject multipart or unsatisfiable ranges", () => {
  assert.deepEqual(rangeHeader("bytes=0-9", 100), { start: 0, end: 9 });
  assert.deepEqual(rangeHeader("bytes=-10", 100), { start: 90, end: 99 });
  assert.deepEqual(rangeHeader("bytes=40-", 100), { start: 40, end: 99 });
  for (const range of [
    "bytes=0-1,4-5",
    "bytes=100-",
    "bytes=5-1",
    "bytes=-",
    "bytes=NaN-2",
    "bytes=-0",
  ])
    assert.throws(() => rangeHeader(range, 100));
});
test("group membership removes duplicates, retains its creator and enforces the twenty-person limit", () => {
  assert.deepEqual(safeMembers(["bob", "alice", "bob"], "alice"), [
    "alice",
    "bob",
  ]);
  assert.throws(() => safeMembers(["alice"], "alice"));
  assert.throws(() =>
    safeMembers(
      Array.from({ length: 20 }, (_, i) => "user" + i),
      "alice",
    ),
  );
});
test("search indexes actual normalized Turkish words, mentions and hashtags without evaluating markup", () => {
  const result = searchTokens("İSTANBUL #Müzik @birarada");
  assert.ok(result.includes("istanbul"));
  assert.ok(result.includes("müzik"));
  assert.ok(result.includes("@birarada"));
});
