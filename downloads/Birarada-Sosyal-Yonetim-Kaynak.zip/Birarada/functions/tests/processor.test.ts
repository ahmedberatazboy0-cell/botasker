import { test } from "node:test";
import assert from "node:assert/strict";
import sharp from "sharp";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { processMedia } from "../src/processor";
const run = promisify(execFile),
  ffmpeg = require("ffmpeg-for-homebridge");
test("image processing rotates orientation, bounds dimensions and strips EXIF instead of trusting the extension", async () => {
  const original = await sharp({
    create: { width: 2000, height: 1000, channels: 3, background: "#ff925c" },
  })
    .jpeg()
    .withMetadata({ orientation: 6 })
    .toBuffer();
  const result = await processMedia(original, "image", "avatar"),
    metadata = await sharp(result.bytes).metadata();
  assert.equal(metadata.format, "jpeg");
  assert.ok(metadata.width! <= 512);
  assert.ok(metadata.height! <= 512);
  assert.equal(metadata.exif, undefined);
  assert.ok(metadata.height! > metadata.width!);
});
test("HTML, SVG and malformed files cannot be published as image media", async () => {
  for (const input of [
    "<html>not a photo</html>",
    '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"><rect width="1" height="1"/></svg>',
    "garbage",
  ])
    await assert.rejects(processMedia(Buffer.from(input), "image", "post"));
});
test(
  "real video and voice data are normalized to playable MP4/AAC, without accepting remote playlists",
  { timeout: 30000 },
  async () => {
    const directory = await mkdtemp(path.join(tmpdir(), "birarada-processor-"));
    try {
      const video = path.join(directory, "video.mp4"),
        audio = path.join(directory, "audio.wav");
      await run(
        ffmpeg,
        [
          "-v",
          "error",
          "-f",
          "lavfi",
          "-i",
          "color=c=orange:s=128x128:d=1",
          "-c:v",
          "libx264",
          "-pix_fmt",
          "yuv420p",
          "-y",
          video,
        ],
        { timeout: 10000 },
      );
      await run(
        ffmpeg,
        [
          "-v",
          "error",
          "-f",
          "lavfi",
          "-i",
          "sine=frequency=440:duration=1",
          "-y",
          audio,
        ],
        { timeout: 10000 },
      );
      const v = await processMedia(await readFile(video), "video", "reel"),
        a = await processMedia(await readFile(audio), "audio", "message");
      assert.equal(v.contentType, "video/mp4");
      assert.equal(a.contentType, "audio/mp4");
      assert.ok(v.bytes.length > 100);
      assert.ok(a.bytes.length > 100);
      await assert.rejects(
        processMedia(
          Buffer.from(
            "#EXTM3U\n#EXTINF:1,\nhttps://example.invalid/private.mp4",
          ),
          "video",
          "reel",
        ),
      );
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
  },
);
