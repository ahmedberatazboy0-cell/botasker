import { getStorage } from "firebase-admin/storage";
import { mkdir, writeFile, rm } from "node:fs/promises";
import { createReadStream } from "node:fs";
import path from "node:path";
import { tmpdir } from "node:os";
// Only the demo-project Functions Emulator may substitute fixture file storage.
// Authentication, ownership, audience checks and transcoding remain the real code.
const fixtureRoot = () =>
  process.env.FUNCTIONS_EMULATOR === "true" &&
  process.env.GCLOUD_PROJECT === "demo-birarada"
    ? process.env.MEDIA_TEST_STORAGE_DIR
    : undefined;
function fixtureFile(key: string) {
  const root = path.resolve(fixtureRoot()!);
  if (!root.startsWith(path.resolve(tmpdir()) + path.sep))
    throw Error("Fixture directory must be inside the OS temp directory");
  const file = path.resolve(root, key);
  if (!file.startsWith(root + path.sep))
    throw Error("Invalid fixture object path");
  return file;
}
const bucket = () =>
  getStorage().bucket(
    process.env.MEDIA_BUCKET || "birarada-5650c.firebasestorage.app",
  );
export async function saveBlob(
  key: string,
  bytes: Buffer,
  contentType: string,
) {
  if (fixtureRoot()) {
    const file = fixtureFile(key);
    await mkdir(path.dirname(file), { recursive: true });
    await writeFile(file, bytes);
    return;
  }
  // No Firebase download token; clients use the authenticated media gateway.
  await bucket()
    .file(key)
    .save(bytes, {
      resumable: false,
      metadata: {
        contentType,
        cacheControl: "private, no-store",
        metadata: {},
      },
    });
}
export async function deleteBlob(key: string) {
  if (fixtureRoot()) {
    await rm(fixtureFile(key), { force: true });
    return;
  }
  await bucket().file(key).delete({ ignoreNotFound: true });
}
export function readBlob(key: string, start: number, end: number) {
  return fixtureRoot()
    ? createReadStream(fixtureFile(key), { start, end })
    : bucket().file(key).createReadStream({ start, end });
}
