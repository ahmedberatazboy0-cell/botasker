import sharp from "sharp";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdtemp, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { InputError, LIMITS, type MediaKind, type Purpose } from "./domain.js";
const execute = promisify(execFile);
const ffmpeg: string | undefined = require("ffmpeg-for-homebridge");
export async function mediaProcessorReady() {
  if (!ffmpeg) return false;
  try {
    const result = await execute(ffmpeg, ["-version"], {
      timeout: 5000,
      maxBuffer: 16384,
    });
    return /ffmpeg version (?:[8-9]|[1-9][0-9])\./.test(result.stdout);
  } catch {
    return false;
  }
}
const FORMATS = "mov,matroska,webm,mpegts,ogg,wav,mp3,flac,aac";
async function inspect(file: string) {
  let diagnostic = "";
  try {
    const result = await execute(
      ffmpeg!,
      [
        "-nostdin",
        "-hide_banner",
        "-max_alloc",
        "268435456",
        "-protocol_whitelist",
        "file,pipe",
        "-format_whitelist",
        FORMATS,
        "-i",
        file,
      ],
      { timeout: 15000, maxBuffer: 1024 * 1024 },
    );
    diagnostic = result.stderr;
  } catch (error) {
    diagnostic = String((error as { stderr?: string }).stderr || "");
  }
  const duration = /^  Duration: (\d+):(\d+):(\d+(?:\.\d+)?)/m.exec(diagnostic);
  const video = /^\s*Stream #.*Video:.*$/m.exec(diagnostic)?.[0] || "";
  const dimensions = /\b(\d{1,5})x(\d{1,5})\b/.exec(video);
  return {
    duration: duration
      ? Number(duration[1]) * 3600 +
        Number(duration[2]) * 60 +
        Number(duration[3])
      : null,
    video: !!video,
    audio: /^\s*Stream #.*Audio:/m.test(diagnostic),
    width: Number(dimensions?.[1] || 0),
    height: Number(dimensions?.[2] || 0),
  };
}
export async function processMedia(
  bytes: Buffer,
  kind: MediaKind,
  purpose: Purpose,
) {
  if (kind === "image") {
    try {
      const metadata = await sharp(bytes, {
        limitInputPixels: 40_000_000,
        animated: false,
      }).metadata();
      if (!["jpeg", "png", "webp"].includes(metadata.format || ""))
        throw new InputError("Unsupported image format");
      const result = await sharp(bytes, {
        limitInputPixels: 40_000_000,
        animated: false,
        failOn: "error",
      })
        .rotate()
        .resize({
          width: purpose === "avatar" ? 512 : 1440,
          height: purpose === "avatar" ? 512 : 1920,
          fit: "inside",
          withoutEnlargement: true,
        })
        .jpeg({ quality: 85, mozjpeg: true })
        .toBuffer({ resolveWithObject: true });
      return {
        bytes: result.data,
        contentType: "image/jpeg",
        width: result.info.width,
        height: result.info.height,
        duration: 0,
      };
    } catch {
      throw new InputError("Fotoğraf okunamadı. JPEG, PNG veya WebP kullan.");
    }
  }
  const directory = await mkdtemp(path.join(tmpdir(), "birarada-media-"));
  try {
    const input = path.join(directory, "input"),
      output = path.join(
        directory,
        kind === "audio" ? "output.m4a" : "output.mp4",
      );
    await writeFile(input, bytes);
    if (!ffmpeg)
      throw new InputError(
        "Medya işleyici sunucuda kurulamadı. Yöneticiyle iletişime geç.",
      );
    const probe = await inspect(input),
      max = purpose === "story" ? 60 : purpose === "reel" ? 90 : 180;
    if (
      !(kind === "audio" ? probe.audio : probe.video) ||
      (probe.duration !== null &&
        (probe.duration <= 0 || probe.duration > max)) ||
      probe.width * probe.height > 40_000_000
    )
      throw new InputError(
        `Geçerli bir ses/video seç. Bu alanda en fazla ${max} saniye kullanılabilir.`,
      );
    const common = [
      "-nostdin",
      "-v",
      "error",
      "-max_alloc",
      "268435456",
      "-protocol_whitelist",
      "file,pipe",
      "-format_whitelist",
      "mov,matroska,webm,mpegts,ogg,wav,mp3,flac,aac",
      "-i",
      input,
      "-map_metadata",
      "-1",
      "-t",
      String(max),
      "-threads",
      "2",
    ];
    const options =
      kind === "audio"
        ? ["-vn", "-c:a", "aac", "-b:a", "96k"]
        : [
            "-map",
            "0:v:0",
            "-map",
            "0:a:0?",
            "-vf",
            "scale=w='min(1080,iw)':h='min(1920,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "26",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-b:a",
            "128k",
          ];
    await execute(
      ffmpeg,
      [...common, ...options, "-movflags", "+faststart", "-y", output],
      { timeout: 100000, maxBuffer: 1024 * 1024 },
    );
    const normalized = await inspect(output),
      result = await readFile(output);
    if (
      !normalized.duration ||
      normalized.duration > max + 0.2 ||
      result.length > LIMITS[kind]
    )
      throw new InputError("Medya işlenemedi veya boyut sınırını aşıyor.");
    return {
      bytes: result,
      contentType: kind === "audio" ? "audio/mp4" : "video/mp4",
      width: normalized.width,
      height: normalized.height,
      duration: normalized.duration,
    };
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
}
