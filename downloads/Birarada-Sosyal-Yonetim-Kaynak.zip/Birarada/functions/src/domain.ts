export type Role = "owner" | "admin" | "moderator" | "member";
export type Actor = { uid: string; role: Role; emailVerified: boolean };
export type MediaKind = "image" | "video" | "audio";
export type Purpose = "post" | "story" | "reel" | "message" | "avatar";
export const LIMITS = Object.freeze({
  image: 10 * 1024 ** 2,
  video: 20 * 1024 ** 2,
  audio: 8 * 1024 ** 2,
});
export class InputError extends Error {}
export function text(value: unknown, max: number, required = false): string {
  if (typeof value !== "string") throw new InputError("Geçerli bir metin yaz.");
  const result = value.normalize("NFC").trim();
  if (result.length > max || (required && !result))
    throw new InputError(
      `Metin ${required ? "1–" : "0–"}${max} karakter olmalı.`,
    );
  return result;
}
export function id(value: unknown): string {
  if (typeof value !== "string" || !/^[a-zA-Z0-9_:\-]{1,160}$/.test(value))
    throw new InputError("Geçersiz kayıt kimliği.");
  return value;
}
export function uuid(value: unknown): string {
  if (
    typeof value !== "string" ||
    !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(
      value,
    )
  )
    throw new InputError("Geçersiz işlem kimliği.");
  return value;
}
export function roleFromToken(token: Record<string, unknown>): Role {
  // An email address, a profile flag or a request-body role NEVER grants access.
  if (token.email_verified !== true) return "member";
  return ["owner", "admin", "moderator"].includes(String(token.biraradaRole))
    ? (token.biraradaRole as Role)
    : "member";
}
export function requireRole(
  actor: Actor,
  minimum: "moderator" | "admin" | "owner",
): void {
  const ranks: Record<Role, number> = {
    member: 0,
    moderator: 1,
    admin: 2,
    owner: 3,
  };
  if (!actor.emailVerified || ranks[actor.role] < ranks[minimum])
    throw new InputError("Bu işlem için yönetici yetkin yok.");
}
export function parseUpload(data: Record<string, unknown>) {
  const mediaId = uuid(data.requestId);
  const kind = data.kind as MediaKind,
    purpose = data.purpose as Purpose;
  if (
    !Object.hasOwn(LIMITS, kind) ||
    !["post", "story", "reel", "message", "avatar"].includes(purpose)
  )
    throw new InputError("Geçersiz medya türü.");
  if (
    (purpose === "avatar" && kind !== "image") ||
    (purpose === "reel" && kind !== "video") ||
    (purpose !== "message" && kind === "audio")
  )
    throw new InputError("Bu alanda bu medya türü kullanılamaz.");
  const bytes = Number(data.bytes);
  if (!Number.isSafeInteger(bytes) || bytes < 1 || bytes > LIMITS[kind])
    throw new InputError(
      `Dosya en fazla ${LIMITS[kind] / 1024 ** 2} MB olabilir.`,
    );
  return { mediaId, kind, purpose, bytes };
}
export function searchTokens(caption: string): string[] {
  const words =
    caption.toLocaleLowerCase("tr-TR").match(/[\p{L}\p{N}_#@]{2,40}/gu) || [];
  return [
    ...new Set(words.flatMap((word) => [word, word.replace(/^[#@]/, "")])),
  ].slice(0, 50);
}
export function safeMembers(value: unknown, self: string): string[] {
  if (!Array.isArray(value) || value.length > 19)
    throw new InputError("Grupta en fazla 20 kişi olabilir.");
  const members = [...new Set([self, ...value.map(id)])].sort();
  if (members.length < 2) throw new InputError("En az bir kişi seç.");
  return members;
}
export function rangeHeader(
  value: unknown,
  size: number,
): { start: number; end: number } | null {
  if (!value) return null;
  if (typeof value !== "string")
    throw new InputError("Geçersiz medya aralığı.");
  const match = /^bytes=(\d*)-(\d*)$/.exec(value);
  if (!match || (!match[1] && !match[2]))
    throw new InputError("Geçersiz medya aralığı.");
  const start = match[1]
    ? Number(match[1])
    : Math.max(0, size - Number(match[2]));
  const end =
    match[1] && match[2] ? Math.min(size - 1, Number(match[2])) : size - 1;
  if (
    !Number.isSafeInteger(start) ||
    !Number.isSafeInteger(end) ||
    start < 0 ||
    start >= size ||
    end < start
  )
    throw new InputError("Geçersiz medya aralığı.");
  return { start, end };
}
export type AccessFacts = {
  self: boolean;
  blocked: boolean;
  ownerActive: boolean;
  viewerActive: boolean;
  isPrivate: boolean;
  follows: boolean;
  expired?: boolean;
  member?: boolean;
};
export function canView(facts: AccessFacts): boolean {
  return (
    facts.viewerActive &&
    facts.ownerActive &&
    !facts.expired &&
    (facts.self || (!facts.blocked && (!facts.isPrivate || facts.follows)))
  );
}
export function canMessage(
  facts: AccessFacts & { strangerAllowed: boolean; followsViewer: boolean },
): boolean {
  return (
    !facts.self &&
    facts.viewerActive &&
    facts.ownerActive &&
    !facts.blocked &&
    (facts.strangerAllowed || facts.followsViewer)
  );
}
export const REACTIONS = ["❤️", "😂", "😮", "😢", "👍", "🔥"] as const;
