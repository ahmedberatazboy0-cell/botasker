'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const zlib=require('node:zlib');
const {prepareLegal,publishLegal,installLiveChecker,versionName,readPublic,PREFIX,ROUTES,LIVE_URL}=require('../YASAL_YAYINLA.cjs');
const root=path.resolve(__dirname,'..');
const sources=Object.fromEntries([...ROUTES.map(r=>r+'.html'),'birarada-legal.css'].map(n=>[n,fs.readFileSync(path.join(root,'hosting/public',n))]));
const digest=b=>crypto.createHash('sha256').update(zlib.gzipSync(b,{level:9})).digest('hex');
const old='projects/birarada-5650c/sites/birarada-5650c/versions/old';
const next=old.replace(/old$/,'new');
const config={cleanUrls:true,trailingSlashBehavior:'REMOVE',rewrites:[{glob:'/api/**',function:'backend'},{glob:'**',path:'/index.html'}],redirects:[{glob:'/legacy',location:'/home',statusCode:301},{glob:'/privacy',location:'/outdated',statusCode:302}],headers:[{glob:'**',headers:{'X-Content-Type-Options':'nosniff'}},{glob:'/privacy',headers:{'X-Frame-Options':'DENY','Content-Type':'wrong'}}]};
const original=new Map([['/index.html',Buffer.from('original home')],['/app.js',Buffer.from('original app')],['/privacy.html',Buffer.from('old policy')],['/birarada-legal.css',Buffer.from('existing shared CSS')]]);
const manifest=m=>[...m].map(([p,b])=>({path:p,hash:digest(b)}));
function fixture(options={}){
 let live=options.empty?null:{release:{name:'release-old',version:{name:old}}};
 let liveReads=0;const releases=[],records=[];const versions=new Map([[old,{config,bytes:original,files:manifest(original)}]]);
 const api={
  ensureSite:async()=>{}, getLive:async()=>{liveReads++;if(options.concurrentBefore&&liveReads===2)live={release:{name:'some-other-release',version:{name:old}}};return structuredClone(live);},
  getVersion:async n=>versions.get(n),listFiles:async n=>{const files=versions.get(n).files;return options.corruptManifest&&n===next?files.filter(f=>f.path!='/app.js'):files;},
  createVersion:async c=>{versions.set(next,{config:c});return {name:next};},
  upload:async(n,payload,expected)=>{const v=versions.get(n);v.bytes=new Map([...(options.empty?[]:original),...payload]);v.files=[...expected].map(([path,hash])=>({path,hash}));},
  finalize:async(n,c)=>{versions.get(n).config=c;},
  createPreview:async()=>({url:'https://birarada-5650c--legal-test.web.app'}),
  release:async(channel,n)=>{releases.push([channel,n]);if(channel==='live')live={release:{name:'release-'+releases.length,version:{name:n}}};},
 };
 let responseCount=0;
 const read=async(base,p)=>{
  responseCount++;
  if(options.transient && responseCount<=2)return {status:404,body:Buffer.from('not yet deployed'),contentType:'text/html'};
  if(options.wrongMime && p==='/privacy')return {status:200,body:prepareLegal(config,manifest(original),sources).pages.get('privacy'),contentType:'application/octet-stream'};
  const isLive=base===LIVE_URL;
  if((options.badPreview&&!isLive)||(options.badLive&&isLive)){
    if(options.concurrentAfter&&isLive)live={release:{name:'another',version:{name:old.replace(/old$/,'other')}}};
    return {status:200,body:Buffer.from('incorrect content'),contentType:'text/html'};
  }
  const v=versions.get(isLive?live.release.version.name:next);
  const dest=v.bytes.has(p)?p:v.config.rewrites.find(r=>r.glob===p)?.path;
  return {status:dest?200:404,body:v.bytes.get(dest)||Buffer.from('missing'),contentType:p.endsWith('.css')?'text/css':'text/html'};
 };
 return {api,read,records,releases,versions,run:()=>publishLegal({api,read,sources,record:s=>records.push(structuredClone(s)),log:()=>{},wait:async()=>{},channelId:'legal-test'})};
}
test('legal overlay preserves unrelated assets, routing and security headers',()=>{
 const p=prepareLegal(config,manifest(original),sources);
 assert.equal(p.expected.get('/index.html'),digest(original.get('/index.html')));
 assert.equal(p.expected.get('/app.js'),digest(original.get('/app.js')));
 assert.equal(p.expected.get('/birarada-legal.css'),digest(original.get('/birarada-legal.css')));
 assert.notEqual(p.expected.get('/privacy.html'),digest(original.get('/privacy.html')));
 assert.equal(p.payload.has('/terms.html'),false);
 assert.ok(p.pages.get('privacy').toString().includes(PREFIX+'/birarada-legal.css'));
 assert.deepEqual(p.config.rewrites.slice(-2),config.rewrites);
 assert.deepEqual(p.config.redirects,[config.redirects[0]]);
 assert.deepEqual(p.config.headers[0],config.headers[0]);
 assert.equal(p.config.headers.find(h=>h.glob==='/privacy').headers['X-Frame-Options'],'DENY');
 assert.equal(p.config.cleanUrls,true);assert.equal(p.config.trailingSlashBehavior,'REMOVE');
 assert.equal(config.headers[1].headers['Content-Type'],'wrong');
});
test('preview verified before live release and complete original manifest retained',async()=>{
 const f=fixture();const result=await f.run();assert.equal(result.phase,'verified');
 assert.deepEqual(f.releases,[['legal-test',next],['live',next]]);
 assert.equal(f.versions.get(next).files.find(f=>f.path==='/app.js').hash,digest(original.get('/app.js')));
 assert.ok(f.records.some(r=>r.phase==='preview-verified'));
});
test('missing unrelated site file blocks live publication',async()=>{
 const f=fixture({corruptManifest:true});await assert.rejects(f.run(),/dosya sayisi/);assert.equal(f.releases.length,0);
});
test('incorrect preview content blocks live publication',async()=>{
 const f=fixture({badPreview:true});await assert.rejects(f.run(),/privacy/);assert.ok(!f.releases.some(r=>r[0]==='live'));
});
test('concurrent site publication blocks overwriting another deployment',async()=>{
 const f=fixture({concurrentBefore:true});await assert.rejects(f.run(),/baska bir islemde/);assert.ok(!f.releases.some(r=>r[0]==='live'));
});
test('failed live content verification restores previous version',async()=>{
 const f=fixture({badLive:true});await assert.rejects(f.run(),/onceki Hosting surumune donuldu/);
 assert.deepEqual(f.releases.slice(-2),[['live',next],['live',old]]);assert.equal(f.records.at(-1).phase,'rolled-back');
});
test('rollback cannot overwrite a concurrent third-party version',async()=>{
 const f=fixture({badLive:true,concurrentAfter:true});await assert.rejects(f.run(),/privacy/);assert.equal(f.releases.filter(r=>r[0]==='live').length,1);
});
test('first Hosting deployment can publish without existing files',async()=>{
 const f=fixture({empty:true});assert.equal((await f.run()).phase,'verified');assert.equal(f.versions.get(next).files.length,5);
});
test('outdated or scripted local policy rejected before creating a version',()=>{
 assert.throws(()=>prepareLegal(config,manifest(original),{...sources,'privacy.html':Buffer.from('old policy')}),/privacy/);
 assert.throws(()=>prepareLegal({},[],{...sources,'terms.html':Buffer.concat([sources['terms.html'],Buffer.from('<script>bad()</script>')])}),/terms/);
});
test('guard installer matches source exactly and preserves customized files',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'birarada-legal-test-'));fs.mkdirSync(path.join(temp,'scripts'));
 const target=path.join(temp,'scripts/check-live.cjs');const current=fs.readFileSync(path.join(root,'scripts/check-live.cjs'));
 try{fs.writeFileSync(target,current);installLiveChecker(temp,temp);assert.deepEqual(fs.readFileSync(target),current);
 fs.writeFileSync(target,'custom guard');assert.throws(()=>installLiveChecker(temp,temp),/ozel degisikliklerin/);assert.equal(fs.readFileSync(target,'utf8'),'custom guard');}
 finally{fs.rmSync(temp,{recursive:true,force:true});}
});
test('foreign version resources and unsafe public URLs rejected',async()=>{
 assert.equal(versionName('sites/birarada-5650c/versions/xyz'),old.replace(/old$/,'xyz'));
 assert.throws(()=>versionName('sites/foreign/versions/xyz'));
 await assert.rejects(readPublic('https://evil.example','/privacy'),/Beklenmeyen/);
 await assert.rejects(readPublic('https://birarada-5650c.web.app','https://birarada-5650c.web.app.evil.example/privacy'),/Beklenmeyen/);
});

test('known previous guard upgrades atomically with byte-for-byte backup',()=>{
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'birarada-upgrade-test-'));fs.mkdirSync(path.join(temp,'scripts'));
 const target=path.join(temp,'scripts/check-live.cjs');const oldGuard=fs.readFileSync(path.join(__dirname,'fixtures/check-live-before-legal.txt'));
 try{fs.writeFileSync(target,oldGuard);installLiveChecker(temp,temp);
 assert.deepEqual(fs.readFileSync(path.join(temp,'previous-check-live.cjs')),oldGuard);
 assert.deepEqual(fs.readFileSync(target),fs.readFileSync(path.join(root,'scripts/check-live.cjs')));installLiveChecker(temp,temp);}
 finally{fs.rmSync(temp,{recursive:true,force:true});}
});

test('temporary preview 404 responses are retried until the exact page is served',async()=>{
 const f=fixture({transient:true});const state=await f.run();assert.equal(state.phase,'verified');
 assert.equal(f.records.filter(r=>r.lastVerification?.status===404).length>=2,true);
});
test('persistent mismatch records safe detailed diagnostics and never publishes live',async()=>{
 const f=fixture({badPreview:true});await assert.rejects(f.run(),/HTTP 200; tur=text\/html; alinan=/);
 assert.equal(f.records.at(-1).lastVerification.attempt,6);
 assert.equal(f.records.at(-1).lastVerification.actualBytes,17);
 assert.ok(f.records.at(-1).previewUrl);assert.ok(!f.releases.some(r=>r[0]==='live'));
});
test('even an exact HTML body with wrong MIME is rejected after bounded retries',async()=>{
 const f=fixture({wrongMime:true});await assert.rejects(f.run(),/application\/octet-stream/);assert.ok(!f.releases.some(r=>r[0]==='live'));
});
