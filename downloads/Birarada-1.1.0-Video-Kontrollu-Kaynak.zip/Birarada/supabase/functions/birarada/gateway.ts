import { accounts, context, HttpsError, type Identity } from "./context.ts";
import {
  decode,
  type Driver,
  encode,
  Query,
  Records,
  Timestamp,
} from "./records.ts";
import {
  active,
  apiCall,
  blocked,
  mediaReadable,
  rate,
  removeAttachedMedia,
} from "./core.ts";
import { canRead, commitClient } from "./policy.ts";
import { validateMedia } from "./media.ts";
import {
  type Actor,
  id,
  InputError,
  rangeHeader,
  roleFromToken,
  uuid,
} from "./domain.ts";
export type Storage = {
  save: (key: string, bytes: Uint8Array, type: string) => Promise<void>;
  remove: (key: string) => Promise<void>;
  read: (key: string, start: number, end: number) => Promise<Response>;
  health: () => Promise<boolean>;
};
export type Dependencies = {
  driver: Driver;
  storage: Storage;
  identify: (token: string) => Promise<Identity>;
  background?: (work: Promise<unknown>) => void;
  push?: (messages: any[]) => Promise<any>;
};
const allowedOrigin = (origin: string) =>
  ["https://birarada-5650c.web.app", "https://birarada-5650c.firebaseapp.com"]
    .includes(origin) || /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);
async function body(request: Request, max: number) {
  const reader = request.body?.getReader();
  if (!reader) return new Uint8Array();
  let total = 0;
  const chunks: Uint8Array[] = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > max) throw new InputError("İstek boyutu çok büyük.");
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.byteLength;
  }
  return out;
}
const json = (data: any, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
export async function handle(
  request: Request,
  deps: Dependencies,
): Promise<Response> {
  const url = new URL(request.url),
    route = url.pathname.split("/").filter(Boolean).at(-1),
    origin = request.headers.get("origin") || "";
  const corsHeaders = {
    "Access-Control-Allow-Origin": allowedOrigin(origin)
      ? origin
      : "https://birarada-5650c.web.app",
    "Access-Control-Allow-Headers":
      "authorization,apikey,content-type,x-client-info,range",
    "Access-Control-Allow-Methods": "GET,HEAD,POST,PUT,OPTIONS",
    "Access-Control-Expose-Headers":
      "Content-Length,Content-Range,Accept-Ranges",
    "Vary": "Origin",
  };
  let response: Response;
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders });
  }
  try {
    const records = new Records(deps.driver);
    if (route === "health") {
      if (request.method !== "GET") return json({}, 405);
      await records.getAll(records.doc("system/owner"));
      const storageReady = await deps.storage.health();
      response = json({
        service: "birarada-social-free",
        protocol: 3,
        revision: "2026-10-22-social1",
        provider: "supabase",
        firebaseProjectId: "birarada-5650c",
        supabaseProjectId: "qinevhhhdtslnzrtcanq",
        termsVersion: "2026-10-21-free1",
        storageReady,
        serverTranscoding: false,
      }, storageReady ? 200 : 503);
    } else {
      const header = request.headers.get("authorization") || "";
      if (!header.startsWith("Bearer ") || header.length > 8192) {
        throw new HttpsError("unauthenticated", "Önce giriş yap.");
      }
      let identity: Identity;
      try {
        identity = await deps.identify(header.slice(7));
      } catch {
        throw new HttpsError(
          "unauthenticated",
          "Oturumunu yenilemek için yeniden giriş yap.",
        );
      }
      id(identity.uid);
      response = await context.run({
        db: records,
        identity,
        storage: deps.storage,
      }, async () => {
        // Auth identity comes from verified Google JWT + current account lookup, never the request body.
        const authRef = records.doc("authUsers/" + identity.uid),
          saved = (await authRef.get()).data();
        if (saved?.emailVerified !== identity.emailVerified || saved?.email) {
          await authRef.set({ emailVerified: identity.emailVerified });
        }
        const claim = (await records.doc("roles/" + identity.uid).get()).data();
        if (claim?.reauthAfter && identity.authTime < claim.reauthAfter) {
          throw new HttpsError(
            "unauthenticated",
            "Güvenlik için yeniden giriş yap.",
          );
        }
        if (
          (await records.doc("accountStatus/" + identity.uid).get()).data()
            ?.suspended === true
        ) throw new HttpsError("permission-denied", "Hesabın kısıtlandı.");
        const actor: Actor = {
          uid: identity.uid,
          emailVerified: identity.emailVerified,
          role: roleFromToken({
            email_verified: identity.emailVerified,
            biraradaRole: claim?.role,
          }),
        };
        let result: Response;
        if (route === "mediaContent") {
          result = await content(request, actor, records, deps.storage, url);
        } else if (route === "mediaUpload") {
          result = await upload(request, actor, records, deps.storage, url);
        } else {
          if (request.method !== "POST") return json({}, 405);
          const input = decode(
            JSON.parse(new TextDecoder().decode(await body(request, 150000))),
          );
          if (route === "socialApi") {
            const data = await apiCall(actor, input.action, input.input || {});
            result = json({ data });
          } else if (route === "documents") {
            await rate(actor.uid, "client-read", 180);
            if (input.operation === "get") {
              if (!Array.isArray(input.paths) || input.paths.length > 100) {
                throw new InputError("Geçersiz kayıt listesi.");
              }
              const rows = await records.getAll(
                ...input.paths.map((p: string) => records.doc(p)),
              );
              for (const row of rows) {
                if (!await canRead(actor, row.raw.path, row.data())) {
                  throw new HttpsError(
                    "permission-denied",
                    "Bu kayıt görünür değil.",
                  );
                }
              }
              result = json({ data: rows.map((r: any) => r.raw) });
            } else if (input.operation === "query") {
              const spec = input.spec;
              if (
                !spec || typeof spec.path !== "string" ||
                !Array.isArray(spec.filters) || spec.filters.length > 10 ||
                !Array.isArray(spec.orders) || spec.orders.length > 3 ||
                spec.limit > 500 ||
                spec.group &&
                  !["likes", "comments", "messages"].includes(spec.path)
              ) throw new InputError("Geçersiz sorgu.");
              const roots = spec.path.split("/");
              if (
                ![
                  "users",
                  "usernames",
                  "posts",
                  "notes",
                  "follows",
                  "chats",
                  "saved",
                  "notifications",
                  "reports",
                ].includes(roots[0]) && !spec.group
              ) {
                throw new HttpsError(
                  "permission-denied",
                  "Bu listeye erişilemez.",
                );
              }
              let q = new Query(records, spec.path, spec.group === true);
              for (const [f, op, v] of spec.filters) {
                if (
                  typeof f !== "string" ||
                  !["==", "!=", ">", ">=", "<", "<=", "array-contains", "in"]
                    .includes(op)
                ) throw new InputError("Geçersiz sorgu.");
                q = q.where(f, op, v);
              }
              for (const [f, d] of spec.orders) {
                if (typeof f !== "string" || !["asc", "desc"].includes(d)) {
                  throw new InputError("Geçersiz sıralama.");
                }
                q = q.orderBy(f, d);
              }
              q = q.limit(Math.min(Number(spec.limit) || 50, 500));
              if (spec.bounds) q.bounds = spec.bounds;
              const rows = await q.get(), visible = [];
              for (const row of rows.docs) {
                if (await canRead(actor, row.raw.path, row.data())) {
                  visible.push(row.raw);
                }
              }
              result = json({ data: visible });
            } else if (input.operation === "commit") {
              result = json({
                data: await commitClient(actor, input.reads, input.writes),
              });
            } else throw new InputError("Geçersiz işlem.");
          } else throw new HttpsError("not-found", "Sunucu yolu bulunamadı.");
        }
        const work = maintain(records, deps).then(() =>
          flushJobs(records, deps)
        ).catch(() => {});
        if (deps.background) deps.background(work);
        else await work;
        return result;
      });
    }
  } catch (error) {
    const code = error instanceof HttpsError
      ? error.code
      : error instanceof InputError
      ? "invalid-argument"
      : (error as any)?.code === "conflict"
      ? "aborted"
      : "internal";
    const status = ({
      "unauthenticated": 401,
      "permission-denied": 403,
      "invalid-argument": 400,
      "not-found": 404,
      "failed-precondition": 412,
      "resource-exhausted": 429,
      "unavailable": 503,
      "aborted": 409,
    } as Record<string, number>)[code] || 500;
    response = json({
      error: {
        code,
        message: error instanceof HttpsError || error instanceof InputError
          ? error.message
          : code === "aborted"
          ? "İşlem çakıştı; yeniden dene."
          : "İşlem tamamlanamadı. Lütfen yeniden dene.",
      },
    }, status);
  }
  for (const [key, value] of Object.entries(corsHeaders)) {
    response.headers.set(key, value);
  }
  return response;
}
async function upload(
  request: Request,
  a: Actor,
  db: Records,
  storage: Storage,
  url: URL,
) {
  if (request.method !== "PUT") return json({}, 405);
  if (!await active(a.uid)) {
    throw new HttpsError("permission-denied", "Profilini tamamla.");
  }
  const mediaId = uuid(url.searchParams.get("id")),
    ref = db.doc("media/" + mediaId),
    media = (await ref.get()).data();
  if (
    !media || media.uid !== a.uid || media.attachedTo ||
    media.expiresAt.toMillis() <= Date.now()
  ) throw new HttpsError("permission-denied", "Yükleme izni yok.");
  if (media.status === "ready") return json({ id: mediaId, status: "ready" });
  const bytes = await body(request, 20 * 1024 ** 2);
  if (bytes.length !== media.declaredBytes) {
    throw new InputError("Dosya boyutu geçersiz.");
  }
  await db.runTransaction(async (t) => {
    const current = (await t.get(ref)).data();
    if (
      current?.status === "processing" &&
      current.processingAt.toMillis() > Date.now() - 90000
    ) throw new HttpsError("resource-exhausted", "Dosya işleniyor.");
    t.update(ref, { status: "processing", processingAt: Timestamp.now() });
  });
  try {
    const result = validateMedia(bytes, media.kind, media.purpose),
      key = `private/${a.uid}/${mediaId}`;
    await storage.save(key, result.bytes, result.contentType);
    await ref.update({
      path: key,
      status: "ready",
      contentType: result.contentType,
      bytes: result.bytes.length,
      width: result.width,
      height: result.height,
      duration: result.duration,
    });
    return json({ id: mediaId, status: "ready" });
  } catch (error) {
    await ref.update({ status: "pending" });
    throw error;
  }
}
async function content(
  request: Request,
  a: Actor,
  db: Records,
  storage: Storage,
  url: URL,
) {
  if (!["GET", "HEAD"].includes(request.method)) return json({}, 405);
  if (!await active(a.uid)) {
    throw new HttpsError("permission-denied", "Hesap kullanıma kapalı.");
  }
  const media =
    (await db.doc("media/" + uuid(url.searchParams.get("id"))).get()).data();
  if (!media || media.status !== "ready" || !await mediaReadable(a, media)) {
    throw new HttpsError("permission-denied", "Bu medyaya erişim iznin yok.");
  }
  const range = rangeHeader(
      request.headers.get("range") || undefined,
      media.bytes,
    ),
    start = range?.start || 0,
    end = range?.end ?? media.bytes - 1;
  const headers = new Headers({
    "Content-Type": media.contentType,
    "Content-Length": String(end - start + 1),
    "Cache-Control": "private, no-store",
    "X-Content-Type-Options": "nosniff",
    "Accept-Ranges": "bytes",
  });
  if (range) {
    headers.set("Content-Range", `bytes ${start}-${end}/${media.bytes}`);
  }
  if (request.method === "HEAD") {
    return new Response(null, { status: range ? 206 : 200, headers });
  }
  // Conservative application transfer limit; it does not promise provider accounting equivalence.
  const budget = db.doc(
    "system/transfer-" + new Date().toISOString().slice(0, 7),
  );
  await db.runTransaction(async (t) => {
    const r = (await t.get(budget)).data(),
      used = (r?.bytes || 0) + end - start + 1;
    if (used > 2147483648) {
      throw new HttpsError(
        "resource-exhausted",
        "Bu ay için ücretsiz medya aktarım sınırına ulaşıldı.",
      );
    }
    t.set(budget, { bytes: used });
  });
  const result = await storage.read(media.path, start, end);
  if (!result.ok) throw new HttpsError("not-found", "Medya bulunamadı.");
  if (start > 0 && result.status !== 206) {
    throw new HttpsError(
      "unavailable",
      "Medya sunucusu parça isteğini desteklemedi.",
    );
  }
  return new Response(result.body, { status: range ? 206 : 200, headers });
}
export async function flushJobs(db: Records, deps: Dependencies) {
  const jobs = await db.rpc("birarada_claim_jobs", {});
  for (const job of jobs) {
    let success = false;
    try {
      if (job.kind === "remove-media") await removeAttachedMedia(job.payload);
      else if (job.kind === "push") {
        const n = (await db.doc(job.payload.path).get()).data();
        if (
          !n || !await active(n.targetUid) ||
          await blocked(n.sourceUid, n.targetUid)
        ) {
          success = true;
          continue;
        }
        const devices = await db.collection("pushDevices").where(
          "uid",
          "==",
          n.targetUid,
        ).where("enabled", "==", true).limit(10).get();
        if (devices.size && deps.push) {
          const tickets = await deps.push(
            devices.docs.map((d) => ({
              to: d.get("token"),
              title: "Birarada",
              body: "Yeni bir bildirimin var.",
              sound: "default",
              data: { ...n.target, targetUid: n.targetUid },
            })),
          );
          for (let i = 0; i < devices.size; i++) {
            if (tickets?.data?.[i]?.details?.error === "DeviceNotRegistered") {
              await devices.docs[i]!.ref.delete();
            }
          }
        }
      }
      success = true;
    } finally {
      await db.rpc("birarada_finish_job", { job_id: job.id, success });
    }
  }
}

// Bounded lazy maintenance: no paid cron and no guaranteed wall-clock schedule.
export async function maintain(db: Records, deps: Dependencies) {
  const now = Date.now(), lease = db.doc("system/maintenance");
  const acquired = await db.runTransaction(async (tx) => {
    const old = (await tx.get(lease)).data();
    if ((old?.after || 0) > now) return false;
    tx.set(lease, { after: now + 60000 });
    return true;
  });
  if (!acquired) return;
  const uploads = await db.collection("media").where(
    "expiresAt",
    "<",
    Timestamp.fromMillis(now - 900000),
  ).limit(10).get();
  for (const row of uploads.docs) {
    const m = row.data()!;
    if (m.attachedTo) continue;
    if (m.path) await deps.storage.remove(m.path);
    await row.ref.delete();
  }
  const stories = await db.collection("stories").where(
    "highlighted",
    "==",
    false,
  ).where("expiresAt", "<", Timestamp.fromMillis(now - 30 * 86400000)).limit(10)
    .get();
  for (const row of stories.docs) {
    const removed = await db.runTransaction(async (tx) => {
      const current = (await tx.get(row.ref)).data();
      if (
        !current || current.highlighted ||
        current.expiresAt?.toMillis() > now - 30 * 86400000
      ) return false;
      tx.delete(row.ref);
      return true;
    });
    if (removed) await db.recursiveDelete(row.ref);
  }
  for (const name of ["rateLimits", "reviewGrants"]) {
    const old = await db.collection(name).where(
      "expiresAt",
      "<",
      Timestamp.fromMillis(now),
    ).limit(20).get();
    for (const row of old.docs) await row.ref.delete();
  }
}
