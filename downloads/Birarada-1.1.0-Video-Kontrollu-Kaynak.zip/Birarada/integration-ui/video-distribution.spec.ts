import { test, expect, type Page } from "@playwright/test";
import { randomUUID } from "node:crypto";
import fs from "node:fs/promises";

const password = "Local-video-distribution-940!";
type Account = { uid: string; email: string; token: string; username: string };
let accounts: Record<string, Account>;
async function auth(action: string, input: unknown, admin = false) {
  const response = await fetch(
    "http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/" +
      action +
      "?key=local",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(admin ? { Authorization: "Bearer owner" } : {}),
      },
      body: JSON.stringify(input),
    },
  );
  const result = await response.json();
  expect(response.status, JSON.stringify(result)).toBe(200);
  return result;
}
async function response(
  who: string,
  route: string,
  input?: unknown,
  method = "POST",
) {
  return fetch("http://127.0.0.1:5002/" + route, {
    method,
    headers: {
      Authorization: "Bearer " + accounts[who]!.token,
      "Content-Type": "application/json",
    },
    ...(input === undefined ? {} : { body: JSON.stringify(input) }),
  });
}
async function data(who: string, route: string, input: unknown) {
  const result = await response(who, route, input);
  const value = await result.json();
  expect(result.status, JSON.stringify(value)).toBe(200);
  return value.data;
}
const api = (who: string, action: string, input: unknown = {}) =>
  data(who, "socialApi", { action, input });
async function document(who: string, path: string) {
  return (await data(who, "documents", { operation: "get", paths: [path] }))[0];
}
async function change(
  who: string,
  path: string,
  fields: Record<string, unknown>,
) {
  const old = await document(who, path);
  await data(who, "documents", {
    operation: "commit",
    reads: [{ path, rev: old.rev }],
    writes: [{ kind: "set", path, data: { ...old.data, ...fields } }],
  });
}
async function login(page: Page, who: string) {
  await page.goto("/", { waitUntil: "commit", timeout: 30000 });
  await expect(
    page.getByText("Arkadaşlarını bul", { exact: true }),
  ).toBeVisible({ timeout: 90000 });
  await page
    .getByRole("button", { name: "Tanıtımı atla", exact: true })
    .click();
  await page.getByLabel("E-posta", { exact: true }).fill(accounts[who]!.email);
  await page.getByLabel("Şifre", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Giriş yap", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function follow(page: Page, privateAccount: boolean) {
  await page.getByRole("tab", { name: "Keşfet", exact: true }).click();
  await page.getByRole("tab", { name: "Hesaplar", exact: true }).click();
  await page
    .getByPlaceholder("Kullanıcı, kelime veya #etiket ara")
    .fill(accounts.publisher!.username);
  await page.getByText(accounts.publisher!.username, { exact: true }).click();
  await page
    .getByRole("button", {
      name: privateAccount ? "Takip isteği gönder" : "Takip et",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("button", {
      name: privateAccount ? "İsteği geri çek" : "Takipten çık",
      exact: true,
    }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
}
async function publish(page: Page, kind: "post" | "reel", caption: string) {
  await page.getByRole("tab", { name: "Oluştur", exact: true }).click();
  if (kind === "reel")
    await page.getByRole("tab", { name: "Reels", exact: true }).first().click();
  await page.getByPlaceholder("Açıklama, #etiket, @kullanıcı…").fill(caption);
  const chooser = page.waitForEvent("filechooser");
  await page
    .getByRole("button", { name: "Galeriden seç", exact: true })
    .click();
  await (
    await chooser
  ).setFiles({
    name: "video.mp4",
    mimeType: "video/mp4",
    buffer: await fs.readFile("tests/free-video.mp4"),
  });
  await expect(page.getByText("1. Video", { exact: true })).toBeVisible();
  const published = page.waitForResponse(
    (r) =>
      r.url().endsWith("/socialApi") &&
      r.request().postDataJSON()?.action === "publishContent",
  );
  await page.getByRole("button", { name: "Paylaş", exact: true }).click();
  const result = await published;
  expect(result.status()).toBe(200);
  const id = (await result.json()).data.id;
  await expect(
    page.getByRole("button", { name: "Keşfet akışı", exact: true }),
  ).toBeVisible();
  return id as string;
}
async function homeVideo(page: Page, id: string, following: boolean) {
  await page
    .getByRole("button", {
      name: following ? "Takip ettiklerin" : "Keşfet akışı",
      exact: true,
    })
    .click();
  const card = page.getByTestId("post-" + id);
  await expect(card).toBeVisible();
  await card
    .getByRole("button", { name: "Videoyu yükle", exact: true })
    .click();
  await expect
    .poll(() =>
      card.locator("video").evaluateAll((videos) =>
        videos.some((video) => {
          const v = video as HTMLVideoElement;
          return (
            v.src.startsWith("blob:") &&
            v.readyState >= 1 &&
            v.videoWidth === 160
          );
        }),
      ),
    )
    .toBe(true);
  await card.locator("video").evaluate(async (element) => {
    const video = element as HTMLVideoElement;
    video.muted = true;
    await video.play();
  });
  await expect
    .poll(() =>
      card.locator("video").evaluate((element) => {
        const video = element as HTMLVideoElement;
        return (
          video.readyState >= 2 &&
          video.currentTime > 0.01 &&
          video.error === null
        );
      }),
    )
    .toBe(true);
  return card;
}
test.beforeEach(async () => {
  expect(process.env.BIRARADA_TEST_SECRET).toBeTruthy();
  accounts = {};
  const profiles = [],
    suffix = Date.now().toString(36);
  for (const who of ["publisher", "follower", "stranger"]) {
    const email = `video-${who}-${suffix}@example.test`;
    const created = await auth("accounts:signUp", {
      email,
      password,
      returnSecureToken: true,
    });
    await auth(
      "projects/demo-birarada/accounts:update",
      { localId: created.localId, emailVerified: true },
      true,
    );
    const signed = await auth("accounts:signInWithPassword", {
      email,
      password,
      returnSecureToken: true,
    });
    const username = "v_" + who + "_" + suffix;
    accounts[who] = {
      uid: created.localId,
      email,
      token: signed.idToken,
      username,
    };
    profiles.push({ uid: created.localId, email, username, displayName: who });
  }
  const seeded = await fetch("http://127.0.0.1:5002/__fixtures", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + process.env.BIRARADA_TEST_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ profiles }),
  });
  expect(seeded.status).toBe(200);
});
for (const kind of ["post", "reel"] as const) {
  test(`public ${kind} video reaches another account's home and respects the Reels filter`, async ({
    page,
    browser,
  }) => {
    const context = await browser.newContext(),
      outsider = await browser.newContext();
    try {
      const viewer = await context.newPage(),
        stranger = await outsider.newPage();
      await login(page, "publisher");
      await login(viewer, "follower");
      await follow(viewer, false);
      const caption = `Public ${kind} ${randomUUID()}`;
      const id = await publish(page, kind, caption);
      const post = await api("publisher", "getContent", { id });
      expect(post.kind).toBe(kind);
      expect(post.mediaItems[0].kind).toBe("video");
      const card = await homeVideo(viewer, id, true);
      await card.getByRole("button", { name: "Beğen", exact: true }).click();
      await expect
        .poll(
          async () =>
            !!(
              await document(
                "publisher",
                `posts/${id}/likes/${accounts.follower!.uid}`,
              )
            ).data,
        )
        .toBe(true);
      await card.getByRole("button", { name: "Yorumlar", exact: true }).click();
      await viewer
        .getByPlaceholder("Bir şey söyle…")
        .fill("Başka hesaptan videoya yorum.");
      await viewer
        .getByRole("button", { name: "Yorum gönder", exact: true })
        .click();
      await expect(
        viewer.getByText("Başka hesaptan videoya yorum.", { exact: false }),
      ).toBeVisible();
      await viewer.getByRole("button", { name: "Kapat", exact: true }).click();
      const comments = await data("publisher", "documents", {
        operation: "query",
        spec: {
          path: `posts/${id}/comments`,
          group: false,
          filters: [],
          orders: [],
          limit: 50,
        },
      });
      expect(
        comments.some(
          (r: any) =>
            r.data.uid === accounts.follower!.uid &&
            r.data.text === "Başka hesaptan videoya yorum.",
        ),
      ).toBe(true);
      await login(stranger, "stranger");
      await homeVideo(stranger, id, false);
      await homeVideo(viewer, id, false);
      const reels = await api("follower", "listContent", { kind: "reel" });
      expect(reels.rows.some((r: any) => r.id === id)).toBe(kind === "reel");
      await viewer.getByRole("tab", { name: "Reels", exact: true }).click();
      await expect(
        viewer.getByRole("tab", { name: "Reels", exact: true }),
      ).toHaveAttribute("aria-selected", "true");
      const reelsFeed = viewer.getByTestId("reels-feed");
      await expect(reelsFeed).toBeVisible();
      if (kind === "reel") {
        await expect(
          reelsFeed.getByText(caption, { exact: true }),
        ).toBeVisible();
        await expect
          .poll(() =>
            reelsFeed
              .locator("video")
              .evaluateAll((videos) =>
                videos.some(
                  (v) =>
                    (v as HTMLVideoElement).readyState >= 2 &&
                    (v as HTMLVideoElement).currentTime > 0.01 &&
                    (v as HTMLVideoElement).videoWidth === 160,
                ),
              ),
          )
          .toBe(true);
      } else
        await expect(reelsFeed.getByText(caption, { exact: true })).toHaveCount(
          0,
        );
      const anonymous = await fetch(
        "http://127.0.0.1:5002/mediaContent?id=" + post.mediaItems[0].id,
      );
      expect(anonymous.status).toBe(401);
    } finally {
      await context.close();
      await outsider.close();
    }
  });
  test(`private ${kind} video stays hidden until approval and is revoked on blocking`, async ({
    page,
    browser,
  }) => {
    const context = await browser.newContext();
    try {
      await change("publisher", "users/" + accounts.publisher!.uid, {
        isPrivate: true,
      });
      const viewer = await context.newPage();
      await login(page, "publisher");
      await login(viewer, "follower");
      await follow(viewer, true);
      const caption = `Private ${kind} ${randomUUID()}`,
        id = await publish(page, kind, caption);
      const post = await api("publisher", "getContent", { id });
      const media = "mediaContent?id=" + post.mediaItems[0].id;
      for (const who of ["follower", "stranger"]) {
        expect(
          (
            await response(who, "socialApi", {
              action: "getContent",
              input: { id },
            })
          ).status,
        ).toBe(403);
        expect((await response(who, media, undefined, "GET")).status).toBe(403);
        expect(
          (await api(who, "listContent", { kind: "post" })).rows.some(
            (r: any) => r.id === id,
          ),
        ).toBe(false);
        expect(
          (await api(who, "listContent", { kind: "reel" })).rows.some(
            (r: any) => r.id === id,
          ),
        ).toBe(false);
      }
      await viewer
        .getByRole("button", { name: "Takip ettiklerin", exact: true })
        .click();
      expect(
        (await api("follower", "followingFeed")).rows.some(
          (r: any) => r.id === id,
        ),
      ).toBe(false);
      await expect(viewer.getByTestId("post-" + id)).toHaveCount(0);
      await page
        .getByRole("button", { name: "Bildirimler", exact: true })
        .click();
      await page.getByRole("button", { name: "Kabul et", exact: true }).click();
      await expect
        .poll(async () =>
          (await api("follower", "followingFeed")).rows.some(
            (r: any) => r.id === id,
          ),
        )
        .toBe(true);
      await viewer
        .getByRole("button", { name: "Keşfet akışı", exact: true })
        .click();
      await homeVideo(viewer, id, true);
      expect((await response("follower", media, undefined, "GET")).status).toBe(
        200,
      );
      expect((await response("stranger", media, undefined, "GET")).status).toBe(
        403,
      );
      expect(
        (
          await api("follower", "listContent", {
            kind,
            uid: accounts.publisher!.uid,
          })
        ).rows.some((r: any) => r.id === id),
      ).toBe(true);
      // The global Reels/explore streams stay public; private videos remain in
      // accepted followers' following streams and the owner's profile.
      expect(
        (await api("follower", "listContent", { kind: "reel" })).rows.some(
          (r: any) => r.id === id,
        ),
      ).toBe(false);
      const path = `users/${accounts.publisher!.uid}/blocks/${accounts.follower!.uid}`,
        old = await document("publisher", path);
      await data("publisher", "documents", {
        operation: "commit",
        reads: [{ path, rev: old.rev }],
        writes: [
          {
            kind: "set",
            path,
            data: {
              uid: accounts.follower!.uid,
              createdAt: { __ts: [Math.floor(Date.now() / 1000), 0] },
            },
          },
        ],
      });
      expect((await response("follower", media, undefined, "GET")).status).toBe(
        403,
      );
      expect(
        (await api("follower", "followingFeed")).rows.some(
          (r: any) => r.id === id,
        ),
      ).toBe(false);
    } finally {
      await context.close();
    }
  });
}
