import { test, expect } from "@playwright/test";
import { build } from "esbuild";
import path from "node:path";

// Exercise the real editor component in isolation. Callbacks are simulated;
// this deliberately does not claim a Firebase or signed Android integration test.
let bundle = "";
test.beforeAll(async () => {
  const result = await build({
    absWorkingDir: path.resolve(__dirname, ".."),
    stdin: {
      resolveDir: path.resolve(__dirname, ".."),
      loader: "tsx",
      contents: `
        import React, {useState} from 'react';
        import {createRoot} from 'react-dom/client';
        import {NoteEditor} from './src/components/NoteEditor';
        import {noteContent, noteIsActive} from './src/utils/notes';
        window.noteTest = {saved: [], removed: 0, fail: false};
        function Harness() {
          const [record, setRecord] = useState(null);
          window.noteTest.replace = setRecord;
          return <NoteEditor record={record} active={!!record && noteIsActive(record)} onSave={async (text,title,url) => {
            if (window.noteTest.fail) throw Error('Bağlantı kesildi.');
            const value = noteContent(text,title,url);
            window.noteTest.saved.push(value);
            setRecord({uid:'fixture-user',username:'fixture',...value,updatedAt:{seconds:Math.floor(Date.now()/1000)}});
          }} onRemove={async () => {window.noteTest.removed++;setRecord(null);}} />;
        }
        createRoot(document.getElementById('root')).render(<Harness/>);
      `,
    },
    loader: { ".png": "dataurl", ".ttf": "dataurl" },
    bundle: true,
    write: false,
    platform: "browser",
    format: "iife",
    alias: { "react-native": "react-native-web" },
    resolveExtensions: [
      ".web.tsx",
      ".tsx",
      ".web.ts",
      ".ts",
      ".web.js",
      ".js",
      ".json",
    ],
    define: {
      "process.env": "{}",
      "process.env.NODE_ENV": '"test"',
      __DEV__: "false",
    },
  });
  bundle = result.outputFiles[0]!.text;
});

test.beforeEach(async ({ page }) => {
  await page.route(/^https?:\/\//, (route) => route.abort());
  await page.setContent(
    '<html lang="tr"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="margin:0;background:#101112"><div id="root"></div></body></html>',
  );
  await page.addScriptTag({ content: bundle });
});

test("music-note editor validates complete song sharing and publishes a canonical link", async ({
  page,
}) => {
  const failures: string[] = [];
  page.on("pageerror", (error) => failures.push(error.message));
  const publish = page.getByRole("button", {
    name: "Notu paylaş",
    exact: true,
  });
  const text = page.getByLabel("Notun (en fazla 60 karakter)");
  const title = page.getByLabel("Şarkı ve sanatçı adı (isteğe bağlı)");
  const url = page.getByLabel("Spotify veya YouTube bağlantısı");
  await expect(publish).toBeDisabled();
  await text.fill("Bugünün şarkısı");
  await expect(publish).toBeEnabled();
  await title.fill("Sanatçı – Şarkı");
  await expect(publish).toBeDisabled();
  await url.fill("https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ");
  await expect(publish).toBeDisabled();
  await url.fill("https://youtu.be/dQw4w9WgXcQ?si=tracking");
  await expect(publish).toBeEnabled();
  await publish.click();
  await expect(
    page.getByText("Notun paylaşıldı.", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Notu güncelle", exact: true }),
  ).toBeEnabled();
  const saved = await page.evaluate(() => (window as any).noteTest.saved);
  expect(saved).toEqual([
    {
      text: "Bugünün şarkısı",
      songTitle: "Sanatçı – Şarkı",
      songUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    },
  ]);
  await expect(url).toHaveValue("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  await page.screenshot({
    path: "artifacts/music-note-mobile.png",
    fullPage: true,
  });
  expect(failures).toEqual([]);
});

test("failed note save preserves the draft and deletion requires explicit confirmation", async ({
  page,
}) => {
  const text = page.getByLabel("Notun (en fazla 60 karakter)");
  await text.fill("Taslağım kaybolmasın");
  await page.evaluate(() => {
    (window as any).noteTest.fail = true;
  });
  await page.getByRole("button", { name: "Notu paylaş", exact: true }).click();
  await expect(page.getByRole("alert")).toHaveText("Bağlantı kesildi.");
  await expect(text).toHaveValue("Taslağım kaybolmasın");
  await page.evaluate(() => {
    (window as any).noteTest.fail = false;
  });
  await page.getByRole("button", { name: "Notu paylaş", exact: true }).click();
  await expect(
    page.getByText("Notun paylaşıldı.", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Notumu sil", exact: true }).click();
  expect(await page.evaluate(() => (window as any).noteTest.removed)).toBe(0);
  await page.getByRole("button", { name: "Vazgeç", exact: true }).click();
  expect(await page.evaluate(() => (window as any).noteTest.removed)).toBe(0);
  await page.getByRole("button", { name: "Notumu sil", exact: true }).click();
  await page
    .getByRole("button", { name: "Evet, notumu sil", exact: true })
    .click();
  await expect(page.getByText("Notun silindi.", { exact: true })).toBeVisible();
  await expect(text).toHaveValue("");
  expect(await page.evaluate(() => (window as any).noteTest.removed)).toBe(1);
});

test("incoming own-note updates cannot overwrite a draft being edited", async ({
  page,
}) => {
  const text = page.getByLabel("Notun (en fazla 60 karakter)");
  await text.fill("Yazmaya devam ediyorum");
  await page.evaluate(() =>
    (window as any).noteTest.replace({
      uid: "fixture-user",
      username: "fixture",
      text: "Başka cihazdan not",
      songTitle: "",
      songUrl: "",
      updatedAt: { seconds: Math.floor(Date.now() / 1000) },
    }),
  );
  await expect(text).toHaveValue("Yazmaya devam ediyorum");
});
