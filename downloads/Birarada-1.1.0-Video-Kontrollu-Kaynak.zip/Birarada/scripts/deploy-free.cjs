"use strict";
const path = require("node:path"),
  { spawnSync } = require("node:child_process"),
  { ensureCli } = require("./supabase-cli.cjs"),
  { commandSpec } = require("./build-no-github.cjs");
const root = path.resolve(__dirname, ".."),
  REF = "qinevhhhdtslnzrtcanq";
function run(command, args, capture = false) {
  const [binary, argv] = commandSpec(command, args);
  const r = spawnSync(binary, argv, {
    cwd: root,
    env: process.env,
    stdio: capture ? "pipe" : "inherit",
    encoding: "utf8",
  });
  if (r.error || r.status !== 0) {
    throw Error(
      "Kurulum durdu. Yukaridaki CLI hatasini kontrol et. Ucretli plan veya Firebase Blaze acilmadi.",
    );
  }
  return r.stdout || "";
}
async function main() {
  if (Number(process.versions.node.split(".")[0]) < 22) {
    throw Error("Node.js 22 veya 24 LTS gerekiyor.");
  }
  console.log(
    "Birarada ucretsiz Supabase kurulumu: " +
      REF +
      "\nParola/token/service_role anahtarini sohbete veya kaynaklara yazma. Girisler resmi CLI akisindadir.",
  );
  run("npm", ["ci", "--include=dev", "--no-audit", "--no-fund"]);
  run("npm", ["run", "typecheck"]);
  run("npm", ["run", "test:free"]);
  const cli = await ensureCli(root);
  let list;
  try {
    list = JSON.parse(run(cli, ["projects", "list", "--output", "json"], true));
  } catch {
    run(cli, ["login"]);
    list = JSON.parse(run(cli, ["projects", "list", "--output", "json"], true));
  }
  const projects = Array.isArray(list) ? list : list.projects;
  if (!projects?.some((p) => (p.id || p.ref) === REF)) {
    throw Error(
      "Giris yaptigin Supabase hesabinda beklenen proje yok. Baska proje olusturulmadan duruldu.",
    );
  }
  if (!process.argv.includes("--update-only")) {
    run(cli, ["link", "--project-ref", REF]);
    run(cli, ["db", "push", "--linked"]);
  }
  run(cli, [
    "functions",
    "deploy",
    "birarada",
    "--project-ref",
    REF,
    "--use-api",
  ]);
  run("npm", ["run", "release:backend"]);
  console.log(
    "UCRETSIZ_SUNUCU_HAZIR. Veritabani, ozel bucket ve Edge sunucusu kontrol edildi. Simdi AAB_OLUSTUR.bat veya npm run build:no-github.",
  );
}
module.exports = { main };
if (require.main === module) {
  main().catch((e) => {
    console.error(e.message);
    process.exitCode = 1;
  });
}
