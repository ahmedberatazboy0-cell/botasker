import { AppState, Platform } from "react-native";
import { randomUUID } from "expo-crypto";
import { auth } from "../firebase/client";
export type DocumentData = Record<string, any>;
export class Timestamp {
  constructor(
    public seconds: number,
    public nanoseconds: number,
  ) {}
  static now() {
    return Timestamp.fromMillis(Date.now());
  }
  static fromMillis(ms: number) {
    return new Timestamp(Math.floor(ms / 1000), Math.floor((ms % 1000) * 1e6));
  }
  toMillis() {
    return this.seconds * 1000 + this.nanoseconds / 1e6;
  }
  toDate() {
    return new Date(this.toMillis());
  }
}
export const serverTimestamp = () => ({ __op: "time" }),
  deleteField = () => ({ __op: "delete" }),
  arrayUnion = (...values: any[]) => ({ __op: "union", values });
export function encode(v: any): any {
  if (v instanceof Timestamp) return { __ts: [v.seconds, v.nanoseconds] };
  if (Array.isArray(v)) return v.map(encode);
  if (v && typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v)
        .filter(([, x]) => x !== undefined)
        .map(([k, x]) => [k, encode(x)]),
    );
  }
  return v;
}
export function decode(v: any): any {
  if (v?.__ts) return new Timestamp(v.__ts[0], v.__ts[1]);
  if (Array.isArray(v)) return v.map(decode);
  if (v && typeof v === "object") {
    return Object.fromEntries(
      Object.entries(v).map(([k, x]) => [k, decode(x)]),
    );
  }
  return v;
}
const LOCAL = process.env.EXPO_PUBLIC_USE_EMULATORS === "true";
export const apiBase = LOCAL
  ? `http://${process.env.EXPO_PUBLIC_EMULATOR_HOST || "127.0.0.1"}:5002`
  : "https://qinevhhhdtslnzrtcanq.supabase.co/functions/v1/birarada";
const listeners = new Set<(paths: string[]) => void>();
// Share concurrent reads only; never retain results across requests or accounts.
const readsInFlight = new Map<string, Promise<any[]>>();
function readDocuments(input: any): Promise<any[]> {
  const key = `${auth.currentUser?.uid || ""}:${JSON.stringify(encode(input))}`;
  const pending = readsInFlight.get(key);
  if (pending) return pending;
  const work = request<any[]>("documents", input).finally(() => {
    if (readsInFlight.get(key) === work) readsInFlight.delete(key);
  });
  readsInFlight.set(key, work);
  return work;
}
export async function request<T = any>(
  route: string,
  input?: any,
  method = "POST",
): Promise<T> {
  const token = await auth.currentUser?.getIdToken();
  if (!token) {
    throw Object.assign(Error("Önce giriş yap."), { code: "unauthenticated" });
  }
  const controller = new AbortController(),
    timer = setTimeout(() => controller.abort(), 45000);
  try {
    const response = await fetch(apiBase + "/" + route, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: input === undefined ? undefined : JSON.stringify(encode(input)),
      signal: controller.signal,
    });
    const result = await response.json();
    if (!response.ok || result.error) {
      throw Object.assign(
        Error(result.error?.message || "Sunucuya bağlanılamadı."),
        { code: result.error?.code || "unavailable" },
      );
    }
    return result.data as T;
  } finally {
    clearTimeout(timer);
  }
}
export class DocumentReference<T = DocumentData> {
  readonly id: string;
  constructor(public path: string) {
    this.id = path.split("/").at(-1)!;
  }
}
export class Query<T = DocumentData> {
  constructor(
    public spec: {
      path: string;
      group: boolean;
      filters: any[];
      orders: any[];
      limit: number;
      bounds?: any[];
    },
  ) {}
}
export class DocumentSnapshot<T = DocumentData> {
  readonly id: string;
  readonly ref: DocumentReference<T>;
  readonly metadata = { fromCache: false };
  constructor(public raw: { path: string; data: T | null; rev: any }) {
    this.id = raw.path.split("/").at(-1)!;
    this.ref = new DocumentReference(raw.path);
  }
  exists(): this is this & { data(): T } {
    return this.raw.data !== null;
  }
  data(): T | undefined {
    return this.raw.data === null ? undefined : decode(this.raw.data);
  }
  get(key: string) {
    return key.split(".").reduce((a, k) => a?.[k], this.data() as any);
  }
}
export type QueryDocumentSnapshot<T = DocumentData> = DocumentSnapshot<T>;
export class QuerySnapshot<T = DocumentData> {
  readonly size: number;
  readonly empty: boolean;
  readonly metadata = { fromCache: false };
  constructor(public docs: DocumentSnapshot<T>[]) {
    this.size = docs.length;
    this.empty = !docs.length;
  }
  forEach(cb: (s: DocumentSnapshot<T>) => void) {
    this.docs.forEach(cb);
  }
}
export function collection(_db: any, ...parts: string[]) {
  return new Query({
    path: [_db instanceof DocumentReference ? _db.path : "", ...parts]
      .filter(Boolean)
      .join("/"),
    group: false,
    filters: [],
    orders: [],
    limit: 100,
  });
}
export function collectionGroup(_db: any, name: string) {
  return new Query({
    path: name,
    group: true,
    filters: [],
    orders: [],
    limit: 100,
  });
}
export function doc(_db: any, ...parts: string[]): DocumentReference {
  return new DocumentReference(
    (_db instanceof Query
      ? _db.spec.path
      : _db instanceof DocumentReference
        ? _db.path
        : "") +
      (parts.length
        ? (_db instanceof Query || _db instanceof DocumentReference
            ? "/"
            : "") + parts.join("/")
        : _db instanceof Query
          ? "/" + randomUUID()
          : ""),
  );
}
export const where = (field: string, op: string, value: any) => ({
  kind: "filter",
  value: [field, op, value],
});
export const orderBy = (field: string, direction = "asc") => ({
  kind: "order",
  value: [field, direction],
});
export const limit = (value: number) => ({ kind: "limit", value });
export const startAfter = (...value: any[]) => ({
  kind: "bound",
  value: { kind: "after", values: value },
});
export function query<T = DocumentData>(
  base: Query<T>,
  ...constraints: any[]
): Query<T> {
  const spec = JSON.parse(JSON.stringify(base.spec));
  for (const c of constraints) {
    if (c.kind === "filter") spec.filters.push(c.value);
    else if (c.kind === "order") spec.orders.push(c.value);
    else if (c.kind === "limit") spec.limit = c.value;
    else if (c.kind === "bound") {
      spec.bounds = spec.bounds || [];
      const b = c.value;
      if (b.values[0] instanceof DocumentSnapshot) {
        b.values = spec.orders.map(([f]: [string]) =>
          f === "__name__" ? b.values[0].id : b.values[0].get(f),
        );
      }
      spec.bounds.push(b);
    }
  }
  return new Query(spec);
}
export const queryEqual = (a: Query, b: Query) =>
  JSON.stringify(a.spec) === JSON.stringify(b.spec);
export async function getDoc<T = DocumentData>(ref: DocumentReference<T>) {
  const rows = await readDocuments({
    operation: "get",
    paths: [ref.path],
  });
  return new DocumentSnapshot<T>(rows[0]);
}
export async function getDocs<T = DocumentData>(q: Query<T>) {
  const rows = await readDocuments({
    operation: "query",
    spec: q.spec,
  });
  return new QuerySnapshot<T>(rows.map((r) => new DocumentSnapshot<T>(r)));
}
function apply(
  old: DocumentData | undefined,
  next: DocumentData,
  merge = false,
) {
  const data = merge ? decode(encode(old || {})) : {};
  for (const [key, v] of Object.entries(next)) {
    if (v?.__op === "delete") delete data[key];
    else if (v?.__op === "time") data[key] = Timestamp.now();
    else if (v?.__op === "union") {
      data[key] = [
        ...new Map(
          [...(data[key] || []), ...v.values].map((x) => [
            JSON.stringify(encode(x)),
            x,
          ]),
        ).values(),
      ];
    } else data[key] = v;
  }
  return data;
}
export class Transaction {
  reads = new Map<string, DocumentSnapshot<any>>();
  writes: any[] = [];
  async get<T = DocumentData>(ref: DocumentReference<T>) {
    if (!this.reads.has(ref.path)) this.reads.set(ref.path, await getDoc(ref));
    return this.reads.get(ref.path)! as DocumentSnapshot<T>;
  }
  set(
    ref: DocumentReference,
    data: DocumentData,
    options?: { merge?: boolean },
  ) {
    this.writes.push({ ref, data, merge: options?.merge });
    return this;
  }
  update(ref: DocumentReference, data: DocumentData) {
    return this.set(ref, data, { merge: true });
  }
  delete(ref: DocumentReference) {
    this.writes.push({ ref, delete: true });
    return this;
  }
  async commit() {
    for (const w of this.writes) {
      if (!this.reads.has(w.ref.path)) await this.get(w.ref);
    }
    const final = new Map<string, any>();
    for (const w of this.writes) {
      const old =
        final.get(w.ref.path)?.data || this.reads.get(w.ref.path)?.data();
      final.set(
        w.ref.path,
        w.delete
          ? { path: w.ref.path, kind: "delete" }
          : {
              path: w.ref.path,
              kind: "set",
              data: apply(old, w.data, w.merge),
            },
      );
    }
    await request("documents", {
      operation: "commit",
      reads: [...this.reads.values()].map((s) => ({
        path: s.raw.path,
        rev: s.raw.rev,
      })),
      writes: [...final.values()],
    });
    for (const update of listeners) update([...final.keys()]);
  }
}
export async function runTransaction<T>(
  _db: any,
  fn: (t: Transaction) => Promise<T>,
) {
  for (let i = 0; i < 5; i++) {
    const t = new Transaction();
    try {
      const r = await fn(t);
      await t.commit();
      return r;
    } catch (e) {
      if ((e as any).code !== "aborted" || i === 4) throw e;
    }
  }
  throw Error("İşlem tamamlanamadı.");
}
export const writeBatch = (_db: any) => new Transaction();
export const setDoc = async (
  ref: DocumentReference,
  data: DocumentData,
  options?: { merge?: boolean },
) =>
  runTransaction({}, async (t) => {
    if (options?.merge) await t.get(ref);
    t.set(ref, data, options);
  });
export const updateDoc = async (ref: DocumentReference, data: DocumentData) =>
  runTransaction({}, async (t) => {
    await t.get(ref);
    t.update(ref, data);
  });
export const deleteDoc = async (ref: DocumentReference) =>
  runTransaction({}, async (t) => {
    t.delete(ref);
  });
export const addDoc = async (q: Query, data: DocumentData) => {
  const ref = doc(q);
  await setDoc(ref, data);
  return ref;
};
export function onSnapshot<T = DocumentData>(
  target: DocumentReference<T>,
  next: (s: DocumentSnapshot<T>) => void,
  error?: (e: any) => void,
): () => void;
export function onSnapshot<T = DocumentData>(
  target: Query<T>,
  options: any,
  next: (s: QuerySnapshot<T>) => void,
  error?: (e: any) => void,
): () => void;
export function onSnapshot<T = DocumentData>(
  target: Query<T>,
  next: (s: QuerySnapshot<T>) => void,
  error?: (e: any) => void,
): () => void;
export function onSnapshot(target: any, ...args: any[]) {
  const next = typeof args[0] === "function" ? args[0] : args[1],
    error = typeof args[0] === "function" ? args[1] : args[2];
  let alive = true,
    busy = false;
  const load = async () => {
    if (!alive || busy) return;
    busy = true;
    try {
      const snap =
        target instanceof Query ? await getDocs(target) : await getDoc(target);
      if (alive) next(snap);
    } catch (e) {
      if (alive) error?.(e);
    } finally {
      busy = false;
    }
  };
  void load();
  const path = target instanceof Query ? target.spec.path : target.path;
  const interval = /^chats(?:\/|$)/.test(path)
    ? 3000
    : /(?:^saved\/|\/likes$)/.test(path)
      ? 60000
      : 10000;
  const timer = setInterval(() => {
    if (
      (typeof document === "undefined" ||
        document.visibilityState !== "hidden") &&
      (Platform.OS === "web" || AppState.currentState === "active")
    )
      void load();
  }, interval);
  const invalidate = (paths: string[]) => {
    const matches = paths.some((changed) =>
      target instanceof Query && target.spec.group
        ? changed.split("/").includes(path)
        : changed === path ||
          changed.startsWith(path + "/") ||
          path.startsWith(changed + "/"),
    );
    if (matches) void load();
  };
  listeners.add(invalidate);
  return () => {
    alive = false;
    clearInterval(timer);
    listeners.delete(invalidate);
  };
}
