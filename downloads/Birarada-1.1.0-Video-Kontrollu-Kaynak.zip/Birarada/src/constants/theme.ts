export const colors = {
  bg: "#ffffff",
  surface: "#f5f5f5",
  line: "#e8e8e8",
  text: "#121212",
  muted: "#737373",
  accent: "#0095f6",
  brand: "#e46f4d",
  danger: "#ed4956",
  incoming: "#efefef",
  outgoing: "#3797f0",
  story: "#d62976",
};
