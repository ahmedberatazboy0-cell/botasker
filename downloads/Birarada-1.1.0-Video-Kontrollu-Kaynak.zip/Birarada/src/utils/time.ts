export function secondsOf(value: any): number {
  if (typeof value?.seconds === "number") return value.seconds;
  if (typeof value?.toMillis === "function") return value.toMillis() / 1000;
  return 0;
}
export function timeAgo(value: any, now = Date.now()): string {
  const seconds = secondsOf(value);
  if (!seconds) return "Az önce";
  const delta = Math.max(0, Math.floor(now / 1000 - seconds));
  if (delta < 60) return "Az önce";
  if (delta < 3600) return `${Math.floor(delta / 60)} dk`;
  if (delta < 86400) return `${Math.floor(delta / 3600)} sa`;
  if (delta < 604800) return `${Math.floor(delta / 86400)} g`;
  return new Date(seconds * 1000).toLocaleDateString("tr-TR", {
    day: "numeric",
    month: "short",
  });
}
export function clockTime(value: any): string {
  const seconds = secondsOf(value);
  return seconds
    ? new Date(seconds * 1000).toLocaleTimeString("tr-TR", {
        hour: "2-digit",
        minute: "2-digit",
      })
    : "";
}
