import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  Switch,
  ScrollView,
  Linking,
} from "react-native";
import {
  collection,
  query,
  where,
  orderBy,
  limit,
  doc,
  onSnapshot,
  updateDoc,
  deleteDoc,
  serverTimestamp,
} from "../database/client";
import { db } from "../firebase/client";
import { useSession } from "../store/session";
import { useFeed } from "../hooks/useFeed";
import { useRows } from "../hooks/useRows";
import {
  Page,
  Label,
  Button,
  Field,
  State,
  LegalLinks,
  ReportForm,
  DeleteAccountForm,
  styles,
} from "../components/ui";
import { PostCard } from "../components/PostCard";
import {
  feedQuery,
  ownPostsQuery,
  editProfile,
  follow,
  chatWith,
  report,
  block,
  acceptFollow,
  logout,
  sendMessage,
  deleteOwnAccount,
} from "../services/social";
import { friendly } from "../utils/errors";
import type { Profile, Post, Row } from "../types";
import { FollowedNote } from "./Notes";
import { useFocusEffect } from "@react-navigation/native";
import { useApiList } from "../hooks/useApiList";
import { api, uploadMedia } from "../services/api";
import { selectMedia } from "../services/picker";
import { StoriesRail } from "./Stories";
import { PostGrid } from "./Discovery";
import { ProtectedImage } from "../components/ProtectedMedia";
import { ServerBanner } from "../components/ServerBanner";
import { useRole } from "../hooks/useRole";
import { enablePush, disablePush } from "../services/push";
import {
  Action,
  Avatar,
  Icon,
  TopBar,
  Sheet,
  MenuRow,
} from "../components/social-ui";
import { usePerson } from "../hooks/usePerson";
import { timeAgo } from "../utils/time";
import { colors as c } from "../constants/theme";
import { auth } from "../firebase/client";
import { sendEmailVerification } from "firebase/auth";
export function Feed({ navigation }: any) {
  const [mode, setMode] = useState("public");
  const data = useApiList(
      mode === "following" ? "followingFeed" : "listContent",
      { kind: "post" },
    ),
    me = useSession((s) => s.profile)!.uid,
    blocks = useRows(query(collection(db, "users", me, "blocks"), limit(200))),
    hidden = new Set(blocks.rows.map((r) => r.id));
  useFocusEffect(
    React.useCallback(() => {
      data.refresh();
    }, [data.refresh]),
  );
  return (
    <Page scroll={false}>
      <TopBar
        title="birarada"
        brand
        right={
          <>
            <Action
              name="heart-outline"
              label="Bildirimler"
              onPress={() => navigation.navigate("Notifications")}
              size={27}
            />
            <Action
              name="paper-plane-outline"
              label="Mesajlar"
              onPress={() => navigation.navigate("Chats")}
              size={26}
            />
          </>
        }
      />
      <FlatList
        data={
          blocks.loading || blocks.error
            ? []
            : data.rows.filter((p) => !hidden.has(p.uid))
        }
        keyExtractor={(r) => r.id}
        onEndReached={() => {
          void data.loadMore();
        }}
        onEndReachedThreshold={0.4}
        refreshing={data.loading}
        onRefresh={data.refresh}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <>
            <StoriesRail navigation={navigation} />
            <ServerBanner />
            <View
              style={{
                flexDirection: "row",
                paddingHorizontal: 14,
                gap: 22,
                borderBottomWidth: 0.5,
                borderBottomColor: c.line,
              }}
            >
              {[
                ["public", "Keşfet akışı"],
                ["following", "Takip ettiklerin"],
              ].map(([key, label]) => (
                <Pressable
                  key={key}
                  accessibilityRole="button"
                  accessibilityLabel={label}
                  accessibilityState={{ selected: mode === key }}
                  onPress={() => setMode(key!)}
                  style={{
                    paddingVertical: 12,
                    borderBottomWidth: mode === key ? 1.5 : 0,
                    borderBottomColor: c.text,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 13,
                      fontWeight: mode === key ? "700" : "400",
                      color: mode === key ? c.text : c.muted,
                    }}
                  >
                    {label}
                  </Text>
                </Pressable>
              ))}
              <View style={{ flex: 1 }} />
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Notlar · Şarkını paylaş"
                onPress={() => navigation.navigate("Notes")}
                style={{ justifyContent: "center" }}
              >
                <Icon name="musical-notes-outline" size={21} />
              </Pressable>
            </View>
          </>
        }
        ListEmptyComponent={
          <State
            {...(blocks.loading || blocks.error ? blocks : data)}
            empty
            retry={() => {
              blocks.refresh();
              data.refresh();
            }}
          />
        }
        ListFooterComponent={
          data.paging ? (
            <Label muted>Yeni paylaşımlar geliyor…</Label>
          ) : data.error && data.rows.length ? (
            <Button secondary title="Tekrar dene" onPress={data.loadMore} />
          ) : (
            <View style={{ height: 16 }} />
          )
        }
        renderItem={({ item }) => (
          <PostCard
            post={item as Post}
            blockedUids={hidden}
            openProfile={(uid) => navigation.navigate("User", { uid })}
          />
        )}
      />
    </Page>
  );
}

export function Explore({ navigation }: any) {
  const [search, setSearch] = useState("");
  const me = useSession((s) => s.profile)!.uid;
  const blocks = useRows(
    query(collection(db, "users", me, "blocks"), limit(200)),
  );
  const hidden = new Set(blocks.rows.map((r) => r.id));
  const users = useRows(
    query(
      collection(db, "users"),
      orderBy("username"),
      where("username", ">=", search.toLowerCase()),
      where("username", "<=", search.toLowerCase() + "\uf8ff"),
      limit(30),
    ),
  );
  return (
    <Page title="Çevrene bak.">
      <Label muted>Yeni bir sohbet, tanıdık bir yüz.</Label>
      <Field
        placeholder="Kullanıcı adı ara"
        value={search}
        onChangeText={setSearch}
      />
      <State
        loading={users.loading || blocks.loading}
        error={users.error || blocks.error}
        empty={!users.rows.some((r) => !hidden.has(r.id))}
        retry={() => {
          users.refresh();
          blocks.refresh();
        }}
      />
      {!blocks.loading &&
        !blocks.error &&
        users.rows
          .filter((r) => !hidden.has(r.id))
          .map((r) => (
            <Pressable
              key={r.id}
              onPress={() => navigation.navigate("User", { uid: r.id })}
              style={styles.card}
            >
              <Text style={styles.text}>{r.displayName}</Text>
              <Label muted>@{r.username}</Label>
            </Pressable>
          ))}
    </Page>
  );
}
export function ProfileScreen({ route, navigation }: any) {
  const current = useSession((s) => s.profile)!,
    id = route?.params?.uid || current.uid,
    [profile, setProfile] = useState<Profile | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [reporting, setReporting] = useState(false),
    [confirmBlock, setConfirmBlock] = useState(false);
  React.useEffect(() => {
    setLoading(true);
    setProfile(null);
    setError("");
    return onSnapshot(
      doc(db, "users", id),
      (s) => {
        setProfile(s.exists() ? (s.data() as Profile) : null);
        setError("");
        setLoading(false);
      },
      (e) => {
        setError(friendly(e));
        setLoading(false);
      },
    );
  }, [id]);
  const blocks = useRows(
    query(collection(db, "users", current.uid, "blocks"), limit(200)),
  );
  const isBlocked = blocks.rows.some((row) => row.id === id);
  const blockedUids = new Set(blocks.rows.map((row) => row.id));
  const relation = useRows(
    query(
      collection(db, "follows"),
      where("followerUid", "==", current.uid),
      where("followingUid", "==", id),
      limit(1),
    ),
  );
  const [contentKind, setContentKind] = useState("post");
  const mine = id === current.uid,
    posts = useApiList("listContent", {
      kind: contentKind === "reel" ? "reel" : "post",
      uid: id,
      relation: relation.rows[0]?.status || "none",
    });
  const [grid, setGrid] = useState(true),
    [stats, setStats] = useState<{
      posts: number;
      followers: number;
      following: number;
    } | null>(null);
  useFocusEffect(
    React.useCallback(() => {
      let alive = true;
      api("profileStats", { uid: id })
        .then((value) => {
          if (alive) setStats(value);
        })
        .catch(() => {
          if (alive) setStats(null);
        });
      return () => {
        alive = false;
      };
    }, [id, relation.rows[0]?.status]),
  );
  const [menu, setMenu] = useState(false);
  const locked =
    !!profile?.isPrivate && !mine && relation.rows[0]?.status !== "accepted";
  return (
    <Page scroll={false}>
      {mine && (
        <TopBar
          title={profile?.username || current.username}
          left={
            profile?.isPrivate ? (
              <View style={{ paddingRight: 7 }}>
                <Icon name="lock-closed-outline" size={17} />
              </View>
            ) : undefined
          }
          right={
            <>
              <Action
                name="add-circle-outline"
                label="Yeni paylaşım"
                onPress={() => navigation.navigate("Oluştur")}
              />
              <Action
                name="menu-outline"
                label="Profil menüsü"
                onPress={() => setMenu(true)}
              />
            </>
          }
        />
      )}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
      >
        <State
          loading={loading || blocks.loading}
          error={error || blocks.error}
          empty={!profile}
          retry={() => {
            blocks.refresh();
            navigation.replace("User", { uid: id });
          }}
        />
        {isBlocked && (
          <View style={{ padding: 20, gap: 12 }}>
            <Label>Bu hesabı engelledin.</Label>
            <Button
              secondary
              title="Engeli kaldır"
              onPress={() =>
                deleteDoc(doc(db, "users", current.uid, "blocks", id))
              }
            />
          </View>
        )}
        {profile &&
          !loading &&
          !blocks.loading &&
          !blocks.error &&
          !isBlocked && (
            <>
              <View style={{ paddingHorizontal: 16, paddingTop: 18, gap: 12 }}>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 24,
                  }}
                >
                  <Avatar
                    name={profile.displayName || profile.username}
                    mediaId={profile.avatarMediaId}
                    size={82}
                  />
                  <View
                    style={{
                      flex: 1,
                      flexDirection: "row",
                      justifyContent: "space-around",
                    }}
                  >
                    {[
                      ["posts", "gönderi"],
                      ["followers", "takipçi"],
                      ["following", "takip"],
                    ].map(([key, label]) => (
                      <Pressable
                        key={key}
                        disabled={!mine || key === "posts"}
                        accessibilityRole="button"
                        accessibilityLabel={
                          key === "followers"
                            ? "Takipçilerim"
                            : key === "following"
                              ? "Takip ettiklerim"
                              : "Gönderiler"
                        }
                        onPress={() =>
                          navigation.navigate("Connections", { kind: key })
                        }
                        style={{
                          alignItems: "center",
                          paddingVertical: 12,
                          minWidth: 55,
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 18,
                            fontWeight: "700",
                            color: c.text,
                          }}
                        >
                          {stats ? stats[key as keyof typeof stats] : "—"}
                        </Text>
                        <Text
                          style={{ fontSize: 12, color: c.text, marginTop: 3 }}
                        >
                          {label}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
                <View style={{ gap: 3 }}>
                  <Text
                    style={{ fontSize: 14, fontWeight: "700", color: c.text }}
                  >
                    {profile.displayName} {profile.official ? "✓" : ""}
                  </Text>
                  {!!profile.bio && <Label>{profile.bio}</Label>}
                  {!!profile.website && (
                    <Text
                      accessibilityRole="link"
                      onPress={() => {
                        void Linking.openURL(profile.website);
                      }}
                      style={{ fontSize: 13, color: c.accent }}
                    >
                      {profile.website}
                    </Text>
                  )}
                </View>
                <View style={{ flexDirection: "row", gap: 8 }}>
                  {mine ? (
                    <>
                      <View style={{ flex: 1 }}>
                        <Button
                          secondary
                          title="Profili düzenle"
                          onPress={() => navigation.navigate("EditProfile")}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Button
                          secondary
                          title="Notum ve şarkım"
                          onPress={() => navigation.navigate("Notes")}
                        />
                      </View>
                    </>
                  ) : (
                    <>
                      <View style={{ flex: 1 }}>
                        <Button
                          secondary={!!relation.rows.length}
                          title={
                            relation.rows[0]?.status === "pending"
                              ? "İsteği geri çek"
                              : relation.rows[0]?.status === "accepted"
                                ? "Takipten çık"
                                : profile.isPrivate
                                  ? "Takip isteği gönder"
                                  : "Takip et"
                          }
                          onPress={() => follow(profile)}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Button
                          secondary
                          title="Mesaj gönder"
                          onPress={async () =>
                            navigation.navigate("Conversation", {
                              id: await chatWith(profile),
                              title: profile.displayName,
                              otherUid: profile.uid,
                            })
                          }
                        />
                      </View>
                      <Action
                        name="ellipsis-horizontal"
                        label="Hesap seçenekleri"
                        onPress={() => setMenu(true)}
                      />
                    </>
                  )}
                </View>
                {!mine &&
                  !relation.loading &&
                  relation.rows[0]?.status === "accepted" && (
                    <FollowedNote user={id} />
                  )}
              </View>
              {!locked && (
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={{
                    gap: 22,
                    paddingHorizontal: 16,
                    paddingVertical: 22,
                  }}
                >
                  <Pressable
                    accessibilityRole="button"
                    accessibilityLabel="Öne çıkan hikâyeler"
                    onPress={() =>
                      navigation.navigate("StoryViewer", {
                        uid: id,
                        highlighted: true,
                      })
                    }
                    style={{ alignItems: "center", gap: 7 }}
                  >
                    <View
                      style={{
                        width: 63,
                        height: 63,
                        borderRadius: 32,
                        borderWidth: 1,
                        borderColor: c.line,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <Icon name="heart-outline" size={27} />
                    </View>
                    <Text style={{ fontSize: 11, color: c.text }}>
                      Öne çıkanlar
                    </Text>
                  </Pressable>
                  {mine && (
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="Hikâye arşivim · son 30 gün"
                      onPress={() =>
                        navigation.navigate("StoryViewer", {
                          uid: id,
                          archived: true,
                        })
                      }
                      style={{ alignItems: "center", gap: 7 }}
                    >
                      <View
                        style={{
                          width: 63,
                          height: 63,
                          borderRadius: 32,
                          borderWidth: 1,
                          borderColor: c.line,
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Icon name="time-outline" size={27} />
                      </View>
                      <Text style={{ fontSize: 11, color: c.text }}>Arşiv</Text>
                    </Pressable>
                  )}
                </ScrollView>
              )}
              <View
                style={{
                  flexDirection: "row",
                  borderTopWidth: 0.5,
                  borderBottomWidth: 0.5,
                  borderColor: c.line,
                  marginTop: locked ? 20 : 0,
                }}
              >
                {[
                  ["post", "grid-outline", "Izgara"],
                  ["reel", "play-circle-outline", "Reels"],
                  ["list", "list-outline", "Liste"],
                ].map(([key, icon, label]) => (
                  <Pressable
                    key={key}
                    accessibilityRole="tab"
                    accessibilityLabel={label}
                    accessibilityState={{ selected: contentKind === key }}
                    onPress={() => setContentKind(key!)}
                    style={{
                      flex: 1,
                      height: 48,
                      alignItems: "center",
                      justifyContent: "center",
                      borderBottomColor: c.text,
                      borderBottomWidth: contentKind === key ? 1.5 : 0,
                    }}
                  >
                    <Icon
                      name={icon as any}
                      size={24}
                      color={contentKind === key ? c.text : c.muted}
                    />
                  </Pressable>
                ))}
              </View>
              {locked ? (
                <View style={{ padding: 35, alignItems: "center", gap: 12 }}>
                  <Icon name="lock-closed-outline" size={44} />
                  <Text
                    style={{ fontWeight: "700", fontSize: 16, color: c.text }}
                  >
                    Bu hesap gizli
                  </Text>
                  <Text
                    style={{
                      fontSize: 13,
                      color: c.muted,
                      textAlign: "center",
                    }}
                  >
                    Fotoğraf ve videolarını görmek için bu hesabı takip et.
                  </Text>
                </View>
              ) : (
                <>
                  <State
                    {...posts}
                    empty={!posts.rows.length}
                    retry={posts.refresh}
                  />
                  {contentKind === "list" ? (
                    posts.rows.map((p) => (
                      <PostCard
                        key={p.id}
                        post={p as Post}
                        blockedUids={blockedUids}
                        openProfile={(uid) => navigation.push("User", { uid })}
                      />
                    ))
                  ) : (
                    <PostGrid
                      rows={posts.rows}
                      open={(p) =>
                        navigation.navigate("PostDetails", { id: p.id })
                      }
                    />
                  )}{" "}
                  {posts.hasMore && (
                    <Button
                      secondary
                      title="Daha fazla paylaşım"
                      onPress={posts.loadMore}
                    />
                  )}
                </>
              )}
            </>
          )}
      </ScrollView>
      <Sheet
        visible={menu}
        title={mine ? "Profil menüsü" : "Hesap seçenekleri"}
        onClose={() => setMenu(false)}
      >
        {mine ? (
          <>
            <MenuRow
              title="Ayarlar"
              icon="settings-outline"
              onPress={() => {
                setMenu(false);
                navigation.navigate("Settings");
              }}
            />
            <MenuRow
              title="Kaydedilenler"
              icon="bookmark-outline"
              onPress={() => {
                setMenu(false);
                navigation.navigate("Saved");
              }}
            />
            <MenuRow
              title="Hikâye arşivim · son 30 gün"
              icon="time-outline"
              onPress={() => {
                setMenu(false);
                navigation.navigate("StoryViewer", { uid: id, archived: true });
              }}
            />
            <MenuRow
              title="Takipçilerim"
              icon="people-outline"
              onPress={() => {
                setMenu(false);
                navigation.navigate("Connections", { kind: "followers" });
              }}
            />
          </>
        ) : (
          <>
            <MenuRow
              title="Hesabı şikâyet et"
              icon="flag-outline"
              danger
              onPress={() => {
                setMenu(false);
                setReporting(true);
              }}
            />
            <MenuRow
              title="Engelle"
              icon="ban-outline"
              danger
              onPress={() => {
                setMenu(false);
                setConfirmBlock(true);
              }}
            />
          </>
        )}
      </Sheet>
      <Sheet
        visible={reporting}
        title="Hesabı şikâyet et"
        onClose={() => setReporting(false)}
      >
        <ReportForm
          onSubmit={(reason) => report(id, reason)}
          onCancel={() => setReporting(false)}
        />
      </Sheet>
      <Sheet
        visible={confirmBlock}
        title="Hesabı engelle"
        onClose={() => setConfirmBlock(false)}
      >
        <Label>
          Bu hesabı engellemek istiyor musun? Karşılıklı mesajlaşma ve
          paylaşımlara erişim engellenir.
        </Label>
        <Button
          title="Evet, engelle"
          onPress={async () => {
            await block(id);
            setConfirmBlock(false);
            blocks.refresh();
          }}
        />
        <Button
          secondary
          title="Vazgeç"
          onPress={() => setConfirmBlock(false)}
        />
      </Sheet>
    </Page>
  );
}
export function EditProfile({ navigation }: any) {
  const p = useSession((s) => s.profile)!,
    [name, setName] = useState(p.displayName),
    [bio, setBio] = useState(p.bio),
    [website, setWebsite] = useState(p.website),
    [privacy, setPrivacy] = useState(p.isPrivate),
    [dm, setDm] = useState(p.allowStrangerDM);
  return (
    <Page title="Kendin gibi.">
      {!!p.avatarMediaId && (
        <ProtectedImage
          id={p.avatarMediaId}
          style={{ width: 100, height: 100, borderRadius: 50 }}
        />
      )}
      <Button
        secondary
        title="Profil fotoğrafını değiştir"
        onPress={async () => {
          const asset = (await selectMedia())[0];
          if (!asset) return;
          if (asset.type === "video") throw Error("Profil için fotoğraf seç.");
          const media = await uploadMedia(asset.uri, "image", "avatar");
          await api("setAvatar", { mediaId: media.id });
        }}
      />
      <Field
        placeholder="Görünen ad"
        value={name}
        onChangeText={setName}
        maxLength={60}
      />
      <Field
        placeholder="Bio"
        value={bio}
        onChangeText={setBio}
        multiline
        maxLength={160}
      />
      <Field
        placeholder="Web sitesi"
        value={website}
        onChangeText={setWebsite}
      />
      <Label muted>
        Kullanıcı adın: @{p.username}. Benzersiz kullanıcı adın bu sürümde
        değiştirilemez.
      </Label>
      <View style={styles.row}>
        <Label>Gizli hesap</Label>
        <Switch
          accessibilityLabel="Gizli hesap"
          value={privacy}
          onValueChange={setPrivacy}
        />
      </View>
      <View style={styles.row}>
        <Label>Yabancılardan mesaj al</Label>
        <Switch
          accessibilityLabel="Yabancılardan mesaj al"
          value={dm}
          onValueChange={setDm}
        />
      </View>
      <Label muted>
        Gizli hesapların medyasına yalnız onaylı takipçiler erişebilir. Daha
        önce özel paylaştığın içerikler, hesabı açsan da özel kalır.
      </Label>
      <Button
        title="Kaydet"
        disabled={name.trim().length < 2}
        onPress={async () => {
          await editProfile({
            displayName: name.trim(),
            bio,
            website,
            isPrivate: privacy,
            allowStrangerDM: dm,
          });
          navigation.goBack();
        }}
      />
    </Page>
  );
}
export function Settings({ navigation }: any) {
  const role = useRole();
  const p = useSession((s) => s.profile)!,
    [deleting, setDeleting] = useState(false),
    blocks = useRows(
      query(collection(db, "users", p.uid, "blocks"), limit(100)),
    );
  return (
    <Page>
      <View
        style={{
          paddingVertical: 8,
          flexDirection: "row",
          alignItems: "center",
          gap: 14,
        }}
      >
        <Avatar name={p.displayName} mediaId={p.avatarMediaId} size={54} />
        <View>
          <Text style={{ fontWeight: "700", fontSize: 16, color: c.text }}>
            {p.username}
          </Text>
          <Text style={{ fontSize: 12, color: c.muted, marginTop: 4 }}>
            Ayarlar ve hareketlerin
          </Text>
        </View>
      </View>
      <Text
        style={{
          fontSize: 12,
          fontWeight: "600",
          color: c.muted,
          marginTop: 14,
        }}
      >
        Hesabını nasıl kullanıyorsun?
      </Text>
      <MenuRow
        title="Profili ve gizliliği düzenle"
        icon="person-circle-outline"
        onPress={() => navigation.navigate("EditProfile")}
      />
      <MenuRow
        title="Kaydedilenler"
        icon="bookmark-outline"
        onPress={() => navigation.navigate("Saved")}
      />
      <MenuRow
        title="Hikâye arşivi"
        icon="time-outline"
        onPress={() =>
          navigation.navigate("StoryViewer", { uid: p.uid, archived: true })
        }
      />
      <View style={styles.divider} />
      <Text style={{ fontSize: 12, fontWeight: "600", color: c.muted }}>
        Bildirimler
      </Text>
      <MenuRow
        title="Telefon bildirimlerini aç"
        icon="notifications-outline"
        onPress={enablePush}
      />
      <MenuRow
        title="Telefon bildirimlerini kapat"
        icon="notifications-off-outline"
        onPress={disablePush}
      />
      {!auth.currentUser?.emailVerified && (
        <MenuRow
          title="E-postamı doğrula"
          icon="mail-outline"
          onPress={async () => {
            if (auth.currentUser) await sendEmailVerification(auth.currentUser);
          }}
        />
      )}
      {role !== "member" && (
        <MenuRow
          title="Yönetim paneli"
          icon="shield-checkmark-outline"
          onPress={() => navigation.navigate("Admin")}
        />
      )}
      <OwnerActivation />
      <View style={styles.divider} />
      <Text style={{ fontSize: 12, fontWeight: "600", color: c.muted }}>
        Engellenen hesaplar
      </Text>
      <State {...blocks} empty={!blocks.rows.length} retry={blocks.refresh} />
      {blocks.rows.map((r) => (
        <BlockedPerson
          key={r.id}
          uid={r.id}
          remove={() => deleteDoc(doc(db, "users", p.uid, "blocks", r.id))}
        />
      ))}
      <View style={styles.divider} />
      <LegalLinks includeDeletion />
      <MenuRow title="Çıkış yap" icon="log-out-outline" onPress={logout} />
      <MenuRow
        title="Hesabımı sil"
        icon="trash-outline"
        danger
        onPress={() => setDeleting(true)}
      />
      {deleting && (
        <DeleteAccountForm
          onDelete={deleteOwnAccount}
          onCancel={() => setDeleting(false)}
        />
      )}
    </Page>
  );
}
function BlockedPerson({
  uid,
  remove,
}: {
  uid: string;
  remove: () => Promise<unknown>;
}) {
  const person = usePerson(uid);
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
      <Avatar
        name={person?.username}
        mediaId={person?.avatarMediaId}
        size={38}
      />
      <Text style={{ flex: 1, fontSize: 14, color: c.text }}>
        {person?.username || "Engellenen kullanıcı"}
      </Text>
      <Button secondary title="Engeli kaldır" onPress={remove} />
    </View>
  );
}

export function Notifications({ navigation }: any) {
  const id = useSession((s) => s.profile)!.uid,
    requests = useRows(
      query(
        collection(db, "follows"),
        where("followingUid", "==", id),
        where("status", "==", "pending"),
        limit(50),
      ),
    ),
    notifications = useRows(
      query(
        collection(db, "notifications"),
        where("targetUid", "==", id),
        orderBy("createdAt", "desc"),
        limit(50),
      ),
    );
  const [notice, setNotice] = useState("");
  return (
    <Page>
      {!!notice && (
        <Text accessibilityRole="alert" style={styles.error}>
          {notice}
        </Text>
      )}
      {!!requests.rows.length && (
        <Text style={{ fontWeight: "700", fontSize: 16, color: c.text }}>
          Takip istekleri
        </Text>
      )}
      <State
        loading={requests.loading}
        error={requests.error}
        retry={requests.refresh}
      />
      {requests.rows.map((r) => (
        <RequestRow
          key={r.id}
          row={r}
          navigation={navigation}
          refresh={requests.refresh}
        />
      ))}
      <Text
        style={{ fontWeight: "700", fontSize: 16, color: c.text, marginTop: 8 }}
      >
        Bildirimler
      </Text>
      <State
        {...notifications}
        empty={!notifications.rows.length}
        retry={notifications.refresh}
      />
      {notifications.rows.map((r) => (
        <Pressable
          key={r.id}
          accessibilityRole="button"
          accessibilityLabel={r.text || "Bildirimi aç"}
          onPress={async () => {
            try {
              if (!r.read)
                await updateDoc(doc(db, "notifications", r.id), { read: true });
              if (r.postId)
                navigation.navigate("PostDetails", { id: r.postId });
              else if (r.actorUid || r.sourceUid)
                navigation.navigate("User", { uid: r.actorUid || r.sourceUid });
              notifications.refresh();
            } catch (e) {
              setNotice(friendly(e));
            }
          }}
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 12,
            paddingVertical: 10,
          }}
        >
          <View
            style={{
              width: 42,
              height: 42,
              borderRadius: 21,
              backgroundColor: r.read ? c.surface : "#eaf5ff",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Icon
              name="heart-outline"
              size={23}
              color={r.read ? c.text : c.accent}
            />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: c.text, fontSize: 14, lineHeight: 20 }}>
              {r.text}
            </Text>
            <Text style={{ color: c.muted, fontSize: 11, marginTop: 3 }}>
              {timeAgo(r.createdAt)}
            </Text>
          </View>
          {!r.read && (
            <View
              style={{
                width: 7,
                height: 7,
                borderRadius: 4,
                backgroundColor: c.accent,
              }}
            />
          )}
        </Pressable>
      ))}
    </Page>
  );
}
function RequestRow({
  row,
  navigation,
  refresh,
}: {
  row: Row;
  navigation: any;
  refresh: () => void;
}) {
  const person = usePerson(row.followerUid);
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 10,
        paddingVertical: 8,
      }}
    >
      <Pressable
        onPress={() => navigation.navigate("User", { uid: row.followerUid })}
      >
        <Avatar
          name={person?.username}
          mediaId={person?.avatarMediaId}
          size={42}
        />
      </Pressable>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 13, fontWeight: "600", color: c.text }}>
          {person?.username || "Yeni takip isteği"}
        </Text>
        <Text style={{ fontSize: 12, color: c.muted, marginTop: 2 }}>
          Seni takip etmek istiyor.
        </Text>
      </View>
      <Button
        title="Kabul et"
        onPress={async () => {
          await acceptFollow(row.id, true);
          refresh();
        }}
      />
      <Action
        name="close"
        label="Reddet"
        size={20}
        onPress={async () => {
          await acceptFollow(row.id, false);
          refresh();
        }}
      />
    </View>
  );
}

function OwnerActivation() {
  const user = auth.currentUser,
    [notice, setNotice] = useState("");
  if (user?.email?.toLowerCase() !== "ahmedberatazboy0@gmail.com") return null;
  return (
    <View style={styles.card}>
      <Label>Birarada resmî hesabı</Label>
      <Label muted>
        E-postanın doğrulanmış olması ve sunucuda hesap sahibi kurulumunun
        etkinleştirilmesi gerekir.
      </Label>
      <Button
        secondary
        title="Resmî hesap ve yönetim yetkisini etkinleştir"
        onPress={async () => {
          await user.reload();
          await user.getIdToken(true);
          await api("activateOwner", { acceptTerms: true });
          await user.getIdToken(true);
          setNotice("Resmî hesap ve yönetim yetkisi etkinleşti.");
        }}
      />
      {!!notice && <Label>{notice}</Label>}
    </View>
  );
}
