import React, { useState } from "react";
import { sendEmailVerification } from "firebase/auth";
import { auth } from "../firebase/client";
import { api } from "../services/api";
import { Text, View, Platform, Pressable } from "react-native";
import { Action, Icon } from "../components/social-ui";
import { colors as c } from "../constants/theme";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  Page,
  Label,
  Field,
  Button,
  CommunityAgreement,
  LegalLinks,
  DeleteAccountForm,
  styles,
} from "../components/ui";
import {
  register,
  login,
  resetPassword,
  googleLogin,
  createProfile,
  logout,
  deleteOwnAccount,
} from "../services/social";
export function AuthScreen() {
  const [step, setStep] = useState(0),
    [onboard, setOnboard] = useState(false),
    [mode, setMode] = useState<"login" | "register" | "reset">("login"),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [notice, setNotice] = useState(""),
    [accepted, setAccepted] = useState(false),
    [passwordVisible, setPasswordVisible] = useState(false);
  React.useEffect(() => {
    AsyncStorage.getItem("onboarded")
      .then((v) => setOnboard(v === "yes"))
      .catch(() => setOnboard(false));
  }, []);
  if (!onboard) {
    const copy = [
      [
        "Arkadaşlarını bul",
        "İlgi alanlarını paylaşan insanlarla tanış. Kendi çevrene bir adım daha yaklaş.",
      ],
      [
        "Anlarını paylaş",
        "Büyük olayları bekleme. Güzel bir gün, küçük bir anla başlar.",
      ],
      ["Birlikte daha fazlasını yaşa", "Yeni insanlarla, daha güzel anlara."],
    ][step]!;
    return (
      <Page>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text
            style={{
              color: c.text,
              fontSize: 30,
              fontWeight: "700",
              letterSpacing: -1.4,
            }}
          >
            birarada
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Tanıtımı atla"
            onPress={async () => {
              await AsyncStorage.setItem("onboarded", "yes");
              setOnboard(true);
            }}
          >
            <Text style={{ color: c.muted, fontSize: 13 }}>Atla</Text>
          </Pressable>
        </View>
        <View
          style={{
            height: 270,
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
          }}
        >
          <View
            style={{
              width: 180,
              height: 210,
              backgroundColor: c.surface,
              borderRadius: 22,
              borderWidth: 1,
              borderColor: c.line,
              transform: [{ rotate: "-8deg" }],
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Icon
              name={
                step === 0
                  ? "people-outline"
                  : step === 1
                    ? "images-outline"
                    : "chatbubbles-outline"
              }
              size={85}
              color={c.text}
            />
          </View>
          <View
            style={{
              position: "absolute",
              bottom: 28,
              right: 35,
              width: 64,
              height: 64,
              borderRadius: 20,
              backgroundColor: "#fde9f0",
              alignItems: "center",
              justifyContent: "center",
              transform: [{ rotate: "10deg" }],
            }}
          >
            <Icon
              name={step === 1 ? "musical-notes" : "heart"}
              size={32}
              color="#d62976"
            />
          </View>
        </View>
        <Text style={[styles.title, { textAlign: "center", fontSize: 20 }]}>
          {copy[0]}
        </Text>
        <Label muted>{copy[1]}</Label>
        <Label muted>{step + 1} / 3</Label>
        <Button
          title={step < 2 ? "Devam et" : "Giriş yap"}
          onPress={async () => {
            if (step < 2) setStep(step + 1);
            else {
              await AsyncStorage.setItem("onboarded", "yes");
              setOnboard(true);
            }
          }}
        />
        {step === 2 && (
          <Button
            secondary
            title="Hesap oluştur"
            onPress={async () => {
              await AsyncStorage.setItem("onboarded", "yes");
              setMode("register");
              setOnboard(true);
            }}
          />
        )}
      </Page>
    );
  }
  return (
    <Page>
      <View style={{ height: 65 }} />
      <Text
        style={{
          color: c.text,
          fontSize: 45,
          fontWeight: "700",
          textAlign: "center",
          letterSpacing: -2,
        }}
      >
        birarada
      </Text>
      <View style={{ height: 18 }} />
      <Text style={styles.title}>
        {mode === "register"
          ? "Aramıza katıl."
          : mode === "reset"
            ? "Yeniden bağlan."
            : "İyi ki geldin."}
      </Text>
      <Text
        style={{
          color: c.muted,
          fontSize: 13,
          textAlign: "center",
          marginBottom: 12,
        }}
      >
        Arkadaşlarınla aynı yerde.
      </Text>
      <Field
        placeholder="E-posta"
        keyboardType="email-address"
        autoComplete="email"
        value={email}
        onChangeText={setEmail}
      />
      {mode !== "reset" && (
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: c.surface,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: c.line,
          }}
        >
          <Field
            style={{ flex: 1, borderWidth: 0 }}
            placeholder="Şifre"
            secureTextEntry={!passwordVisible}
            autoComplete={
              mode === "register" ? "new-password" : "current-password"
            }
            value={password}
            onChangeText={setPassword}
          />
          <Action
            name={passwordVisible ? "eye-off-outline" : "eye-outline"}
            label={passwordVisible ? "Şifreyi gizle" : "Şifreyi göster"}
            size={20}
            onPress={() => setPasswordVisible((v) => !v)}
          />
        </View>
      )}
      {mode === "register" && (
        <CommunityAgreement value={accepted} onChange={setAccepted} />
      )}
      <Button
        title={
          mode === "register"
            ? "Hesap oluştur"
            : mode === "reset"
              ? "Sıfırlama bağlantısı gönder"
              : "Giriş yap"
        }
        disabled={
          !email.trim() ||
          (mode !== "reset" && !password) ||
          (mode === "register" && (!accepted || password.length < 8))
        }
        onPress={async () => {
          setNotice("");
          if (mode === "register") await register(email, password);
          else if (mode === "reset") {
            await resetPassword(email);
            setNotice("E-posta kutunu kontrol et.");
          } else await login(email, password);
        }}
      />
      {!!notice && <Label>{notice}</Label>}
      {Platform.OS === "web" && mode !== "reset" && (
        <Button
          secondary
          title="Google ile devam et"
          disabled={mode === "register" && !accepted}
          onPress={googleLogin}
        />
      )}
      <Button
        secondary
        title={mode === "register" ? "Zaten hesabım var" : "Yeni hesap oluştur"}
        onPress={() => {
          setNotice("");
          setAccepted(false);
          setMode(mode === "register" ? "login" : "register");
        }}
      />
      {mode !== "reset" && (
        <Button
          secondary
          title="Şifremi unuttum"
          onPress={() => setMode("reset")}
        />
      )}
      <Label muted>Hesabın varsayılan olarak gizli. Konumun paylaşılmaz.</Label>
      {mode !== "register" && <LegalLinks />}
    </Page>
  );
}
export function CompleteProfile() {
  const [name, setName] = useState(""),
    [username, setUsername] = useState(""),
    [accepted, setAccepted] = useState(false),
    [deleting, setDeleting] = useState(false);
  return (
    <Page title="Seni tanıyalım.">
      <Label muted>Görünen adını ve benzersiz kullanıcı adını seç.</Label>
      <Field
        placeholder="Görünen ad"
        value={name}
        onChangeText={setName}
        maxLength={60}
      />
      <Field
        placeholder="Kullanıcı adı"
        value={username}
        onChangeText={(v) => setUsername(v.toLowerCase())}
        maxLength={24}
      />
      <Label muted>
        Kullanıcı adı 3–24 küçük harf, rakam veya alt çizgi içerebilir.
      </Label>
      <CommunityAgreement value={accepted} onChange={setAccepted} />
      <Button
        title="Birarada’ya katıl"
        disabled={
          name.trim().length < 2 ||
          !/^[a-z0-9_]{3,24}$/.test(username) ||
          !accepted
        }
        onPress={() => createProfile(username, name.trim())}
      />
      {auth.currentUser?.email?.toLowerCase() ===
        "ahmedberatazboy0@gmail.com" && (
        <View style={styles.card}>
          <Label>Birarada resmî hesabı</Label>
          <Button
            secondary
            title="Doğrulama e-postası gönder"
            onPress={async () => {
              if (auth.currentUser)
                await sendEmailVerification(auth.currentUser);
            }}
          />
          <Button
            title="Resmî hesabı oluştur"
            disabled={!accepted}
            onPress={async () => {
              const user = auth.currentUser;
              if (!user) return;
              await user.reload();
              await user.getIdToken(true);
              await api("activateOwner", { acceptTerms: true });
              await user.getIdToken(true);
            }}
          />
        </View>
      )}
      <Button secondary title="Çıkış yap" onPress={logout} />
      <Button
        secondary
        title="Hesabımı sil"
        onPress={() => setDeleting(!deleting)}
      />
      {deleting && (
        <DeleteAccountForm
          onDelete={deleteOwnAccount}
          onCancel={() => setDeleting(false)}
        />
      )}
    </Page>
  );
}
