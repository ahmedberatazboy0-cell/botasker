import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  ScrollView,
  Animated,
  Easing,
  View,
  Pressable,
  Text,
  useWindowDimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { newId } from "../services/api";
import { Sheet } from "../components/social-ui";
import { friendly } from "../utils/errors";
import { timeAgo } from "../utils/time";
import { useFocusEffect, useIsFocused } from "@react-navigation/native";
import { api } from "../services/api";
import { ProtectedMedia } from "../components/ProtectedMedia";
import {
  Page,
  Button,
  Field,
  Label,
  State,
  ReportForm,
  styles,
} from "../components/ui";
import { useApiList } from "../hooks/useApiList";
import { Avatar, Action, Icon } from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { usePerson } from "../hooks/usePerson";
import { useSession } from "../store/session";
import type { Row } from "../types";
export function StoriesRail({ navigation }: any) {
  const [rows, setRows] = useState<Row[]>([]),
    [after, setAfter] = useState<string | null>(null),
    [error, setError] = useState("");
  const load = useCallback(
    async (more = false) => {
      try {
        const result = await api("storyFeed", more ? { after } : {});
        setRows((old) => (more ? [...old, ...result.rows] : result.rows));
        setAfter(result.after);
        setError("");
      } catch (e) {
        setError((e as Error).message);
      }
    },
    [after],
  );
  useFocusEffect(
    useCallback(() => {
      void load(false);
    }, []),
  );
  const me = useSession((s) => s.profile)!;
  const unique = [...new Map(rows.map((row) => [row.uid, row])).values()];
  return (
    <View
      style={{
        paddingVertical: 12,
        borderBottomWidth: 0.5,
        borderBottomColor: c.line,
      }}
    >
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 14, gap: 16 }}
      >
        <Pressable
          onPress={() =>
            navigation.navigate("StoryComposer", { kind: "story" })
          }
          style={{ alignItems: "center", gap: 5, width: 72 }}
          accessibilityRole="button"
          accessibilityLabel="Hikâye ekle"
        >
          <Avatar name={me.username} mediaId={me.avatarMediaId} size={72} add />
          <Text style={{ color: c.muted, fontSize: 11, marginTop: 2 }}>
            Hikâyen
          </Text>
        </Pressable>
        {unique.map((row) => (
          <StoryBubble
            key={row.uid}
            row={row}
            open={() =>
              navigation.navigate("StoryViewer", { uid: row.uid, id: row.id })
            }
          />
        ))}
        {!!after && (
          <Action
            name="chevron-forward-circle-outline"
            label="Daha fazla kişi"
            onPress={() => load(true)}
          />
        )}
      </ScrollView>
      {!!error && (
        <Button
          secondary
          title="Hikâyeleri yeniden yükle"
          onPress={() => load(false)}
        />
      )}
    </View>
  );
}
function StoryBubble({ row, open }: { row: Row; open: () => void }) {
  const person = usePerson(row.uid);
  return (
    <Pressable
      onPress={open}
      style={{ alignItems: "center", gap: 5, width: 72 }}
      accessibilityRole="button"
      accessibilityLabel={`@${row.username} hikâyesi`}
    >
      <Avatar
        name={row.username}
        mediaId={person?.avatarMediaId}
        size={72}
        ring
      />
      <Text
        numberOfLines={1}
        style={{ fontSize: 11, color: c.text, maxWidth: 76 }}
      >
        {row.username}
      </Text>
    </Pressable>
  );
}

export function StoryViewer({ route, navigation }: any) {
  const me = useSession((s) => s.profile)!.uid,
    focused = useIsFocused();
  const data = useApiList("listContent", {
    kind: "story",
    uid: route.params.uid,
    ...(route.params.highlighted ? { highlighted: true } : {}),
    ...(route.params.archived ? { archived: true } : {}),
  });
  const [index, setIndex] = useState(0),
    [menu, setMenu] = useState(false),
    [reporting, setReporting] = useState(false),
    [title, setTitle] = useState("Öne çıkanlar"),
    [viewers, setViewers] = useState<Row[] | null>(null),
    [viewAfter, setViewAfter] = useState<string | null>(null),
    [notice, setNotice] = useState(""),
    [confirmDelete, setConfirmDelete] = useState(false),
    [held, setHeld] = useState(false),
    [reply, setReply] = useState("");
  const row = data.rows[index],
    person = usePerson(row?.uid),
    progress = useRef(new Animated.Value(0)).current,
    requested = useRef(false),
    replyRequest = useRef(newId()),
    fraction = useRef(0),
    advanceAfterPage = useRef(false);
  useEffect(() => {
    const id = progress.addListener(({ value }) => {
      fraction.current = value;
    });
    return () => progress.removeListener(id);
  }, [progress]);
  useEffect(() => {
    if (requested.current || !data.rows.length) return;
    const start = data.rows.findIndex((r) => r.id === route.params.id);
    if (start >= 0) setIndex(start);
    requested.current = true;
  }, [data.rows, route.params.id]);
  function next() {
    if (data.paging) return;
    if (index + 1 < data.rows.length) setIndex((i) => i + 1);
    else if (data.hasMore) {
      advanceAfterPage.current = true;
      void data.loadMore();
    } else navigation.goBack();
  }
  useEffect(() => {
    if (!advanceAfterPage.current || data.paging) return;
    if (data.error) {
      advanceAfterPage.current = false;
      return;
    }
    if (index + 1 < data.rows.length) {
      advanceAfterPage.current = false;
      setIndex((i) => i + 1);
    } else if (!data.hasMore) {
      advanceAfterPage.current = false;
      navigation.goBack();
    }
  }, [data.rows.length, data.paging, data.error, data.hasMore, index]);
  useEffect(() => {
    fraction.current = 0;
    progress.setValue(0);
    setViewers(null);
    setConfirmDelete(false);
    if (row && !route.params.highlighted && !route.params.archived)
      void api("storyView", { id: row.id }).catch((e) =>
        setNotice(friendly(e)),
      );
  }, [row?.id]);
  useEffect(() => {
    if (
      !row ||
      !focused ||
      held ||
      menu ||
      reporting ||
      viewers ||
      reply ||
      row.mediaItems?.[0]?.kind !== "image"
    )
      return;
    const animation = Animated.timing(progress, {
      toValue: 1,
      duration: Math.max(1, 8000 * (1 - fraction.current)),
      easing: Easing.linear,
      useNativeDriver: false,
    });
    animation.start(({ finished }) => {
      if (finished) next();
    });
    return () => animation.stop();
  }, [
    row?.id,
    focused,
    held,
    menu,
    reporting,
    viewers,
    reply,
    data.rows.length,
  ]);
  async function loadViewers(more = false) {
    const r = await api("storyViewers", {
      id: row!.id,
      ...(more ? { after: viewAfter } : {}),
    });
    setViewers((old) => (more ? [...(old || []), ...r.rows] : r.rows));
    setViewAfter(r.after);
  }
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#080808" }}>
      <StatusBar style="light" />
      <View
        style={{ flex: 1, maxWidth: 680, width: "100%", alignSelf: "center" }}
      >
        <View
          style={{
            flexDirection: "row",
            gap: 3,
            paddingHorizontal: 8,
            paddingTop: 8,
          }}
        >
          {data.rows.map((r, i) => (
            <View
              key={r.id}
              style={{
                flex: 1,
                height: 2,
                backgroundColor: "#ffffff40",
                overflow: "hidden",
                borderRadius: 2,
              }}
            >
              {i < index ? (
                <View
                  style={{ width: "100%", height: 2, backgroundColor: "#fff" }}
                />
              ) : i === index ? (
                <Animated.View
                  style={{
                    height: 2,
                    backgroundColor: "#fff",
                    width: progress.interpolate({
                      inputRange: [0, 1],
                      outputRange: ["0%", "100%"],
                    }),
                  }}
                />
              ) : null}
            </View>
          ))}
        </View>
        <View
          style={{
            height: 62,
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 12,
            gap: 9,
          }}
        >
          <Avatar
            name={row?.username}
            mediaId={person?.avatarMediaId}
            size={33}
          />
          <Pressable
            onPress={() => row && navigation.replace("User", { uid: row.uid })}
            style={{ flex: 1 }}
          >
            <Text style={{ color: "#fff", fontSize: 14, fontWeight: "600" }}>
              {row?.username || "Hikâyeler"}
            </Text>
            <Text style={{ color: "#ffffff90", fontSize: 11, marginTop: 2 }}>
              {timeAgo(row?.createdAt)}
            </Text>
          </Pressable>
          <Action
            name="ellipsis-horizontal"
            color="#fff"
            label="Hikâye seçenekleri"
            onPress={() => setMenu(true)}
          />
          <Action
            name="close"
            color="#fff"
            label="Hikâyeyi kapat"
            onPress={() => navigation.goBack()}
          />
        </View>
        <View
          style={{ flex: 1, justifyContent: "center", position: "relative" }}
        >
          {row?.mediaItems?.[0] && (
            <ProtectedMedia
              item={row.mediaItems[0]}
              active={
                focused && !held && !menu && !reporting && !viewers && !reply
              }
              loop={false}
              onEnd={next}
              style={{ width: "100%", height: "100%", borderRadius: 10 }}
            />
          )}
          {row?.mediaItems?.[0]?.kind === "image" && (
            <View
              style={{ position: "absolute", inset: 0, flexDirection: "row" }}
            >
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Önceki hikâye"
                style={{ width: "30%" }}
                onPress={() =>
                  index > 0 ? setIndex((i) => i - 1) : navigation.goBack()
                }
                onPressIn={() => setHeld(true)}
                onPressOut={() => setHeld(false)}
              />
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Sonraki hikâye"
                style={{ flex: 1 }}
                onPress={next}
                onPressIn={() => setHeld(true)}
                onPressOut={() => setHeld(false)}
              />
            </View>
          )}
          {!!row?.caption && (
            <View
              pointerEvents="none"
              style={{
                position: "absolute",
                bottom: 22,
                left: 18,
                right: 18,
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  textAlign: "center",
                  fontSize: 15,
                  lineHeight: 22,
                  textShadowColor: "#000",
                  textShadowRadius: 4,
                  textShadowOffset: { width: 0, height: 1 },
                }}
              >
                {row.caption}
              </Text>
            </View>
          )}
          {(data.loading || data.error || !row) && (
            <View
              style={{ backgroundColor: c.bg, borderRadius: 12, margin: 20 }}
            >
              <State {...data} empty={!row} retry={data.refresh} />
            </View>
          )}
        </View>
        {!!notice && (
          <Text
            accessibilityRole="alert"
            style={{ color: "#ffb4b4", padding: 12, fontSize: 12 }}
          >
            {notice}
          </Text>
        )}
        <View
          style={{
            padding: 12,
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
          }}
        >
          {row?.uid === me ? (
            <>
              <Text style={{ color: "#ffffffa0", fontSize: 12, flex: 1 }}>
                Hikâyen ·{" "}
                {route.params.archived
                  ? "Arşiv"
                  : route.params.highlighted
                    ? "Öne çıkan"
                    : "24 saat"}
              </Text>
              <Action
                name="eye-outline"
                color="#fff"
                label="Görüntüleyenler"
                onPress={() => loadViewers()}
              />
            </>
          ) : (
            <>
              <Field
                placeholder="Mesaj gönder…"
                value={reply}
                onChangeText={setReply}
                maxLength={2000}
                style={{
                  flex: 1,
                  backgroundColor: "transparent",
                  borderColor: "#ffffff80",
                  borderRadius: 24,
                  color: "#fff",
                }}
              />
              <Action
                name="paper-plane-outline"
                color="#fff"
                label="Hikâyeye yanıt gönder"
                disabled={!reply.trim() || !row}
                onPress={async () => {
                  const chat = await api("createChat", { members: [row!.uid] });
                  await api("sendMessage", {
                    chatId: chat.id,
                    requestId: replyRequest.current,
                    text: reply,
                    mediaIds: [],
                  });
                  setReply("");
                  replyRequest.current = newId();
                  setNotice("Yanıtın gönderildi.");
                }}
              />
            </>
          )}
        </View>
      </View>
      <Sheet
        visible={menu}
        title="Hikâye seçenekleri"
        onClose={() => setMenu(false)}
      >
        {row?.uid === me ? (
          <>
            <Field
              placeholder="Öne çıkan başlığı"
              value={title}
              onChangeText={setTitle}
              maxLength={30}
            />
            <Button
              secondary
              title={
                row.highlighted
                  ? "Öne çıkanlardan kaldır"
                  : "Öne çıkanlara ekle"
              }
              onPress={async () => {
                await api("highlightStory", {
                  id: row.id,
                  enabled: !row.highlighted,
                  title,
                });
                data.refresh();
                setMenu(false);
              }}
            />
            <Button
              secondary
              title="Hikâyeyi sil"
              onPress={() => setConfirmDelete(true)}
            />
            {confirmDelete && (
              <>
                <Label>Hikâyeyi kalıcı olarak silmek istiyor musun?</Label>
                <Button
                  title="Evet, sil"
                  onPress={async () => {
                    await api("deleteContent", { kind: "story", id: row.id });
                    navigation.goBack();
                  }}
                />
                <Button
                  secondary
                  title="Vazgeç"
                  onPress={() => setConfirmDelete(false)}
                />
              </>
            )}
          </>
        ) : (
          <Button
            secondary
            title="Şikâyet et"
            onPress={() => {
              setMenu(false);
              setReporting(true);
            }}
          />
        )}
      </Sheet>
      <Sheet
        visible={viewers !== null}
        title="Görüntüleyenler"
        onClose={() => setViewers(null)}
      >
        {viewers?.length === 0 && <Label muted>Henüz görüntüleyen yok.</Label>}
        {viewers?.map((v) => (
          <View
            key={v.id}
            style={{
              flexDirection: "row",
              gap: 10,
              alignItems: "center",
              paddingVertical: 8,
            }}
          >
            <Avatar name={v.username} size={36} />
            <Label>{v.username}</Label>
          </View>
        ))}
        {!!viewAfter && (
          <Button
            secondary
            title="Diğer izleyenler"
            onPress={() => loadViewers(true)}
          />
        )}
      </Sheet>
      <Sheet
        visible={reporting}
        title="Şikâyet et"
        onClose={() => setReporting(false)}
      >
        <ReportForm
          onSubmit={async (reason) => {
            await api("reportContent", { kind: "story", id: row!.id, reason });
            setReporting(false);
            setNotice("Şikâyetin alındı.");
          }}
          onCancel={() => setReporting(false)}
        />
      </Sheet>
    </SafeAreaView>
  );
}
