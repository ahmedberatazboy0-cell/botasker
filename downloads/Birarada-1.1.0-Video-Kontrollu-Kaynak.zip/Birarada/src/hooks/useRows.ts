import { useEffect, useState, useCallback, useRef } from "react";
import {
  onSnapshot,
  Query,
  DocumentData,
  queryEqual,
} from "../database/client";
import { useIsFocused } from "@react-navigation/native";
import { friendly } from "../utils/errors";
import type { Row } from "../types";
export function useRows(q: Query<DocumentData> | null) {
  const focused = useIsFocused();
  const stable = useRef(q);
  if (
    !stable.current !== !q ||
    (stable.current && q && !queryEqual(stable.current, q))
  )
    stable.current = q;
  const [rows, setRows] = useState<Row[]>([]),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [retry, setRetry] = useState(0),
    [offline, setOffline] = useState(false);
  useEffect(() => {
    const target = stable.current;
    if (!focused) return;
    if (!target) {
      setRows([]);
      setLoading(false);
      return;
    }
    setRows([]);
    setLoading(true);
    setError("");
    return onSnapshot(
      target,
      { includeMetadataChanges: true },
      (snap) => {
        setRows(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        setOffline(snap.metadata.fromCache);
        setLoading(false);
      },
      (e) => {
        setError(friendly(e));
        setLoading(false);
      },
    );
  }, [stable.current, retry, focused]);
  return {
    rows,
    loading,
    error,
    offline,
    refresh: useCallback(() => setRetry((n) => n + 1), []),
  };
}
