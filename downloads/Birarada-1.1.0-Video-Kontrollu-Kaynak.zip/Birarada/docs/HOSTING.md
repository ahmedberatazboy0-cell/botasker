# Güncel yasal sayfaların yayını

Ücretsiz sürüm Firebase Authentication ve Supabase PostgreSQL/Storage/Edge kullanır. Onay sürümü `2026-10-21-free1`. Dört güncel adres: https://birarada-5650c.web.app/privacy, /delete-account, /terms ve /child-safety.

Uygulama klasöründe bağımlılıklar kuruluysa:

```cmd
node YASAL_YAYINLA.cjs
npm run release:live
```

Yardımcı mevcut resmî Firebase CLI oturumundan ahmedberatazboy0@gmail.com hesabını kullanır. Gerekirse resmî Google girişi açılır. Parola veya token kaynaklara yazılmaz. Ücretli plan, Supabase verisi ve Android imzası değiştirilmez.

Mevcut canlı sürümün tüm dosya yolları/hashleri ve Hosting config'i okunur. Yeni sürüme tam dosya manifesti ile yalnız dört yasal sayfanın güncel içerikleri eklenir; mevcut ana sayfa, diğer dosyalar ve ilgili olmayan yönlendirmeler korunur. Paylaşılan CSS dosyası değiştirilmez; yasal CSS ayrı bir yolda bulunur. Tam manifest korunmadan canlıya geçilmez.

Önce 24 saatlik önizleme kanalında dört HTML ve CSS birebir doğrulanır. Canlı site eşzamanlı değiştirilmişse yayın durur. Canlı yayından sonra doğrulama başarısızsa ve hâlâ yardımcının sürümü etkinse önceki sürüme dönülür. Başkasının yeni yayını geri alınmaz. Mevcut config/hash/sürüm yedeği `.birarada-legal-*` klasörüne kaydedilir. Aynı yardımcı güvenli yönlendirmeleri izleyen güncel canlı kontrolünü de kurar; eski kontrolün birebir yedeğini saklar ve özel değiştirilmiş kontrolü üzerine yazmaz.

`YASAL_SAYFALAR_HAZIR` ve `npm run release:live` başarısından sonra `npm run build:no-github` ile AAB üretilebilir. Kaynak Firebase config'i ile yalnız küçük legal klasörünü doğrudan Hosting'e dağıtmak mevcut site dosyalarını kaldırabilir; bunun yerine tam manifesti koruyan yardımcı kullanılır.

Bu bulut ortamında Google/Firebase ağı ve hesap oturumu bulunmadığından gerçek canlı yayın yapılmadı. Yardımcı yerel sahte API ile 15 senaryoda doğrulandı; gerçek servis doğrulaması çalıştırıldığı bilgisayarda yapılır. Yayın sonrasında Play Console beyanları ve cihaz kontrolleri ayrıca tamamlanmalıdır.

İlk önizleme yanıtı henüz yayılmamış olabileceği için her sayfa için en fazla altı kontrol yapılır; aralarda toplam41 saniye beklenir. Yanlış içerik veya MIME yine reddedilir. Önizleme adresi kontrol başlamadan yazılır ve son HTTP durumu, byte sayısı ve beklenen/alınan SHA-256 yedek JSON içine kaydedilir. HTML veya kimlik bilgisi hata çıktısına dökülmez. Kullanıcının ilk önizleme hatasında bu ayrıntılar bulunmadığından kesin kök neden henüz doğrulanmamıştır.
