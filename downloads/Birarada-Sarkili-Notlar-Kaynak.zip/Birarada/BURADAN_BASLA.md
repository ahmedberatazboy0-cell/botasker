# Birarada — şarkılı notlar eklenmiş kaynak kodu

Bu arşiv imzalı AAB içermez ve Play Console'a doğrudan yüklenmez. Yayına hazır uygulama onayı değildir. Ana uygulama mobile klasöründeki Expo projesidir. downloads içindeki eski HTML yalnız ayrı bir demodur; mobil uygulama değildir ve yeni not özelliğini içermez.

Notlara şarkı adı ve Spotify/YouTube bağlantısı ekleme, 24 saatlik görünürlük, takipçi erişimi, engelleme, şikâyet ve silme eklendi. Ana Sayfa → Notlar · Şarkını paylaş veya Profil → Notum ve şarkım yolunu kullanın. Şarkı ilgili serviste açılır.

Windows'ta Node.js LTS, Java 21 ve Chrome/Edge kurulu bilgisayarda AAB_OLUSTUR.bat dosyasını çalıştırın. Araç gerçek testleri çalıştırır; başarılı olursa resmî Expo hesabı girişini ve EAS AAB derlemesini başlatır. Hata veren testler atlanmaz. GitHub kurulumu gerekmez.

17 birim, 6 yayın ayarı ve 4 arayüz testi geçti; web/Android/iOS JS-Hermes paketlemesi başarılı. Arayüzdeki not kayıtları simüle edilmiştir. 40 Firestore güvenlik testi ağ engeli nedeniyle çalıştırılmadı. Canlı Firebase/yasal sayfa kurulumu, gerçek cihaz doğrulaması ve imzalı AAB tamamlanmadı. Ayrıntılar mobile/TEST_REPORT.md, mobile/docs/NOTLAR.md ve mobile/docs/PLAY_STORE_RELEASE.md dosyalarındadır.
