import React, { useEffect, useState } from "react";
import {
  ScrollView,
  FlatList,
  Pressable,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import { Avatar, Icon, Segments } from "../components/social-ui";
import { colors as c } from "../constants/theme";
import { useApiList } from "../hooks/useApiList";
import { api, cachedApi } from "../services/api";
import { ProtectedMedia } from "../components/ProtectedMedia";
import { Page, Button, Field, Label, State, styles } from "../components/ui";
import { PostCard } from "../components/PostCard";
import type { Row, Post } from "../types";
function PostTile({
  row,
  width,
  open,
}: {
  row: Row;
  width: number;
  open: (row: Row) => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`@${row.username}: ${row.caption}`}
      onPress={() => open(row)}
      style={{
        width,
        height: (width * 4) / 3,
        backgroundColor: c.surface,
        overflow: "hidden",
      }}
    >
      {row.mediaItems?.[0]?.kind === "image" ? (
        <ProtectedMedia
          item={row.mediaItems[0]}
          style={{ width, height: (width * 4) / 3 }}
        />
      ) : (
        <View style={{ padding: 8, justifyContent: "center", flex: 1 }}>
          <Label>
            {row.kind === "reel"
              ? "▷ Reels"
              : row.mediaItems?.length
                ? "▷ Video"
                : row.caption}
          </Label>
        </View>
      )}
      {(row.mediaItems?.length > 1 ||
        row.mediaItems?.[0]?.kind === "video") && (
        <View style={{ position: "absolute", right: 6, top: 6 }}>
          <Icon
            name={row.mediaItems?.length > 1 ? "copy" : "play"}
            color="#fff"
            size={19}
          />
        </View>
      )}
    </Pressable>
  );
}
export function PostGrid({
  rows,
  open,
}: {
  rows: Row[];
  open: (row: Row) => void;
}) {
  const [container, setContainer] = useState(
    Math.min(useWindowDimensions().width, 680),
  );
  return (
    <View
      onLayout={(e) => setContainer(e.nativeEvent.layout.width)}
      style={{ flexDirection: "row", flexWrap: "wrap", gap: 2, width: "100%" }}
    >
      {rows.map((row) => (
        <PostTile
          key={row.id}
          row={row}
          width={(container - 4) / 3}
          open={open}
        />
      ))}
    </View>
  );
}
export function Explore({ navigation }: any) {
  const [search, setSearch] = useState(""),
    [term, setTerm] = useState(""),
    [mode, setMode] = useState("posts"),
    [users, setUsers] = useState<Row[]>([]),
    [userError, setUserError] = useState(""),
    [after, setAfter] = useState<string | null>(null),
    [userLoading, setUserLoading] = useState(false),
    [width, setWidth] = useState(Math.min(useWindowDimensions().width, 680));
  const request = React.useRef(0);
  useEffect(() => {
    const timer = setTimeout(() => setTerm(search.trim()), 300);
    return () => clearTimeout(timer);
  }, [search]);
  const content = useApiList(
    "listContent",
    {
      kind: mode === "reels" ? "reel" : "post",
      search: term.replace(/^#/, ""),
    },
    { enabled: mode !== "users", pollInterval: 15000 },
  );
  async function loadUsers(more = false) {
    const current = ++request.current;
    setUserLoading(true);
    try {
      const r = await api(
        "searchUsers",
        {
          search: term.replace(/^@/, ""),
          ...(more ? { after } : {}),
        },
        { maxAgeMs: more ? 0 : 5000 },
      );
      if (request.current !== current) return;
      setUsers((old) =>
        more
          ? [...new Map([...old, ...r.rows].map((r) => [r.id, r])).values()]
          : r.rows,
      );
      setAfter(r.after);
      setUserError("");
    } catch (e) {
      if (request.current === current) {
        setUserError((e as Error).message);
        setUsers([]);
      }
    } finally {
      if (request.current === current) setUserLoading(false);
    }
  }
  useEffect(() => {
    setUsers([]);
    setAfter(null);
    if (mode === "users") void loadUsers();
    return () => {
      request.current++;
    };
  }, [term, mode]);
  const accounts = mode === "users";
  return (
    <Page scroll={false}>
      <FlatList
        key={accounts ? "accounts" : "grid"}
        testID="explore-grid"
        onLayout={(event) => setWidth(event.nativeEvent.layout.width)}
        data={accounts ? users : content.rows}
        keyExtractor={(row) => row.id}
        numColumns={accounts ? 1 : 3}
        columnWrapperStyle={accounts ? undefined : { gap: 2, marginBottom: 2 }}
        initialNumToRender={9}
        maxToRenderPerBatch={6}
        windowSize={5}
        showsVerticalScrollIndicator={false}
        refreshing={accounts ? userLoading : content.refreshing}
        onRefresh={accounts ? () => loadUsers() : content.refresh}
        ListHeaderComponent={
          <View style={{ padding: 12, gap: 12 }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                backgroundColor: c.surface,
                borderRadius: 12,
                paddingLeft: 12,
              }}
            >
              <Icon name="search-outline" size={19} color={c.muted} />
              <Field
                placeholder="Kullanıcı, kelime veya #etiket ara"
                value={search}
                onChangeText={setSearch}
                maxLength={100}
                style={{
                  flex: 1,
                  borderWidth: 0,
                  backgroundColor: "transparent",
                }}
              />
            </View>
            <Segments
              value={mode}
              onChange={setMode}
              items={[
                { value: "posts", label: "Gönderiler" },
                { value: "users", label: "Hesaplar" },
                { value: "reels", label: "Reels" },
              ]}
            />
          </View>
        }
        ListEmptyComponent={
          <State
            loading={accounts ? userLoading : content.loading}
            error={accounts ? userError : content.error}
            empty
            retry={accounts ? () => loadUsers() : content.refresh}
          />
        }
        ListFooterComponent={
          accounts ? (
            after ? (
              <Button
                secondary
                title="Daha fazla hesap"
                onPress={() => loadUsers(true)}
              />
            ) : null
          ) : content.hasMore ? (
            <Button
              secondary
              title="Daha fazla paylaşım"
              onPress={content.loadMore}
            />
          ) : content.error && content.rows.length ? (
            <Button secondary title="Tekrar dene" onPress={content.retry} />
          ) : null
        }
        renderItem={({ item: user }) =>
          accounts ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={`@${user.username} hesabını aç`}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                paddingHorizontal: 16,
                paddingVertical: 10,
              }}
              onPress={() => navigation.navigate("User", { uid: user.id })}
            >
              <Avatar
                name={user.displayName || user.username}
                mediaId={user.avatarMediaId}
                size={48}
              />
              <View>
                <Text
                  style={{ fontSize: 14, fontWeight: "600", color: c.text }}
                >
                  {user.username} {user.official ? "✓" : ""}
                </Text>
                <Text style={{ fontSize: 13, color: c.muted, marginTop: 3 }}>
                  {user.displayName}
                </Text>
              </View>
            </Pressable>
          ) : (
            <PostTile
              row={user}
              width={(width - 4) / 3}
              open={(row) => navigation.navigate("PostDetails", { id: row.id })}
            />
          )
        }
      />
    </Page>
  );
}
export function PostDetails({ route, navigation }: any) {
  const [post, setPost] = useState<Post | null>(
      () => cachedApi<Post>("getContent", { id: route.params.id }) || null,
    ),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [version, setVersion] = useState(0);
  useEffect(() => {
    let alive = true;
    const warm = cachedApi<Post>("getContent", { id: route.params.id });
    setLoading(!warm);
    setError("");
    setPost(warm || null);
    api<Post>("getContent", { id: route.params.id })
      .then((row) => {
        if (alive) setPost(row);
      })
      .catch((e) => {
        if (alive) {
          setError(e.message);
          if (["permission-denied", "unauthenticated"].includes(e?.code))
            setPost(null);
        }
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [route.params.id, version]);
  return (
    <Page scroll={false}>
      <ScrollView testID="post-details">
        <State
          loading={loading}
          error={error}
          empty={!post && !loading}
          retry={() => setVersion((v) => v + 1)}
        />
        {post && (
          <PostCard
            post={post}
            openProfile={(uid) => navigation.push("User", { uid })}
          />
        )}
      </ScrollView>
    </Page>
  );
}
