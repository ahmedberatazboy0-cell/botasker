# Birarada 1.1.6 — tek akış, açık hesap ve hız düzeltmeleri

Yeni hesaplar **herkese açık** başlar. Kullanıcı profili düzenleyerek gizli hesaba geçebilir; mevcut gizli hesaplar ve eski özel gönderiler otomatik açılmaz. Ana sayfada yalnız Keşfet akışı bulunur. Gizli hesaptan paylaşım yapıldığında kendi profiline dönülür.

Keşfet üç sütunlu ve yalnız ekran çevresindeki kutucukları oluşturan bir liste kullanır. Ana sayfa ve Keşfet aynı boş arama sonucunu paylaşır. Beş saniyeden yeni veriler hızlı sayfa dönüşünde tekrar indirilmez; elle yenileme, yazımlar ve düzenli sunucu sorguları bu beklemeyi atlar. Bellek oturuma özeldir; çıkışta temizlenir. Bildirim listesi tarih grupları ve hesap fotoğraflarıyla gösterilir; kurulum/deneme araçları “Bildirim ayarları” içindedir. Android alt çubuk sistem gezinme boşluğunu dikkate alır.

Hikâye sunucusu takip edilen hesapları tek tek sırayla beklemek yerine en fazla dört sorguyla paralel okur; görünürlük izinlerini tek toplu okumayla hazırlar. Sunucu profil/hesap durumu/ayar okumalarını da birleştirir. Rol, engel, gizlilik ve hesap kısıtlaması her sunucu isteğinde yeniden denetlenir. Ayrıntılı sonuçlar [TEST_REPORT.md](TEST_REPORT.md).

## Güncelleme

ZIP'in tamamını yeni klasöre çıkar. **GUNCELLE_VE_AAB.bat** çalıştır. Aynı klasörde iki kurulum/derleme penceresini birlikte çalıştırma. Node.js 22/24 LTS ve Chrome veya Edge gerekir. Yardımcı, mevcut Supabase sunucusunu günceller, gizlilik sayfasını mevcut Hosting sitesini koruyarak yayımlar, test ve canlı kontrolleri geçerse mevcut Expo projesinde AAB derler.

CMD karşılığı:

```bat
npm run backend:update
npm run legal:deploy
npm run build:no-github
```

Paket **com.birarada.app**, kaynak adayı **1.1.6 / versionCode 8**. Bu kod Play Console'dan doğrulanmış en yüksek kod değildir; yeni AAB öncesi tüm kanallardaki en yüksek kodla karşılaştırılmalıdır. Kaynak bu sohbetteki 1.1.4 temelinden geliştirilmiştir; diğer sohbetin yerel değişiklikleri alınmış sayılmaz. Mevcut EAS **@ahmedberat/birarada / 9c50fe74-fec2-4f09-b4b2-c1711f4e9b6b** ve upload keystore korunur. Yeni proje/imza oluşturma.

Firebase Authentication/Hosting **birarada-5650c**, Supabase **qinevhhhdtslnzrtcanq** korunur. Gerekli yeni Edge revizyonu **2026-11-08-public1**. Veritabanı migration'ı ve Blaze planı gerekmez. Güncel gizlilik sayfasında `birarada-account-default` meta verisi `public` olmalıdır; canlı kontrol eski “varsayılan gizli” sayfasıyla üretim derlemesini durdurur.

## Test ve bildirim

**WEB_TEST.bat** veya `npm run web:local`: http://localhost:8081. Bu modun hesapları/medyası yalnız yereldir. Otomatik testler canlı kullanıcılara paylaşım veya mesaj göndermez.

**BILDIRIM_KUR.bat** mevcut Expo projesinin resmî FCM v1 kurulumunu açar. Özel anahtarlar kaynaklara veya sohbete eklenmez. Bildirimler → Bildirim ayarları bölümünden telefon izni, deneme gönderimi ve bağlantı durumu kontrol edilir. SMS hizmeti bağlı değildir; uygulama içi sorgu aralığı 3 saniyedir ve anlık fiziksel teslim garantisi değildir. [Telefon kurulumu](docs/HIZ_VE_BILDIRIM.md).

**Bu paket kaynak kodudur. Bu bulut oturumunda yeni imzalı AAB, canlı dağıtım veya fiziksel Android/FCM teslim testi yapılmadı.** Remote Desktop Commander PC tarafında çevrimiçi görünse de bu sohbetin kumanda araçları mevcut değildi. Yerel süreler telefonun açılış süresi değildir. Son AAB'nin mevcut imzası, sürüm kodu, hedef API ve 16 KB uyumluluğu ayrıca doğrulanmalıdır.
